/* =====================================================================
   GRAND THEFT ACHOO: GTA 네온 하버 — ONLINE
   game.js = [1] 온라인 모듈(로비 · WebSocket · 채팅 · 접속자 목록)
           + [2] 기존 게임(bootNeonHarbor) — 원작 코드에 멀티플레이 훅만 추가
   서버 주소는 index.html 의 window.NEON_MP_CONFIG.server 에서 설정합니다.
   ===================================================================== */
(function(){
'use strict';
const $=id=>document.getElementById(id);
const store=(s)=>({get(k,d){try{const v=s.getItem(k);return v===null?d:v;}catch(e){return d;}},set(k,v){try{s.setItem(k,v);}catch(e){}}});
const LS=store(window.localStorage),SS=store(window.sessionStorage);
const CODE_RE=/^[A-HJ-NP-Z2-9]{6}$/;
const params=new URLSearchParams(location.search);

// ---------- 서버 주소 ----------
function serverBase(){
  const q=params.get('server');if(q)return q.replace(/\/+$/,'');
  const saved=LS.get('nh.server','');if(saved)return saved.replace(/\/+$/,'');
  const cfg=String((window.NEON_MP_CONFIG||{}).server||'');
  if(cfg&&!/YOUR-SUBDOMAIN/i.test(cfg))return cfg.replace(/\/+$/,'');
  // `wrangler pages dev` (port 8788) + `wrangler dev` (8787) for the two-project setup
  if((location.hostname==='localhost'||location.hostname==='127.0.0.1')&&location.port==='8788')return location.protocol+'//'+location.hostname+':8787';
  // otherwise the game and the server share one address (all-in-one Worker)
  return /^https?:$/.test(location.protocol)?location.origin:'';
}
const wsBase=b=>b.replace(/^http(s?):\/\//i,(m,s)=>'ws'+s+'://');

// 탭마다 다른 플레이어 ID (새로고침해도 유지 → 서버가 점수를 이어 줌)
let PID=SS.get('nh.pid','');
if(!/^[a-z0-9]{8,24}$/.test(PID)){PID=Array.from(crypto.getRandomValues(new Uint8Array(12)),b=>(b%36).toString(36)).join('');SS.set('nh.pid',PID);}

// ---------- 공개 API (게임 쪽에서 사용) ----------
const NET={
  me:null,room:null,seed:0,offline:false,booted:false,connected:false,
  players:new Map(),   // id → {id,name,color,kills,deaths,host,state}
  offset:0,rtt:0,
  _h:{},
  on(t,fn){(this._h[t]||(this._h[t]=[])).push(fn);},
  emit(t,m){const L=this._h[t];if(!L)return;for(const f of L){try{f(m);}catch(e){console.error('[net]',t,e);}}},
  send(o){if(ws&&ws.readyState===1){ws.send(JSON.stringify(o));return true;}return false;},
  pvp(){return !this.offline&&!!(this.room&&this.room.pvp);},
  worldTod(rate){
    const r=this.room;if(!r)return null;
    const now=Date.now()+this.offset;
    return ((r.tod0+(now-r.t0)/1000*rate)%24+24)%24;
  },
  chatActive(){return chatOpen;},
  openChat(onClose){openChat(onClose);},
  togglePlayers(){$('mpPlayers').classList.toggle('expanded');renderPlayers();},
  sys(text){addLine({sys:true,text});},
  updateMe(st){if(this.me){const p=this.players.get(this.me.id);if(p)p.state=st;}schedulePlayers();}
};
window.NH_NET=NET;

// ---------- 로비 ----------
let ws=null,pendingCode=null,retry=0,retryT=null,pingT=null,pingAt=0,closedByUs=false;
const lb={name:$('lbName'),code:$('lbCode'),pvp:$('lbPvp'),max:$('lbMax'),status:$('lbStatus'),server:$('lbServer'),create:$('lbCreate'),join:$('lbJoin')};
lb.name.value=LS.get('nh.name','');
lb.server.value=serverBase();
const qRoom=(params.get('room')||'').toUpperCase();
if(CODE_RE.test(qRoom)){lb.code.value=qRoom;setTimeout(()=>(lb.name.value?lb.join:lb.name).focus(),50);}
else setTimeout(()=>lb.name.focus(),50);
if(window.matchMedia&&matchMedia('(pointer: coarse)').matches)$('game').classList.add('coarse');

function status(msg,kind){lb.status.textContent=msg||'';lb.status.className='lobbyStatus'+(kind?' '+kind:'');}
function busy(on){for(const b of [lb.create,lb.join])b.disabled=on;}
function needName(){
  const n=lb.name.value.trim();
  if(!n){status('닉네임을 먼저 입력해 주세요.','err');lb.name.focus();return null;}
  LS.set('nh.name',n);return n;
}
function base(){
  const v=lb.server.value.trim().replace(/\/+$/,'');
  if(v&&v!==serverBase())LS.set('nh.server',v);
  if(!v){status('멀티플레이 서버 주소가 설정되지 않았어요. 아래 "서버 설정"에 Worker 주소를 넣어 주세요.','err');$('lbAdv').open=true;lb.server.focus();return null;}
  if(!/^https?:\/\//i.test(v)){status('서버 주소는 https:// 로 시작해야 해요.','err');$('lbAdv').open=true;return null;}
  return v;
}
lb.code.addEventListener('input',()=>{const p=lb.code.selectionStart;lb.code.value=lb.code.value.toUpperCase().replace(/[^A-Z0-9]/g,'').slice(0,6);try{lb.code.setSelectionRange(p,p);}catch(e){}});
lb.code.addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();lb.join.click();}});
lb.name.addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();(CODE_RE.test(lb.code.value)?lb.join:lb.create).click();}});

lb.create.addEventListener('click',async()=>{
  const n=needName(),b=n&&base();if(!b)return;
  busy(true);status('방을 만드는 중…');
  try{
    const r=await fetch(b+'/api/rooms',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({pvp:lb.pvp.checked,maxPlayers:+lb.max.value})});
    if(!r.ok)throw new Error('HTTP '+r.status);
    const d=await r.json();
    connect(d.code);
  }catch(e){busy(false);status('서버에 연결할 수 없어요 ('+e.message+'). 서버 주소와 배포 상태를 확인해 주세요.','err');}
});
lb.join.addEventListener('click',async()=>{
  const n=needName();if(!n)return;
  const code=lb.code.value.trim().toUpperCase();
  if(!CODE_RE.test(code)){status('방 코드는 영문 대문자와 숫자 6자리예요. (0, O, 1, I는 쓰지 않아요)','err');lb.code.focus();return;}
  const b=base();if(!b)return;
  busy(true);status('방 '+code+'을(를) 찾는 중…');
  try{
    const r=await fetch(b+'/api/rooms/'+code);
    if(r.status===404){busy(false);status('방 '+code+'이(가) 없어요. 코드를 다시 확인해 주세요.','err');return;}
    if(!r.ok)throw new Error('HTTP '+r.status);
    const d=await r.json();
    if(d.players>=d.max){busy(false);status('방이 가득 찼어요 ('+d.players+'/'+d.max+').','err');return;}
    connect(code);
  }catch(e){busy(false);status('서버에 연결할 수 없어요 ('+e.message+').','err');}
});
// 온라인 전용: 방에 들어가야만 게임이 시작됩니다.

// ---------- WebSocket ----------
function connect(code){
  pendingCode=code;closedByUs=false;
  const b=base();if(!b)return;
  const url=wsBase(b)+'/ws/'+code+'?name='+encodeURIComponent(LS.get('nh.name',''))+'&pid='+PID;
  let s;
  try{s=new WebSocket(url);}catch(e){status('WebSocket을 열 수 없어요: '+e.message,'err');busy(false);return;}
  ws=s;
  if(!NET.booted)status('방 '+code+'에 접속하는 중…');
  s.onopen=()=>{NET.connected=true;retry=0;startPing();};
  s.onmessage=ev=>{
    if(ev.data==='pong'){NET.rtt=Math.round(performance.now()-pingAt);renderTag();return;}
    let m;try{m=JSON.parse(ev.data);}catch(e){return;}
    handle(m);
  };
  s.onclose=ev=>{
    if(ws!==s)return;
    NET.connected=false;stopPing();renderTag();
    if(ev.code===4001)return; // 다른 탭에서 같은 ID로 다시 접속
    if(!NET.booted){busy(false);if(!lb.status.classList.contains('err'))status('연결이 끊겼어요 (코드 '+ev.code+'). 다시 시도해 주세요.','err');return;}
    if(ev.code===4004||ev.code===4003){NET.sys(ev.code===4004?'방이 사라졌어요. 새로고침해서 새 방을 만들어 주세요.':'방이 가득 차서 다시 들어갈 수 없어요.');return;}
    if(closedByUs)return;
    const wait=Math.min(10000,1000*Math.pow(2,retry++));
    NET.sys('서버 연결이 끊겼어요. '+Math.round(wait/1000)+'초 뒤 다시 연결합니다…');
    clearTimeout(retryT);retryT=setTimeout(()=>connect(pendingCode),wait);
  };
}
function startPing(){stopPing();pingT=setInterval(()=>{if(ws&&ws.readyState===1){pingAt=performance.now();ws.send('ping');}},5000);setTimeout(()=>{if(ws&&ws.readyState===1){pingAt=performance.now();ws.send('ping');}},300);}
function stopPing(){clearInterval(pingT);pingT=null;}
addEventListener('beforeunload',()=>{closedByUs=true;try{ws&&ws.close(1000,'bye');}catch(e){}});

function handle(m){
  switch(m.t){
    case 'error':
      if(!NET.booted){busy(false);status(m.code==='ROOM_FULL'?'방이 가득 찼어요.':m.code==='NO_ROOM'?'방을 찾을 수 없어요.':'접속 실패: '+(m.message||m.code),'err');}
      else NET.sys('서버 오류: '+(m.message||m.code));
      return;
    case 'welcome':{
      const first=!NET.booted;
      NET.me=m.you;NET.room=m.room;NET.seed=m.room.seed;
      NET.offset=m.now-Date.now();
      NET.players.clear();
      for(const p of m.players)NET.players.set(p.id,p);
      if(first){
        $('mpChatLog').textContent='';
        for(const c of m.chat)addLine(c,true);
        try{const u=new URL(location.href);u.searchParams.set('room',m.room.code);history.replaceState(null,'',u);}catch(e){}
        boot();
      } else {NET.sys('다시 연결됐어요.');NET.emit('welcome',m);}
      renderPlayers();renderTag();
      return;}
    case 'join':NET.players.set(m.player.id,Object.assign({state:null},m.player));NET.emit('join',m);schedulePlayers();return;
    case 'leave':NET.players.delete(m.id);NET.emit('leave',m);schedulePlayers();return;
    case 'roster':{
      const old=NET.players;const next=new Map();
      for(const p of m.players){const o=old.get(p.id);next.set(p.id,Object.assign({state:o?o.state:null},p));}
      NET.players=next;
      if(NET.room){const was=NET.room.pvp;NET.room.pvp=m.pvp;NET.room.host=m.host;NET.room.max=m.max;if(was!==m.pvp)NET.emit('pvp',m.pvp);}
      if(NET.me&&next.has(NET.me.id))NET.me.name=next.get(NET.me.id).name;
      NET.emit('roster',m);renderPlayers();renderTag();return;}
    case 's':{const p=NET.players.get(m.id);if(p)p.state=m;NET.emit('s',m);schedulePlayers();return;}
    case 'chat':addLine(m);return;
    case 'notice':addLine({notice:true,text:m.text});return;
    case 'renamed':if(NET.me)NET.me.name=m.name;LS.set('nh.name',m.name);renderTag();return;
    default:NET.emit(m.t,m);
  }
}

// ---------- 게임 시작 ----------
function boot(){
  $('lobby').hidden=true;$('mpLoading').hidden=false;
  setTimeout(()=>{
    try{
      window.bootNeonHarbor(NET);
      NET.booted=true;
      $('mpLoading').hidden=true;
      $('start').hidden=false;$('startBtn').focus();
      $('mpHud').hidden=false;
      renderStartRoom();renderPlayers();renderTag();
      if(!NET.offline)NET.sys('Enter 또는 T: 채팅 · Tab: 접속자 목록 · /help: 명령어');
    }catch(e){
      console.error(e);$('mpLoading').hidden=true;$('lobby').hidden=false;busy(false);
      status('게임을 불러오지 못했어요: '+e.message,'err');
    }
  },40);
}
function inviteUrl(){const u=new URL(location.href);u.search='';u.hash='';u.searchParams.set('room',NET.room.code);const q=params.get('server');if(q)u.searchParams.set('server',q);return u.toString();}
function renderStartRoom(){
  const box=$('startRoom');
  if(NET.offline||!NET.room){box.hidden=true;return;}
  box.hidden=false;$('startCode').textContent=NET.room.code;
  $('startRoomMeta').textContent='PvP '+(NET.room.pvp?'켜짐':'꺼짐')+' · 최대 '+NET.room.max+'명 · '+NET.me.name+'(으)로 접속';
}
async function copy(text,btn){
  try{await navigator.clipboard.writeText(text);}catch(e){const t=document.createElement('textarea');t.value=text;document.body.appendChild(t);t.select();try{document.execCommand('copy');}catch(_){}t.remove();}
  const o=btn.textContent;btn.textContent='복사됨!';setTimeout(()=>btn.textContent=o,1400);
}
$('copyCode').addEventListener('click',e=>copy(NET.room.code,e.currentTarget));
$('copyLink').addEventListener('click',e=>copy(inviteUrl(),e.currentTarget));

// ---------- 채팅 ----------
let chatOpen=false,chatClose=null;
const chatEl=$('mpChat'),logEl=$('mpChatLog'),inEl=$('mpChatInput');
function addLine(m,history){
  const d=document.createElement('div');
  d.className='line'+(m.sys?' sys':'')+(m.notice?' notice':'');
  if(m.sys||m.notice)d.textContent=(m.notice?'· ':'')+m.text;
  else{
    const n=document.createElement('b');n.textContent=m.name||'?';n.style.color=m.color||'#fff';
    const t=document.createElement('span');t.textContent=m.text;
    d.append(n,t);
    if(NET.booted&&m.id&&m.id!==(NET.me&&NET.me.id))NET.emit('chatline',m);
  }
  d.dataset.ts=String(history?Date.now()-6000:Date.now());
  logEl.appendChild(d);
  while(logEl.children.length>80)logEl.firstChild.remove();
  logEl.scrollTop=logEl.scrollHeight;
}
setInterval(()=>{const now=Date.now();for(const d of logEl.children){if(now-(+d.dataset.ts)>12000)d.classList.add('old');}},1000);
function openChat(onClose){
  if(NET.offline){addLine({notice:true,text:'오프라인으로 하는 중이라 채팅을 보낼 수 없어요.'});return;}
  chatOpen=true;chatClose=onClose||null;
  chatEl.classList.add('open');inEl.hidden=false;inEl.value='';$('mpHud').classList.add('chatting');
  logEl.scrollTop=logEl.scrollHeight;
  setTimeout(()=>inEl.focus(),0);
}
function closeChat(){
  if(!chatOpen)return;chatOpen=false;
  chatEl.classList.remove('open');inEl.hidden=true;inEl.blur();$('mpHud').classList.remove('chatting');
  const f=chatClose;chatClose=null;if(f)setTimeout(f,0);
}
inEl.addEventListener('keydown',e=>{
  e.stopPropagation(); // 채팅 입력 중에는 게임 단축키가 작동하지 않게
  if(e.key==='Enter'&&!e.isComposing){
    e.preventDefault();
    const text=inEl.value.trim();
    if(text){if(!NET.send({t:'chat',text}))addLine({notice:true,text:'서버에 연결되어 있지 않아 보내지 못했어요.'});}
    closeChat();
  } else if(e.key==='Escape'){e.preventDefault();closeChat();}
});
inEl.addEventListener('keyup',e=>e.stopPropagation());
inEl.addEventListener('blur',()=>setTimeout(()=>{if(chatOpen&&document.activeElement!==inEl)closeChat();},0));

// ---------- 접속자 목록 ----------
let plT=null;
function schedulePlayers(){if(plT)return;plT=setTimeout(()=>{plT=null;renderPlayers();},400);}
function renderPlayers(){
  const el=$('mpPlayers');if(!el||!NET.me)return;
  const list=[...NET.players.values()].sort((a,b)=>(a.joinedAt||0)-(b.joinedAt||0));
  const max=NET.room?NET.room.max:1;
  const head=$('mpPlHead');head.textContent='';
  const c1=document.createElement('span');c1.textContent=NET.offline?'오프라인':'접속자 '+list.length+'/'+max;
  const c2=document.createElement('span');c2.className='x';c2.textContent=NET.room?' · '+NET.room.code+' · PvP '+(NET.room.pvp?'ON':'OFF'):'';
  head.append(c1,c2);
  const body=$('mpPlList');body.textContent='';
  for(const p of list){
    const row=document.createElement('div');row.className='pl'+(p.id===NET.me.id?' me':'');
    const dot=document.createElement('i');dot.style.background=p.color;
    const nm=document.createElement('b');nm.textContent=p.name;
    row.append(dot,nm);
    if(p.host&&!NET.offline){const h=document.createElement('em');h.textContent='방장';row.appendChild(h);}
    const st=p.state;
    const stars=document.createElement('span');stars.className='st';stars.textContent=st&&st.ws?'★'.repeat(st.ws):'';row.appendChild(stars);
    const kd=document.createElement('span');kd.className='kd';kd.textContent=(p.kills||0)+' / '+(p.deaths||0);row.appendChild(kd);
    const hp=document.createElement('span');hp.className='hp';
    const alive=!(st&&(st.f&4));hp.textContent=st?(alive?'♥ '+st.h:'쓰러짐'):'—';if(!alive)hp.classList.add('down');row.appendChild(hp);
    body.appendChild(row);
  }
}
$('mpPlHead').addEventListener('click',()=>NET.togglePlayers());
function renderTag(){
  if(!NET.me)return;
  $('mpTagRoom').textContent=NET.offline?'OFFLINE':'ROOM '+(NET.room?NET.room.code:'------');
  $('mpTagName').textContent=NET.me.name;
  $('mpTagName').style.color=NET.me.color;
  const dot=$('mpTagDot');dot.className=NET.offline?'off':NET.connected?'on':'lost';
  $('mpTagPing').textContent=NET.offline?'':NET.connected?(NET.rtt?NET.rtt+'ms':''):'재연결 중';
}
})();

/* =====================================================================
   [2] 기존 게임 — 방에 들어간 뒤 bootNeonHarbor(NET)로 시작
   ===================================================================== */
window.bootNeonHarbor=function(NET){
'use strict';
// the city is generated with random numbers: during start-up they come from the room's seed so every
// player builds exactly the same map (three.js keeps the browser's own Math.random for its internal ids)
let RNG=(function(a){return function(){a|=0;a=a+0x6D2B79F5|0;let t=Math.imul(a^a>>>15,1|a);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296;};})(NET.seed>>>0||1);
const V3=THREE.Vector3, Y=new V3(0,1,0);
const $=id=>document.getElementById(id);
const container=$('game');

// ---------- helpers ----------
const rand=(a,b)=>a+RNG()*(b-a);
const randi=(a,b)=>Math.floor(rand(a,b+1));
const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
const pick=a=>a[Math.floor(RNG()*a.length)];
function angDiff(a,b){let d=b-a;while(d>Math.PI)d-=Math.PI*2;while(d<-Math.PI)d+=Math.PI*2;return d;}
const d2=(a,b)=>Math.hypot(a.x-b.x,a.z-b.z);

// ---------- city constants ----------
// 18×18 blocks = 3×3 regions of the original 6×6 downtown; the old downtown is the north-west region
const N=18, CELL=60, HALF_ROAD=7, LANE=3.5;
const NZ=21,IND_J=18; // three more rows of blocks south of the old coast road: the industrial estate (rows 18–20)
const OLD_C=-360; // centre of the old downtown (it used to sit at the origin)
const R=[]; for(let k=0;k<=Math.max(N,NZ);k++) R.push((k-N/2)*CELL);
const EDGE=R[N]+13,EDGE_S=R[NZ]+13,LAND_S=EDGE_S-EDGE; // west/east/north edges at ±EDGE, the south coast at EDGE_S
const onMainXZ=(x,z,m)=>x>-m&&x<m&&z>-m&&z<m+LAND_S;
const ROOM_X=5000; // interiors are stored far away beyond this x, out past the islands
const GOD=false; // test build: the player cannot be hurt or starve
// walkable decks beyond the map edge (harbour quay, naval pier) and the swimmable sea off the harbour
const QUAY={x0:-579,x1:-553,z0:-180,z1:180,y:.5},PIER_W={x0:553,x1:662,z0:20,z1:34,y:.4},PIER_H={x0:640,x1:662,z0:-14,z1:70,y:.4};
const JETTY={x0:-640,x1:-579,z0:-8,z1:-2,y:.5}; // marina jetty off the harbour quay
// islands across the water: airport (west, linked by a bridge and a ferry), air force base (east), two islets
const AIR={x0:-1340,x1:-960,z0:-560,z1:-160},ISLET_W={x0:-1230,x1:-1080,z0:320,z1:470};
const AFB={x0:950,x1:1400,z0:-430,z1:110},ISLET_E={x0:1060,x1:1200,z0:430,z1:570};
const ISLANDS=[AIR,ISLET_W,AFB,ISLET_E];
const BRIDGE={x0:-962,x1:-553,z0:-368,z1:-352,y:0,arch:true}; // arched road bridge along z=R[3] to the airport
const bridgeY=x=>{const t=(x-BRIDGE.x1)/(BRIDGE.x0-BRIDGE.x1);return 6*smooth(0,.28,t)*smooth(0,.28,1-t);};
const FERRY_A={x0:-602,x1:-579,z0:25,z1:35,y:.5},FERRY_B={x0:-960,x1:-938,z0:-227,z1:-217,y:.5};
const AFB_DOCK={x0:928,x1:950,z0:-140,z1:-128,y:.4};
const FERRY_RING_A={x:-598,z:30},FERRY_RING_B={x:-942,z:-222};
const DECKS=[QUAY,PIER_W,PIER_H,JETTY,BRIDGE,FERRY_A,FERRY_B,AFB_DOCK];
// the open sea all round (swimmable, navigable), bounded by the edge of the water plane
const SEA={x0:-1650,x1:1650,z0:-1650,z1:1650},WATER_Y=-1.2,SWIM_Y=-2.55;
const SEA_STRIPS=[[-1650,-575,-1650,1650],[575,1650,-1650,1650],[-1650,1650,-1650,-575],[-1650,1650,575+LAND_S,1650]];
const inRect=(p,R)=>p.x>R.x0&&p.x<R.x1&&p.z>R.z0&&p.z<R.z1;
const onDeck=p=>DECKS.some(D=>p.x>=D.x0&&p.x<=D.x1&&p.z>=D.z0&&p.z<=D.z1);
const onIsland=p=>ISLANDS.some(I=>p.x>=I.x0&&p.x<=I.x1&&p.z>=I.z0&&p.z<=I.z1);
const isLand=p=>onMainXZ(p.x,p.z,561)||onIsland(p);
const inSea=p=>!isLand(p)&&inRect(p,SEA)&&!onDeck(p);
const deckY=(D,x)=>D.arch?bridgeY(x):D.y;

// ---------- terrain: the central mountain (with a ridge running down to the mine) rises out of the street grid ----------
// it fills the middle region plus the two mine blocks south of it; the roads around it stay flat
const MT_RECTS=[[-173,173,-173,173],[-53,53,-173,233]];
const MT_PEAKS=[[0,-10,108,62],[-85,65,58,40],[95,45,62,42],[65,-105,50,38],[-95,-95,46,40],[0,140,44,38],[-40,40,40,30]];
const MINE_PAD=[-15,15,196,240]; // flat forecourt in front of the mine portal
const MINE_Z=196;
const smooth=(a,b,v)=>{const t=Math.max(0,Math.min(1,(v-a)/(b-a)));return t*t*(3-2*t);};
const inMountain=(x,z)=>MT_RECTS.some(r=>x>r[0]&&x<r[1]&&z>r[2]&&z<r[3]);
function terrainH(x,z){
  if(x<-173||x>173||z<-173||z>233)return 0;
  let m=0;
  for(const r of MT_RECTS){const d=Math.min(x-r[0],r[1]-x,z-r[2],r[3]-z);if(d>0)m=Math.max(m,smooth(0,38,d));}
  if(m<=0)return 0;
  let h=0;
  for(const p of MT_PEAKS){const dx=x-p[0],dz=z-p[1];h+=p[2]*Math.exp(-(dx*dx+dz*dz)/(2*p[3]*p[3]));}
  h+=5*Math.sin(x*.045+1.3)*Math.cos(z*.05-.7)+2.4*Math.sin(x*.13+z*.11)+1.2*Math.sin(x*.31-z*.27);
  h=Math.max(0,h)*m;
  const ox=Math.max(MINE_PAD[0]-x,0,x-MINE_PAD[1]),oz=Math.max(MINE_PAD[2]-z,0,z-MINE_PAD[3]),out=Math.hypot(ox,oz);
  if(out<10)h*=smooth(0,10,out);
  return h;
}
// height you stand on: decks beyond the edge, otherwise the ground/mountain
function floorH(x,z){
  if(x<-553||x>553||z<-553||z>553+LAND_S){for(const D of DECKS)if(x>=D.x0&&x<=D.x1&&z>=D.z0&&z<=D.z1)return deckY(D,x);return 0;}
  return terrainH(x,z);
}
// what a falling object lands on: land, decks, or the sea surface
function surfaceH(x,z){
  for(const D of DECKS)if(x>=D.x0&&x<=D.x1&&z>=D.z0&&z<=D.z1)return deckY(D,x);
  if(onMainXZ(x,z,561))return terrainH(x,z);
  if(onIsland({x,z}))return 0;
  return WATER_Y;
}
// does the straight line a→b pass under the mountain's surface?
function terrainBlocks(a,b){
  if(Math.max(a.x,b.x)<-173||Math.min(a.x,b.x)>173||Math.max(a.z,b.z)<-173||Math.min(a.z,b.z)>233)return false;
  const d=Math.hypot(b.x-a.x,b.z-a.z),n=Math.ceil(d/6),ya=(a.y||0)+1.5,yb=(b.y||0)+1.5;
  for(let k=1;k<n;k++){const t=k/n;if(terrainH(a.x+(b.x-a.x)*t,a.z+(b.z-a.z)*t)>ya+(yb-ya)*t)return true;}
  return false;
}

// ---------- renderer ----------
const renderer=new THREE.WebGLRenderer({antialias:true});
renderer.setPixelRatio(Math.min(window.devicePixelRatio||1,1.5));
container.insertBefore(renderer.domElement,container.firstChild);
const canvas=renderer.domElement; canvas.tabIndex=0;
const scene=new THREE.Scene();
const FOG=0x4b3358;
scene.fog=new THREE.Fog(FOG,70,290);
const camera=new THREE.PerspectiveCamera(70,1,0.1,430); // fog is opaque by 290m, so nothing past this is visible anyway
scene.add(camera);
let composer=null,bloom=null;
function resize(){const w=container.clientWidth||innerWidth,h=container.clientHeight||innerHeight;renderer.setSize(w,h,false);camera.aspect=w/h;camera.updateProjectionMatrix();if(composer)composer.setSize(w,h);}
function radialTex(stops,size){
  const c=document.createElement('canvas');c.width=c.height=size||64;const g=c.getContext('2d'),r=c.width/2;
  const gr=g.createRadialGradient(r,r,0,r,r,r);stops.forEach(s=>gr.addColorStop(s[0],s[1]));g.fillStyle=gr;g.fillRect(0,0,c.width,c.height);
  return new THREE.CanvasTexture(c);
}
const WHITE_GLOW=radialTex([[0,'rgba(255,255,255,1)'],[.25,'rgba(255,255,255,.55)'],[1,'rgba(255,255,255,0)']]);
addEventListener('resize',resize); resize();

// sky dome: vertex colours are re-blended between night, dusk and day palettes as the clock turns
const SKY_T=[-1,-.02,0,.06,.16,.4,1];
const SKY_PAL={
  night:[0x07060e,0x0f0d1c,0x1a1830,0x2a2648,0x1c1a3a,0x0e0f26,0x05061a],
  dusk:[0x140f22,0x2a1f36,0x4b3358,0xc0605a,0x7a3d6c,0x2a2557,0x0c0f2a],
  day:[0x3a4a5a,0x7a96b0,0xa9c4dc,0xd2e2ef,0x9cc2e6,0x5a92cf,0x2f6ab8]
};
const SKY={};
(function(){
  const g=new THREE.SphereGeometry(400,32,20); const pos=g.attributes.position; const ts=[];
  for(let i=0;i<pos.count;i++)ts.push(pos.getY(i)/400);
  const cols=new Float32Array(pos.count*3);
  g.setAttribute('color',new THREE.Float32BufferAttribute(cols,3));
  const sky=new THREE.Mesh(g,new THREE.MeshBasicMaterial({vertexColors:true,side:THREE.BackSide,fog:false,depthWrite:false}));
  sky.renderOrder=-1; scene.add(sky); scene.userData.sky=sky;
  // stars, thinning toward the horizon
  const n=700,sp=new Float32Array(n*3);
  for(let i=0;i<n;i++){const th=RNG()*Math.PI*2,y=.2+Math.pow(RNG(),.7)*.8,r=Math.sqrt(1-y*y);sp[i*3]=Math.cos(th)*r*380;sp[i*3+1]=y*380;sp[i*3+2]=Math.sin(th)*r*380;}
  const sg=new THREE.BufferGeometry();sg.setAttribute('position',new THREE.Float32BufferAttribute(sp,3));
  const starMat=new THREE.PointsMaterial({color:0xfff6e0,size:1.6,sizeAttenuation:false,transparent:true,opacity:.8,fog:false,depthWrite:false});
  sky.add(new THREE.Points(sg,starMat));
  const mc=document.createElement('canvas');mc.width=mc.height=128;const mg=mc.getContext('2d');
  const halo=mg.createRadialGradient(64,64,10,64,64,64);halo.addColorStop(0,'rgba(255,240,210,.55)');halo.addColorStop(1,'rgba(255,240,210,0)');
  mg.fillStyle=halo;mg.fillRect(0,0,128,128);mg.fillStyle='#fff3da';mg.beginPath();mg.arc(64,64,17,0,Math.PI*2);mg.fill();
  mg.fillStyle='rgba(205,190,170,.45)';[[58,58,4],[70,66,3],[62,72,2.5]].forEach(([x,y,r])=>{mg.beginPath();mg.arc(x,y,r,0,Math.PI*2);mg.fill();});
  const moon=new THREE.Sprite(new THREE.SpriteMaterial({map:new THREE.CanvasTexture(mc),transparent:true,fog:false,depthWrite:false}));
  moon.scale.set(60,60,1);sky.add(moon);
  const sunTex=radialTex([[0,'rgba(255,255,245,1)'],[.12,'rgba(255,250,225,1)'],[.2,'rgba(255,230,170,.55)'],[1,'rgba(255,200,120,0)']],128);
  const sunS=new THREE.Sprite(new THREE.SpriteMaterial({map:sunTex,transparent:true,fog:false,depthWrite:false,blending:THREE.AdditiveBlending}));
  sunS.scale.set(110,110,1);sky.add(sunS);
  Object.assign(SKY,{g,ts,cols:(g.attributes.color&&g.attributes.color.array)||cols,starMat,moon,sun:sunS});
})();
const hemi=new THREE.HemisphereLight(0x9ea4dc,0x3a2a35,0.85); scene.add(hemi);
const sun=new THREE.DirectionalLight(0xffb27a,0.6); sun.position.set(-120,55,-60); scene.add(sun);

// ---------- caches ----------
const GC={}, MC={}, BMC={}, IMC={};
const geo=(k,f)=>GC[k]||(GC[k]=f());
const bx=(w,h,d)=>geo('b'+w+'_'+h+'_'+d,()=>new THREE.BoxGeometry(w,h,d));
const UNIT=new THREE.BoxGeometry(1,1,1);
function mat(color){return MC[color]||(MC[color]=new THREE.MeshLambertMaterial({color}));}
function bmat(color){return BMC[color]||(BMC[color]=new THREE.MeshBasicMaterial({color}));}
function imat(color){return IMC[color]||(IMC[color]=new THREE.MeshLambertMaterial({color,emissive:new THREE.Color(color).multiplyScalar(.28)}));}
const glassMat=new THREE.MeshLambertMaterial({color:0x9cc6d6,transparent:true,opacity:.3,depthWrite:false});
function mesh(g,m,x,y,z){const o=new THREE.Mesh(g,m);o.position.set(x||0,y||0,z||0);return o;}

// ---------- ground & water ----------
const ground=mesh(new THREE.PlaneGeometry(EDGE*2+16,EDGE*2+16+LAND_S),mat(0x25262f)); ground.rotation.x=-Math.PI/2; ground.position.z=LAND_S/2; scene.add(ground);
const water=mesh(new THREE.PlaneGeometry(3400,3400),new THREE.MeshLambertMaterial({color:0x1c2f52})); water.rotation.x=-Math.PI/2; water.position.y=-1.2; scene.add(water);
// the mountain surface: one mesh, coloured by height (forest → scree → rock → snow)
(function(){
  const g=new THREE.PlaneGeometry(346,406,118,138);g.rotateX(-Math.PI/2);g.translate(0,0,30);
  const p=g.attributes.position,cols=new Float32Array(p.count*3),c=new THREE.Color();
  const edge=new THREE.Color(0x4c5a3a),low=new THREE.Color(0x355a30),mid=new THREE.Color(0x5e5a48),rock=new THREE.Color(0x77716a),snow=new THREE.Color(0xeef2f6);
  for(let i=0;i<p.count;i++){
    const x=p.getX(i),z=p.getZ(i),h=terrainH(x,z),n=.5+.5*Math.sin(x*.21+z*.07)*Math.cos(z*.17-x*.05);
    p.setY(i,inMountain(x,z)?h+.03:-1.2);
    if(x>MINE_PAD[0]-6&&x<MINE_PAD[1]+6&&z>MINE_PAD[2]-2&&h<2)c.setHex(0x5a4a3a);
    else if(h<1)c.copy(edge);
    else if(h<38)c.copy(low).lerp(mid,clamp(h/38*.55+n*.3,0,1));
    else if(h<80)c.copy(mid).lerp(rock,clamp((h-38)/42+n*.15,0,1));
    else c.copy(rock).lerp(snow,clamp((h-80)/12+n*.2,0,1));
    cols[i*3]=c.r;cols[i*3+1]=c.g;cols[i*3+2]=c.b;
  }
  g.setAttribute('color',new THREE.Float32BufferAttribute(cols,3));g.computeVertexNormals();
  scene.add(new THREE.Mesh(g,new THREE.MeshLambertMaterial({vertexColors:true})));
})();
// sea walls; open where the harbour quay and the naval pier meet the city
[[0,-EDGE-1.5,EDGE*2+6,1],[0,EDGE_S+1.5,EDGE*2+6,1],
 [-EDGE-1.5,(-EDGE-3+BRIDGE.z0)/2,1,BRIDGE.z0+EDGE+3],[-EDGE-1.5,(BRIDGE.z1+QUAY.z0)/2,1,QUAY.z0-BRIDGE.z1],[-EDGE-1.5,(EDGE_S+3+QUAY.z1)/2,1,EDGE_S+3-QUAY.z1],
 [EDGE+1.5,(-EDGE-3+18)/2,1,18+EDGE+3],[EDGE+1.5,(EDGE_S+3+36)/2,1,EDGE_S+3-36]].forEach(w=>{const m=mesh(UNIT,mat(0x6d6a78),w[0],0,w[1]);m.scale.set(w[2],2.4,w[3]);scene.add(m);});

// ---------- textures ----------
function winTex(v){
  const S=64, a=document.createElement('canvas'), b=document.createElement('canvas'); a.width=a.height=b.width=b.height=S;
  const ga=a.getContext('2d'), gb=b.getContext('2d');
  ga.fillStyle='#c9c6d4';ga.fillRect(0,0,S,S);gb.fillStyle='#000';gb.fillRect(0,0,S,S);
  const lights=['#ffcf73','#ffdc9e','#ffb85c','#a9d8ff'];
  if(v===2){ for(let r=0;r<4;r++){ for(let c=0;c<4;c++){ const lit=RNG()<.4; ga.fillStyle=lit?'#ffe6b0':'#28314d'; ga.fillRect(c*16,r*16+5,16,7); if(lit){gb.fillStyle=pick(lights);gb.fillRect(c*16,r*16+5,16,7);} } } }
  else { const ww=v===1?6:10, wh=v===1?11:9; for(let r=0;r<4;r++)for(let c=0;c<4;c++){ const x=c*16+(16-ww)/2, y=r*16+3; const lit=RNG()<.33; ga.fillStyle=lit?'#ffe6b0':'#28314d'; ga.fillRect(x,y,ww,wh); if(lit){gb.fillStyle=pick(lights);gb.fillRect(x,y,ww,wh);} } }
  const ta=new THREE.CanvasTexture(a), tb=new THREE.CanvasTexture(b);
  [ta,tb].forEach(t=>{t.wrapS=t.wrapT=THREE.RepeatWrapping;t.anisotropy=4;});
  return [ta,tb];
}
const WT=[winTex(0),winTex(1),winTex(2)];
const SMC={};
function sideMat(v,tint){const k=v+'_'+tint;return SMC[k]||(SMC[k]=new THREE.MeshLambertMaterial({color:tint,map:WT[v][0],emissive:0xffffff,emissiveMap:WT[v][1],emissiveIntensity:.95}));}
function boxUV(g,w,h,d){const uv=g.attributes.uv;for(let f=0;f<6;f++){const sx=f<2?d/8:w/8, sy=(f===2||f===3)?d/8:h/8;for(let v=0;v<4;v++){const i=f*4+v;uv.setXY(i,uv.getX(i)*sx,uv.getY(i)*sy);}}uv.needsUpdate=true;}
function glowTex(){const c=document.createElement('canvas');c.width=c.height=64;const g=c.getContext('2d');const gr=g.createRadialGradient(32,32,0,32,32,32);gr.addColorStop(0,'rgba(255,190,100,1)');gr.addColorStop(1,'rgba(255,190,100,0)');g.fillStyle=gr;g.fillRect(0,0,64,64);return new THREE.CanvasTexture(c);}

// ---------- city ----------
const colliders=[], blocks=[];
// colliders live in a 30m bucket grid so lookups stay cheap on the big map
const CGRID=30,cgrid=new Map();let cstamp=0;
const gkey=(ix,iz)=>(ix+4000)*9000+(iz+4000);
function addCollider(x0,x1,z0,z1,h,tree){
  const c={x0,x1,z0,z1,h,tree:!!tree,s:0};colliders.push(c);
  for(let ix=Math.floor(x0/CGRID);ix<=Math.floor(x1/CGRID);ix++)for(let iz=Math.floor(z0/CGRID);iz<=Math.floor(z1/CGRID);iz++){
    const k=gkey(ix,iz);let b=cgrid.get(k);if(!b)cgrid.set(k,b=[]);b.push(c);
  }
}
// visit each collider touching the box once; fn returning true stops early
function forColliders(x0,z0,x1,z1,fn){
  if(x0>x1){const t=x0;x0=x1;x1=t;}if(z0>z1){const t=z0;z0=z1;z1=t;}
  const s=++cstamp;
  for(let ix=Math.floor(x0/CGRID);ix<=Math.floor(x1/CGRID);ix++)for(let iz=Math.floor(z0/CGRID);iz<=Math.floor(z1/CGRID);iz++){
    const b=cgrid.get(gkey(ix,iz));if(!b)continue;
    for(const c of b){if(c.s===s)continue;c.s=s;if(fn(c))return true;}
  }
  return false;
}
const tints=[0x8c8aa3,0x9d8f86,0x7e8fa0,0xa5a0b5,0x8a7f92,0x6f7d8f,0xb39b8a];
const beaconMat=new THREE.MeshBasicMaterial({color:0xff2030});
const neons=[0xff3fa4,0x37e6ff,0xffb53d,0x9a6bff,0x5dff9e];
const BLDGS=[]; // building footprints a fire can break out in
function building(x0,x1,z0,z1,h,o){
  o=o||{};BLDGS.push({x0,x1,z0,z1,h});
  const w=x1-x0,d=z1-z0; const g=new THREE.BoxGeometry(w,h,d); boxUV(g,w,h,d);
  const side=sideMat(o.v!=null?o.v:randi(0,2),pick(o.tints||tints)), roof=mat(0x2c2d3b);
  const m=new THREE.Mesh(g,[side,side,roof,roof,side,side]); m.position.set((x0+x1)/2,h/2,(z0+z1)/2); scene.add(m);
  addCollider(x0,x1,z0,z1,h);
  if(RNG()<.6){const r=mesh(UNIT,mat(0x45465a),(x0+x1)/2+rand(-w/4,w/4),h+1,(z0+z1)/2+rand(-d/4,d/4));r.scale.set(rand(2,4),2,rand(2,4));scene.add(r);}
  if(h>34){const cx=(x0+x1)/2,cz=(z0+z1)/2;const ant=mesh(UNIT,mat(0x3a3a46),cx,h+2.5,cz);ant.scale.set(.15,5,.15);scene.add(ant);const b=mesh(bx(.5,.5,.5),beaconMat,cx,h+5.2,cz);scene.add(b);}
  if(h>12&&RNG()<(o.neon!=null?o.neon:.45)){
    const col=pick(neons), face=randi(0,3), sh=rand(4,8), sy=rand(5,Math.min(h-3,12))+sh/2;
    const s=mesh(UNIT,bmat(col));
    if(face===0){s.position.set(x1+.25,sy,rand(z0+2,z1-2));s.scale.set(.4,sh,1.4);}
    else if(face===1){s.position.set(x0-.25,sy,rand(z0+2,z1-2));s.scale.set(.4,sh,1.4);}
    else if(face===2){s.position.set(rand(x0+2,x1-2),sy,z1+.25);s.scale.set(1.4,sh,.4);}
    else {s.position.set(rand(x0+2,x1-2),sy,z0-.25);s.scale.set(1.4,sh,.4);}
    scene.add(s);
  }
}
const trunkG=new THREE.CylinderGeometry(.22,.3,2.4,6), crownG=new THREE.IcosahedronGeometry(1.9,0);
function tree(x,z){scene.add(mesh(trunkG,mat(0x4a3526),x,1.2,z));const c=mesh(crownG,mat(pick([0x2f6b45,0x3a7a4a,0x285c3c])),x,3.6,z);c.scale.y=1.15;scene.add(c);addCollider(x-.35,x+.35,z-.35,z+.35,4,true);}

// ---------- signs ----------
const signs=[];
function drawSign(s){
  const g=s.c.getContext('2d'),W=s.c.width,H=s.c.height;
  g.fillStyle=s.bg;g.fillRect(0,0,W,H);g.strokeStyle=s.fg;g.lineWidth=H*.05;g.strokeRect(H*.06,H*.06,W-H*.12,H-H*.12);
  g.fillStyle=s.fg;g.textAlign='center';g.textBaseline='middle';
  g.font=Math.floor(H*.5)+"px 'Black Han Sans','Noto Sans KR',sans-serif";g.fillText(s.lines[0],W/2,H*(s.lines[1]?.42:.52));
  const room=W-H*.12-16,w0=g.measureText(s.lines[0]).width;let w1=0;
  if(s.lines[1]){g.font="700 "+Math.floor(H*.15)+"px 'JetBrains Mono',ui-monospace,monospace";g.fillText(s.lines[1],W/2,H*.78);w1=g.measureText(s.lines[1]).width;}
  // a sign whose text runs off the board, or uses symbols the sign fonts can't draw, isn't put up at all
  s.bad=w0>room||w1>room||SIGN_BAD_GLYPH.test(s.lines.join(''));
  if(s.mesh)s.mesh.visible=!s.bad;
  s.t.needsUpdate=true;
}
const SIGN_BAD_GLYPH=/[\u2190-\u21FF\u2300-\u23FF\u2600-\u27BF\u2B00-\u2BFF]|[\uD83C-\uD83E][\uDC00-\uDFFF]/;
function signTex(lines,bg,fg){const c=document.createElement('canvas');c.width=512;c.height=160;const t=new THREE.CanvasTexture(c);const s={c,t,lines,bg,fg};signs.push(s);drawSign(s);return t;}
if(document.fonts&&document.fonts.load){Promise.all([document.fonts.load("40px 'Black Han Sans'","한글 HANGUL 0123"),document.fonts.load("700 20px 'JetBrains Mono'","ABC abc 0123"),document.fonts.load("700 20px 'Noto Sans KR'","한글")]).then(()=>signs.forEach(drawSign)).catch(()=>{});}
function signPlane(lines,bg,fg,x,y,z,w,h,rotY){const p=new THREE.Mesh(new THREE.PlaneGeometry(w,h),new THREE.MeshBasicMaterial({map:signTex(lines,bg,fg)}));p.position.set(x,y,z);p.rotation.y=rotY;scene.add(p);const S=signs[signs.length-1];S.mesh=p;p.visible=!S.bad;return p;}

// ---------- landmarks ----------
const LOC_TYPES={
  bank:{name:'은행',color:0x61e08e,w:22,d:30,h:20,body:0xd9cfb6,room:{w:24,d:20,h:6,floor:0xd8d2c6,wall:0xcabf9f,ceil:0xece6d6},title:'하버 저축은행',sub:'HARBOR SAVINGS · 창구',counter:'은행 창구'},
  hospital:{name:'병원',color:0x5fb7ff,w:24,d:28,h:26,body:0xaab4c0,room:{w:22,d:18,h:5,floor:0xa6b0b8,wall:0xb8c1ca,ceil:0xc0c7ce},title:'하버 종합병원',sub:'HARBOR GENERAL · 접수처',counter:'접수처'},
  gun:{name:'총포상',color:0xff4d5e,w:14,d:18,h:8,body:0x6e5a49,room:{w:16,d:14,h:4.5,floor:0x4a3d34,wall:0x7a6655,ceil:0x5a4c40},title:'하버 총포상',sub:'HARBOR ARMS',counter:'총포상 주인과 거래'},
  conv:{name:'편의점',color:0xc77dff,w:12,d:14,h:6,body:0xe9e6ee,room:{w:14,d:12,h:4,floor:0xe6e3ea,wall:0xf2f0f5,ceil:0xf5f3f8},title:'하버마트 24',sub:'HARBOR MART · 계산대',counter:'계산대'},
  police:{name:'경찰서',color:0x3f8cff,w:22,d:28,h:14,body:0xd6dbe4,room:{w:20,d:16,h:5,floor:0x9aa3b2,wall:0xdfe4ec,ceil:0xeef1f5},title:'경찰서 민원실',sub:'HARBOR POLICE',counter:'민원실'},
  garage:{name:'카센터',color:0x37e6ff,w:16,d:22,h:8,body:0x5b6270,room:null,service:true,title:'하버 모터스',sub:'HARBOR MOTORS · 카센터'},
  jail:{name:'감옥',color:0xffb53d,room:{w:18,d:14,h:5,floor:0x6f7682,wall:0xb8bec8,ceil:0xc8ccd4},title:'하버 교도소',sub:'',counter:'환풍구 뜯기'},
  diner:{name:'식당',color:0xff8a3d,w:14,d:20,h:7,body:0x9a4a36,room:{w:16,d:14,h:4.5,floor:0x7a5a40,wall:0xf0e2c8,ceil:0xf5ecdc},title:'하버 식당',sub:'HARBOR DINER · 계산대',counter:'식당 계산대'},
  cityhall:{name:'시청',color:0xe8e2d0,w:30,d:24,h:18,body:0xe6e0cf,room:null},
  fire:{name:'소방서',color:0xff6a3d,w:24,d:28,h:11,body:0xa8352a,room:null,noDoor:true},
  junk:{name:'고물상',color:0xc9a26a,room:null,noDoor:true},
  airport:{name:'국제공항',color:0x7ff3ff,room:null,noDoor:true},
  afb:{name:'공군 기지',color:0x9bbf5a,room:null,noDoor:true},
  ferry:{name:'페리 터미널',color:0x4ec2d8,room:null,noDoor:true},
  hotel:{name:'호텔',color:0xf0c060,w:20,d:30,h:30,body:0xcfc6b4,room:{w:26,d:22,h:6,floor:0x7a3a34,wall:0xe8dcc4,ceil:0xf4ecdc},title:'호텔',sub:'HOTEL · 프런트 데스크',counter:'프런트 데스크 · 객실 예약'},
  terminal:{name:'공항 터미널',color:0x7ff3ff,room:{w:34,d:24,h:8,floor:0xcfd4dc,wall:0xeef2f6,ceil:0xf4f6f8},title:'네온 아일랜드 국제공항',sub:'출국장 · 발권 카운터',counter:'항공권 발권 카운터'},
  airsec:{name:'공항 경비대',color:0x3f8cff,room:null,noDoor:true},
  cityoffice:{name:'시청 출장소',color:0xe8e2d0,w:22,d:24,h:12,body:0xe4dccd,room:null,title:'시청 동부 출장소',sub:'도시관리과 · 주차 단속'},
  gang:{name:'하버 갱단 본거지',color:0xb3202a,room:null,noDoor:true},
  realty:{name:'공인중개사',color:0xb48cff,w:12,d:16,h:8,body:0xe4dccd,room:null,title:'공인중개사 사무소',sub:'REAL ESTATE'},
  parking:{name:'주차장',color:0x4da3ff,room:null,noDoor:true},
  gas:{name:'주유소',color:0xff5a3a,room:null,noDoor:true},
  busdepot:{name:'버스 차고지',color:0x3ad07a,room:null,noDoor:true},
  taxidepot:{name:'택시 영업소',color:0xf4c430,room:null,noDoor:true},
  logistics:{name:'물류센터',color:0xff8a3d,room:null,noDoor:true},
  marina:{name:'마리나',color:0x4ec2d8,room:null,shop:true,title:'하버 마리나',sub:'HARBOR MARINA · 보트 판매',counter:'마리나 · 보트 구매'},
  mine:{name:'광산 갱도',color:0xe0b04a,room:{w:10,d:56,h:5.5,floor:0x4a3e32,wall:0x5e544a,ceil:0x3e362e},title:'하버 광산 갱도',sub:'HARBOR MINE · 광부의 매입소',counter:'광부와 거래 · 곡괭이 · 광물 매입'}
};
// [type, door side, look]; looks: city (old downtown), harbor, slum, army (east army flats)
const LOC_AT={
  '3,2':['bank','w'],'2,3':['hospital','e'],'3,4':['gun','w'],'2,4':['conv','e'],'4,2':['conv','w'],'4,3':['police','w'],'3,3':['cityhall','w'],'3,1':['diner','w'],'1,3':['diner','e'],'2,1':['garage','e'],'1,2':['fire','e'],
  '2,7':['police','w','harbor'],'2,9':['fire','w','harbor'],'3,10':['gun','e','harbor'],'3,7':['diner','e','harbor'],'4,8':['conv','w','harbor'],'4,10':['garage','w','harbor'],
  '7,14':['gun','e','slum'],'10,14':['diner','w','slum'],'8,15':['conv','e','slum'],'10,16':['garage','w','slum'],
  '13,8':['police','e','army'],'13,10':['fire','e','army'],'12,7':['gun','w','army'],'14,6':['diner','w','army'],'12,9':['conv','w','army'],'14,11':['garage','w','army'],'13,6':['hospital','e','army'],
  // north and north-east streets
  '7,2':['gun','e','north'],'9,1':['conv','w','north'],'10,3':['diner','e','north'],
  '13,3':['gun','w','north'],'15,1':['conv','e','north'],'16,4':['diner','w','north'],
  // south-west and south-east slums
  '1,13':['gun','e','slum'],'4,16':['conv','w','slum'],'2,15':['diner','e','slum'],
  '13,14':['gun','e','slum'],'15,13':['conv','w','slum'],'16,16':['diner','w','slum'],
  // hotels (not open yet): two in the old downtown, two in the south-west suburbs, two among the army flats
  '1,1':['hotel','e','city',['네온 그랜드 호텔','NEON GRAND HOTEL','네온 그랜드 호텔']],'4,4':['hotel','w','city',['하버뷰 호텔','HARBOR VIEW HOTEL','하버뷰 호텔']],
  '2,13':['hotel','e','suburb',['오렌지 모텔','ORANGE MOTEL','오렌지 모텔']],'0,16':['hotel','e','suburb',['파인 인','PINE INN','파인 인']],
  '12,11':['hotel','e','army',['동부 군 휴양 호텔','EAST MILITARY RESORT','동부 군 휴양 호텔']],'14,7':['hotel','w','army',['부대 앞 모텔','GATE MOTEL','부대 앞 모텔']]
};
Object.assign(LOC_AT,{
  // second old-town garage, the south slum police box and garage
  '13,9':['cityoffice','e','army',['시청 출장소','CITY HALL · EAST OFFICE','시청 동부 출장소','도시관리과 · 불법 주정차 단속']],
  '5,4':['garage','w','city',['카센터','OLDTOWN MOTORS','구도심 모터스','OLDTOWN MOTORS · 카센터']],
  '11,14':['police','e','slum',['파출소','SOUTH SLUM POLICE BOX','남부 파출소 민원실','SOUTH SLUM POLICE BOX']],
  '14,15':['garage','w','slum',['빈민가 정비소','SOUTHSIDE GARAGE','남동 정비소','SOUTHSIDE GARAGE · 카센터']],
  // two estate agents in every district but the mountain (not open yet)
  '0,3':['realty','e','city'],'5,2':['realty','w','city'],'7,4':['realty','e','north'],'10,0':['realty','w','north'],
  '12,2':['realty','e','north'],'16,0':['realty','w','north'],'3,8':['realty','e','harbor'],'5,10':['realty','w','harbor'],
  '15,6':['realty','e','army'],'16,11':['realty','w','army'],'4,12':['realty','w','suburb'],'1,17':['realty','e','suburb'],
  '6,12':['realty','e','slum'],'11,16':['realty','w','slum'],'14,13':['realty','e','slum'],'17,15':['realty','w','slum']
});
// the industrial estate's own services (rows 19–20, where the side streets run)
Object.assign(LOC_AT,{
  '3,19':['police','e','harbor',['공단 경비대','ESTATE SECURITY','남부 공단 경비대','ESTATE SECURITY · 민원실']],
  '15,19':['fire','e','harbor',['공단 소방서','ESTATE FIRE STATION','남부 공단 소방서','ESTATE FIRE STATION']],
  '8,20':['hospital','e','harbor',['보건소','ESTATE CLINIC','남부 공단 보건소','ESTATE CLINIC · 진료']],
  '6,19':['gun','w','harbor',['총포상','ESTATE ARMS','공단 총포상','ESTATE ARMS']],
  '10,19':['conv','e','harbor',['편의점','ESTATE MART 24','공단 마트 24','ESTATE MART · 계산대']],
  '12,20':['diner','w','harbor',['공단 식당','WORKERS CANTEEN','공단 함바식당','WORKERS CANTEEN · 계산대']]
});
const DEPOT_KEY='11,1',GANG_KEY='16,12',LOGI_KEY='0,7';let GANG=null;
// taxi companies: every cab in town starts from one of these yards; the dispatcher's booth hires drivers
const TAXI_AT={'8,1':['north','북부 택시 영업소','NORTH CAB CO.'],'1,12':['suburb','남서 택시 영업소','SOUTHWEST CAB CO.'],'12,10':['army','동부 택시 영업소','EAST CAB CO.'],'5,9':['harbor','항구 택시 영업소','HARBOR CAB CO.'],'10,20':['harbor','공단 택시 영업소','ESTATE CAB CO.']},TAXI_DEPOTS=[];
// parking towers (old town, harbour, army flats) and open-air car parks
const PARK_AT={'5,20':['lot','harbor','공단 공영 주차장'],'1,5':['tower','city','구도심 주차 타워'],'3,9':['tower','harbor','항구 주차 타워'],'15,7':['tower','army','동부 주차 타워'],
  '9,3':['lot','north','북부 공영 주차장'],'13,4':['lot','north','북동 공영 주차장'],'4,13':['lot','suburb','남서 공영 주차장'],'11,12':['lot','slum','남부 공영 주차장'],'16,14':['lot','slum','남동 공영 주차장'],'5,7':['lot','harbor','항구 공영 주차장'],
  '2,0':['lot','city','구도심 북부 공영 주차장'],'4,5':['lot','city','구도심 남부 공영 주차장'],'6,2':['lot','north','북부 서쪽 공영 주차장'],'17,3':['lot','north','북동 끝 공영 주차장'],
  '4,6':['lot','harbor','서부 공영 주차장'],'12,6':['lot','army','군인 아파트 공영 주차장'],'0,13':['lot','suburb','남서 끝 공영 주차장'],'7,13':['lot','slum','광산 앞 공영 주차장'],'13,16':['lot','slum','남동 시장 공영 주차장']};
const PARK_ZONES=[],PARK_SPOTS=[],GAS_ZONES=[],GAS_PRICE=1;
const GAS_AT={'0,0':['city','구도심 주유소'],'8,0':['north','북부 주유소'],'15,4':['north','북동 주유소'],'3,11':['harbor','항구 주유소'],'13,11':['army','동부 주유소'],'3,16':['suburb','남서 주유소'],'10,15':['slum','남부 주유소'],'15,15':['slum','남동 주유소']};
const JUNK_AT={'14,20':'harbor','5,15':'slum','7,16':'slum','2,11':'harbor','3,14':'slum','8,4':'north','14,2':'north','12,16':'slum'};
// per-look sign text: [big sign, small sign, menu title, menu subtitle]
const SIGNS={
  gun:{north:['총포상','NORTHSIDE ARMS','북부 총포상','NORTHSIDE ARMS'],city:['총포상','HARBOR ARMS · AMMO','하버 총포상','HARBOR ARMS'],harbor:['총포상','DOCKSIDE ARMS','부두 총포상','DOCKSIDE ARMS'],slum:['고물·총기','BACKALLEY GUNS','뒷골목 총포상','BACKALLEY GUNS'],army:['총포상','ARMY SURPLUS','군용품 총포상','ARMY SURPLUS']},
  diner:{north:['식당','NORTHSIDE DINER','북부 식당','NORTHSIDE DINER · 계산대'],city:['식당','HARBOR DINER','하버 식당','HARBOR DINER · 계산대'],harbor:['항구 식당','DOCKSIDE GRILL','항구 식당','DOCKSIDE GRILL · 계산대'],slum:['골목 식당','ALLEY KITCHEN','골목 식당','ALLEY KITCHEN · 계산대'],army:['부대찌개','MESS HALL','부대찌개 식당','MESS HALL · 계산대']},
  conv:{north:['편의점','NORTH MART 24','노스마트 24','NORTH MART · 계산대'],city:['편의점','HARBOR MART 24','하버마트 24','HARBOR MART · 계산대'],harbor:['항구마트','PIER MART 24','항구마트','PIER MART · 계산대'],slum:['구멍가게','CORNER SHOP','골목 구멍가게','CORNER SHOP · 계산대'],army:['PX 마트','PX MART','PX 마트','PX MART · 계산대']},
  garage:{city:['카센터','HARBOR MOTORS','하버 모터스','HARBOR MOTORS · 카센터'],harbor:['부두 카센터','DOCK MOTORS','부두 카센터','DOCK MOTORS · 카센터'],slum:['중고차·정비','JUNK MOTORS','고물 모터스','JUNK MOTORS · 카센터'],army:['정비창','MOTOR POOL','동부 정비창','MOTOR POOL · 카센터']},
  police:{city:['경찰서','HARBOR POLICE','경찰서 민원실','HARBOR POLICE'],harbor:['항만경찰','PORT POLICE','항만경찰대 민원실','PORT POLICE'],army:['경찰서','EAST PRECINCT','동부경찰서 민원실','EAST PRECINCT']},
  fire:{city:['소방서','FIRE STATION 1'],harbor:['소방서','FIRE STATION 2'],army:['소방서','FIRE STATION 3']},
  realty:{city:['공인중개사','HARBOR REALTY','하버 공인중개사','HARBOR REALTY'],north:['부동산','NORTHSIDE REALTY','북부 부동산','NORTHSIDE REALTY'],harbor:['항구 부동산','DOCKSIDE REALTY','항구 부동산','DOCKSIDE REALTY'],slum:['복덕방','ALLEY REALTY','골목 복덕방','ALLEY REALTY'],army:['부동산','EAST GATE REALTY','동문 부동산','EAST GATE REALTY'],suburb:['공인중개사','SUBURB HOMES','교외 공인중개사','SUBURB HOMES']},
  bank:{city:['은행','HARBOR SAVINGS BANK']},hospital:{city:['병원','HARBOR GENERAL · 24H','하버 종합병원','HARBOR GENERAL · 접수처'],army:['병원','EAST MILITARY HOSPITAL','동부 군 병원','EAST MILITARY HOSPITAL · 접수처']},cityhall:{city:['시청','CITY HALL']}
};
const SIGN_COL={realty:['#1c1230','#d9c2ff'],hotel:['#2a1a08','#ffd27a'],bank:['#13261b','#e8c66a'],hospital:['#14243a','#ff5a6a'],gun:['#160b0d','#ff4d5e'],conv:['#1a0f2e','#d9b8ff'],police:['#0d1a3a','#ffffff'],garage:['#062a33','#7ff3ff'],diner:['#2a0f08','#ffb47a'],cityhall:['#f4efe2','#2a2a33'],fire:['#3a0a08','#ffd27a']};
const LOOK={
  city:{},north:{},
  harbor:{body:{gun:0x4f5f6e,diner:0x2f5a74,conv:0xc8d0d8,police:0xc4ccd6,fire:0x9a2e26,garage:0x56636e},band:0x2e86c1,bg:'#0d2236'},
  slum:{body:{gun:0x6a4a34,diner:0x8a5a3a,conv:0x9a8a6a,garage:0x5a5048},band:0x8a3a2a,bg:'#2a1d10',fg:'#ffd27a'},
  army:{body:{gun:0x5f6648,diner:0x6a6a52,conv:0x8a8a78,police:0xb8bca8,fire:0x9a3a2a,garage:0x56603e},band:0x3a4426,bg:'#2a2e1c',fg:'#e8c547'}
};
const LOCS=[], rings=[], stationSpots=[], fireSpots=[];
const colG=new THREE.CylinderGeometry(.5,.55,9,10);
const bigColG=new THREE.CylinderGeometry(.7,.75,12,12);
const ringG=new THREE.RingGeometry(1.15,1.55,36);ringG.rotateX(-Math.PI/2);
const discG=new THREE.CircleGeometry(1.15,36);discG.rotateX(-Math.PI/2);
function addRing(x,z,color,sc){
  sc=sc||1;
  const r=mesh(ringG,new THREE.MeshBasicMaterial({color,transparent:true,opacity:.85,side:THREE.DoubleSide,depthWrite:false}),x,.25,z);r.scale.setScalar(sc);r.userData.base=sc;scene.add(r);
  const d=mesh(discG,new THREE.MeshBasicMaterial({color,transparent:true,opacity:.18,depthWrite:false}),x,.24,z);d.scale.setScalar(sc);scene.add(d);
  rings.push(r);return r;
}
const CMC={};
function corrMat(color){return CMC[color]||(CMC[color]=new THREE.MeshLambertMaterial({color,map:CORR.map}));}
// fills the rest of a landmark's block in the look of its neighbourhood
function fillLot(look,x0,x1,z0,z1,tall){
  if(x1-x0<4||z1-z0<4)return;
  if(look==='harbor'){const h=rand(7,11);boxI('wh',CORR,x0,x1,z0,z1,0,h,pick([0x5a6a7a,0x7a5a4a,0x4a6a5a,0x6a6a72]),true);boxI('whroof',PLAIN,x0-.3,x1+.3,z0-.3,z1+.3,h,.35,0x3a3d44,false);}
  else if(look==='slum')slumBlock(x0,x1,z0,z1);
  else if(look==='army')building(x0,x1,z0,z1,tall?rand(16,26):rand(10,16),{tints:APT_TINT,v:1,neon:0});
  else building(x0,x1,z0,z1,tall?rand(14,30):rand(10,18));
}
// small props by the door that say which part of town this is
function lookProps(look,fx,s,cz,T){
  const px=fx+s*1.6,side=T.d/2-1.4;
  if(look==='harbor'){
    for(const o of [-side,side]){inst('bollard',cylG,PLAIN,fx+s*3.2,.6,cz+o,.28,.8,.28,0,0x2a2c30);}
    boxI('crate',CORR,px-.7,px+.7,cz-side-.2,cz-side+1.2,.22,1.3,0x8a6a3a,true);boxI('crate',CORR,px-.6,px+.6,cz-side,cz-side+1.1,1.52,1.1,0x7a5a2a,false);
    inst('rope',cylG,PLAIN,px,.32,cz+side-.4,.5,.2,.5,0,0xc9b48a);
  } else if(look==='slum'){
    for(let k=0;k<3;k++)inst('barrel',cylG,PLAIN,px+rand(-.5,.5),.6,cz-side+k*.85,.35,.9,.35,0,pick([0x2f5e8a,0x8a3a2a,0x3a6a3a]));
    inst('tarp',UNIT,PLAIN,fx+s*1.3,3.1,cz,2.6,.06,5,0,pick([0x2f6fb0,0x3a8a5a,0xb05a2f]));
    for(const o of [-2.4,2.4])inst('tpole',UNIT,PLAIN,fx+s*2.5,1.55,cz+o,.1,3.1,.1,0,0x5a4a3a);
  } else if(look==='army'){
    for(const o of [-1,1]){boxI('sand',PLAIN,px-.5,px+.5,cz+o*3.2-1.4,cz+o*3.2+1.4,.22,1,0x9a8a6a,true);}
    inst('fpole',UNIT,PLAIN,fx+s*2.6,4,cz+side,.12,8,.12,0,0x6a6a60);
    inst('flag',UNIT,UNLIT,fx+s*2.6,7.2,cz+side-.9,.04,1,1.7,0,0x4a5a2a);
    inst('camo',UNIT,PLAIN,fx+s*1.2,T.h+.2,cz,2.4,.08,T.d*.7,0,0x3a4a2a);
  }
}
function buildLoc(type,face,bx0,bx1,bz0,bz1,look,names){
  look=look||'city';
  let padSpot=null;
  const T=type==='hotel'?Object.assign({},LOC_TYPES.hotel,{h:{city:46,suburb:16,army:30}[look]||30,w:look==='suburb'?24:20}):LOC_TYPES[type],LK=LOOK[look]||{},ix0=bx0+3,ix1=bx1-3,iz0=bz0+3,iz1=bz1-3,cz=(iz0+iz1)/2,west=face==='w';
  const x0=west?ix0+.7:ix1-.7-T.w,x1=x0+T.w,z0=cz-T.d/2,z1=cz+T.d/2;
  const body=(LK.body&&LK.body[type])||T.body;
  const m=mesh(UNIT,look==='harbor'&&type!=='police'&&type!=='fire'?corrMat(body):mat(body),(x0+x1)/2,T.h/2,cz);m.scale.set(T.w,T.h,T.d);scene.add(m);addCollider(x0,x1,z0,z1,T.h);BLDGS.push({x0,x1,z0,z1,h:T.h});
  const fx=west?x0:x1,s=west?-1:1,rot=west?-Math.PI/2:Math.PI/2;
  const r0=west?x1+.7:ix0+.7,r1=west?ix1-.7:x0-.7;
  if(r1-r0>4)fillLot(look,r0,r1,iz0+.7,iz1-.7,true);
  const RAMPED=type==='police'||type==='fire'||type==='garage'||type==='hospital'||type==='cityhall'||type==='cityoffice';
  if(z0-(iz0+.7)>5&&type!=='garage'&&type!=='cityhall'&&type!=='cityoffice')fillLot(look,x0,x1,iz0+.7,z0-.7,false);
  if((iz1-.7)-z1>5&&!RAMPED)fillLot(look,x0,x1,z1+.7,iz1-.7,false);
  const SG=names||(SIGNS[type]&&(SIGNS[type][look]||SIGNS[type].city))||[T.name,''],SC=SIGN_COL[type]||['#111','#fff'];
  const sbg=look==='city'?SC[0]:LK.bg||SC[0],sfg=look==='city'?SC[1]:LK.fg||SC[1];
  if(type!=='fire'){const door=mesh(UNIT,bmat(0xffd890),fx+s*.06,1.6,cz);door.scale.set(.1,3.2,2.8);scene.add(door);}
  const sign=(y,w,h)=>signPlane([SG[0],SG[1]],sbg,sfg,fx+s*.08,y,cz,w,h,rot);
  if(type==='bank'){
    for(const o of [-13.5,-9,-4.5,4.5,9,13.5]){const c=mesh(colG,mat(0xece4d0),fx+s*1.3,4.5,cz+o);scene.add(c);addCollider(fx+s*1.3-.5,fx+s*1.3+.5,cz+o-.5,cz+o+.5,9,true);}
    const ped=mesh(UNIT,mat(0xcfc4a8),fx+s*1.3,9.6,cz);ped.scale.set(3.2,1.3,T.d);scene.add(ped);
    const st=mesh(UNIT,mat(0xbab09a),fx+s*1.5,.3,cz);st.scale.set(3,.36,10);scene.add(st);
    sign(15,13,4);
  } else if(type==='hospital'){
    // rooftop helipad: dark square, white H, amber edge lights
    {const px=(x0+x1)/2,y=T.h;boxI('hpPad',PLAIN,px-6,px+6,cz-6,cz+6,y,.06,0x3a3c44,false);
      boxI('hpH',UNLIT,px-2.2,px-1.4,cz-3,cz+3,y+.06,.02,0xf2f2f2,false);boxI('hpH',UNLIT,px+1.4,px+2.2,cz-3,cz+3,y+.06,.02,0xf2f2f2,false);boxI('hpH',UNLIT,px-1.4,px+1.4,cz-.4,cz+.4,y+.06,.02,0xf2f2f2,false);
      for(let k=0;k<8;k++){const a=k/8*Math.PI*2;inst('hpLight',UNIT,UNLIT,px+Math.cos(a)*5.6,y+.15,cz+Math.sin(a)*5.6,.3,.15,.3,0,0xffc21a);}
      padSpot={x:px,z:cz,y:y+.06};}
    const v=mesh(UNIT,bmat(0xff3344),fx+s*.12,14,cz-8);v.scale.set(.2,4.4,1.4);scene.add(v);
    const h=mesh(UNIT,bmat(0xff3344),fx+s*.12,14,cz-8);h.scale.set(.2,1.4,4.4);scene.add(h);
    const can=mesh(UNIT,mat(0xd8dde6),fx+s*1.6,3.9,cz);can.scale.set(3.2,.25,9);scene.add(can);
    sign(20,14,4.4);
  } else if(type==='gun'){
    for(const o of [-5,5]){const w=mesh(UNIT,bmat(look==='army'?0x2a2e1c:0x3a2418),fx+s*.06,2,cz+o);w.scale.set(.1,2.2,3.4);scene.add(w);}
    if(look!=='city')for(const y of [1.2,2,2.8]){const b=mesh(UNIT,mat(0x2a2a2e),fx+s*.12,y,cz);b.scale.set(.06,.08,T.d-2);scene.add(b);}
    sign(6.3,10,3);
  } else if(type==='conv'){
    const gl=mesh(UNIT,bmat(0xdff3ff),fx+s*.05,1.7,cz);gl.scale.set(.08,2.6,T.d-3);scene.add(gl);
    for(let o=-T.d/2+2;o<=T.d/2-2+.01;o+=2.5){const mm=mesh(UNIT,mat(0x2a2a33),fx+s*.1,1.7,cz+o);mm.scale.set(.12,2.7,.12);scene.add(mm);}
    const aw=mesh(UNIT,bmat(look==='army'?0x4a5a2a:look==='harbor'?0x2e86c1:look==='slum'?0xb05a2f:0x8f4dff),fx+s*.7,3.35,cz);aw.scale.set(1.4,.35,T.d);scene.add(aw);
    sign(4.75,8,2.2);
  } else if(type==='police'){
    const band=mesh(UNIT,mat(look==='army'?0x3a4426:look==='harbor'?0x1a3a6a:0x1f4fa8),(x0+x1)/2,4.4,cz);band.scale.set(T.w+.12,.9,T.d+.12);scene.add(band);
    for(const o of [-2.4,2.4]){const l=mesh(UNIT,bmat(0x3f8cff),fx+s*.3,3.2,cz+o);l.scale.set(.4,.4,.4);scene.add(l);}
    sign(8.4,12,3.6);
    const px=west?bx0-1:bx1+1,h=west?Math.PI:0;
    stationSpots.push({x:px,z:cz-10,h},{x:px,z:cz+10,h});
  } else if(type==='garage'){
    for(const o of [-5,5]){const bay=mesh(UNIT,bmat(0x9ff3ff),fx+s*.06,2.2,cz+o);bay.scale.set(.1,4.2,7);scene.add(bay);
      for(let k=0;k<6;k++){const sl=mesh(UNIT,mat(0x3a4250),fx+s*.1,.6+k*.7,cz+o);sl.scale.set(.06,.08,7);scene.add(sl);}}
    const band=mesh(UNIT,bmat(look==='city'?0x37e6ff:look==='army'?0xe8c547:0xffb53d),fx+s*.08,4.6,cz);band.scale.set(.1,.18,T.d-1);scene.add(band);
    sign(6.3,10,2.6);
  } else if(type==='diner'){
    const gl=mesh(UNIT,bmat(0xffd9a0),fx+s*.05,1.6,cz);gl.scale.set(.08,2.2,T.d-4);scene.add(gl);
    for(let o=-T.d/2+2;o<=T.d/2-2+.01;o+=2){const mm=mesh(UNIT,mat(0x3a2418),fx+s*.1,1.6,cz+o);mm.scale.set(.12,2.3,.12);scene.add(mm);}
    const stA=look==='harbor'?0x2e86c1:look==='army'?0x4a5a2a:0xd23a2a;
    const n=Math.floor(T.d/1.4);for(let k=0;k<n;k++){const st=mesh(UNIT,bmat(k%2?0xf4efe4:stA),fx+s*.8,3.1,cz-T.d/2+.7+k*1.4);st.scale.set(1.6,.3,1.4);scene.add(st);}
    sign(5.1,8,2.4);
  } else if(type==='cityoffice'){
    const pole=mesh(UNIT,mat(0xc8ccd4),fx+s*2.2,5,cz+T.d/2-2);pole.scale.set(.15,10,.15);scene.add(pole);
    const fl=mesh(UNIT,mat(0x1f4fa8),fx+s*2.2,9.2,cz+T.d/2-1.2);fl.scale.set(.05,1,1.6);scene.add(fl);
    const can=mesh(UNIT,mat(0x2f6a46),fx+s*1.4,3.4,cz);can.scale.set(2.6,.25,7);scene.add(can);
    sign(7.6,12,2.2);
  } else if(type==='cityhall'){
    for(let o=-10;o<=10.01;o+=4){const c=mesh(bigColG,mat(0xf0eadb),fx+s*1.05,6,cz+o);c.scale.set(.75,1,.75);scene.add(c);addCollider(fx+s*1.05-.5,fx+s*1.05+.5,cz+o-.5,cz+o+.5,12,true);}
    const port=mesh(UNIT,mat(0xd8d0bb),fx+s*1.1,12.7,cz);port.scale.set(2.6,1.4,T.d-2);scene.add(port);
    const st=mesh(UNIT,mat(0xc8bfa8),fx+s*.8,.12,cz);st.scale.set(1.6,.1,T.d-6);scene.add(st);
    const drum=mesh(new THREE.CylinderGeometry(6,6,4,28),mat(0xe0d9c6),(x0+x1)/2,T.h+2,cz);scene.add(drum);
    const dome=mesh(new THREE.SphereGeometry(6.2,28,12,0,Math.PI*2,0,Math.PI/2),mat(0x5f8f86),(x0+x1)/2,T.h+4,cz);scene.add(dome);
    const pole=mesh(UNIT,mat(0x3a3a46),(x0+x1)/2,T.h+12.2,cz);pole.scale.set(.15,4,.15);scene.add(pole);
    const flag=mesh(UNIT,bmat(0xffb53d),(x0+x1)/2,T.h+13.6,cz+.85);flag.scale.set(.05,1,1.6);scene.add(flag);
    sign(15.6,12,3.4);
  } else if(type==='hotel'){
    // window grid on the street face and the long side, a canopy over the door, a vertical sign and a rooftop name
    const wc=look==='suburb'?0xffe2a8:look==='army'?0xe8e0b0:0xffd890;
    for(let y=4.6;y<T.h-1.5;y+=3.2){
      for(let o=-T.d/2+2;o<=T.d/2-2+.01;o+=2.6){if(y<5&&Math.abs(o)<4)continue;inst('hwin',UNIT,UNLIT,fx+s*.06,y,cz+o,.08,1.5,1.4,0,RNG()<.75?wc:0x2a2c38);}
      for(let o=x0+2;o<=x1-2+.01;o+=2.6){inst('hwin',UNIT,UNLIT,o,y,z0-.06,1.4,1.5,.08,0,RNG()<.7?wc:0x2a2c38);inst('hwin',UNIT,UNLIT,o,y,z1+.06,1.4,1.5,.08,0,RNG()<.7?wc:0x2a2c38);}
    }
    const can=mesh(UNIT,mat(look==='army'?0x4a5a2a:0x7a1a2a),fx+s*1.8,3.4,cz);can.scale.set(3.6,.3,7);scene.add(can);
    for(const o of [-3.2,3.2]){const p=mesh(UNIT,mat(0xd8c890),fx+s*3.4,1.7,cz+o);p.scale.set(.18,3.4,.18);scene.add(p);}
    const cp=mesh(UNIT,mat(0x7a1a2a),fx+s*2.4,.25,cz);cp.scale.set(4.6,.04,2.4);scene.add(cp);
    signPlane([SG[0],SG[1]],sbg,sfg,fx+s*.1,Math.min(T.h-3,11),cz-T.d/2+3.2,7,2.2,rot);
    const top=signPlane(['HOTEL',SG[0]],'#120a04','#ffd27a',(x0+x1)/2,T.h+1.6,cz,10,2.6,rot);top.position.x=fx-s*.4;
    const rf=mesh(UNIT,mat(0x3a3a46),(x0+x1)/2,T.h+.2,cz);rf.scale.set(T.w-1,.4,T.d-1);scene.add(rf);
    sign(4.6,8,1.8);
  } else if(type==='fire'){
    // three engine bays, a white band, the hose-drying tower at the back and a concrete apron
    for(const o of [-9,0,9]){
      const d=mesh(UNIT,mat(0xe4e0d8),fx+s*.06,2.6,cz+o);d.scale.set(.1,5.2,7);scene.add(d);
      for(let k=0;k<6;k++){const sl=mesh(UNIT,mat(0xb0aaa0),fx+s*.1,.7+k*.8,cz+o);sl.scale.set(.06,.08,7);scene.add(sl);}
      const fr=mesh(UNIT,mat(0xf2f2f2),fx+s*.08,5.4,cz+o);fr.scale.set(.12,.35,7.6);scene.add(fr);
      const num=mesh(UNIT,bmat(0xffd27a),fx+s*.1,6.1,cz+o);num.scale.set(.06,.5,.5);scene.add(num);
    }
    const band=mesh(UNIT,mat(0xf2f2f2),(x0+x1)/2,8.2,cz);band.scale.set(T.w+.12,.5,T.d+.12);scene.add(band);
    const tx=west?x1-3:x0+3,tz=cz-T.d/2+3;
    const tw=mesh(UNIT,mat(body),tx,(T.h+10)/2,tz);tw.scale.set(5,T.h+10,5);scene.add(tw);addCollider(tx-2.5,tx+2.5,tz-2.5,tz+2.5,T.h+10);
    const twr=mesh(UNIT,mat(0x3a2a28),tx,T.h+10.2,tz);twr.scale.set(5.6,.4,5.6);scene.add(twr);
    for(const o of [-4.5,4.5]){const l=mesh(UNIT,bmat(0xff3a2a),fx+s*.3,7.2,cz+o);l.scale.set(.4,.4,.4);scene.add(l);}
    const ap=mesh(UNIT,mat(0x8a8a90),(fx+(west?bx0:bx1))/2,.235,cz);ap.scale.set(Math.abs(fx-(west?bx0:bx1)),.03,T.d);scene.add(ap);
    sign(9.6,12,3.4);
    fireSpots.push({x:west?bx0-1:bx1+1,z:cz+10,h:west?Math.PI:0});
  }
  lookProps(look,fx,s,cz,T);
  const zx=west?bx0+1.6:bx1-1.6;
  // underground car park: a covered ramp down beside the building, shutter closed at the bottom
  let ramp=null,lot=null;
  if(RAMPED){
    const za=z1+.7,zb=iz1-.7,rz=(za+zb)/2,e=west?bx0:bx1,deep=9,xa=fx-s*deep;
    const lo=Math.min(fx,xa),hi=Math.max(fx,xa);
    for(const wz of [za,zb]){boxI('rampw',PLAIN,lo,hi,wz-.18,wz+.18,0,3.1,0x6a6e78,true);}
    boxI('rampr',PLAIN,lo,hi,za-.2,zb+.2,3.1,.35,0x50545e,false);
    boxI('rampf',PLAIN,lo,hi,za+.18,zb-.18,0,.04,0x15161b,false);
    boxI('ramps',PLAIN,Math.min(xa,xa+s*.4),Math.max(xa,xa+s*.4),za,zb,0,3.1,0x2a2c33,true);
    for(let k=0;k<5;k++)boxI('rampsl',PLAIN,Math.min(xa+s*.42,xa+s*.46),Math.max(xa+s*.42,xa+s*.46),za+.2,zb-.2,.3+k*.55,.07,0x4a4e58,false);
    for(let k=0;k<4;k++){const q=lo+(hi-lo)*(k+.5)/4;boxI('rampstr',PLAIN,q-.4,q+.4,za+.4,zb-.4,.05,.02,0xe8c547,false);}
    signPlane(['지하주차장','PARKING ↓'],'#16243c','#ffffff',fx+s*.1,3.85,rz,Math.max(3,zb-za-.4),1.1,rot);
    ramp={in:{x:fx-s*3.5,z:rz},mouth:{x:e+s*5.5,z:rz},out:west?-Math.PI/2:Math.PI/2,lane:west?-1:1};
  }
  if(type==='garage'){ // the repair yard: two bays where fixed cars wait
    const za=iz0+.7,zb=z0-.7,lz=(za+zb)/2;
    boxI('lotf',PLAIN,Math.min(fx-s*4,west?bx0:bx1),Math.max(fx-s*4,west?bx0:bx1),za,zb,.235,.03,0x3a3d44,false);
    for(const o of [-4.2,0,4.2])boxI('lotl',UNLIT,Math.min(fx-s*3.6,fx+s*1.4),Math.max(fx-s*3.6,fx+s*1.4),lz+o-.07,lz+o+.07,.268,.01,0xf2f2f2,false);
    boxI('lotl',UNLIT,Math.min(fx-s*3.6,fx-s*3.46),Math.max(fx-s*3.6,fx-s*3.46),lz-4.2,lz+4.2,.268,.01,0xf2f2f2,false);
    signPlane(['수리 완료','READY'],'#0e3a44','#9ff3ff',fx-s*4.1,2.2,lz,3.2,1,rot);
    lot={spots:[{x:fx-s*1,z:lz-2.1},{x:fx-s*1,z:lz+2.1}],h:west?-Math.PI/2:Math.PI/2,exit:{x:(west?bx0:bx1)+s*3.5,z:lz}};
    PARK_ZONES.push({x0:bx0,x1:bx1,z0:bz0,z1:bz1,name:'카센터'});
  }
  if(type==='cityhall'||type==='cityoffice'){ // city car park beside the hall; towed cars are kept here
    const za=iz0+.7,zb=z0-.7,lz=(za+zb)/2,e=west?bx0:bx1,far=fx-s*(T.w-.5);
    boxI('lotf',PLAIN,Math.min(far,e),Math.max(far,e),za,zb,.235,.03,0x34363e,false);
    const spots=[];
    for(let k=0,nk=Math.floor((T.w-3)/3);k<nk;k++){const x=fx-s*(2.2+k*3);spots.push({x,z:lz,h:0});boxI('lotl',UNLIT,Math.min(x-s*1.5-.07,x-s*1.5+.07),Math.max(x-s*1.5-.07,x-s*1.5+.07),za+.4,zb-.4,.268,.01,0xf2f2f2,false);}
    boxI('lotl',UNLIT,Math.min(fx-s*.7,fx-s*.56),Math.max(fx-s*.7,fx-s*.56),za+.4,zb-.4,.268,.01,0xf2f2f2,false);boxI('lotl',UNLIT,Math.min(fx-s*.7,far),Math.max(fx-s*.7,far),zb-.47,zb-.33,.268,.01,0xf2f2f2,false);
    signPlane([type==='cityoffice'?'출장소 주차장':'시청 주차장','CITY PARKING · 견인 차량 보관소'],'#0d2a4a','#ffffff',fx-s*.2,2.6,za+.3,5,1.1,0);
    lot={spots,h:0,exit:{x:e+s*3.5,z:lz},impound:true};
    PARK_ZONES.push({x0:Math.min(far,e),x1:Math.max(far,e),z0:za,z1:zb,name:type==='cityoffice'?'출장소 주차장':'시청 주차장'});
  }
  if(type==='realty'){
    for(let k=-1;k<=1;k++){const p=mesh(UNIT,bmat(pick([0xfff4d6,0xe8f4ff,0xffe8f0])),fx+s*.07,1.9,cz+k*2.2);p.scale.set(.05,.9,.7);scene.add(p);}
    const gl=mesh(UNIT,bmat(0xdcefff),fx+s*.05,1.8,cz);gl.scale.set(.06,2.4,T.d-4);scene.add(gl);
    sign(4.4,8,1.8);
  }
  const loc={type,T,look,name:T.name,title:SG[2]||T.title,sub:SG[3]||T.sub,sign:[SG[0],SG[1]],door:new V3(zx,0,cz),out:{x:s,z:0},robCD:0,room:null,
    spawnSpot:{x:west?bx0-1:bx1+1,z:cz+(T.service?9:0),h:west?Math.PI:0},roadX:west?bx0-HALF_ROAD:bx1+HALF_ROAD,cz,noDoor:!!T.noDoor,ramp,lot,pad:padSpot};
  if(ramp)loc.spawnSpot={x:ramp.mouth.x,z:ramp.mouth.z,h:west?Math.PI:0};
  if(!T.noDoor)addRing(zx,cz,T.color,T.service?2.1:1);
  LOCS.push(loc);return loc;
}

// ---------- world layout: 3×3 regions ----------
//   NW old downtown │ N city+suburb   │ NE city+suburb
//   W  harbour+mix  │ C mountain      │ E  military base
//   SW suburb+slum  │ S mine+slum     │ SE slum+army flats
//   (three rows)    south industrial estate behind a fence, gates on the two coast roads
const REGION=[['city','mixN','mixNE'],['harborW','mountain','base'],['subSlum','mineSlum','slumApt'],['industry','industry','industry']];
const REGION_NAME={city:'구도심',mixN:'북부 시가지',mixNE:'북동 시가지',harborW:'서부 항구',mountain:'중앙 산',base:'군인 아파트',subSlum:'남서 교외',mineSlum:'광산 · 빈민가',slumApt:'남동 빈민가',industry:'남부 공단'};
const regionOf=(i,j)=>REGION[Math.floor(j/6)][Math.floor(i/6)];
function blockKind(i,j){
  const reg=regionOf(i,j),li=i%6,lj=j%6,r=RNG(),mineCol=li===2||li===3;
  switch(reg){
    case 'mixN':return r<.5?'midcity':'suburb';
    case 'mixNE':return r<.4?'midcity':'suburb';
    case 'harborW':return li<=1?'harbor':(r<.5?'midcity':'suburb');
    case 'mountain':return 'mountain';
    case 'base':return li>=3&&lj>=2&&lj<=4?'base':'apartments'; // the walled base hugs the coast; army flats fill the rest
    case 'subSlum':return r<.55?'suburb':'slum';
    case 'mineSlum':return mineCol&&lj===0?'mountain':mineCol&&lj===1?'mineyard':'slum'; // the mountain's southern ridge holds the mine
    case 'slumApt':return r<.5?'slum':'apartments';
    case 'industry':return r<.17?'prefab':'factory'; // mostly plants and sheds, a few prefab worker flats
  }
  return 'city';
}
const KIND_GROUND={factory:0x5c5e60,prefab:0x5e5a56,city:0x5d5a6a,park:0x5d5a6a,midcity:0x5d5a6a,apartments:0x5f5d66,suburb:0x6c6a72,slum:0x5a4a3a,mine:0x4e4236,mineyard:0x5a4a3a,mountain:0x4c5a3a,base:0x67685a,harbor:0x55565e};
const KIND_MAP={factory:'#3a3b40',prefab:'#3f3a36',city:'#24263a',midcity:'#2a2c40',apartments:'#34343e',suburb:'#2e3b33',slum:'#3e3128',mine:'#4d3b2a',mineyard:'#45372a',mountain:'#4a4434',base:'#3b4130',harbor:'#2c3445'};
const WALKABLE=new Set(['city','park','midcity','apartments','suburb','slum','harbor','mineyard','factory','prefab']);

// static scenery outside the old downtown is batched into instanced meshes (one draw call per prop type)
const BATCH=new Map();
function inst(key,geo,mt,x,y,z,sx,sy,sz,ry,color){let b=BATCH.get(key);if(!b){b={geo,mt,list:[]};BATCH.set(key,b);}b.list.push([x,y,z,sx,sy,sz,ry||0,color==null?0xffffff:color]);}
function flushBatches(){
  const m4=new THREE.Matrix4(),q=new THREE.Quaternion(),p=new V3(),s=new V3(),col=new THREE.Color();
  for(const b of BATCH.values()){
    const im=new THREE.InstancedMesh(b.geo,b.mt,b.list.length);
    b.list.forEach((t,i)=>{p.set(t[0],t[1],t[2]);q.setFromAxisAngle(Y,t[6]);s.set(t[3],t[4],t[5]);m4.compose(p,q,s);im.setMatrixAt(i,m4);col.setHex(t[7]);im.setColorAt(i,col);});
    if(im.instanceColor)im.instanceColor.needsUpdate=true;
    im.frustumCulled=false;scene.add(im);
  }
  BATCH.clear();
}
const PLAIN=new THREE.MeshLambertMaterial({color:0xffffff});
const UNLIT=new THREE.MeshBasicMaterial({color:0xffffff});
const CORR=new THREE.MeshLambertMaterial({map:(()=>{const c=document.createElement('canvas');c.width=64;c.height=8;const g=c.getContext('2d');for(let x=0;x<64;x+=4){g.fillStyle=x%8?'#d8d8d8':'#a4a4a4';g.fillRect(x,0,4,8);}const t=new THREE.CanvasTexture(c);t.wrapS=t.wrapT=THREE.RepeatWrapping;t.repeat.set(3,1);return t;})()});
const HOUSE=(()=>{
  const a=document.createElement('canvas'),b=document.createElement('canvas');a.width=a.height=b.width=b.height=64;
  const ga=a.getContext('2d'),gb=b.getContext('2d');
  ga.fillStyle='#ece6da';ga.fillRect(0,0,64,64);gb.fillStyle='#000';gb.fillRect(0,0,64,64);
  ga.fillStyle='#6b6258';ga.fillRect(0,0,64,3);
  [[9,12],[41,12]].forEach(([x,y],k)=>{ga.fillStyle='#2e3850';ga.fillRect(x,y,14,12);ga.fillStyle='#f4f0e8';ga.fillRect(x+6,y,2,12);if(k){gb.fillStyle='#ffcf7a';gb.fillRect(x,y,14,12);}});
  ga.fillStyle='#5a3a2a';ga.fillRect(25,38,12,26);ga.fillStyle='#2e3850';ga.fillRect(44,40,12,10);gb.fillStyle='#ffd08a';gb.fillRect(44,40,12,10);
  return new THREE.MeshLambertMaterial({map:new THREE.CanvasTexture(a),emissive:0xffffff,emissiveMap:new THREE.CanvasTexture(b),emissiveIntensity:.8});
})();
const roofG=new THREE.ConeGeometry(1,1,4);roofG.rotateY(Math.PI/4);
const rockG=(()=>{const g=new THREE.IcosahedronGeometry(1,2),p=g.attributes.position;
  for(let i=0;i<p.count;i++){const x=p.getX(i),y=p.getY(i),z=p.getZ(i),n=1+.16*Math.sin(x*5.1+z*3.7)+.1*Math.sin(y*7.3+x*2.1);p.setXYZ(i,x*n,y*n,z*n);}
  g.computeVertexNormals();return g;})();
const pineG=new THREE.ConeGeometry(1,1,7);
const cylG=new THREE.CylinderGeometry(1,1,1,16);
const hangarG=new THREE.CylinderGeometry(1,1,1,18,1,false,0,Math.PI);hangarG.rotateZ(Math.PI/2); // half-cylinder with half-disc ends, dome up, axis along x
const HOUSE_TINT=[0xf2e6cf,0xd8e6d2,0xe8d2d2,0xd2dcea,0xeee0b8,0xd9d0e6];
const ROOF_COL=[0x7a3b2e,0x4a4f5a,0x5a4030,0x2f4a5e,0x6b2f2f];
const SHACK_COL=[0x8a5a3a,0x6f7a80,0x7a6a5a,0x5a6a7a,0x9a8a6a,0x6a5040,0x7a3a2a];
const SROOF_COL=[0x8c8f94,0x7a4a30,0x5f7a8a,0x6a6a5a];
const CONT_COL=[0xc0392b,0x2e86c1,0xe67e22,0x16a085,0xd4ac0d,0x8e44ad,0x7f8c8d,0x2c3e50];
const ROCK_COL=[0x6b6458,0x5e574c,0x726a5c,0x645e56];
const ARMY=0x5f6648,APT_TINT=[0x8a8a78,0x7f8270,0x9a9580,0x8a8270];
function treeI(x,z,s){s=s||1;inst('trunk',trunkG,PLAIN,x,1.2*s,z,s,s,s,0,0x4a3526);inst('crown',crownG,PLAIN,x,3.6*s,z,s,1.15*s,s,rand(0,6),pick([0x2f6b45,0x3a7a4a,0x285c3c]));addCollider(x-.35,x+.35,z-.35,z+.35,4,true);}
function pineI(x,z,s){s=s||1;inst('trunk',trunkG,PLAIN,x,.9*s,z,.7*s,.75*s,.7*s,0,0x4a3526);inst('pine',pineG,PLAIN,x,4.6*s,z,1.8*s,6*s,1.8*s,rand(0,6),pick([0x1f4a30,0x24553a,0x2a5e3c]));addCollider(x-.35,x+.35,z-.35,z+.35,5,true);}
function boxI(key,mt,x0,x1,z0,z1,y0,h,color,collide){inst(key,UNIT,mt,(x0+x1)/2,y0+h/2,(z0+z1)/2,x1-x0,h,z1-z0,0,color);if(collide)addCollider(x0,x1,z0,z1,y0+h);}

function cityBlock(ix0,ix1,iz0,iz1,boost,o){
  const W=ix1-ix0,D=iz1-iz0,r=RNG();let lots;
  if(r<.2) lots=[[ix0,ix1,iz0,iz1]];
  else if(r<.45){const m=ix0+W*rand(.38,.62);lots=[[ix0,m,iz0,iz1],[m,ix1,iz0,iz1]];}
  else if(r<.68){const m=iz0+D*rand(.38,.62);lots=[[ix0,ix1,iz0,m],[ix0,ix1,m,iz1]];}
  else {const mx=ix0+W*rand(.4,.6),mz=iz0+D*rand(.4,.6);lots=[[ix0,mx,iz0,mz],[mx,ix1,iz0,mz],[ix0,mx,mz,iz1],[mx,ix1,mz,iz1]];}
  for(const l of lots){
    const g=.7,cx=(l[0]+l[1])/2,cz=(l[2]+l[3])/2;
    building(l[0]+g,l[1]-g,l[2]+g,l[3]-g,rand(8,20)+boost(cx,cz)*rand(8,48)*(lots.length===1?.6:1),o);
  }
}
function suburbBlock(ix0,ix1,iz0,iz1){
  const W=ix1-ix0,D=iz1-iz0;
  inst('lawn',UNIT,PLAIN,(ix0+ix1)/2,.245,(iz0+iz1)/2,W,.05,D,0,0x3d6a3a);
  for(const fx of [.25,.75])for(const fz of [.25,.75]){
    const lx=ix0+W*fx,lz=iz0+D*fz,sx=fx<.5?-1:1,sz=fz<.5?-1:1;
    if(RNG()<.12){treeI(lx+rand(-4,4),lz+rand(-4,4),rand(.9,1.2));treeI(lx+rand(-4,4),lz+rand(-4,4),rand(.8,1.1));continue;}
    const w=rand(8.5,11),d=rand(7.5,9.5),h=rand(4.2,5.6);
    inst('house',UNIT,HOUSE,lx,h/2,lz,w,h,d,0,pick(HOUSE_TINT));BLDGS.push({x0:lx-w/2,x1:lx+w/2,z0:lz-d/2,z1:lz+d/2,h:h+1.5});
    inst('roof',roofG,PLAIN,lx,h+1.35,lz,w*.8,2.7,d*.8,0,pick(ROOF_COL));
    addCollider(lx-w/2,lx+w/2,lz-d/2,lz+d/2,h+2.7);
    inst('drive',UNIT,PLAIN,lx+sx*(w/2+2),.27,lz,3.2,.03,d,0,0x6b6b70);
    if(RNG()<.65)treeI(lx-sx*(w/2+2.3),lz+sz*(d/2-.5),rand(.8,1.1));
    if(RNG()<.5)boxI('fence',PLAIN,lx-9.5,lx+9.5,lz+sz*9.6-.1,lz+sz*9.6+.1,.22,1,0xe8e2d4,false);
  }
}
function slumBlock(ix0,ix1,iz0,iz1){
  const cell=7;
  for(let x=ix0+cell/2;x<ix1-1;x+=cell)for(let z=iz0+cell/2;z<iz1-1;z+=cell){
    const r=RNG();if(r<.12)continue;
    if(r<.2){for(let k=0;k<3;k++)inst('barrel',cylG,PLAIN,x+rand(-1.5,1.5),.6,z+rand(-1.5,1.5),.35,.9,.35,0,pick([0x2f5e8a,0x8a3a2a,0x3a6a3a,0x6a6a6a]));continue;}
    const w=rand(4,6),d=rand(4,6),h=rand(2.6,3.8),cx=x+rand(-.4,.4),cz=z+rand(-.4,.4);
    inst('shack',UNIT,CORR,cx,h/2,cz,w,h,d,0,pick(SHACK_COL));
    inst('sroof',UNIT,CORR,cx,h+.08,cz,w+.7,.16,d+.7,rand(-.05,.05),pick(SROOF_COL));
    if(RNG()<.4)inst('tarp',UNIT,PLAIN,cx+w/2+.6,h*.72,cz,1.3,.06,d*.8,0,pick([0x2f6fb0,0x3a8a5a,0xb05a2f]));
    if(RNG()<.6)inst('sdoor',UNIT,PLAIN,cx,1,cz+d/2+.03,1,2,.05,0,0x2a221c);
    if(RNG()<.25)inst('swin',UNIT,UNLIT,cx-w/4,1.7,cz+d/2+.04,.8,.6,.04,0,0xffb35a);
    addCollider(cx-w/2,cx+w/2,cz-d/2,cz+d/2,h);
  }
}
function harborBlock(ix0,ix1,iz0,iz1,i){
  const cx=(ix0+ix1)/2,cz=(iz0+iz1)/2;
  if(i===0){ // container yard on the quay
    for(let z=iz0+2;z+12<=iz1-1;z+=14)for(let x=ix0+2;x<ix1-2;x+=3){
      if(Math.abs(x-cx)<3||RNG()<.2)continue;
      const n=randi(1,3);for(let k=0;k<n;k++)inst('cont',UNIT,CORR,x+1.25,1.3+k*2.6,z+6,2.5,2.55,12,0,pick(CONT_COL));
      addCollider(x,x+2.5,z,z+12,n*2.6);
    }
  } else { // warehouses
    for(const s of [-1,1]){
      const x0=cx+(s<0?-19:2),x1=cx+(s<0?-2:19);
      boxI('wh',CORR,x0,x1,iz0+2,iz1-2,0,9,pick([0x5a6a7a,0x7a5a4a,0x4a6a5a,0x6a6a72]),true);
      boxI('whroof',PLAIN,x0-.4,x1+.4,iz0+1.6,iz1-1.6,9,.4,0x3a3d44,false);
      inst('whdoor',UNIT,PLAIN,s<0?x0-.05:x1+.05,3,cz,.1,6,8,0,0x2a2c30);
      inst('whlamp',UNIT,UNLIT,s<0?x0-.1:x1+.1,6.6,cz,.15,.3,1.6,0,0xffd08a);
    }
  }
}
function mineyardBlock(ix0,ix1,iz0,iz1){
  const cx=(ix0+ix1)/2,cz=(iz0+iz1)/2;
  for(let k=0;k<4;k++)inst('pile',rockG,PLAIN,ix0+6+k*9,1.4,iz0+7,4.5,2.6,4.5,rand(0,6),pick([0x6a5a48,0x5a5048,0x7a6a50]));
  // headframe: four legs, braces and the winding wheel
  const hx=cx+8,hz=cz+5;
  for(const a of [-1,1])for(const b of [-1,1])inst('hleg',UNIT,PLAIN,hx+a*2.2,8,hz+b*2.2,.4,16,.4,0,0x6a4a2a);
  for(const y of [5,10,15])inst('hbrace',UNIT,PLAIN,hx,y,hz,4.8,.3,4.8,0,0x5a3c22);
  const wheel=mesh(new THREE.CylinderGeometry(2.2,2.2,.3,20),mat(0x3a3a40),hx,17.6,hz);wheel.rotation.x=Math.PI/2;scene.add(wheel);
  addCollider(hx-2.5,hx+2.5,hz-2.5,hz+2.5,16);
  for(const z of [cz-2,cz+12]){const x=ix0+8;boxI('dump',PLAIN,x-2,x+2,z-3.5,z+2,.8,2,0xd4a017,true);boxI('dumpCab',PLAIN,x-1.4,x+1.4,z+2,z+4,.8,2.6,0xb88a10,true);}
  boxI('shack',CORR,cx-4,cx+4,iz1-9,iz1-3,0,3.6,0x7a6a5a,true);boxI('sroof',CORR,cx-4.4,cx+4.4,iz1-9.4,iz1-2.6,3.6,.2,0x8c8f94,false);
}
function junkyardBlock(bx0,bx1,bz0,bz1,look){
  const ix0=bx0+3,ix1=bx1-3,iz0=bz0+3,iz1=bz1-3,cx=(ix0+ix1)/2,cz=(iz0+iz1)/2,FC=look==='harbor'?0x5a6a7a:0x7a6a5a,fh=2.6;
  // corrugated fence, gate on the west side
  boxI('jfence',CORR,ix0,ix1,iz0-.15,iz0+.15,0,fh,FC,true);boxI('jfence',CORR,ix0,ix1,iz1-.15,iz1+.15,0,fh,FC,true);
  boxI('jfence',CORR,ix1-.15,ix1+.15,iz0,iz1,0,fh,FC,true);
  boxI('jfence',CORR,ix0-.15,ix0+.15,iz0,cz-5,0,fh,FC,true);boxI('jfence',CORR,ix0-.15,ix0+.15,cz+5,iz1,0,fh,FC,true);
  inst('ground',UNIT,PLAIN,cx,.235,cz,ix1-ix0,.03,iz1-iz0,0,0x4e4438);
  // scrap heaps you can dig through
  for(const [hx,hz] of [[cx+7,iz0+7],[cx+7,iz1-7],[ix1-7,cz],[cx-5,iz0+7]]){
    for(let k=0;k<4;k++)inst('pile',rockG,PLAIN,hx+rand(-1.6,1.6),rand(.6,1.2),hz+rand(-1.6,1.6),rand(2,3),rand(1.2,2.2),rand(2,3),rand(0,6),pick([0x7a4a2a,0x5a5048,0x6a6a72,0x8a5a32,0x4a4a50]));
    for(let k=0;k<4;k++)inst('junkbit',UNIT,PLAIN,hx+rand(-2.4,2.4),rand(.4,1.6),hz+rand(-2.4,2.4),rand(.4,1.4),rand(.1,.5),rand(.3,1.2),rand(0,6),pick([0x8a8a90,0x5a3a2a,0xb05a2f,0x2f5e8a]));
    addCollider(hx-1.8,hx+1.8,hz-1.8,hz+1.8,2);
    const dx=cx-hx,dz=cz-hz,dl=Math.hypot(dx,dz)||1,sx=hx+dx/dl*3.3,sz=hz+dz/dl*3.3;
    heaps.push({pos:new V3(sx,0,sz),cd:0,room:null,loot:'junk'});addRing(sx,sz,0xc9a26a,.75);
  }
  // crushed cars and tyres
  for(const [x,z] of [[ix0+6,iz1-8],[ix0+12,iz1-8]])for(let k=0;k<3;k++)boxI('crush',PLAIN,x-2,x+2,z-1,z+1,k*1.05,1,pick([0x6a3030,0x3a4a6a,0x7a7a70,0x4a5a3a,0x8a7a4a]),k===0);
  for(let k=0;k<7;k++)inst('tyre',cylG,PLAIN,ix0+5+rand(0,6),.25+(k%3)*.32,iz0+5+rand(0,4),.5,.3,.5,0,0x1a1a1c);
  // magnet crane
  boxI('craneBase',PLAIN,cx-1.5,cx+1.5,cz-1.5,cz+1.5,0,1.2,0xd8a020,true);
  inst('craneMast',UNIT,PLAIN,cx,5,cz,.6,8,.6,0,0xd8a020);inst('craneArm',UNIT,PLAIN,cx+4,8.8,cz,9,.5,.5,0,0xd8a020);
  inst('magnet',cylG,PLAIN,cx+8,5.6,cz,1.2,.4,1.2,0,0x2a2a2e);inst('cable',UNIT,PLAIN,cx+8,7.2,cz,.05,3,.05,0,0x111111);
  // office shack by the gate
  boxI('shack',CORR,ix0+1,ix0+7,cz+6,cz+12,0,3.2,0x8a7a6a,true);boxI('sroof',CORR,ix0+.6,ix0+7.4,cz+5.6,cz+12.4,3.2,.18,0x8c8f94,false);
  inst('swin',UNIT,UNLIT,ix0+7.03,1.8,cz+9,.04,.8,1.2,0,0xffb35a);
  signPlane(['고물상','SCRAP · SALVAGE'],'#2a1d10','#ffd27a',ix0-.2,3.5,cz-9,6,1.9,-Math.PI/2);
  LOCS.push({type:'junk',T:LOC_TYPES.junk,look,name:'고물상',title:'고물상',sub:'',sign:['고물상',''],door:new V3(cx,0,cz),out:{x:-1,z:0},robCD:0,room:null,noDoor:true,cz});
}
function apartmentsBlock(ix0,ix1,iz0,iz1){
  const o={tints:APT_TINT,v:1,neon:0};
  building(ix0+.7,ix1-.7,iz0+.7,iz0+11,rand(16,26),o);
  building(ix0+.7,ix1-.7,iz1-11,iz1-.7,rand(16,26),o);
  const cz=(iz0+iz1)/2;
  for(let k=0;k<4;k++)treeI(ix0+5+k*10,cz+rand(-3,3),rand(.8,1));
  boxI('bench',PLAIN,ix0+8,ix0+11,cz-.4,cz+.4,.22,.5,0x6a4a2a,false);
}

// ---------- the industrial estate: plants, sheds and tank farms, each with a loading dock on its south street ----------
const FACTORY_DOCKS=[],SMOKE_STACKS=[];
const FAC_COL=[0x7a8590,0x8a7a6a,0x6a7a6a,0x9a9488,0x5a6a7a,0x8a6a5a,0xa09a8a];
const FAC_NAMES=['대성 금속','한빛 화학','동양 섬유','남부 제지','세진 기계','하버 식품','광명 전자','태양 플라스틱','신흥 철강','바다 수산가공','미래 부품','삼호 도료','청운 유리','네온 인쇄','대륙 시멘트','한결 가구'];
let facNameK=0;
function stackI(x,z,h,r){
  inst('stack',cylG,PLAIN,x,h/2,z,r,h,r,0,0xc8c4bc);
  for(const y of [h-1.6,h-4.4])inst('stackBand',cylG,PLAIN,x,y,z,r+.04,1.1,r+.04,0,0xc0392b);
  inst('stackLamp',UNIT,UNLIT,x,h+.2,z,.4,.3,.4,0,0xff3a2a);addCollider(x-r,x+r,z-r,z+r,h);
  SMOKE_STACKS.push({x,z,y:h+.4,t:RNG()*2});
}
function factoryBlock(bx0,bx1,bz0,bz1,i,j){
  const ix0=bx0+3,ix1=bx1-3,iz0=bz0+3,iz1=bz1-3,cx=(ix0+ix1)/2,col=pick(FAC_COL),v=RNG();
  const name=FAC_NAMES[(facNameK++)%FAC_NAMES.length]+(v<.45?' 공장':v<.75?' 공업사':' 물류창고');
  boxI('indYard',PLAIN,bx0+.5,bx1-.5,bz0+.5,bz1-.5,.235,.03,0x4e5054,false);
  if(v<.45){ // plant: a long hall with roof lights, a stack, pallets and a forklift in the yard
    const hz1=iz0+21,h=rand(8,11);
    boxI('facHall',CORR,ix0+1,ix1-1,iz0,hz1,0,h,col,true);BLDGS.push({x0:ix0+1,x1:ix1-1,z0:iz0,z1:hz1,h});
    boxI('facRoof',PLAIN,ix0+.6,ix1-.6,iz0-.4,hz1+.4,h,.35,0x3a3d44,false);
    for(let z=iz0+3;z<hz1-2;z+=4.5){boxI('facMon',PLAIN,ix0+3,ix1-3,z,z+1.6,h+.35,1.3,0x50545e,false);inst('facMonG',UNIT,UNLIT,cx,h+1,z+1.62,ix1-ix0-7,.7,.05,0,0xffe0a0);}
    for(const x of [cx-11,cx,cx+11]){inst('rollDoor',UNIT,PLAIN,x,2.6,hz1+.06,6,5.2,.1,0,0x3a3d44);for(let k=0;k<6;k++)inst('rollSlat',UNIT,PLAIN,x,.6+k*.8,hz1+.12,6,.06,.04,0,0x5a5e66);inst('dockLamp',UNIT,UNLIT,x,5.8,hz1+.2,1.2,.2,.3,0,0xffd08a);}
    stackI(ix1-4,iz0+4,rand(20,28),rand(1.3,1.8));
    for(let k=0;k<6;k++){const x=rand(ix0+3,ix1-3),z=rand(hz1+4,iz1-6);inst('pallet',UNIT,PLAIN,x,.35,z,1.4,.2,1.2,0,0x9a7a4a);inst('crate',UNIT,PLAIN,x,.95,z,1.2,1,1,0,pick([0xb08a5a,0x8a9aa0,0x6a8a5a]));addCollider(x-.7,x+.7,z-.6,z+.6,1.5);}
    {const fx=ix0+6,fz=iz1-8;boxI('fork',PLAIN,fx-.8,fx+.8,fz-1.2,fz+1.2,.2,1.4,0xf4c430,true);inst('forkMast',UNIT,PLAIN,fx,1.6,fz+1.35,1,3,.15,0,0x2a2a2e);}
  } else if(v<.75){ // tank farm: storage tanks, a pipe rack and a small control house
    for(let k=0;k<3;k++){const tx=ix0+7+k*13,tz=iz0+9,r=rand(4.2,5.2),h=rand(9,13);
      inst('tank',cylG,PLAIN,tx,h/2,tz,r,h,r,0,pick([0xdedad2,0xc8ccd0,0xe8e2d0]));inst('tankTop',cylG,PLAIN,tx,h+.2,tz,r*.92,.4,r*.92,0,0x9a9a9e);
      inst('tankBand',cylG,PLAIN,tx,h*.7,tz,r+.03,.6,r+.03,0,col);addCollider(tx-r*.85,tx+r*.85,tz-r*.85,tz+r*.85,h);}
    for(let x=ix0+2;x<ix1-2;x+=6)inst('pipeLeg',UNIT,PLAIN,x,2.2,iz0+20,.3,4.4,.3,0,0x6a6e78);
    for(const y of [3.8,4.4])inst('pipe',UNIT,PLAIN,cx,y,iz0+20,ix1-ix0-4,.4,.4,0,0x8a8e98);
    boxI('ctrl',HOUSE,ix1-12,ix1-2,iz1-12,iz1-4,0,4.2,0xe8e4da,true);boxI('ctrlR',PLAIN,ix1-12.3,ix1-1.7,iz1-12.3,iz1-3.7,4.2,.3,col,false);
    inst('ctrlWin',UNIT,UNLIT,ix1-7,2.4,iz1-3.95,6,1,.05,0,0xffe8b0);
    stackI(ix0+4,iz1-6,rand(16,22),1.1);
    for(let k=0;k<5;k++)inst('drum',cylG,PLAIN,ix0+12+k*1.3,.6,iz1-5,.45,1.2,.45,0,pick([0x2f5e8a,0x8a3a2a,0x3a6a3a]));
  } else { // depot shed with containers stacked in the yard
    const h=rand(9,12);
    boxI('facShed',CORR,ix0+1,cx+4,iz0,iz1-3,0,h,col,true);BLDGS.push({x0:ix0+1,x1:cx+4,z0:iz0,z1:iz1-3,h});boxI('facRoof',PLAIN,ix0+.6,cx+4.4,iz0-.4,iz1-2.6,h,.35,0x3a3d44,false);
    for(const z of [iz0+9,iz1-12]){inst('rollDoor',UNIT,PLAIN,cx+4.06,2.6,z,.1,5.2,6,0,0x3a3d44);inst('dockLamp',UNIT,UNLIT,cx+4.2,5.8,z,.3,.2,1.2,0,0xffd08a);}
    for(let z=iz0+1;z+12<=iz1-6;z+=13)for(let x=cx+8;x<ix1-2;x+=3){const n=randi(1,3);for(let k=0;k<n;k++)inst('cont',UNIT,CORR,x+1.25,1.3+k*2.6,z+6,2.5,2.55,12,0,pick(CONT_COL));addCollider(x,x+2.5,z,z+12,n*2.6);}
  }
  // company sign at the gate and the dock where deliveries are dropped off (south street)
  const gx=cx+(v<.75?-10:10);
  inst('facPole',UNIT,PLAIN,gx,2.2,bz1-.8,.2,4.4,.2,0,0x3a3a46);
  signPlane([name,'INDUSTRIAL ESTATE · 납품은 남쪽 하역장'],'#14181e','#ffd27a',gx,4.6,bz1-.68,7,1.7,0);
  boxI('dockApron',PLAIN,cx-7,cx+7,bz1-5,bz1-.5,.25,.04,0x8a8a90,false);
  for(let k=0;k<4;k++)boxI('dockStripe',UNLIT,cx-6.5+k*4,cx-5.5+k*4,bz1-4.6,bz1-.9,.29,.01,0xf4c430,false);
  FACTORY_DOCKS.push({x:cx,z:R[j+1]-LANE,ax:cx,az:bz1-2.5,name,i,j,boxes:[]});
}
// prefab worker flats: stacked container-style modules with open walkways and a stair tower
function prefabBlock(ix0,ix1,iz0,iz1){
  const PF=[0xe8d8b0,0xc8dce8,0xe8c8b8,0xd0e0c0,0xdcd4e8,0xf0e0c8],cx=(ix0+ix1)/2;
  for(const [z0,z1,face] of [[iz0+1,iz0+9,1],[iz1-9,iz1-1,-1]]){
    const n=6,mw=(ix1-ix0-8)/n,fl=3;
    for(let k=0;k<n;k++)for(let f=0;f<fl;f++){
      const x0=ix0+1+k*mw,y=f*3;
      boxI('pfMod',CORR,x0+.1,x0+mw-.1,z0,z1,y+.05,2.9,pick(PF),false);
      const wz=face>0?z1+.05:z0-.05;
      inst('pfWin',UNIT,UNLIT,x0+mw*.35,y+1.7,wz,1.3,.9,.06,0,RNG()<.65?0xffe0a8:0x2a2c38);
      inst('pfDoor',UNIT,PLAIN,x0+mw*.72,y+1.1,wz,.9,2,.06,0,0x3a4a5a);
    }
    addCollider(ix0+1,ix0+1+n*mw,z0,z1,fl*3);BLDGS.push({x0:ix0+1,x1:ix0+1+n*mw,z0,z1,h:fl*3});
    for(let f=1;f<=fl;f++){const wz=face>0?z1+.8:z0-.8;if(f<fl)boxI('pfWalk',PLAIN,ix0+1,ix0+1+n*mw,Math.min(wz-.75,wz+.75),Math.max(wz-.75,wz+.75),f*3-.1,.15,0x8a8e94,false);
      if(f<fl)inst('pfRail',UNIT,PLAIN,ix0+1+n*mw/2,f*3+.55,wz+face*.72,n*mw,.08,.06,0,0xd0d4d8);}
    boxI('pfStair',PLAIN,ix1-6.5,ix1-1.5,z0,z1,0,fl*3+1,0x7a7e86,true);
    boxI('pfRoof',PLAIN,ix0+.6,ix1-1.2,z0-.3,z1+.3,fl*3,.25,0x50545e,false);
  }
  // shared yard: washing lines, benches, a few trees
  const cz=(iz0+iz1)/2;
  for(let k=0;k<3;k++){const x=ix0+6+k*10;inst('lineP',UNIT,PLAIN,x-3,1.2,cz,.08,2.4,.08,0,0x6a6a70);inst('lineP',UNIT,PLAIN,x+3,1.2,cz,.08,2.4,.08,0,0x6a6a70);
    for(let q=0;q<4;q++)inst('laundry',UNIT,PLAIN,x-2.2+q*1.45,1.75,cz,.9,.8,.04,0,pick([0xff8a8a,0x8ac8ff,0xffffff,0xffe08a,0x9aff9a]));}
  treeI(ix1-4,cz-3,.8);treeI(ix1-4,cz+3,.9);boxI('bench',PLAIN,cx-2,cx+1,cz+3.5,cz+4.3,.22,.5,0x6a4a2a,false);
}
// the fence between the estate and the slums: chain link topped with barbed wire, gates only on the coast roads
const IND_FZ=R[IND_J]+HALF_ROAD+.6,IND_FX=R[N]-HALF_ROAD-3;
const indGate=x=>Math.abs(x)>IND_FX; // fence gaps over the two coast roads
function buildEstateFence(){
  const z=IND_FZ,x0=-IND_FX,x1=IND_FX,len=x1-x0,fh=3.2;
  const cv=document.createElement('canvas');cv.width=cv.height=32;const g=cv.getContext('2d');g.strokeStyle='rgba(190,198,206,1)';g.lineWidth=1.6;
  g.beginPath();g.moveTo(0,0);g.lineTo(32,32);g.moveTo(32,0);g.lineTo(0,32);g.stroke();
  const tx=new THREE.CanvasTexture(cv);tx.wrapS=tx.wrapT=THREE.RepeatWrapping;tx.repeat.set(len/1.1,fh/1.1);
  const net=new THREE.Mesh(new THREE.PlaneGeometry(len,fh),new THREE.MeshLambertMaterial({map:tx,transparent:true,alphaTest:.35,side:THREE.DoubleSide}));
  net.position.set(0,fh/2,z);scene.add(net);
  for(let x=x0;x<=x1+.01;x+=3){inst('fPost',UNIT,PLAIN,x,(fh+.6)/2,z,.12,fh+.6,.12,0,0x7a8088);inst('fArm',UNIT,PLAIN,x,fh+.55,z-.25,.08,.08,.7,0,0x7a8088);}
  for(const [y,o] of [[fh+.25,-.08],[fh+.5,-.3],[fh+.75,-.52]])inst('fWire',UNIT,PLAIN,0,y,z+o,len,.03,.03,0,0x9aa0a8);
  inst('fRail',UNIT,PLAIN,0,fh,z,len,.06,.06,0,0x7a8088);
  addCollider(x0-.1,x1+.1,z-.2,z+.2,fh+.8);
  for(let x=x0+60;x<x1-30;x+=180)signPlane(['공단 부지 · 출입은 해안도로 정문으로','INDUSTRIAL ESTATE'],'#3a2a06','#ffd27a',x,1.9,z-.08,4.2,.8,Math.PI);
  // the gates: pillars on both sides of the coast road, a beam with the estate's name, a guard booth
  for(const sx of [-1,1]){
    const rx=sx*R[N],pa=sx*(EDGE-1.2),pb=sx*(IND_FX+.4);
    for(const px of [pa,pb]){boxI('gateP',PLAIN,px-.45,px+.45,z-.45,z+.45,0,7.2,0x8a8e98,true);inst('gateLamp',UNIT,UNLIT,px,7.4,z,.4,.3,.4,0,0xffd08a);}
    inst('gateBeam',UNIT,PLAIN,rx,6.9,z,Math.abs(pa-pb)+.9,.7,.5,0,0x3a3d44);
    signPlane(['남부 공단 정문','NEON HARBOR INDUSTRIAL ESTATE'],'#14181e','#ffd27a',rx,6.9,z-.28,10,1.3,Math.PI);
    signPlane(['남부 공단','공장 · 하역장'],'#14181e','#ffd27a',rx,6.9,z+.28,10,1.3,0);
    const bx=sx>0?IND_FX-5:-IND_FX+1;boxI('gBooth',HOUSE,bx,bx+4,z+1.4,z+5,0,2.8,0xe8e4da,true);boxI('gBoothR',PLAIN,bx-.3,bx+4.3,z+1.1,z+5.3,2.8,.25,0xf4c430,false);
    inst('gBoothW',UNIT,UNLIT,bx+2,1.7,z+1.35,3,.9,.05,0,0xffe8b0);
    inst('barArm',UNIT,UNLIT,sx*(IND_FX+1.2),4.2,z+.9,.18,4.2,.18,0,0xff4a4a);
  }
}

// ---------- courier company on the harbour front: warehouse, loading docks, trucks in and out of the basement ----------
const LOGI={L:null,T:8,spot:null,load:null};
function logisticsBlock(bx0,bx1,bz0,bz1){
  const OR=0xff8a3d,cz=(bz0+bz1)/2;
  boxI('lgYard',PLAIN,bx0+.5,bx1-.5,bz0+.5,bz1-.5,.235,.03,0x44464c,false);
  // warehouse: loading doors on its yard side, the company name in lights
  const wx0=bx0+17,wx1=bx1-1.5,wz0=bz0+1.5,wz1=bz1-11,h=11;
  boxI('lgWh',CORR,wx0,wx1,wz0,wz1,0,h,0xe8e6e0,true);boxI('lgWhR',PLAIN,wx0-.4,wx1+.4,wz0-.4,wz1+.4,h,.4,0x3a3d44,false);
  boxI('lgBand',UNLIT,wx0-.08,wx0,wz0+.5,wz1-.5,h-2.2,.9,OR,false);
  for(let k=0;k<5;k++){const z=wz0+3.5+k*(wz1-wz0-7)/4;inst('rollDoor',UNIT,PLAIN,wx0-.06,2.4,z,.1,4.8,3.6,0,0x3a3d44);inst('dockLamp',UNIT,UNLIT,wx0-.2,5.3,z,.3,.2,1.2,0,0xffd08a);boxI('dockBump',PLAIN,wx0-.5,wx0,z-1.9,z-1.6,.3,1,0x1a1a1c,false);boxI('dockBump',PLAIN,wx0-.5,wx0,z+1.6,z+1.9,.3,1,0x1a1a1c,false);}
  signPlane(['네온 익스프레스','NEON EXPRESS · 물류센터'],'#2a1406','#ffb36a',wx0-.12,h+2.2,(wz0+wz1)/2,14,2.6,-Math.PI/2);
  inst('lgSignPost',UNIT,PLAIN,wx0+1,h+1,(wz0+wz1)/2,.3,2,.3,0,0x3a3a46);
  // two trucks backed up to the docks
  LOGI.decor=[];for(const z of [wz0+3.5+(wz1-wz0-7)/4,wz0+3.5+3*(wz1-wz0-7)/4]){LOGI.decor.push({x:wx0-4.6,z});addCollider(wx0-8.4,wx0-.8,z-1.3,z+1.3,3.4);}
  // dispatch office by the street (sign on as a driver here)
  boxI('lgOff',HOUSE,bx0+3,bx0+11,bz0+1.5,bz0+9,0,3.6,0xfff1e4,true);boxI('lgOffR',PLAIN,bx0+2.7,bx0+11.3,bz0+1.2,bz0+9.3,3.6,.3,OR,false);
  inst('lgOffW',UNIT,UNLIT,bx0+2.95,1.8,bz0+5.2,.05,1,4,0,0xffe8c8);
  signPlane(['배송 기사 모집','DRIVERS WANTED · 상시 채용'],'#2a1406','#ffb36a',bx0+2.92,2.85,bz0+5.2,3.4,.7,-Math.PI/2);
  inst('lgPole',UNIT,PLAIN,bx0+.6,3.3,bz0+12,.22,6.6,.22,0,0x3a3a46);
  signPlane(['물류센터','NEON EXPRESS'],'#2a1406','#ffb36a',bx0+.75,6.6,bz0+12,5.4,1.5,-Math.PI/2);
  const desk={x:bx0+1.6,z:bz0+5.2};addRing(desk.x,desk.z,OR,1);
  // basement ramp for the trucks, at the south end of the yard
  const za=bz1-8.6,zb=bz1-1.6,rz=(za+zb)/2,fx=bx0+3,deep=10,xa=fx+deep,lo=fx,hi=xa;
  for(const wz of [za,zb])boxI('rampw',PLAIN,lo,hi,wz-.18,wz+.18,0,3.6,0x6a6e78,true);
  boxI('rampr',PLAIN,lo,hi,za-.2,zb+.2,3.6,.35,0x50545e,false);
  boxI('rampf',PLAIN,lo,hi,za+.18,zb-.18,0,.04,0x15161b,false);
  boxI('ramps',PLAIN,xa,xa+.4,za,zb,0,3.6,0x2a2c33,true);
  for(let k=0;k<6;k++)boxI('rampsl',PLAIN,xa-.06,xa-.02,za+.2,zb-.2,.3+k*.55,.07,0x4a4e58,false);
  for(let k=0;k<4;k++){const q=lo+(hi-lo)*(k+.5)/4;boxI('rampstr',PLAIN,q-.4,q+.4,za+.4,zb-.4,.05,.02,0xe8c547,false);}
  signPlane(['화물차 전용 · 지하','TRUCKS ONLY ↓'],'#2a1406','#ffffff',fx-.1,4.35,rz,Math.max(3,zb-za-.4),1.1,-Math.PI/2);
  const ramp={in:{x:fx+3.5,z:rz},mouth:{x:bx0-5.5,z:rz},out:-Math.PI/2,lane:-1};
  LOGI.spot={x:bx0+11,z:bz0+15,h:-Math.PI/2};LOGI.load={x:bx0-3.5,z:cz};
  PARK_ZONES.push({x0:bx0,x1:bx1,z0:bz0,z1:bz1,name:'물류센터'});
  LOGI.L={type:'logistics',T:LOC_TYPES.logistics,look:'harbor',name:'물류센터',title:'네온 익스프레스 물류센터',sub:'NEON EXPRESS',sign:['물류센터',''],door:new V3(desk.x,0,desk.z),out:{x:-1,z:0},robCD:0,room:null,noDoor:true,cz,
    ramp,spawnSpot:{x:ramp.mouth.x,z:ramp.mouth.z,h:Math.PI},roadX:bx0-HALF_ROAD,desk};
  LOCS.push(LOGI.L);
}
// Harbor Crew compound: graffiti walls with a gate on the west street, a warehouse, black vans in the yard
function gangBlock(bx0,bx1,bz0,bz1){
  const ix0=bx0+2,ix1=bx1-2,iz0=bz0+2,iz1=bz1-2,cz=(iz0+iz1)/2,gate=5;
  boxI('gYard',PLAIN,ix0,ix1,iz0,iz1,.235,.03,0x3a3630,false);
  const W=(a0,a1,b0,b1)=>{boxI('gWall',PLAIN,a0,a1,b0,b1,0,3.2,0x5a5048,true);};
  W(ix0,ix1,iz0,iz0+.5);W(ix0,ix1,iz1-.5,iz1);W(ix1-.5,ix1,iz0,iz1);W(ix0,ix0+.5,iz0,cz-gate);W(ix0,ix0+.5,cz+gate,iz1);
  for(let k=0;k<14;k++){const z=iz0+1+k*(iz1-iz0-2)/13;if(Math.abs(z-cz)<gate+.5)continue;inst('gGraf',UNIT,UNLIT,ix0-.03,rand(.8,2.4),z,.04,rand(.6,1.6),rand(1.2,2.6),0,pick([0xff3a8a,0x3ad0ff,0xffd23a,0x9a5aff,0x3aff8a]));}
  for(const z of [iz0+.25,iz1-.25])for(let x=ix0+2;x<ix1-1;x+=3.2)inst('gGraf',UNIT,UNLIT,x,rand(.8,2.4),z+(z<cz?-.3:.3),rand(1.2,2.6),rand(.6,1.6),.04,0,pick([0xff3a8a,0x3ad0ff,0xffd23a,0x9a5aff]));
  boxI('gWare',HOUSE,ix1-18,ix1-1,iz0+4,iz1-4,0,7,0x6a5a4e,true);boxI('gWareR',PLAIN,ix1-18.4,ix1-.6,iz0+3.6,iz1-3.6,7,.4,0x2a2422,false);
  inst('gDoor',UNIT,PLAIN,ix1-18.05,2.2,cz,.1,4.4,6,0,0x1a1a1a);
  signPlane(['HARBOR CREW','하버 갱단'],'#120404','#ff4a4a',ix1-18.1,5.6,cz,9,1.8,-Math.PI/2);
  signPlane(['사유지 · 접근 금지','KEEP OUT'],'#120404','#ffd27a',ix0-.1,3.9,cz-gate-2.6,4.4,.9,-Math.PI/2);
  for(let k=0;k<8;k++)inst('gBarrel',cylG,PLAIN,rand(ix0+3,ix1-20),.6,rand(iz0+2,iz1-2),.6,1.2,.6,0,pick([0x3a4a8a,0x8a3a2a,0x4a4a4a]));
  for(const z of [iz0+5,iz1-5]){inst('gVan',UNIT,PLAIN,ix0+12,1.4,z,5,2,2.2,Math.PI/2,0x121214);inst('gVanW',UNIT,UNLIT,ix0+12,1.9,z,4.2,.55,2.24,Math.PI/2,0x05060a);addCollider(ix0+9.5,ix0+14.5,z-1.2,z+1.2,2.4);}
  inst('gLight',UNIT,UNLIT,ix0+.6,3.6,cz-gate,.3,.3,.3,0,0xff4a4a);inst('gLight',UNIT,UNLIT,ix0+.6,3.6,cz+gate,.3,.3,.3,0,0xff4a4a);
  GANG={x0:ix0,x1:ix1,z0:iz0,z1:iz1,cz,gate:{x:bx0-HALF_ROAD+LANE,z:cz},inside:{x:ix0+6,z:cz},guards:[[ix0+3,cz-gate-1.5],[ix0+3,cz+gate+1.5],[ix1-20,cz-3],[ix1-20,cz+4]].map(([x,z])=>({x,z,p:null})),raidT:rand(90,240),van:null};
  LOCS.push({type:'gang',T:LOC_TYPES.gang,look:'slum',name:'하버 갱단 본거지',title:'하버 갱단 본거지',sub:'',sign:['갱단',''],door:new V3(ix0+4,0,cz),out:{x:-1,z:0},robCD:0,room:null,noDoor:true,cz});
}
// bus depot: open-fronted bus shed, yard, office and the transit sign on the street
let DEPOT=null;
function busDepotBlock(bx0,bx1,bz0,bz1){
  const ix0=bx0+3,ix1=bx1-3,iz0=bz0+3,iz1=bz1-3,cz=(iz0+iz1)/2;
  boxI('depotYard',PLAIN,bx0+.5,ix1,iz0,iz1,0,.05,0x3a3c44,false);
  for(let z=iz0+4;z<iz1-2;z+=8.6)boxI('depotLine',UNLIT,ix0+10,ix1-1,z-.06,z+.06,.06,.01,0xf2f2f2,false);
  const sx0=ix1-15;
  boxI('shedBack',PLAIN,ix1-.6,ix1,iz0,iz1,0,8,0x8a9098,true);
  boxI('shedSide',PLAIN,sx0,ix1,iz0,iz0+.6,0,8,0x8a9098,true);boxI('shedSide',PLAIN,sx0,ix1,iz1-.6,iz1,0,8,0x8a9098,true);
  boxI('shedRoof',PLAIN,sx0-.6,ix1+.3,iz0-.3,iz1+.3,8,.5,0x2f6a46,false);
  for(let z=iz0+4.3;z<iz1-2;z+=8.6)inst('shedPost',UNIT,PLAIN,sx0,4,z,.35,8,.35,0,0x6a7078);
  for(let k=0;k<4;k++){const z=iz0+4.3+k*8.6;if(z>iz1-3)break;const col=k===3?0x2e6fd8:0x2fa35a;
    inst('pbus',UNIT,PLAIN,ix1-7.5,1.8,z,9.4,2.5,2.6,0,col);inst('pbusWin',UNIT,UNLIT,ix1-7.8,2.3,z,8.2,.85,2.64,0,0x18202e);
    inst('pbusRoof',UNIT,PLAIN,ix1-7.5,3.1,z,9,.2,2.5,0,0xdedede);addCollider(ix1-12.2,ix1-2.8,z-1.3,z+1.3,3);}
  boxI('depotOffice',HOUSE,ix0,ix0+8,iz0,iz0+9,0,4.2,0xe8e2d0,true);boxI('depotOfficeR',PLAIN,ix0-.3,ix0+8.3,iz0-.3,iz0+9.3,4.2,.3,0x2f6a46,false);
  boxI('depotFence',PLAIN,ix0,sx0,iz1-.3,iz1,0,1.6,0x6a7078,true);
  signPlane(['버스 차고지','NEON HARBOR TRANSIT'],'#0d3a1a','#7dffb0',bx0+.1,4.8,iz0+4.5,9,2.4,-Math.PI/2);
  inst('depotPole',UNIT,PLAIN,bx0+.4,2.4,iz0+4.5,.2,4.8,.2,0,0x3a3a46);
  DEPOT={x:R[Math.round((bx0-HALF_ROAD-R[0])/CELL)]+LANE,z:cz+6,h:Math.PI,cz};
  LOCS.push({type:'busdepot',T:LOC_TYPES.busdepot,look:'city',name:'버스 차고지',title:'버스 차고지',sub:'',sign:['버스',''],door:new V3(bx0+2,0,cz),out:{x:-1,z:0},robCD:0,room:null,noDoor:true,cz});
}
// taxi company yard: a row of cabs facing the street, the dispatcher's booth by the gate, office and wash bay at the back
function taxiDepotBlock(bx0,bx1,bz0,bz1,look,name,en){
  const ix0=bx0+3,ix1=bx1-3,iz0=bz0+3,iz1=bz1-3,cz=(iz0+iz1)/2;
  boxI('tdYard',PLAIN,bx0+.5,ix1,iz0,iz1,.235,.03,0x34363e,false);
  const bx=bx0+13,slots=[];
  for(let k=0;k<9;k++){const z=iz0+7+k*3.5;if(z>iz1-2)break;slots.push({x:bx,z,h:-Math.PI/2,car:null,cd:0});
    boxI('tdLine',UNLIT,bx-2.8,bx+2.8,z-1.75-.06,z-1.75+.06,.268,.01,0xf4c430,false);}
  {const zl=slots[slots.length-1].z+1.75;boxI('tdLine',UNLIT,bx-2.8,bx+2.8,zl-.06,zl+.06,.268,.01,0xf4c430,false);
    boxI('tdLine',UNLIT,bx+2.74,bx+2.86,slots[0].z-1.75,zl,.268,.01,0xf4c430,false);}
  // office (back, north) and the open wash bay (back, south)
  const ox0=ix1-11;
  boxI('tdOffice',HOUSE,ox0,ix1,iz0,iz0+15,0,7,look==='army'?0xd8d4b8:0xf2ecd8,true);boxI('tdOfficeR',PLAIN,ox0-.3,ix1+.3,iz0-.3,iz0+15.3,7,.35,0x2a2a2e,false);
  boxI('tdBand',UNLIT,ox0-.08,ox0,iz0+.5,iz0+14.5,5.6,.6,0xf4c430,false);
  for(let k=0;k<4;k++)inst('tdWin',UNIT,UNLIT,ox0-.05,2.6,iz0+2.5+k*3.3,.08,1.5,2,0,0xfff1c4);
  signPlane(['택시 영업소',en],'#2a2206','#ffd84a',ox0-.12,8.6,iz0+7.5,10,2.2,-Math.PI/2);
  boxI('tdWashBack',PLAIN,ix1-.5,ix1,iz1-16,iz1,0,5,0x8a9098,true);boxI('tdWashRoof',PLAIN,ox0,ix1+.3,iz1-16.3,iz1+.3,5,.35,0xf4c430,false);
  for(const z of [iz1-15.6,iz1-.4])inst('tdWashPost',UNIT,PLAIN,ox0+.3,2.5,z,.35,5,.35,0,0x6a7078);
  boxI('tdFence',PLAIN,ix0+8,ox0,iz0,iz0+.3,0,1.6,0x6a7078,true);boxI('tdFence',PLAIN,ix0+8,ox0,iz1-.3,iz1,0,1.6,0x6a7078,true);
  // the dispatcher's booth at the gate: walk up to its window to sign on as a driver
  boxI('tdBooth',HOUSE,bx0+3,bx0+6.4,iz0+.6,iz0+4.6,0,2.8,0xfff4c8,true);boxI('tdBoothR',PLAIN,bx0+2.7,bx0+6.7,iz0+.3,iz0+4.9,2.8,.25,0xf4c430,false);
  inst('tdBoothWin',UNIT,UNLIT,bx0+2.95,1.6,iz0+2.6,.06,1,2.2,0,0xfff1c4);
  signPlane(['배차실','DISPATCH'],'#2a2206','#ffd84a',bx0+2.92,2.45,iz0+2.6,2.4,.55,-Math.PI/2);
  inst('tdPole',UNIT,PLAIN,bx0+.6,3,iz1-2.5,.2,6,.2,0,0x3a3a46);
  signPlane(['TAXI '+name.replace(' 택시 영업소',''),en],'#2a2206','#ffd84a',bx0+.75,6.4,iz1-2.5,6,1.6,-Math.PI/2);
  const desk={x:bx0+1.6,z:iz0+2.6};addRing(desk.x,desk.z,0xf4c430,1);
  const D={name,look,slots,desk,bx0,bx1,bz0,bz1,cx:(bx0+bx1)/2,cz,roadX:bx0-HALF_ROAD,outT:rand(8,20)};TAXI_DEPOTS.push(D);
  PARK_ZONES.push({x0:bx0,x1:bx1,z0:bz0,z1:bz1,name});
  LOCS.push({type:'taxidepot',T:LOC_TYPES.taxidepot,look,name:'택시 영업소',title:name,sub:'',sign:['택시',''],door:new V3(desk.x,0,desk.z),out:{x:-1,z:0},robCD:0,room:null,noDoor:true,cz,depot:D});
}
// multi-storey car park: open decks on columns, cars park on the ground floor (the decks above are full)
function parkTowerBlock(bx0,bx1,bz0,bz1,look,name){
  const ix0=bx0+3,ix1=bx1-3,iz0=bz0+3,iz1=bz1-3,cx=(ix0+ix1)/2,cz=(iz0+iz1)/2,col=look==='army'?0x9a9a86:0xb8b8bc;
  boxI('ptFloor',PLAIN,ix0,ix1,iz0,iz1,.235,.03,0x3a3c44,false);
  for(const y of [3.6,7.2,10.8]){boxI('ptDeck',PLAIN,ix0,ix1,iz0,iz1,y,.4,col,false);
    for(const [a0,a1,b0,b1] of [[ix0,ix1,iz0,iz0+.25],[ix0,ix1,iz1-.25,iz1],[ix0,ix0+.25,iz0,iz1],[ix1-.25,ix1,iz0,iz1]])boxI('ptPar',PLAIN,a0,a1,b0,b1,y+.4,1,look==='army'?0x6a6e58:0x4da3ff,false);
    for(let k=0;k<16;k++)if(RNG()<.7){const z=iz0+3+k*2.25,x=k%2?ix0+4:ix1-4;inst('ptCar',UNIT,PLAIN,x,y+1.15,z,4.2,1.1,2,0,pick([0xc0392b,0x2e86c1,0xf1c40f,0x27ae60,0xecf0f1,0x34495e,0x7f8c8d]));inst('ptCarTop',UNIT,PLAIN,x-.3,y+1.95,z,2.2,.6,1.8,0,0x1b2030);}}
  boxI('ptRoofP',PLAIN,ix0,ix1,iz0,iz1,14.2,.3,0x4a4c54,false);
  for(const x of [ix0+.4,cx,ix1-.4])for(let z=iz0+.4;z<=iz1-.3;z+=9.8){inst('ptCol',UNIT,PLAIN,x,7.1,z,.6,14.2,.6,0,col);addCollider(x-.3,x+.3,z-.3,z+.3,14);}
  const spots=[];
  for(let k=0;k<13;k++){const z=iz0+3+k*2.8;if(z>iz1-2.5)break;for(const [x,h] of [[ix0+3.6,-Math.PI/2],[ix1-3.6,Math.PI/2]]){spots.push({x,z,h});}
    boxI('ptLine',UNLIT,ix0+1.2,ix0+6,z+1.4-.06,z+1.4+.06,.268,.01,0xf2f2f2,false);boxI('ptLine',UNLIT,ix1-6,ix1-1.2,z+1.4-.06,z+1.4+.06,.268,.01,0xf2f2f2,false);}
  signPlane(['P '+name,'PARKING · 24H'],'#0d2a4a','#ffffff',bx0+.1,13,cz,12,2.6,-Math.PI/2);
  signPlane(['P '+name,'PARKING · 24H'],'#0d2a4a','#ffffff',bx1-.1,13,cz,12,2.6,Math.PI/2);
  inst('ptP',UNIT,UNLIT,cx,16.4,cz,4,4,.3,0,0x4da3ff);
  addParking(bx0,bx1,bz0,bz1,name,spots,cx,cz);
}
const LOTS=[];
function parkLotBlock(bx0,bx1,bz0,bz1,look,name){
  const ix0=bx0+3,ix1=bx1-3,iz0=bz0+3,iz1=bz1-3,cx=(ix0+ix1)/2,cz=(iz0+iz1)/2;
  boxI('plFloor',PLAIN,ix0,ix1,iz0,iz1,.235,.03,0x34363e,false);
  const spots=[],aisles=[(ix0+3.2+cx-3.2)/2,(cx+3.2+ix1-3.2)/2];
  for(const rx of [ix0+3.2,cx-3.2,cx+3.2,ix1-3.2]){
    for(let k=0;k<12;k++){const z=iz0+3+k*2.9;if(z>iz1-2.5)break;
      if(Math.abs(z-cz)<(rx===ix0+3.2?9:3.6))continue; // keep the gate, the booth and the cross aisle clear
      spots.push({x:rx,z,h:rx<cx?-Math.PI/2:Math.PI/2,aisle:rx<cx?aisles[0]:aisles[1]});}
    boxI('plLine',UNLIT,rx<cx?rx+2.54:rx-2.66,rx<cx?rx+2.66:rx-2.54,iz0+1.55,iz0+1.55+11*2.9,.268,.01,0xf2f2f2,false);
    for(let k=0;k<=12;k++){const z=iz0+1.55+k*2.9;if(z>iz1-1)break;boxI('plLine',UNLIT,rx-2.6,rx+2.6,z-.06,z+.06,.268,.01,0xf2f2f2,false);}
  }
  for(const z of [iz0+.8,iz1-.8])for(let x=ix0+4;x<ix1-3;x+=9)treeI(x,z,rand(.7,.9));
  // a low railing all round with one gate on the street side; booth and barrier arms beside it
  const rail=(x0,x1,z0,z1)=>{if(x1-x0<.3&&z1-z0<.3)return;boxI('plRail',PLAIN,x0,x1,z0,z1,.25,1,0xb8bec8,true);};
  rail(ix0-.15,ix0+.15,iz0-.3,cz-5);rail(ix0-.15,ix0+.15,cz+5,iz1+.3);rail(ix1-.15,ix1+.15,iz0-.3,iz1+.3);
  rail(ix0-.15,ix1+.15,iz0-.45,iz0-.15);rail(ix0-.15,ix1+.15,iz1+.15,iz1+.45);
  boxI('plBooth',HOUSE,ix0+.5,ix0+3,cz+5.6,cz+8.6,0,2.6,0xe8f2f6,true);
  for(const z of [cz-5,cz+5]){inst('plGateP',UNIT,PLAIN,ix0,.75,z,.35,1.5,.35,0,0xf4c430);inst('plArm',UNIT,UNLIT,ix0+.2,2.6,z,.12,2.6,.12,0,0xff4a4a);}
  for(let k=0;k<3;k++)boxI('plArrow',UNLIT,ix0+1+k*2.2,ix0+2.4+k*2.2,cz-.18,cz+.18,.268,.01,0xf2f2f2,false);
  inst('plPole',UNIT,PLAIN,bx0+.6,2.2,cz+4,.15,4.4,.15,0,0x3a3a46);
  signPlane(['P','공영 주차장'],'#0d2a4a','#ffffff',bx0+.7,4.6,cz+4,2.4,1.6,-Math.PI/2);
  signPlane(['P '+name,'PUBLIC PARKING'],'#0d2a4a','#ffffff',bx1-.1,3.4,cz,9,1.8,Math.PI/2);
  const L={name,bx0,bx1,bz0,bz1,cx,cz,roadX:bx0-HALF_ROAD,li:nearestIdx(bx0-HALF_ROAD),gateOut:{x:bx0-2.5,z:cz},gateIn:{x:ix0+2.5,z:cz},aisles,spots,t:rand(5,20),busy:null};
  for(const q of spots)q.lot=L;LOTS.push(L);
  addParking(bx0,bx1,bz0,bz1,name,spots,cx,cz);
}
// filling station: a canopy over two pump islands, price board on the street, a small shop behind
function gasStation(x0,x1,z0,z1,name,rot){
  const cx=(x0+x1)/2,cz=(z0+z1)/2;
  boxI('gsFloor',PLAIN,x0,x1,z0,z1,.235,.03,0x4a4c54,false);
  boxI('gsRoof',PLAIN,x0+1,x1-1,z0+1,z1-1,5.2,.5,0xf4f6f8,false);boxI('gsBand',UNLIT,x0+.9,x1-.9,z0+.9,z1-.9,5.0,.22,0xd23a2a,false);
  for(const [px,pz] of [[x0+3,z0+3],[x1-3,z0+3],[x0+3,z1-3],[x1-3,z1-3]]){inst('gsPost',UNIT,PLAIN,px,2.6,pz,.4,5.2,.4,0,0xdfe4ec);addCollider(px-.2,px+.2,pz-.2,pz+.2,5.2);}
  const lx=Math.abs(x1-x0)>Math.abs(z1-z0);
  for(const o of [-.22,.22]){const ix=lx?cx:cx+o*(x1-x0),iz=lx?cz+o*(z1-z0):cz;
    boxI('gsIsle',PLAIN,lx?ix-4:ix-.7,lx?ix+4:ix+.7,lx?iz-.7:iz-4,lx?iz+.7:iz+4,.27,.2,0xc8ccd4,true);
    for(const k of [-2,2]){const qx=lx?ix+k:ix,qz=lx?iz:iz+k;inst('gsPump',UNIT,PLAIN,qx,1.2,qz,.8,1.8,.6,0,0xd23a2a);inst('gsScreen',UNIT,UNLIT,qx,1.6,qz,lx?.82:.62,.4,lx?.62:.82,0,0xfff1c4);}}
  for(let k=0;k<6;k++)inst('gsLamp',UNIT,UNLIT,x0+3+k*(x1-x0-6)/5,4.92,cz,.8,.06,.8,0,0xfff6dc);
  signPlane(['주유소','FUEL · 1% = $1'],'#3a0a08','#ffffff',cx,5.4,z0+.85,Math.min(10,Math.abs(x1-x0)-3),.6,Math.PI);
  GAS_ZONES.push({x0,x1,z0,z1,name});PARK_ZONES.push({x0,x1,z0,z1,name});
  LOCS.push({type:'gas',T:LOC_TYPES.gas,look:'city',name:'주유소',title:name,sub:'',sign:['주유소',''],door:new V3(cx,0,cz),out:{x:1,z:0},robCD:0,room:null,noDoor:true,cz});
}
function gasBlock(bx0,bx1,bz0,bz1,look,name){
  const cz=(bz0+bz1)/2;
  gasStation(bx0+1,bx0+23,cz-10,cz+10,name);
  boxI('gsShop',HOUSE,bx1-15,bx1-3,cz-7,cz+7,0,4.4,0xeef0f2,true);boxI('gsShopR',PLAIN,bx1-15.3,bx1-2.7,cz-7.3,cz+7.3,4.4,.35,0xd23a2a,false);
  signPlane(['편의점','24H MART'],'#3a0a08','#ffffff',bx1-15.1,3.4,cz,6,1.2,-Math.PI/2);
  inst('gsBoardPole',UNIT,PLAIN,bx0+.8,3,bz0+4,.3,6,.3,0,0x3a3a46);
  signPlane(['⛽ '+name,'휘발유 1% = $1'],'#3a0a08','#ffd27a',bx0+.6,6.4,bz0+4,4,1.6,-Math.PI/2);
  for(const z of [bz0+1.5,bz1-1.5])for(let x=bx0+26;x<bx1-16;x+=6)treeI(x,z,rand(.7,.9));
}
function addParking(x0,x1,z0,z1,name,spots,cx,cz){
  const Z={x0,x1,z0,z1,name};PARK_ZONES.push(Z);for(const q of spots){q.zone=Z;PARK_SPOTS.push(q);}
  LOCS.push({type:'parking',T:LOC_TYPES.parking,look:'city',name:'주차장',title:name,sub:'',sign:['주차장',''],door:new V3(cx,0,cz),out:{x:1,z:0},robCD:0,room:null,noDoor:true,cz});
}
const parks=new Set(['1,4','4,1','2,2']);
const heaps=[]; // scrap heaps you can dig through (junkyards, mine)
for(let i=0;i<N;i++)for(let j=0;j<NZ;j++){
  const bx0=R[i]+HALF_ROAD,bx1=R[i+1]-HALF_ROAD,bz0=R[j]+HALF_ROAD,bz1=R[j+1]-HALF_ROAD;
  const key=i+','+j,inOld=i<6&&j<6,park=inOld&&parks.has(key);
  const kind=park?'park':inOld?'city':blockKind(i,j),closed=kind==='mountain'||kind==='base';
  blocks.push({bx0,bx1,bz0,bz1,park,kind,closed});
  if(closed)continue; // mountain and walled base are built as a whole below
  inst('walk',UNIT,PLAIN,(bx0+bx1)/2,.11,(bz0+bz1)/2,bx1-bx0,.22,bz1-bz0,0,KIND_GROUND[kind]);
  if(LOC_AT[key]){const a=LOC_AT[key];buildLoc(a[0],a[1],bx0,bx1,bz0,bz1,a[2],a[3]);continue;}
  if(key===DEPOT_KEY){busDepotBlock(bx0,bx1,bz0,bz1);continue;}
  if(key===LOGI_KEY){logisticsBlock(bx0,bx1,bz0,bz1);continue;}
  if(TAXI_AT[key]){const a=TAXI_AT[key];taxiDepotBlock(bx0,bx1,bz0,bz1,a[0],a[1],a[2]);continue;}
  if(key===GANG_KEY){gangBlock(bx0,bx1,bz0,bz1);continue;}
  if(PARK_AT[key]){const a=PARK_AT[key];(a[0]==='tower'?parkTowerBlock:parkLotBlock)(bx0,bx1,bz0,bz1,a[1],a[2]);continue;}
  if(GAS_AT[key]){const a=GAS_AT[key];gasBlock(bx0,bx1,bz0,bz1,a[0],a[1]);continue;}
  if(JUNK_AT[key]){junkyardBlock(bx0,bx1,bz0,bz1,JUNK_AT[key]);continue;}
  const ix0=bx0+3,ix1=bx1-3,iz0=bz0+3,iz1=bz1-3,W=ix1-ix0,D=iz1-iz0;
  if(kind==='city'){cityBlock(ix0,ix1,iz0,iz1,(cx,cz)=>1-Math.min(1,Math.hypot(cx-OLD_C,cz-OLD_C)/180));continue;}
  if(kind==='midcity'){cityBlock(ix0,ix1,iz0,iz1,()=>rand(0,.3),{neon:.25});continue;}
  if(kind==='suburb'){suburbBlock(ix0,ix1,iz0,iz1);continue;}
  if(kind==='slum'){slumBlock(ix0,ix1,iz0,iz1);continue;}
  if(kind==='harbor'){harborBlock(ix0,ix1,iz0,iz1,i%6);continue;}
  if(kind==='mineyard'){mineyardBlock(ix0,ix1,iz0,iz1);continue;}
  if(kind==='apartments'){apartmentsBlock(ix0,ix1,iz0,iz1);continue;}
  if(kind==='factory'){factoryBlock(bx0,bx1,bz0,bz1,i,j);continue;}
  if(kind==='prefab'){prefabBlock(ix0,ix1,iz0,iz1);continue;}
  if(park){
    const gr=mesh(UNIT,mat(0x2d553a),(ix0+ix1)/2,.15,(iz0+iz1)/2); gr.scale.set(W,.3,D); scene.add(gr);
    for(let t=0;t<9;t++) tree(rand(ix0+3,ix1-3),rand(iz0+3,iz1-3));
    const f=mesh(new THREE.CylinderGeometry(3.2,3.4,.7,16),mat(0x7d7a88),(ix0+ix1)/2,.5,(iz0+iz1)/2); scene.add(f);
    const wv=mesh(new THREE.CylinderGeometry(2.7,2.7,.1,16),new THREE.MeshLambertMaterial({color:0x4aa0d8,emissive:0x0d3050}),(ix0+ix1)/2,.86,(iz0+iz1)/2); scene.add(wv);
    addCollider((ix0+ix1)/2-3,(ix0+ix1)/2+3,(iz0+iz1)/2-3,(iz0+iz1)/2+3,1,true);
    continue;
  }
}

buildEstateFence();
// ---------- road graph: a road segment exists unless every block it touches is mountain or walled base ----------
const NN=N+1,NS=NZ+1; // node id = i*NS + j
const blkOpen=(i,j)=>i>=0&&j>=0&&i<N&&j<NZ&&!blocks[i*NZ+j].closed;
const blkClosed=(i,j)=>i>=0&&j>=0&&i<N&&j<NZ&&blocks[i*NZ+j].closed;
const SEG_H=new Uint8Array(N*NS),SEG_V=new Uint8Array(NZ*NN);
for(let i=0;i<N;i++)for(let j=0;j<=NZ;j++)SEG_H[i*NS+j]=blkOpen(i,j-1)||blkOpen(i,j)?1:0; // z=R[j], x from R[i] to R[i+1]
for(let i=0;i<=N;i++)for(let j=0;j<NZ;j++)SEG_V[j*NN+i]=blkOpen(i-1,j)||blkOpen(i,j)?1:0; // x=R[i], z from R[j] to R[j+1]
for(let i=1;i<N;i++)SEG_V[IND_J*NN+i]=0; // the estate fence: side streets stop short of it, only the two coast roads run through the gates
const segH=(i,j)=>i>=0&&i<N&&j>=0&&j<=NZ&&SEG_H[i*NS+j]===1;
const segV=(i,j)=>j>=0&&j<NZ&&i>=0&&i<=N&&SEG_V[j*NN+i]===1;
const nodeOpen=(i,j)=>segH(i-1,j)||segH(i,j)||segV(i,j-1)||segV(i,j);
// breadth-first distances (in road segments) from one intersection to every other
function nodeField(gi,gj){
  const f=new Int16Array(NS*NS).fill(-1);if(!nodeOpen(gi,gj))return f;
  const q=new Int16Array(NS*NS);let h=0,t=0;f[gi*NS+gj]=0;q[t++]=gi*NS+gj;
  while(h<t){const id=q[h++],i=(id/NS)|0,j=id%NS,d=f[id]+1;
    if(segH(i,j)&&f[id+NS]<0){f[id+NS]=d;q[t++]=id+NS;}
    if(segH(i-1,j)&&f[id-NS]<0){f[id-NS]=d;q[t++]=id-NS;}
    if(segV(i,j)&&f[id+1]<0){f[id+1]=d;q[t++]=id+1;}
    if(segV(i,j-1)&&f[id-1]<0){f[id-1]=d;q[t++]=id-1;}
  }
  return f;
}
const gridIdx=v=>Math.max(0,Math.min(N,Math.round((v-R[0])/CELL))),gridIdxZ=v=>Math.max(0,Math.min(NZ,Math.round((v-R[0])/CELL)));
function nearNode(p){
  const i0=gridIdx(p.x),j0=gridIdxZ(p.z);let best=null,bd=1e9;
  for(let r=1;r<=4&&!best;r++)for(let i=i0-r;i<=i0+r;i++)for(let j=j0-r;j<=j0+r;j++){
    if(i<0||j<0||i>N||j>NZ||!nodeOpen(i,j))continue;const d=Math.hypot(p.x-R[i],p.z-R[j]);if(d<bd){bd=d;best=[i,j];}}
  return best;
}
// intersections reachable from p without cutting through a block: the node you are at, the two ends of the road
// segment you are on, or (off the road, e.g. on the mountain) the nearest open intersection
function roadCands(p){
  const ix=gridIdx(p.x),iz=gridIdxZ(p.z),dx=Math.abs(p.x-R[ix]),dz=Math.abs(p.z-R[iz]);
  if(dx<10&&dz<10&&nodeOpen(ix,iz))return [[ix,iz]];
  if(dx<=HALF_ROAD+2&&dx<=dz){const j=clamp(Math.floor((p.z-R[0])/CELL),0,NZ-1);if(segV(ix,j))return [[ix,j],[ix,j+1]];}
  if(dz<=HALF_ROAD+2){const i=clamp(Math.floor((p.x-R[0])/CELL),0,N-1);if(segH(i,iz))return [[i,iz],[i+1,iz]];}
  const n=nearNode(p);return n?[n]:[];
}
// the intersection a driver at p should head for next to reach the field's goal (null = drive straight at the goal)
function routeNode(p,f){
  if(!f)return null;
  let best=-1,bc=1e9;
  for(const [i,j] of roadCands(p)){const id=i*NS+j;if(f[id]<0)continue;const c=Math.hypot(p.x-R[i],p.z-R[j])+f[id]*CELL;if(c<bc){bc=c;best=id;}}
  if(best<0)return null;
  const bi=(best/NS)|0,bj=best%NS,d=Math.hypot(p.x-R[bi],p.z-R[bj]);
  if(f[best]===0)return d>10?[bi,bj]:null;
  if(d<9){
    const k=f[best]-1;
    if(segH(bi,bj)&&f[best+NS]===k)return [bi+1,bj];
    if(segH(bi-1,bj)&&f[best-NS]===k)return [bi-1,bj];
    if(segV(bi,bj)&&f[best+1]===k)return [bi,bj+1];
    if(segV(bi,bj-1)&&f[best-1]===k)return [bi,bj-1];
  }
  return [bi,bj];
}
function routeTarget(p,f,goal){const bt=bridgeTarget(p,goal);if(bt)return bt;const n=routeNode(p,f);return n?new V3(R[n[0]],0,R[n[1]]):new V3(goal.x,goal.y||0,goal.z);}
// the airport island is only reachable over the bridge on z=R[3]: drivers on the wrong side head for it first
const onAirSide=p=>p.x<-548&&((p.x>AIR.x0-6&&p.z>AIR.z0-6&&p.z<AIR.z1+6)||(p.z>BRIDGE.z0-4&&p.z<BRIDGE.z1+4));
let HEAD_FIELD=null;
function bridgeTarget(pos,goal){
  const A=onAirSide(pos),B=onAirSide(goal);if(A===B)return null;
  if(B){
    HEAD_FIELD=HEAD_FIELD||nodeField(0,3);
    if(Math.hypot(pos.x-R[0],pos.z-R[3])>12){const n=routeNode(pos,HEAD_FIELD);return n?new V3(R[n[0]],0,R[n[1]]):new V3(R[0],0,R[3]);}
    return new V3(-985,0,R[3]);
  }
  if(pos.x>BRIDGE.x0-2&&Math.abs(pos.z-R[3])<9)return new V3(R[0]+10,0,R[3]);
  return new V3(BRIDGE.x0-6,0,R[3]);
}

// ---------- region extras: harbour quay, cranes and ships; base checkpoints ----------
{
  const z0=R[6],z1=R[12],qx=-EDGE-13;
  inst('quay',UNIT,PLAIN,qx,-.1,(z0+z1)/2,26,1.2,z1-z0,0,0x6a6a70);
  for(let z=z0+15;z<z1;z+=40){ // gantry cranes straddling the quay edge
    for(const a of [-1,1])for(const b of [-1,1]){inst('crane',UNIT,PLAIN,qx+a*6,14,z+b*5,1.1,28,1.1,0,0xd8a020);addCollider(qx+a*6-.55,qx+a*6+.55,z+b*5-.55,z+b*5+.55,28);}
    inst('crane',UNIT,PLAIN,qx-14,28.5,z,62,2.2,2,0,0xd8a020);
    inst('crane',UNIT,PLAIN,qx+4,30.5,z,4,2.4,3.2,0,0x3a3d44);
    inst('beaconI',UNIT,beaconMat,qx-44,29.9,z,.6,.6,.6,0,0xffffff);
  }
  for(const z of [z0+70,z1-80]){ // moored cargo ships
    const sx=-EDGE-45,hc=pick([0x7a1f1f,0x1f2f5a,0x2a2a2a]);
    inst('hull',UNIT,PLAIN,sx,1.2,z,15,7,84,0,hc);addCollider(sx-7.5,sx+7.5,z-42,z+42,5);inst('deck',UNIT,PLAIN,sx,4.8,z,14.6,.3,83,0,0x5a5a60);
    boxI('bridge',HOUSE,sx-6,sx+6,z+30,z+40,4.9,9,0xf2f2ee,false);
    for(let k=-3;k<=1;k++)for(let c=-1;c<=1;c++)inst('cont',UNIT,CORR,sx+c*4,6.4+(k%2?2.6:0)*.5,z+k*12,3.6,2.55,11,0,pick(CONT_COL));
  }
  // ladders down to the water and a few lifebuoys along the quay edge
  for(let z=z0+30;z<z1;z+=60){inst('ladder',UNIT,PLAIN,QUAY.x0-.1,-.4,z,.12,1.8,.9,0,0xb8bcc4);inst('buoy',cylG,UNLIT,QUAY.x0+.6,1.2,z+4,.35,.1,.35,0,0xff6a3d);}
  // marina: a timber jetty with boat slips, a sales booth on the quay
  boxI('jetty',PLAIN,JETTY.x0,JETTY.x1,JETTY.z0,JETTY.z1,-1.5,2,0x8a6a4a,false);
  for(let x=JETTY.x0+2;x<JETTY.x1;x+=6)for(const z of [JETTY.z0+.3,JETTY.z1-.3])inst('piling',cylG,PLAIN,x,-1.9,z,.3,3,.3,0,0x4a3a2a);
  for(let x=JETTY.x0+4;x<JETTY.x1;x+=9){for(const z of [JETTY.z0+.4,JETTY.z1-.4])inst('bollard',cylG,PLAIN,x,.75,z,.2,.5,.2,0,0xd8d8d0);}
  for(const x of [JETTY.x0+3,JETTY.x0+33]){inst('fpost',UNIT,PLAIN,x,2.2,JETTY.z1-.4,.12,3.4,.12,0,0x3a3a46);inst('flood',UNIT,UNLIT,x,3.9,JETTY.z1-.4,.4,.25,.4,0,0xfff1c4);}
  boxI('mbooth',HOUSE,-571,-564,-17,-11,.5,3,0xe8f2f6,true);boxI('mboothRoof',PLAIN,-571.5,-563.5,-17.5,-10.5,3.5,.25,0x2e86c1,false);
  inst('mboothWin',UNIT,UNLIT,-571.05,2,-14,.05,1,3,0,0xbfe6ff);
  signPlane(['마리나','HARBOR MARINA · 보트 판매'],'#062a33','#7ff3ff',-571.1,4.6,-14,6,1.8,-Math.PI/2);
  LOCS.push({type:'marina',T:LOC_TYPES.marina,look:'harbor',name:'마리나',title:'하버 마리나',sub:'HARBOR MARINA · 보트 판매',sign:['마리나',''],door:new V3(-568,0,-7),out:{x:-1,z:0},robCD:0,room:null,cz:-7});
  addRing(-568,-7,LOC_TYPES.marina.color);
}

// ---------- the walled military base on the east coast ----------
const BASE={x0:R[15]+HALF_ROAD,x1:EDGE-2,z0:R[8]+HALF_ROAD,z1:R[11]-HALF_ROAD};
const inBase=p=>p.x>BASE.x0&&p.x<BASE.x1&&p.z>BASE.z0&&p.z<BASE.z1;
const GATES=[{side:'w',at:R[9]},{side:'n',at:R[16]},{side:'s',at:R[17]}];
const GUARD_SLOTS=[];
const WIRE=new THREE.MeshBasicMaterial({color:0xffffff,wireframe:true});
const MESHMAT=new THREE.MeshLambertMaterial({color:0xffffff,transparent:true,opacity:.3,depthWrite:false,side:THREE.DoubleSide});
const coilG=new THREE.CylinderGeometry(1,1,1,7,6,true);coilG.rotateZ(Math.PI/2);
{
  const B=BASE,FC=0x5a5e52;
  boxI('baseSlab',PLAIN,B.x0,EDGE,B.z0,B.z1,0,.2,0x6e705f,false);
  // chain-link fence with razor wire on top; runs are split around the gates
  function fenceRun(ax,az,bx_,bz){
    const len=Math.hypot(bx_-ax,bz-az);if(len<.5)return;
    const horiz=Math.abs(bz-az)<1e-6,n=Math.max(1,Math.round(len/4));
    for(let k=0;k<=n;k++){const t=k/n,x=ax+(bx_-ax)*t,z=az+(bz-az)*t;inst('fpost',UNIT,PLAIN,x,1.85,z,.16,3.7,.16,0,FC);}
    for(let k=0;k<n;k++){const t=(k+.5)/n,x=ax+(bx_-ax)*t,z=az+(bz-az)*t,l=len/n;inst('coil',coilG,WIRE,x,3.95,z,l,.32,.32,horiz?0:Math.PI/2,0x9a9a92);}
    const cx=(ax+bx_)/2,cz=(az+bz)/2;
    for(const y of [.25,1.8,3.4])inst('frail',UNIT,PLAIN,cx,y,cz,horiz?len:.06,.06,horiz?.06:len,0,FC);
    inst('fmesh',UNIT,MESHMAT,cx,1.8,cz,horiz?len:.03,3.2,horiz?.03:len,0,0x9aa098);
    if(horiz)addCollider(Math.min(ax,bx_),Math.max(ax,bx_),az-.15,az+.15,3.7);else addCollider(ax-.15,ax+.15,Math.min(az,bz),Math.max(az,bz),3.7);
  }
  const GAP=5.5;
  fenceRun(B.x0,B.z0,B.x0,GATES[0].at-GAP);fenceRun(B.x0,GATES[0].at+GAP,B.x0,B.z1);
  fenceRun(B.x0,B.z0,GATES[1].at-GAP,B.z0);fenceRun(GATES[1].at+GAP,B.z0,B.x1,B.z0);
  fenceRun(B.x0,B.z1,GATES[2].at-GAP,B.z1);fenceRun(GATES[2].at+GAP,B.z1,B.x1,B.z1);
  fenceRun(B.x1,B.z0,B.x1,PIER_W.z0-1);fenceRun(B.x1,PIER_W.z1+1,B.x1,B.z1);
  // naval pier: a walkway out from the base's sea gate, T-head, pilings, bollards, a crane and lamps
  boxI('pier',PLAIN,PIER_W.x0,PIER_W.x1,PIER_W.z0,PIER_W.z1,-1.6,2,0x8a8a84,false);
  boxI('pier',PLAIN,PIER_H.x0,PIER_H.x1,PIER_H.z0,PIER_H.z1,-1.6,2,0x8a8a84,false);
  for(let x=PIER_W.x0+6;x<PIER_W.x1;x+=8)for(const z of [PIER_W.z0+.6,PIER_W.z1-.6])inst('piling',cylG,PLAIN,x,-2,z,.4,3,.4,0,0x4a4440);
  for(let z=PIER_H.z0+4;z<PIER_H.z1;z+=8)for(const x of [PIER_H.x0+.6,PIER_H.x1-.6])inst('piling',cylG,PLAIN,x,-2,z,.4,3,.4,0,0x4a4440);
  for(let x=PIER_W.x0+10;x<PIER_H.x0;x+=10)for(const z of [PIER_W.z0+.5,PIER_W.z1-.5]){inst('bollard',cylG,PLAIN,x,.75,z,.28,.7,.28,0,0x2a2c30);}
  for(const z of [PIER_W.z0+.8,PIER_W.z1-.8])for(let x=PIER_W.x0+20;x<PIER_W.x1;x+=30){inst('fpost',UNIT,PLAIN,x,2.4,z,.16,4,.16,0,0x5a5e52);inst('flood',UNIT,UNLIT,x,4.5,z,.5,.3,.5,0,0xfff6dc);}
  boxI('termBox',PLAIN,PIER_H.x0+5,PIER_H.x0+6,PIER_H.z1-10.2,PIER_H.z1-9.6,.4,1.5,0x3a4250,true);inst('termScr',UNIT,UNLIT,PIER_H.x0+5.5,1.4,PIER_H.z1-10.25,.7,.4,.04,0,0xffb53d);
  boxI('pierHut',HOUSE,PIER_H.x0+3,PIER_H.x0+8,PIER_H.z1-9,PIER_H.z1-3,.4,2.8,0xd8d8c8,true);boxI('boothRoof',PLAIN,PIER_H.x0+2.6,PIER_H.x0+8.4,PIER_H.z1-9.4,PIER_H.z1-2.6,3.2,.25,0x3a3a2e,false);
  inst('craneMast',UNIT,PLAIN,PIER_H.x1-4,6,PIER_H.z0+6,.8,11,.8,0,0xd8a020);inst('craneArm',UNIT,PLAIN,PIER_H.x1-4,11.2,PIER_H.z0+11,.6,.6,10,0,0xd8a020);addCollider(PIER_H.x1-4.5,PIER_H.x1-3.5,PIER_H.z0+5.5,PIER_H.z0+6.5,11);
  for(let k=0;k<3;k++)boxI('cont',CORR,PIER_H.x0+3,PIER_H.x0+5.5,PIER_H.z0+3+k*3.2,PIER_H.z0+5.5+k*3.2,.4,2.5,pick([0x5f6648,0x4a5a6a,0x6a6a5a]),true);
  signPlane(['해군 부두','NAVAL PIER · 관계자 외 출입 금지'],'#0d1a2a','#e8c547',B.x1+.3,4.2,(PIER_W.z0+PIER_W.z1)/2,7,2,Math.PI/2);
  // gates: booth, striped barrier, floodlight, two sentries each
  for(const G of GATES){
    const w=G.side==='w',gx=w?B.x0:G.at,gz=w?G.at:(G.side==='n'?B.z0:B.z1),inn=G.side==='n'?1:-1;
    const bx_=w?gx+3.2:gx+GAP+2.2,bz=w?gz-GAP-2.2:gz+inn*3.2;
    boxI('booth',HOUSE,bx_-1.3,bx_+1.3,bz-1.3,bz+1.3,.2,2.8,0xd8d8c8,true);boxI('boothRoof',PLAIN,bx_-1.7,bx_+1.7,bz-1.7,bz+1.7,3,.25,0x3a3a2e,false);
    inst('boothWin',UNIT,UNLIT,bx_,1.9,bz,2.66,.7,2.66,0,0xfff1c4);
    for(let k=0;k<5;k++){const t=-GAP+1+k*2;inst('barrier',UNIT,PLAIN,w?gx+.4:gx+t,1.05,w?gz+t:gz+inn*.4,w?.14:2,.14,w?2:.14,0,k%2?0xf2f2f2:0xd23a2a);}
    inst('fpole2',UNIT,PLAIN,w?gx+.4:gx+GAP-.2,.6,w?gz+GAP-.2:gz+inn*.4,.3,1.2,.3,0,0x3a3a2e);
    inst('flood',UNIT,UNLIT,w?gx+1:gx-GAP-.6,4.4,w?gz-GAP-.6:gz+inn*1,.6,.35,.6,0,0xfff6dc);inst('fpost',UNIT,PLAIN,w?gx+1:gx-GAP-.6,2.2,w?gz-GAP-.6:gz+inn*1,.16,4.4,.16,0,FC);
    for(let k=0;k<3;k++)boxI('sand',PLAIN,w?gx+2:gx-GAP-4+k*1.3,w?gx+3:gx-GAP-2.8+k*1.3,w?gz+GAP+1+k*1.3:gz+inn*2,w?gz+GAP+2.2+k*1.3:gz+inn*3,.2,1,0x9a8a6a,true);
    const face=w?-Math.PI/2:G.side==='n'?Math.PI:0;
    for(const o of [-GAP-1.2,GAP+1.2])GUARD_SLOTS.push({x:w?gx+1.6:gx+o,z:w?gz+o:gz+inn*1.6,yaw:face,p:null});
  }
  signPlane(['군사 기지','출입 통제 구역 · 무단 침입 시 발포'],'#2a2e1c','#e8c547',B.x0-.2,4.6,GATES[0].at+GAP+5,8,2.4,-Math.PI/2);
  // hangars on the north side
  for(const hx of [465,515]){
    const hz=B.z0+16;
    inst('hangar',hangarG,PLAIN,hx,0,hz,30,9.5,11,0,0x6b7050);
    inst('hdoor',UNIT,PLAIN,hx+15.05,3.25,hz,.2,6.5,12,0,0x3a3d32);
    addCollider(hx-15,hx+15,hz-11,hz+11,9.5);
  }
  // barracks
  for(const z of [25,40,55]){boxI('barr',HOUSE,398,426,z-3.5,z+3.5,0,5,0x9aa080,true);boxI('barrRoof',PLAIN,397.7,426.3,z-3.8,z+3.8,5,.35,0x4a4f3a,false);}
  // helipad with a parked helicopter, control tower
  {const cx=505,cz=38;
    inst('pad',cylG,PLAIN,cx,.27,cz,11,.06,11,0,0x34373a);inst('padRing',cylG,UNLIT,cx,.26,cz,11.6,.04,11.6,0,0xe8e2d4);
    inst('padH',UNIT,PLAIN,cx-2.5,.32,cz,1,.04,7,0,0xe8c547);inst('padH',UNIT,PLAIN,cx+2.5,.32,cz,1,.04,7,0,0xe8c547);inst('padH',UNIT,PLAIN,cx,.32,cz,5,.04,1,0,0xe8c547);

    boxI('ctower',PLAIN,535,543,70,78,0,16,0x8a8a7a,true);boxI('ccab',UNLIT,534.5,543.5,69.5,78.5,16,2.8,0x6fb0d0,false);boxI('croof',PLAIN,534,544,69,79,18.8,.4,0x3a3a2e,false);}
  // fuel depot and trucks
  for(const x of [512,524,536]){inst('tank',cylG,PLAIN,x,3.5,100,4,7,4,0,0xb8b8a8);addCollider(x-4,x+4,96,104,7);}
  // motor pool: parked trucks and an APC (real vehicles, spawned later), key locker on the wall
  boxI('mpool',PLAIN,436,462,70,96,0,.06,0x5a5c50,false);
  for(const z of [74,83,92])inst('padH',UNIT,PLAIN,449,.26,z,24,.04,.2,0,0xe8c547);
  // key terminals: each hands out the key/code for one kind of military vehicle
  boxI('termBox',PLAIN,430.6,431.4,71,73,0,2,0x3a4250,true);inst('termScr',UNIT,UNLIT,431.45,1.4,72,.04,.5,.9,0,0x7dffa8);
  boxI('termBox',PLAIN,538,540,66.6,67.4,0,1.6,0x3a4250,true);inst('termScr',UNIT,UNLIT,539,1.2,67.45,.9,.5,.04,0,0x5fd0ff);
  // flagpole on the parade ground
  inst('fpole',UNIT,PLAIN,410,6,-8,.16,12,.16,0,0x6a6a60);inst('flag',UNIT,UNLIT,410,11,-7,.04,1.4,2.2,0,0x4a5a2a);
  // watchtowers in the corners
  for(const [tx,tz] of [[B.x0+4,B.z0+4],[B.x1-4,B.z0+4],[B.x0+4,B.z1-4],[B.x1-4,B.z1-4]]){
    for(const a of [-1,1])for(const b of [-1,1])inst('tleg',UNIT,PLAIN,tx+a*1.3,4.5,tz+b*1.3,.25,9,.25,0,0x4a4a3a);
    boxI('tcab',PLAIN,tx-1.8,tx+1.8,tz-1.8,tz+1.8,9,2.4,0x6a6a52,false);boxI('troof',PLAIN,tx-2.2,tx+2.2,tz-2.2,tz+2.2,11.4,.3,0x3a3a2e,false);
    inst('tlight',UNIT,UNLIT,tx,10.6,tz,3.7,.4,3.7,0,0xfff1c4);addCollider(tx-1.5,tx+1.5,tz-1.5,tz+1.5,12);
  }
  for(const [x,z] of [[400,-8],[480,10],[455,60],[530,-5]])GUARD_SLOTS.push({x,z,yaw:rand(0,6.28),p:null,inner:true});
}

// ---------- mountain: forest, boulders and the mine portal cut into its southern ridge ----------
{
  let n=0;
  for(let k=0;k<2600&&n<520;k++){
    const x=rand(-170,170),z=rand(-170,230);if(!inMountain(x,z))continue;
    const h=terrainH(x,z);if(h<1.2||h>66||(Math.abs(x)<17&&z>186))continue;
    if(RNG()<h/90)continue; // thinner forest higher up
    const sc=rand(.75,1.35),y=h-.4;n++;
    inst('trunk',trunkG,PLAIN,x,y+.9*sc,z,.7*sc,.75*sc,.7*sc,0,0x4a3526);
    inst('pine',pineG,PLAIN,x,y+4.6*sc,z,1.8*sc,6*sc,1.8*sc,rand(0,6),pick([0x1f4a30,0x24553a,0x2a5e3c,0x2f6a40]));
    addCollider(x-.35,x+.35,z-.35,z+.35,y+5,true);
  }
  for(let k=0;k<160;k++){
    const x=rand(-170,170),z=rand(-170,230);if(!inMountain(x,z))continue;const h=terrainH(x,z);if(h<2||(Math.abs(x)<18&&z>184))continue;
    const sc=rand(1,3.4);inst('rock',rockG,PLAIN,x,h+sc*.25,z,sc*rand(1,1.6),sc*rand(.6,1),sc*rand(1,1.6),rand(0,6),pick(ROCK_COL));
    if(sc>2.2)addCollider(x-sc*.9,x+sc*.9,z-sc*.9,z+sc*.9,h+sc*.9);
  }
  // portal: stone headwall, timber frame, rails out into the forecourt
  const z=MINE_Z;
  boxI('headwall',PLAIN,-8,8,z-7,z-.2,0,8.5,0x6b6458,true);
  inst('mineDark',UNIT,UNLIT,0,2.75,z-.12,5.6,5.5,.1,0,0x050404);
  for(const sx of [-1,1])inst('beam',UNIT,PLAIN,sx*3.2,2.9,z+.1,.6,5.8,.6,0,0x6a4a2a);
  inst('beam',UNIT,PLAIN,0,5.9,z+.1,7.6,.7,.7,0,0x6a4a2a);
  inst('minelamp',UNIT,UNLIT,0,5.2,z+.5,.5,.3,.2,0,0xffc070);
  for(const sx of [-1,1])inst('minelamp',UNIT,UNLIT,sx*5,4.2,z+.05,.4,.4,.1,0,0xffc070);
  signPlane(['광산 갱도','HARBOR MINE · 입구'],'#2a1d10','#ffb53d',0,7.4,z+.02,6.4,1.9,0);
  const L=232-(z+1),zc=z+1+L/2;
  for(const sx of [-1,1])inst('rail',UNIT,PLAIN,sx*.7,.16,zc,.12,.08,L,0,0x5a5a60);
  for(let t=z+1.5;t<231;t+=1.2)inst('sleeper',UNIT,PLAIN,0,.09,t,2,.08,.3,0,0x4a3424);
  for(const t of [z+12,z+20]){boxI('cart',PLAIN,-.8,.8,t-1.1,t+1.1,.35,1.1,0x4a4a52,true);inst('ore',rockG,PLAIN,0,1.55,t,.7,.35,.9,rand(0,6),0x6a5a48);}
  for(const [x,t] of [[-9,z+6],[9,z+8],[-10,z+16]])inst('pile',rockG,PLAIN,x,1,t,3.4,2,3.4,rand(0,6),pick([0x6a5a48,0x5a5048,0x7a6a50]));
  addCollider(-11,-7,z+4,z+8,1.8);addCollider(7,11,z+6,z+10,1.8);addCollider(-12,-8,z+14,z+18,1.8);
  const D=new V3(0,0,z+3.6);
  LOCS.push({type:'mine',T:LOC_TYPES.mine,look:'mine',name:'광산 갱도',title:LOC_TYPES.mine.title,sub:LOC_TYPES.mine.sub,sign:['광산 갱도',''],door:D,out:{x:0,z:1},robCD:0,room:null,cz:D.z,roadX:0});
  addRing(D.x,D.z,LOC_TYPES.mine.color);
}
// ---------- islands across the water: the airport (bridge + ferry), the air force base, two islets ----------
const coneG=new THREE.ConeGeometry(1,1,12),jetNoseG=new THREE.ConeGeometry(1,1,12),cylZ=new THREE.CylinderGeometry(1,1,1,14),domeG=new THREE.SphereGeometry(1,16,10);
jetNoseG.rotateX(Math.PI/2);cylZ.rotateX(Math.PI/2);
// flat planform (wing, tailplane) from an outline in (span, chord) and a fin from an outline in (chord, height)
function planG(pts,th){const sh=new THREE.Shape();sh.moveTo(pts[0][0],pts[0][1]);for(let k=1;k<pts.length;k++)sh.lineTo(pts[k][0],pts[k][1]);
  const g=new THREE.ExtrudeGeometry(sh,{depth:th,bevelEnabled:false});g.rotateX(Math.PI/2);g.translate(0,th/2,0);return g;}
function finG(pts,th){const sh=new THREE.Shape();sh.moveTo(pts[0][0],pts[0][1]);for(let k=1;k<pts.length;k++)sh.lineTo(pts[k][0],pts[k][1]);
  const g=new THREE.ExtrudeGeometry(sh,{depth:th,bevelEnabled:false});g.translate(0,0,-th/2);g.rotateY(-Math.PI/2);return g;}
const sweptWing=(span,rf,root,tip,sweep)=>[[0,rf],[span,rf-sweep],[span,rf-sweep-tip],[0,rf-root],[-span,rf-sweep-tip],[-span,rf-sweep]];
// twin-engine airliner, nose toward +z: round fuselage, swept low wing, podded engines, T-free conventional tail, gear that retracts
function makeAirliner(tail,stripe,lights){
  const g=new THREE.Group(),W=mat(0xf4f6f8),Gr=mat(0xb8bec8),T=mat(tail),D=mat(0x141a26),S=mat(stripe),Rr=2,L=26;
  const f=mesh(cylZ,W);f.scale.set(Rr,Rr,L);g.add(f);
  const belly=mesh(cylZ,Gr);belly.scale.set(Rr*.97,Rr*.6,L*.96);belly.position.y=-.85;g.add(belly);
  const n=mesh(domeG,W);n.scale.set(Rr,Rr,Rr*2.2);n.position.z=L/2;g.add(n);
  const tc=mesh(jetNoseG,W);tc.scale.set(Rr,Rr*.92,7.5);tc.rotation.y=Math.PI;tc.position.set(0,.32,-L/2-3.75);g.add(tc);
  g.add(mesh(bx(2.3,.5,1.3),D,0,1.05,L/2+2.5));
  for(const sx of [-1,1]){g.add(mesh(bx(.06,.34,L-5),D,sx*1.95,.62,.6));g.add(mesh(bx(.06,.28,L+1),S,sx*1.99,-.05,0));
    for(const dz of [L/2-2.4,-L/2+2.2])g.add(mesh(bx(.07,1.5,.8),Gr,sx*1.96,.3,dz));}
  const wing=mesh(planG(sweptWing(15,2.2,7.2,1.9,7.4),.42),mat(0xe4e8ee));wing.position.set(0,-1.05,0);g.add(wing);
  for(const sx of [-1,1]){const tip=mesh(bx(.1,1.4,1.3),T,sx*15,-.3,-5.8);tip.rotation.x=-.2;g.add(tip);}
  for(const sx of [-1,1]){
    const e=mesh(cylZ,mat(0xdfe3e9));e.scale.set(1,1,4.2);e.position.set(sx*5.6,-2.05,3.2);g.add(e);
    const ia=mesh(cylZ,D);ia.scale.set(.82,.82,.1);ia.position.set(sx*5.6,-2.05,5.32);g.add(ia);
    const ex=mesh(jetNoseG,Gr);ex.scale.set(.7,.7,1.2);ex.rotation.y=Math.PI;ex.position.set(sx*5.6,-2.05,.6);g.add(ex);
    g.add(mesh(bx(.25,.9,2.4),W,sx*5.6,-1.35,2.2));
  }
  const hs=mesh(planG(sweptWing(5.6,-L/2-1.2,3.4,1.3,2.7),.22),mat(0xe4e8ee));hs.position.y=.55;g.add(hs);
  const vf=mesh(finG([[-L/2+1.6,0],[-L/2-2.6,6.6],[-L/2-4.7,6.6],[-L/2-4.6,0]],.32),T);vf.position.y=1.5;g.add(vf);
  const gear=new THREE.Group();g.add(gear);g.userData.gear=gear;
  for(const [gx,gz] of [[0,L/2-.6],[-2.3,-.8],[2.3,-.8]]){gear.add(mesh(bx(.22,1.4,.22),Gr,gx,-Rr-.6,gz));
    for(const o of gx?[-.35,.35]:[0]){const w=mesh(cylZ,mat(0x16181c));w.rotation.y=Math.PI/2;w.scale.set(.5,.5,.32);w.position.set(gx+o,-Rr-1.25,gz);gear.add(w);}}
  if(lights){const lt=new THREE.Sprite(tailMat);lt.scale.set(1.5,1.5,1);lt.position.set(15,-.6,-5.8);g.add(lt);
  const lt2=new THREE.Sprite(headMat);lt2.scale.set(1.5,1.5,1);lt2.position.set(-15,-.6,-5.8);g.add(lt2);}
  if(lights){const bc=new THREE.Sprite(tailMat);bc.scale.set(1.1,1.1,1);bc.position.set(0,Rr+.15,-2);g.add(bc);}
  scene.add(g);return g;
}
// single-seat fighter: pointed nose, bubble canopy, cropped delta, twin canted fins, glowing nozzle
function makeFighter(lights,gear){
  const g=new THREE.Group(),Gm=mat(0x6c737d),Dk=mat(0x3c424a),L=11;
  const f=mesh(cylZ,Gm);f.scale.set(.85,.75,L);g.add(f);
  const n=mesh(jetNoseG,Gm);n.scale.set(.85,.75,4.6);n.position.z=L/2+2.3;g.add(n);
  const cp=mesh(domeG,mat(0x1c2a3a));cp.scale.set(.55,.5,1.9);cp.position.set(0,.62,3.2);g.add(cp);
  for(const sx of [-1,1])g.add(mesh(bx(.7,.8,3.4),Dk,sx*1,-.1,1.6));
  const w=mesh(planG([[0,3],[5.4,-2.6],[5.4,-4.2],[0,-4.6],[-5.4,-4.2],[-5.4,-2.6]],.2),Gm);w.position.y=-.1;g.add(w);
  const hs=mesh(planG(sweptWing(2.8,-4.4,2.2,.9,1.6),.14),Gm);hs.position.y=-.05;g.add(hs);
  for(const sx of [-1,1]){const fin=mesh(finG([[-2.6,0],[-4.6,2.7],[-5.6,2.7],[-5.7,0]],.14),Dk);fin.position.set(sx*.9,.35,0);fin.rotation.z=-sx*.32;g.add(fin);}
  const nz=mesh(cylZ,Dk);nz.scale.set(.6,.6,1);nz.position.z=-L/2-.4;g.add(nz);
  const fl=mesh(cylZ,bmat(0xff8a3d));fl.scale.set(.46,.46,.12);fl.position.z=-L/2-.95;g.add(fl);
  if(lights){const lt=new THREE.Sprite(tailMat);lt.scale.set(1,1,1);lt.position.set(5.4,0,-3.6);g.add(lt);
    const lt2=new THREE.Sprite(headMat);lt2.scale.set(1,1,1);lt2.position.set(-5.4,0,-3.6);g.add(lt2);}
  if(gear)for(const [gx,gz] of [[0,4.6],[-1.3,-1.6],[1.3,-1.6]]){g.add(mesh(bx(.14,1,.14),Dk,gx,-1.1,gz));const w=mesh(cylZ,mat(0x16181c));w.rotation.y=Math.PI/2;w.scale.set(.36,.36,.24);w.position.set(gx,-1.6,gz);g.add(w);}
  scene.add(g);return g;
}
{
  const isle=(I,sand,grass)=>{ // flat island: sandy rim, grass top, rocky skirt below the waterline
    boxI('isleBase',PLAIN,I.x0-6,I.x1+6,I.z0-6,I.z1+6,-4,3.6,0x8a7a5a,false);
    boxI('isleSand',PLAIN,I.x0-2,I.x1+2,I.z0-2,I.z1+2,-.6,.58,sand,false);
    boxI('isleTop',PLAIN,I.x0+4,I.x1-4,I.z0+4,I.z1-4,-.05,.06,grass,false);
  };
  const lampRow=(x0,z0,x1,z1,step)=>{const L=Math.hypot(x1-x0,z1-z0),n=Math.floor(L/step);for(let k=0;k<=n;k++){const t=n?k/n:0,x=x0+(x1-x0)*t,z=z0+(z1-z0)*t;
    inst('fpost',UNIT,PLAIN,x,3,z,.16,6,.16,0,0x3a3a46);inst('flood',UNIT,UNLIT,x,6.1,z,.5,.25,.5,0,0xffd08a);}};
  // --- airport island
  const A=AIR;isle(A,0xcdbb8a,0x4f6a3a);
  boxI('apron',PLAIN,-1250,-1110,-510,-210,0,.04,0x6a6c70,false);
  boxI('runway',PLAIN,-1305,-1255,-545,-175,0,.05,0x2c2d33,false);
  for(let z=-530;z<-185;z+=14)inst('rwDash',UNIT,UNLIT,-1280,.07,z,.6,.02,6,0,0xf2f2f2);
  for(let z=-540;z<-178;z+=10)for(const x of [-1304,-1256])inst('rwLight',UNIT,UNLIT,x,.12,z,.3,.1,.3,0,0xffd08a);
  for(let k=0;k<6;k++)for(const z of [-538,-182])inst('rwEnd',UNIT,PLAIN,-1300+k*8,.07,z,5,.02,1.5,0,0xf2f2f2);
  boxI('taxi',PLAIN,-1255,-1235,-500,-220,0,.045,0x34353b,false);
  // the road off the bridge and the drop-off forecourt
  boxI('isleRoad',PLAIN,-1046,-960,BRIDGE.z0,BRIDGE.z1,0,.04,0x2c2d33,false);
  boxI('forecourt',PLAIN,-1046,-990,-420,-300,0,.04,0x34353b,false);
  for(let x=-1040;x<-962;x+=6)inst('dash',UNIT,UNLIT,x,.07,-360,2.4,.02,.22,0,0xe8dcc0);
  // terminal: long glass hall with a roof canopy
  boxI('terminal',PLAIN,-1112,-1048,-445,-275,0,15,0xd8dde6,true);
  inst('termGlass',UNIT,UNLIT,-1047.9,6,-360,.08,10,150,0,0x9fd8ff);
  for(let z=-440;z<=-280;z+=10)inst('termMull',UNIT,PLAIN,-1047.7,6,z,.25,10.2,.25,0,0x3a4250);
  boxI('termRoof',PLAIN,-1116,-1040,-450,-270,15,1,0xeef2f6,false);
  boxI('canopy',PLAIN,-1048,-1036,-420,-300,5.2,.4,0xeef2f6,false);
  for(let z=-410;z<=-310;z+=20)inst('canopyPost',UNIT,PLAIN,-1037,2.6,z,.3,5.2,.3,0,0xc8ccd4);
  signPlane(['네온 아일랜드 국제공항','NEON ISLAND INTERNATIONAL AIRPORT'],'#0d1a3a','#7ff3ff',-1047.6,13,-360,40,4.4,Math.PI/2);
  // control tower
  inst('ctwr',cylG,PLAIN,-1092,20,-492,4,40,4,0,0xd8dde6);addCollider(-1096,-1088,-496,-488,40);
  inst('ctwrCab',cylG,UNLIT,-1092,41.5,-492,6.5,3,6.5,0,0x6fb0d0);inst('ctwrTop',cylG,PLAIN,-1092,43.3,-492,7,.6,7,0,0x3a3a46);
  inst('beaconI',UNIT,beaconMat,-1092,44.2,-492,.8,.8,.8,0,0xffffff);
  // airliners parked at the gates, with jet bridges
  for(const z of [-415,-335,-255]){
    {const j=makeAirliner([0x2e86c1,0xd23a2a,0x2fa35a][(z+415)/80],[0x2e86c1,0xd23a2a,0x2fa35a][(z+415)/80]);j.position.set(-1174,3.35,z);j.rotation.y=Math.PI/2;}
    addCollider(-1190,-1154,z-2.6,z+2.6,6);addCollider(-1180,-1172,z-18,z+18,3);
    inst('jbridge',UNIT,PLAIN,-1131,4.6,z+3,34,3,3,0,0xc8ccd4);addCollider(-1148,-1112,z+1.5,z+4.5,6);
  }
  // car park with a few cars
  boxI('carpark',PLAIN,-1040,-990,-292,-200,0,.04,0x3a3c44,false);
  {const spots=[];
    for(const [rx,h] of [[-1034,-Math.PI/2],[-1027,Math.PI/2],[-1004,-Math.PI/2],[-997,Math.PI/2]]){
      for(let k=0;k<29;k++){const z=-288+k*2.9;if(z>-204)break;spots.push({x:rx,z,h});}
      for(let k=0;k<=29;k++){const z=-289.45+k*2.9;if(z>-202)break;boxI('apLine',UNLIT,rx-2.6,rx+2.6,z-.05,z+.05,.06,.01,0xf2f2f2,false);}
    }
    for(const x of [-1015.5])for(let z=-286;z<-206;z+=8)inst('apArrow',UNIT,UNLIT,x,.07,z,.5,.01,2.4,0,0xe8dcc0);
    boxI('apBooth',HOUSE,-1018,-1013,-296,-292,0,2.8,0xe8f2f6,true);
    signPlane(['P 공항 주차장','AIRPORT PARKING · 단기 · 장기'],'#0d2a4a','#ffffff',-1015.5,4,-296.2,8,1.6,Math.PI);
    addParking(-1040,-990,-292,-200,'공항 주차장',spots,-1015,-246);}
  gasStation(-989,-965,-298,-274,'공항 주유소');
  // airport security office with its patrol cars and guards at the terminal doors
  boxI('secOff',HOUSE,-1032,-1008,-472,-456,0,5,0xdfe4ec,true);boxI('secRoof',PLAIN,-1032.4,-1007.6,-472.4,-455.6,5,.35,0x1f4fa8,false);
  inst('secBand',UNIT,PLAIN,-1020,3.6,-455.9,24,.6,.1,0,0x1f4fa8);
  signPlane(['공항 경비대','AIRPORT SECURITY'],'#0d1a3a','#ffffff',-1020,4.4,-455.8,9,1.2,0);
  for(const x of [-1026,-1014])stationSpots.push({x,z:-449,h:0});
  for(const [x,z,y] of [[-1043,-376,Math.PI/2],[-1043,-344,Math.PI/2],[-1020,-453.5,0]])GUARD_SLOTS.push({x,z,yaw:y,p:null,kind:'cop',weapon:'pistol',look:{vest:0x1f4fa8,hat:0x1f4fa8},airport:true});
  lampRow(-1044,-366,-964,-366,16);lampRow(-1044,-354,-964,-354,16);
  for(let k=0;k<26;k++){const x=rand(A.x0+8,A.x1-8),z=rand(A.z0+8,A.z1-8);if(x>-1310&&x<-1030&&z>-545&&z<-175)continue;if(x>-1050&&z>-450&&z<-180)continue;treeI(x,z,rand(.9,1.3));}
  // ferry pier and ticket kiosk on the airport side
  boxI('ferryPier',PLAIN,FERRY_B.x0,FERRY_B.x1,FERRY_B.z0,FERRY_B.z1,-1.5,2,0x8a6a4a,false);
  boxI('kiosk',HOUSE,-972,-964,-236,-228,0,3,0xe8f2f6,true);
  signPlane(['페리 터미널','FERRY · 하버 ↔ 공항'],'#062a33','#7ff3ff',-963.9,4,-232,6,1.6,Math.PI/2);
  // --- west islet: lighthouse
  const W=ISLET_W;isle(W,0xcdbb8a,0x3f5a34);
  const lx=(W.x0+W.x1)/2,lz=(W.z0+W.z1)/2;
  for(let k=0;k<6;k++)inst('lhouse',cylG,PLAIN,lx,1.5+k*3,lz,3-k*.15,3,3-k*.15,0,k%2?0xd23a2a:0xf2f2f2);
  inst('lhLamp',cylG,UNLIT,lx,19.5,lz,2,2,2,0,0xfff1c4);inst('lhRoof',coneG,PLAIN,lx,21.6,lz,2.6,2.2,2.6,0,0x2a2a2e);addCollider(lx-3,lx+3,lz-3,lz+3,20);
  for(let k=0;k<14;k++)pineI(rand(W.x0+8,W.x1-8),rand(W.z0+8,W.z1-8),rand(.8,1.2));
  for(let k=0;k<10;k++)inst('rock',rockG,PLAIN,rand(W.x0,W.x1),.5,rand(W.z0,W.z1),rand(1.5,3),rand(1,2),rand(1.5,3),rand(0,6),pick(ROCK_COL));
  // --- east islet: rocks and pines
  const E=ISLET_E;isle(E,0xbfae80,0x445a36);
  for(let k=0;k<18;k++)pineI(rand(E.x0+8,E.x1-8),rand(E.z0+8,E.z1-8),rand(.8,1.3));
  for(let k=0;k<14;k++)inst('rock',rockG,PLAIN,rand(E.x0,E.x1),.6,rand(E.z0,E.z1),rand(1.5,4),rand(1,3),rand(1.5,4),rand(0,6),pick(ROCK_COL));
  // --- air force base island (restricted)
  const F=AFB;isle(F,0xbfae80,0x56603e);
  boxI('afbRunway',PLAIN,995,1385,-205,-155,0,.05,0x2c2d33,false);
  for(let x=1005;x<1380;x+=14)inst('rwDash',UNIT,UNLIT,x,.07,-180,6,.02,.6,0,0xf2f2f2);
  for(let x=995;x<1386;x+=10)for(const z of [-204,-156])inst('rwLight',UNIT,UNLIT,x,.12,z,.3,.1,.3,0,0xffd08a);
  boxI('afbApron',PLAIN,1000,1320,-300,-215,0,.04,0x5a5c50,false);
  for(const x of [1050,1140,1230]){inst('hangar',hangarG,PLAIN,x,0,-345,32,11,13,Math.PI/2,0x5f6648);addCollider(x-13,x+13,-361,-329,11);if(x===1140)inst('hdoor',UNIT,PLAIN,x,3.5,-328.9,13,7,.2,0,0x3a3d32);else inst('hlight',UNIT,UNLIT,x,8.6,-340,8,.2,8,0,0xfff1c4);}
  for(let k=0;k<9;k++){const x=1025+k*34,z=-252; // the flight line: fighters nose-out toward the runway
    const j=makeFighter(false,true);j.position.set(x,1.85,z);addCollider(x-5.4,x+5.4,z-6.5,z+8,2.6);}
  for(const x of [1050,1230]){const j=makeFighter(false,true);j.position.set(x,1.85,-347);j.rotation.y=0;} // in the hangars
  inst('ctwr',cylG,PLAIN,1310,14,-380,4,28,4,0,0x8a8a7a);addCollider(1306,1314,-384,-376,28);inst('ctwrCab',cylG,UNLIT,1310,29.5,-380,6,3,6,0,0x6fb0d0);
  inst('radar',domeG,PLAIN,1360,9,-395,6,6,6,0,0xe8e8e0);inst('radarBase',cylG,PLAIN,1360,3,-395,3,6,3,0,0x8a8a7a);addCollider(1354,1366,-401,-389,12);
  for(let k=0;k<3;k++){boxI('barr',HOUSE,1040+k*36,1070+k*36,20,34,0,5,0x9aa080,true);boxI('barrRoof',PLAIN,1039.7+k*36,1070.3+k*36,19.7,34.3,5,.35,0x4a4f3a,false);}
  for(const x of [1260,1285,1310]){inst('tank',cylG,PLAIN,x,3.5,60,4,7,4,0,0xb8b8a8);addCollider(x-4,x+4,56,64,7);}
  boxI('afbDock',PLAIN,AFB_DOCK.x0,AFB_DOCK.x1,AFB_DOCK.z0,AFB_DOCK.z1,-1.6,2,0x8a8a84,false);
  for(const [x,z,r] of [[F.x0+2,(F.z0+F.z1)/2,-Math.PI/2],[(F.x0+F.x1)/2,F.z0+2,Math.PI],[(F.x0+F.x1)/2,F.z1-2,0]])
    signPlane(['출입금지','NEON ISLAND AIR FORCE BASE · RESTRICTED'],'#3a0a08','#ffd27a',x,3.2,z,10,2.4,r);
  for(const [x,z] of [[F.x0+4,F.z0+4],[F.x1-4,F.z0+4],[F.x0+4,F.z1-4],[F.x1-4,F.z1-4]]){
    for(const a of [-1,1])for(const b of [-1,1])inst('tleg',UNIT,PLAIN,x+a*1.3,4.5,z+b*1.3,.25,9,.25,0,0x4a4a3a);
    boxI('tcab',PLAIN,x-1.8,x+1.8,z-1.8,z+1.8,9,2.4,0x6a6a52,false);inst('tlight',UNIT,UNLIT,x,10.6,z,3.7,.4,3.7,0,0xfff1c4);addCollider(x-1.5,x+1.5,z-1.5,z+1.5,12);}
  for(const [x,z,y] of [[960,-134,-Math.PI/2],[1180,-120,0],[1000,-60,0],[1300,-120,Math.PI]])GUARD_SLOTS.push({x,z,yaw:y,p:null,afb:true});
  lampRow(1000,-150,1380,-150,20);
  // --- the bridge: arched road deck on piers, railings and lamps
  const bn=Math.ceil((BRIDGE.x1-BRIDGE.x0)/6);
  for(let k=0;k<bn;k++){const x0=BRIDGE.x0+k*6,x1=Math.min(BRIDGE.x1,x0+6.2),xm=(x0+x1)/2,y=bridgeY(xm);
    inst('bdeck',UNIT,PLAIN,xm,y-.45,(BRIDGE.z0+BRIDGE.z1)/2,x1-x0,.9,BRIDGE.z1-BRIDGE.z0,0,0x6a6a70);
    inst('bdeckTop',UNIT,PLAIN,xm,y+.01,(BRIDGE.z0+BRIDGE.z1)/2,x1-x0,.04,BRIDGE.z1-BRIDGE.z0-1.2,0,0x2c2d33);
    for(const z of [BRIDGE.z0+.25,BRIDGE.z1-.25])inst('brail',UNIT,PLAIN,xm,y+.55,z,x1-x0,1.1,.25,0,0xc8ccd4);
    if(k%2===0)inst('bdash',UNIT,UNLIT,xm,y+.04,(BRIDGE.z0+BRIDGE.z1)/2,2.4,.02,.22,0,0xe8dcc0);
  }
  addCollider(BRIDGE.x0,BRIDGE.x1,BRIDGE.z0-.2,BRIDGE.z0+.4,1.1);addCollider(BRIDGE.x0,BRIDGE.x1,BRIDGE.z1-.4,BRIDGE.z1+.2,1.1);
  for(let x=BRIDGE.x0+30;x<BRIDGE.x1-20;x+=40){inst('bpier',UNIT,PLAIN,x,(bridgeY(x)-4)/2-1,(BRIDGE.z0+BRIDGE.z1)/2,3,bridgeY(x)+2,10,0,0x8a8a84);}
  for(let x=BRIDGE.x0+10;x<BRIDGE.x1;x+=40)for(const z of [BRIDGE.z0+.4,BRIDGE.z1-.4]){const y=bridgeY(x);inst('fpost',UNIT,PLAIN,x,y+3,z,.16,6,.16,0,0x3a3a46);inst('flood',UNIT,UNLIT,x,y+6.1,z,.5,.25,.5,0,0xffd08a);}
  signPlane(['공항 →','NEON ISLAND INTERNATIONAL AIRPORT'],'#0d3a1a','#ffffff',-548,5,BRIDGE.z0-1.5,8,2,Math.PI/2);
  // main-island ferry pier on the harbour quay
  boxI('ferryPier',PLAIN,FERRY_A.x0,FERRY_A.x1,FERRY_A.z0,FERRY_A.z1,-1.5,2,0x8a6a4a,false);
  signPlane(['페리 터미널','FERRY · 공항행'],'#062a33','#7ff3ff',-579.2,4,FERRY_A.z1+.6,6,1.6,0);
  LOCS.push({type:'airport',T:LOC_TYPES.airport,look:'air',name:'네온 아일랜드 국제공항',title:'네온 아일랜드 국제공항',sub:'',sign:['공항',''],door:new V3(-1036,0,-360),out:{x:1,z:0},robCD:0,room:null,noDoor:true,cz:-360});
  LOCS.push({type:'terminal',T:LOC_TYPES.terminal,look:'air',name:'공항 터미널',title:'네온 아일랜드 국제공항 · 출국장',sub:'NEON ISLAND INTERNATIONAL · 발권 카운터',sign:['국제공항','NEON ISLAND INTERNATIONAL'],door:new V3(-1045.4,0,-360),out:{x:1,z:0},robCD:0,room:null,cz:-360});
  addRing(-1045.4,-360,LOC_TYPES.terminal.color);
  LOCS.push({type:'airsec',T:LOC_TYPES.airsec,look:'air',name:'공항 경비대',title:'공항 경비대 사무소',sub:'',sign:['공항 경비대',''],door:new V3(-1020,0,-454),out:{x:0,z:1},robCD:0,room:null,noDoor:true,cz:-454});
  LOCS.push({type:'afb',T:LOC_TYPES.afb,look:'army',name:'네온 아일랜드 공군 기지',title:'네온 아일랜드 공군 기지',sub:'',sign:['공군 기지',''],door:new V3((F.x0+F.x1)/2,0,(F.z0+F.z1)/2),out:{x:1,z:0},robCD:0,room:null,noDoor:true,cz:0});
  LOCS.push({type:'ferry',T:LOC_TYPES.ferry,look:'harbor',name:'페리 터미널',title:'페리 터미널 (하버)',sub:'',sign:['페리',''],door:new V3(FERRY_RING_A.x,0,FERRY_RING_A.z),out:{x:-1,z:0},robCD:0,room:null,noDoor:true,cz:FERRY_RING_A.z});
  LOCS.push({type:'ferry',T:LOC_TYPES.ferry,look:'air',name:'페리 터미널',title:'페리 터미널 (공항)',sub:'',sign:['페리',''],door:new V3(FERRY_RING_B.x,0,FERRY_RING_B.z),out:{x:1,z:0},robCD:0,room:null,noDoor:true,cz:FERRY_RING_B.z});
  addRing(FERRY_RING_A.x,FERRY_RING_A.z,LOC_TYPES.ferry.color);addRing(FERRY_RING_B.x,FERRY_RING_B.z,LOC_TYPES.ferry.color);
}
// ---------- buses: stops along the routes ----------
const BUS_STOPS=[],BUS_ROUTES=[];
function makeStop(name,o,i,j,side){
  if(o==='h'?!segH(i,j):!segV(i,j))return null;
  let S;
  if(o==='h'){const x=(R[i]+R[i+1])/2+8;S={ap:{x,z:R[j]+side*LANE},sh:{x,z:R[j]+side*(HALF_ROAD+1.7)},h:side>0?Math.PI/2:-Math.PI/2,o};}
  else{const z=(R[j]+R[j+1])/2+8;S={ap:{x:R[i]+side*LANE,z},sh:{x:R[i]+side*(HALF_ROAD+1.7),z},h:side>0?Math.PI:0,o};}
  S.name=name;S.side=side;S.i=i;S.j=j;S.field=null;BUS_STOPS.push(S);return S;
}
const STOP_STYLE={city:{panel:0x9fe8c8,roof:0x2f6a46,sign:0x3ad07a,bg:'#0d3a1a',sub:'BUS STOP · 시내버스'},air:{panel:0x9fc8ff,roof:0x1f4fa8,sign:0x3f8cff,bg:'#0d1a3a',sub:'AIRPORT BUS · 공항버스'},mix:{panel:0x9fe8c8,roof:0x2f6a46,sign:0x3ad07a,bg:'#0d2a3a',sub:'시내버스 · 공항버스 환승'}};
function buildShelter(S){
  const {x,z}=S.sh,h=S.o==='h',L=S.kind==='mix'?8:5,back=S.side*1.2,ST=STOP_STYLE[S.kind||'city'];
  const bx0=h?x-L/2:x+back-.08,bx1=h?x+L/2:x+back+.08,bz0=h?z+back-.08:z-L/2,bz1=h?z+back+.08:z+L/2;
  if(S.kind==='mix'){ // half green (city), half blue (airport) under one long roof
    if(h){boxI('shPanel',UNLIT,bx0,x,bz0,bz1,.3,2.2,0x9fe8c8,true);boxI('shPanel',UNLIT,x,bx1,bz0,bz1,.3,2.2,0x9fc8ff,true);}
    else{boxI('shPanel',UNLIT,bx0,bx1,bz0,z,.3,2.2,0x9fe8c8,true);boxI('shPanel',UNLIT,bx0,bx1,z,bz1,.3,2.2,0x9fc8ff,true);}
  } else boxI('shPanel',UNLIT,bx0,bx1,bz0,bz1,.3,2.2,ST.panel,true);
  const rx0=h?x-L/2-.2:x-1.5,rx1=h?x+L/2+.2:x+1.5,rz0=h?z-1.5:z-L/2-.2,rz1=h?z+1.5:z+L/2+.2;
  boxI('shRoof',PLAIN,rx0,rx1,rz0,rz1,2.6,.14,ST.roof,false);
  if(S.kind==='mix'){if(h)boxI('shRoofB',PLAIN,x,rx1,rz0,rz1,2.74,.06,0x1f4fa8,false);else boxI('shRoofB',PLAIN,rx0,rx1,z,rz1,2.74,.06,0x1f4fa8,false);}
  if(S.kind!=='city'){const ax=h?x+(S.kind==='mix'?L/4:0):x+back*.9,az=h?z+back*.9:z+(S.kind==='mix'?L/4:0);
    signPlane(['✈ 공항버스','AIRPORT BUS'],'#0d1a3a','#9fc8ff',ax,1.6,az,h?2.2:2.2,.7,h?(S.side>0?Math.PI:0):(S.side>0?-Math.PI/2:Math.PI/2));}
  for(const k of [-1,1])inst('shPost',UNIT,PLAIN,h?x+k*L/2:x+back,1.3,h?z+back:z+k*L/2,.12,2.6,.12,0,0x3a3a46);
  inst('shBench',UNIT,PLAIN,h?x:x+back*.55,.45,h?z+back*.55:z,h?3.4:.5,.12,h?.5:3.4,0,0x6a4a2a);
  const px=h?x+L/2+.9:x-S.side*.6,pz=h?z-S.side*.6:z+L/2+.9;
  inst('stopPole',UNIT,PLAIN,px,1.6,pz,.12,3.2,.12,0,0x3a3a46);
  inst('stopSign',UNIT,UNLIT,px,3.3,pz,h?.9:.08,.9,h?.08:.9,0,ST.sign);
  signPlane([S.name,ST.sub],ST.bg,'#ffffff',h?x:x+back*.9,3.25,h?z+back*.9:z,S.kind==='mix'?5:3.4,.85,h?(S.side>0?Math.PI:0):(S.side>0?-Math.PI/2:Math.PI/2));
}
{
  // each stop sits on the kerb of the lane that heads toward the next stop, so buses pull away the right way
  const mk=list=>{
    const ok=list.filter(q=>q[1]==='h'?segH(q[2],q[3]):segV(q[2],q[3]));
    const pt=q=>q[1]==='h'?{x:(R[q[2]]+R[q[2]+1])/2,z:R[q[3]]}:{x:R[q[2]],z:(R[q[3]]+R[q[3]+1])/2};
    return ok.map((q,k)=>{const a=pt(q),b=pt(ok[(k+1)%ok.length]);const side=q[1]==='h'?(b.x>=a.x?1:-1):(b.z>=a.z?-1:1);return makeStop(q[0],q[1],q[2],q[3],side);});
  };
  const r1=mk([['구도심 북문','h',1,1],['시청 앞','v',4,2],['구도심 남부','h',3,5],['서부 항구','v',2,7],['항구 페리','h',2,10],['항구 시장','v',5,8]]);
  const r2=mk([['북부 시가지','h',8,2],['북동 시가지','h',13,1],['동부 경찰서','v',14,4],['군인 아파트','v',12,8],['동부 병원','h',13,11],['남동 시장','v',15,13],['광산 입구','h',10,13]]);
  // airport express: the depot, the old town, then over the bridge to the terminal forecourt
  const air={name:'국제공항',ap:{x:-1028,z:-363.5},sh:{x:-1028,z:-371.4},h:-Math.PI/2,o:'h',side:-1,air:true,dwell:9};BUS_STOPS.push(air);
  const dep=DEPOT?{name:'버스 차고지',ap:{x:DEPOT.x,z:DEPOT.z},sh:{x:DEPOT.x+HALF_ROAD-1.8+1.7,z:DEPOT.z},h:Math.PI,o:'v',side:1,dwell:4,depot:true,i:Math.round((DEPOT.x-LANE-R[0])/CELL),j:Math.floor((DEPOT.z-R[0])/CELL)}:null;
  if(dep)BUS_STOPS.push(dep);
  const byName=(L,n)=>L.find(q=>q.name===n);
  const r3=[dep,byName(r2,'북부 시가지'),byName(r1,'시청 앞'),makeStop('구도심 서문','h',1,3,-1),air].filter(Boolean);
  BUS_ROUTES.push({id:1,name:'1번 · 구도심–항구 순환',stops:r1,n:2,color:0x2fa35a},{id:2,name:'2번 · 북동–동부–남부 순환',stops:r2,n:2,color:0x2fa35a},{id:3,name:'공항버스',stops:r3,n:1,color:0x2e6fd8,air:true});
  for(const R_ of BUS_ROUTES)for(const S of R_.stops)(S.routes||(S.routes=[])).push(R_.id);
  for(const S of BUS_STOPS){if(S.depot)continue;const a=S.routes.includes(3),c=S.routes.some(r=>r!==3);S.kind=a&&c?'mix':a?'air':'city';buildShelter(S);}
}
// ---------- kerbside parking bays scattered over the island ----------
{
  const P=[];
  for(let i=0;i<N;i++)for(let j=1;j<N;j++){
    if((i*7+j*13)%11!==0)continue;
    for(const o of ['h','v']){
      if(o==='h'?!segH(i,j):!segV(j,i))continue;
      const side=(i+j)%2?1:-1,mid=(R[i]+R[i+1])/2,road=R[j],bcx=o==='h'?mid:road+side*6,bcz=o==='h'?road+side*6:mid;
      if(BUS_STOPS.some(S=>Math.hypot(S.ap.x-bcx,S.ap.z-bcz)<26||Math.hypot(S.sh.x-bcx,S.sh.z-bcz)<26)||LOCS.some(L=>(L.ramp&&Math.hypot(L.ramp.mouth.x-bcx,L.ramp.mouth.z-bcz)<18)||(L.lot&&Math.hypot(L.lot.exit.x-bcx,L.lot.exit.z-bcz)<18))||(DEPOT&&Math.hypot(DEPOT.x-bcx,DEPOT.z-bcz)<22))continue;
      const bi=o==='h'?i:(side>0?j:j-1),bj=o==='h'?(side>0?j:j-1):i;
      if(bi<0||bj<0||bi>=N||bj>=NZ||blocks[bi*NZ+bj].closed)continue;
      const spots=[];
      for(let k=0;k<4;k++){const t=mid-9+k*6;spots.push(o==='h'?{x:t,z:road+side*6,h:side>0?Math.PI/2:-Math.PI/2}:{x:road+side*6,z:t,h:side>0?Math.PI:0});}
      const a0=mid-12,a1=mid+12,b0=road+side*6-1.5,b1=road+side*6+1.5;
      const Z=o==='h'?{x0:a0,x1:a1,z0:Math.min(b0,b1),z1:Math.max(b0,b1),name:'갓길 주차'}:{x0:Math.min(b0,b1),x1:Math.max(b0,b1),z0:a0,z1:a1,name:'갓길 주차'};
      PARK_ZONES.push(Z);for(const q of spots){q.zone=Z;PARK_SPOTS.push(q);}
      // painted bay outline and a blue P sign on the pavement
      if(o==='h'){for(const z of [Z.z0,Z.z1])boxI('bayL',UNLIT,a0,a1,z-.06,z+.06,.05,.01,0xf2f2f2,false);for(let k=0;k<=4;k++)boxI('bayL',UNLIT,a0+k*6-.06,a0+k*6+.06,Z.z0,Z.z1,.05,.01,0xf2f2f2,false);}
      else{for(const x of [Z.x0,Z.x1])boxI('bayL',UNLIT,x-.06,x+.06,a0,a1,.05,.01,0xf2f2f2,false);for(let k=0;k<=4;k++)boxI('bayL',UNLIT,Z.x0,Z.x1,a0+k*6-.06,a0+k*6+.06,.05,.01,0xf2f2f2,false);}
      const px=o==='h'?mid:road+side*(HALF_ROAD+.6),pz=o==='h'?road+side*(HALF_ROAD+.6):mid;
      inst('bayPole',UNIT,PLAIN,px,1.3,pz,.1,2.6,.1,0,0x3a3a46);inst('bayP',UNIT,UNLIT,px,2.7,pz,.7,.7,.7,0,0x4da3ff);
    }
  }
}
flushBatches();
function instanced(g,m,list){const im=new THREE.InstancedMesh(g,m,list.length);const m4=new THREE.Matrix4(),q=new THREE.Quaternion(),p=new V3(),s=new V3();list.forEach((t,k)=>{p.set(t[0],t[1],t[2]);q.setFromAxisAngle(Y,t[3]||0);s.set(t[4]||1,t[5]||1,t[6]||1);m4.compose(p,q,s);im.setMatrixAt(k,m4);});im.frustumCulled=false;scene.add(im);return im;}
const dashes=[], stripes=[], poles=[], heads=[], pools=[];
for(let k=0;k<=NZ;k++)for(let s=0;s<NZ;s++){
  for(let t=R[s]+HALF_ROAD+2;t<R[s+1]-HALF_ROAD-2;t+=5){if(segH(s,k))dashes.push([t+1.2,.03,R[k],0,2.4,.04,.22]);if(segV(k,s))dashes.push([R[k],.03,t+1.2,0,.22,.04,2.4]);}
}
for(let i=0;i<=N;i++)for(let j=0;j<=NZ;j++){
  if(!nodeOpen(i,j))continue;
  const x=R[i],z=R[j];
  for(let s=-5.5;s<=5.6;s+=2.2){
    if(segH(i,j)) stripes.push([x+HALF_ROAD+1.6,.035,z+s,0,2.4,.04,1.1]);
    if(segH(i-1,j)) stripes.push([x-HALF_ROAD-1.6,.035,z+s,0,2.4,.04,1.1]);
    if(segV(i,j)) stripes.push([x+s,.035,z+HALF_ROAD+1.6,0,1.1,.04,2.4]);
    if(segV(i,j-1)) stripes.push([x+s,.035,z-HALF_ROAD-1.6,0,1.1,.04,2.4]);
  }
  [[1,1],[-1,-1]].forEach(([a,b])=>{if(blkClosed(a>0?i:i-1,b>0?j:j-1))return;const px=x+a*(HALF_ROAD+1.2),pz=z+b*(HALF_ROAD+1.2);poles.push([px,3.5,pz,0,.18,7,.18]);heads.push([px-a*1.1,7,pz-b*1.1,0,1.1,.25,1.1]);pools.push([px-a*1.6,.05,pz-b*1.6,0,16,1,16]);});
}
// a second lamp halfway along every street, sides alternating, kept clear of the parking-bay signs and bus shelters
{
  const busy=(x,z)=>BUS_STOPS.some(S=>Math.hypot(S.sh.x-x,S.sh.z-z)<7);
  const lamp=(px,pz,ox,oz,qx,qz)=>{if(busy(px,pz)){if(busy(qx,qz))return;px=qx;pz=qz;}poles.push([px,3.5,pz,0,.18,7,.18]);heads.push([px+ox*1.1,7,pz+oz*1.1,0,1.1,.25,1.1]);pools.push([px+ox*1.6,.05,pz+oz*1.6,0,16,1,16]);};
  for(let k=0;k<=NZ;k++)for(let s=0;s<N;s++){if(!segH(s,k))continue;let sd=(s+k)%2?1:-1;if(!blkOpen(s,sd>0?k:k-1))sd=-sd;if(!blkOpen(s,sd>0?k:k-1))continue;
    lamp((R[s]+R[s+1])/2+sd*9,R[k]+sd*(HALF_ROAD+1.2),0,-sd,(R[s]+R[s+1])/2-sd*14,R[k]+sd*(HALF_ROAD+1.2));}
  for(let i=0;i<=N;i++)for(let j=0;j<NZ;j++){if(!segV(i,j))continue;let sd=(i+j)%2?1:-1;if(!blkOpen(sd>0?i:i-1,j))sd=-sd;if(!blkOpen(sd>0?i:i-1,j))continue;
    lamp(R[i]+sd*(HALF_ROAD+1.2),(R[j]+R[j+1])/2-sd*9,-sd,0,R[i]+sd*(HALF_ROAD+1.2),(R[j]+R[j+1])/2+sd*14);}
}
instanced(UNIT,mat(0xe8dcc0),dashes);
instanced(UNIT,mat(0xd8d6de),stripes);
instanced(UNIT,mat(0x3a3a46),poles);
const lampHeadMat=new THREE.MeshBasicMaterial({color:0xffd08a});
instanced(UNIT,lampHeadMat,heads);
const haloMat=new THREE.PointsMaterial({map:WHITE_GLOW,color:0xffc070,size:4.5,sizeAttenuation:true,transparent:true,opacity:.75,blending:THREE.AdditiveBlending,depthWrite:false});
const lampPoolMat=new THREE.MeshBasicMaterial({map:glowTex(),transparent:true,opacity:.22,blending:THREE.AdditiveBlending,depthWrite:false});
{ // soft halos around every street lamp, one draw call
  const hp=new Float32Array(heads.length*3);heads.forEach((h,i)=>{hp[i*3]=h[0];hp[i*3+1]=h[1]-.25;hp[i*3+2]=h[2];});
  const hg=new THREE.BufferGeometry();hg.setAttribute('position',new THREE.Float32BufferAttribute(hp,3));
  scene.add(new THREE.Points(hg,haloMat));
}
{const pg=new THREE.PlaneGeometry(1,1);pg.rotateX(-Math.PI/2);instanced(pg,lampPoolMat,pools);}

// ---------- traffic signals at every 3- and 4-way junction (switched off 23:00–06:00) ----------
const SIG=new Set(),sigKey=(i,j)=>i*100+j;
const nodeDeg=(i,j)=>(segH(i,j)?1:0)+(segH(i-1,j)?1:0)+(segV(i,j)?1:0)+(segV(i,j-1)?1:0);
for(let i=1;i<N;i++)for(let j=1;j<NZ;j++)if(nodeOpen(i,j)&&nodeDeg(i,j)>=3)SIG.add(sigKey(i,j));
const SIG_CYCLE=26;let sigClock=0,sigOn=true;
// north–south: green 0–10, amber to 12.5, then red · east–west: green 13–23, amber to 25.5 · a short all-red between
function sigState(axis){if(!sigOn)return 'g';const t=sigClock%SIG_CYCLE;return axis==='ns'?(t<10?'g':t<12.5?'y':'r'):(t<13?'r':t<23?'g':t<25.5?'y':'r');}
// may a pedestrian step off the kerb across a road whose traffic runs along `axis`?
function sigWalk(axis){const t=sigClock%SIG_CYCLE;return axis==='ew'?t<5.5:(t>=13&&t<18.5);}
const SIG_LAMP={},PED_LAMP={},SIG_POLES=new Map();
{
  const L={ns:{r:[],y:[],g:[]},ew:{r:[],y:[],g:[]}},P={z:{r:[],g:[]},x:{r:[],g:[]}},boxes=[],sp=[],arms=[];
  for(const k of SIG){const i=Math.floor(k/100),j=k%100,x=R[i],z=R[j];
    // pedestrian signals on two corners: red standing man above, green walking man below
    for(const [a,b] of [[1,-1],[-1,1]]){
      if(blkClosed(a>0?i:i-1,b>0?j:j-1))continue;
      const px=x+a*(HALF_ROAD+.9),pz=z+b*(HALF_ROAD+.9);sp.push([px,1.6,pz,0,.13,3.2,.13]);
      boxes.push([px,2.75,pz,0,.42,.9,.42]);
      for(const f of [-1,1]){P.z.r.push([px,3.0,pz+f*.22,0,.26,.3,.04]);P.z.g.push([px,2.55,pz+f*.22,0,.26,.3,.04]);
        P.x.r.push([px+f*.22,3.0,pz,0,.04,.3,.26]);P.x.g.push([px+f*.22,2.55,pz,0,.04,.3,.26]);}
    }
    // vehicle signals: one mast per approach on the far kerb, the arm reaching over the lane, a horizontal red-amber-green head
    for(const [fx,fz] of [[1,0],[-1,0],[0,1],[0,-1]]){
      const from=fx>0?segH(i-1,j):fx<0?segH(i,j):fz>0?segV(i,j-1):segV(i,j);if(!from)continue;
      const kx=-fz,kz=fx,ax=fx!==0?'ew':'ns';
      const bi=(fx+kx)>0?i:i-1,bj=(fz+kz)>0?j:j-1;
      const mx=x+fx*(HALF_ROAD+3.4)+kx*(HALF_ROAD+.8),mz=z+fz*(HALF_ROAD+3.4)+kz*(HALF_ROAD+.8);
      if(blkClosed(bi,bj))continue;
      sp.push([mx,3.1,mz,0,.22,6.2,.22]);{const k=Math.floor(mx/2)+','+Math.floor(mz/2);(SIG_POLES.get(k)||SIG_POLES.set(k,[]).get(k)).push([mx,mz]);}
      const hx=x+fx*(HALF_ROAD+3.4)+kx*3.5,hz=z+fz*(HALF_ROAD+3.4)+kz*3.5,armL=HALF_ROAD+.8-1.6;
      arms.push([x+fx*(HALF_ROAD+3.4)+kx*(1.6+armL/2),6.05,z+fz*(HALF_ROAD+3.4)+kz*(1.6+armL/2),0,kx?armL:.14,.14,kz?armL:.14]);
      boxes.push([hx,5.6,hz,0,kx?1.45:.42,.48,kz?1.45:.42]);
      const fc=-.22;
      ['r','y','g'].forEach((c,n)=>{const o=(n-1)*.44;L[ax][c].push([hx+fx*fc+kx*o,5.6,hz+fz*fc+kz*o,0,fx?.04:.34,.34,fz?.04:.34]);});
    }
  }
  instanced(UNIT,mat(0x2a2c33),sp);instanced(UNIT,mat(0x2a2c33),arms);instanced(UNIT,mat(0x1a1b20),boxes);
  for(const ax of ['ns','ew'])for(const c of ['r','y','g']){const m=new THREE.MeshBasicMaterial({color:0x111111});SIG_LAMP[ax+c]=m;instanced(UNIT,m,L[ax][c]);}
  for(const ax of ['z','x'])for(const c of ['r','g']){const m=new THREE.MeshBasicMaterial({color:0x111111});PED_LAMP[ax+c]=m;instanced(UNIT,m,P[ax][c]);}
}
const SIG_ON_COL={r:0xff2a2a,y:0xffc21a,g:0x2aff7a},SIG_OFF_COL={r:0x3a0e0e,y:0x3a2c0a,g:0x0c3a1c};let sigShown='';
function updateSignals(dt){
  sigClock+=dt;sigOn=!(tod>=23||tod<6);
  const ns=sigOn?sigState('ns'):'-',ew=sigOn?sigState('ew'):'-';
  // heads facing ±z guard the crossings over east-west roads, heads facing ±x those over north-south roads
  const wz=sigOn?(sigWalk('ew')?'g':'r'):'-',wx=sigOn?(sigWalk('ns')?'g':'r'):'-',key=ns+ew+wz+wx;if(key===sigShown)return;sigShown=key;
  for(const c of ['r','y','g']){SIG_LAMP['ns'+c].color.setHex(ns===c?SIG_ON_COL[c]:SIG_OFF_COL[c]);SIG_LAMP['ew'+c].color.setHex(ew===c?SIG_ON_COL[c]:SIG_OFF_COL[c]);}
  for(const c of ['r','g']){PED_LAMP['z'+c].color.setHex(wz===c?SIG_ON_COL[c]:SIG_OFF_COL[c]);PED_LAMP['x'+c].color.setHex(wx===c?SIG_ON_COL[c]:SIG_OFF_COL[c]);}
}
// how fast a car heading (fx,fz) may go to stop at a red light ahead (1e9 = no limit)
function sigLimit(c,fx,fz,cur){
  if(!sigOn)return 1e9;
  const i=gridIdx(c.pos.x),j=gridIdxZ(c.pos.z);if(!SIG.has(sigKey(i,j)))return 1e9;
  const dx=R[i]-c.pos.x,dz=R[j]-c.pos.z,ah=dx*fx+dz*fz;
  if(Math.abs(dx*fz-dz*fx)>HALF_ROAD+1||ah>HALF_ROAD+45)return 1e9;
  const stopD=ah-HALF_ROAD-3-c.half;if(stopD<-.5)return 1e9;
  const st=sigState(Math.abs(fx)>Math.abs(fz)?'ew':'ns');if(st==='g')return 1e9;
  if(st==='y'&&stopD<cur*cur/14+1)return 1e9;
  return Math.max(0,stopD)*.9;
}
// traffic police at a few junctions in the old town, the harbour and the army flats
const TRAFFIC_POSTS=[[2,2],[3,4],[5,3],[3,8],[2,10],[4,11],[13,7],[12,10],[14,9]].filter(([i,j])=>SIG.has(sigKey(i,j))).map(([i,j])=>({i,j,x:R[i]+HALF_ROAD+3,z:R[j]+HALF_ROAD+3,p:null}));
for(const P of TRAFFIC_POSTS){inst('tpBox',UNIT,PLAIN,P.x+1.4,.9,P.z+1.4,.9,1.8,.9,0,0xf2f2f2);inst('tpStripe',UNIT,UNLIT,P.x+1.4,1.5,P.z+1.4,.92,.25,.92,0,0x3f8cff);addCollider(P.x+.95,P.x+1.85,P.z+.95,P.z+1.85,1.8);}

// ---------- interiors ----------
let roomIdx=0;
function furn(x,y,z,sx,sy,sz,color,collide,basic){
  const m=mesh(UNIT,basic?bmat(color):imat(color),x,y,z);m.scale.set(sx,sy,sz);scene.add(m);
  if(collide)addCollider(x-sx/2,x+sx/2,z-sz/2,z+sz/2,y+sy/2);
  return m;
}
const vaultG=new THREE.CylinderGeometry(2.2,2.2,.5,32);
const innerColG=new THREE.CylinderGeometry(.45,.5,6,12);
function buildRoom(loc){
  const RD=loc.T.room;if(!RD)return;
  const O=new V3(6000+(roomIdx++)*60,0,6000),w=RD.w,d=RD.d,h=RD.h;
  const x0=O.x-w/2,x1=O.x+w/2,z0=O.z-d/2,z1=O.z+d/2;
  const fl=mesh(new THREE.PlaneGeometry(w,d),imat(RD.floor),O.x,.01,O.z);fl.rotation.x=-Math.PI/2;scene.add(fl);
  const ce=mesh(new THREE.PlaneGeometry(w,d),imat(RD.ceil),O.x,h,O.z);ce.rotation.x=Math.PI/2;scene.add(ce);
  furn(O.x,h/2,z1+.2,w+.8,h,.4,RD.wall,true);
  furn(O.x,h/2,z0-.2,w+.8,h,.4,RD.wall,true);
  furn(x0-.2,h/2,O.z,.4,h,d,RD.wall,true);
  furn(x1+.2,h/2,O.z,.4,h,d,RD.wall,true);
  furn(O.x,.12,z1-.03,w,.24,.06,0x2a2630);furn(x0+.03,.12,O.z,.06,.24,d,0x2a2630);furn(x1-.03,.12,O.z,.06,.24,d,0x2a2630);
  for(let lx=x0+3;lx<x1-1.5;lx+=4.5)for(let lz=z0+3;lz<z1-1.5;lz+=4.5)furn(lx,h-.04,lz,1.8,.06,.5,0xfff3d6,false,true);
  if(loc.type==='jail'){furn(O.x,1.5,z0+.05,2.4,3,.08,0x4a4f58);furn(O.x+.8,1.4,z0+.1,.12,.3,.08,0xc8ccd4);}
  else{
    furn(O.x,1.5,z0+.03,2.4,3,.06,0xffd890,false,true);
    furn(O.x,1.5,z0+.05,2.7,3.2,.04,0x2a2630);
    signPlane(['출구','EXIT'],'#0e3d22','#7dffa8',O.x,3.35,z0+.08,1.6,.5,0);
  }
  const room={O,w,d,h,x0,x1,z0,z1,exit:new V3(O.x,0,z0+1.7),spawn:new V3(O.x,0,z0+3.3),counter:null,staff:[],wake:null};
  loc.room=room;
  if(loc.type!=='jail')addRing(room.exit.x,room.exit.z,0x7dffa8);
  FURNISH[loc.type](room,O,loc);
  if(room.counter)addRing(room.counter.x,room.counter.z,loc.T.color);
  if(room.spots)for(const q of room.spots)addRing(q.pos.x,q.pos.z,q.color||0x7ff3ff,.85);
}
const PI=Math.PI;
const FURNISH={
  hotel(r,O,L){
    const tier=L.look==='city'?2:L.look==='army'?1:0;
    furn(O.x,.03,O.z-1,10,.04,9,tier===2?0x8a2a32:0x5a4a3a);
    // front desk, key wall and the hotel's name behind it
    furn(O.x,.6,r.z1-4,8,1.2,1.2,0x5a3a24,true);furn(O.x,1.23,r.z1-4,8.2,.06,1.3,0xe8dcc0);
    furn(O.x,2.4,r.z1-.25,7,2.4,.06,0x3a2a1c);for(let k=0;k<12;k++)furn(O.x-2.8+(k%6)*1.1,1.9+Math.floor(k/6)*.7,r.z1-.32,.3,.4,.04,0xd8b04a,false,true);
    signPlane([L.sign[0],L.sign[1]],'#2a1a08','#ffd27a',O.x,4.3,r.z1-.32,6,1.3,PI);
    r.counter=new V3(O.x,0,r.z1-5.9);
    // chandelier
    furn(O.x,r.h-.6,O.z,1.6,.5,1.6,0xffe2a0,false,true);furn(O.x,r.h-.2,O.z,.08,.4,.08,0x8a7a5a);
    // the lounge: buffet along the left wall, round tables with chairs
    furn(r.x0+.9,.5,O.z,1.2,1,7,0x5a3a24,true);furn(r.x0+.9,1.03,O.z,1.3,.06,7.2,0xe8dcc0);
    for(let k=-2;k<=2;k++)furn(r.x0+.9,1.15,O.z+k*1.3,.6,.18,.5,pick([0xff8a3d,0xf4efe4,0x8ac34a,0xd23a2a]));
    for(const [tx,tz] of [[r.x0+5,O.z-4],[r.x0+5,O.z+2],[r.x0+9,O.z-1]]){furn(tx,.75,tz,1.4,.08,1.4,0xf4efe4,true);furn(tx,.38,tz,.2,.75,.2,0x3a2a1c);
      for(const [a,b] of [[1,0],[-1,0],[0,1],[0,-1]])furn(tx+a*1.1,.45,tz+b*1.1,.5,.9,.5,0x7a1a2a,true);}
    signPlane(['라운지','LOUNGE · 식사'],'#2a1a08','#ffd27a',r.x0+.08,3.2,O.z,3.6,.9,PI/2);
    // lifts on the right wall
    for(const dz of [0,3]){furn(r.x1-.08,1.5,O.z+dz,.06,3,1.8,0xb8bcc4,false,true);furn(r.x1-.1,3.3,O.z+dz,.04,.3,.6,0xff8a3d,false,true);}
    signPlane(['엘리베이터','객실 · ROOMS'],'#2a1a08','#ffd27a',r.x1-.08,3.9,O.z+1.5,3,.8,-PI/2);
    for(const z of [r.z0+2,r.z1-2])for(const x of [r.x0+1.2,r.x1-1.2]){furn(x,.4,z,.8,.8,.8,0x5a4a3a,true);furn(x,1.3,z,1.1,1.2,1.1,0x3f7a3a);}
    for(const x of [O.x-3,O.x+3])furn(x,.4,O.z+3,2.6,.8,1,0x6a5a7a,true);
    r.elev=new V3(r.x1-2.2,0,O.z+1.5);
    const price=HOTEL_PRICE(L);
    r.spots=[
      {pos:new V3(r.x0+2.6,0,O.z),color:0xff8a3d,label:'라운지 · 식사',act:()=>openMenu({type:'lounge',T:{title:'',sub:''},title:L.title+' · 라운지',sub:'1층 라운지 · 오늘의 메뉴',hotel:L})},
      {pos:r.elev,color:0xf0c060,label:()=>player.hotel&&player.hotel.loc===L?'엘리베이터 · 내 객실로':'엘리베이터 · 객실 예약 필요 ($'+price+')',act:()=>goGuestRoom(L)}
    ];
    r.staff=[{role:'clerk',kind:'civ',x:O.x,z:r.z1-2.8,yaw:PI,look:{shirt:0xf4f2ec,vest:0x2a1a10,pants:0x1a1a22}},
      {role:'bellhop',kind:'civ',x:r.x0+3.2,z:r.z0+3,yaw:0,look:{shirt:0x8a1a2a,pants:0x1a1a22,hat:0x8a1a2a}},
      {role:'diner1',kind:'civ',x:r.x0+5,z:O.z+3.1,yaw:PI},{role:'diner2',kind:'civ',x:r.x0+9,z:O.z-2.1,yaw:0}];
  },
  guest(r,O){
    furn(O.x+2.2,.35,r.z1-2.2,2.6,.5,3.4,0xf4f2ec,true);furn(O.x+2.2,.62,r.z1-2.2,2.62,.08,3.42,0xc8b48a);furn(O.x+2.2,.9,r.z1-.6,2.6,1.2,.2,0x5a3a24);
    furn(O.x+1.6,.72,r.z1-1.2,.8,.12,.5,0xffffff);furn(O.x+2.8,.72,r.z1-1.2,.8,.12,.5,0xffffff);
    furn(O.x-3,.75,r.z1-.8,2.2,.08,.9,0x5a3a24,true);furn(O.x-3,.38,r.z1-.8,.1,.75,.8,0x3a2a1c);
    furn(O.x-3,.95,r.z1-.9,.9,.04,.6,0x2a2c33);furn(O.x-3,1.25,r.z1-1.15,.9,.55,.04,0x6fb0d0,false,true);
    furn(O.x-3,.45,r.z1-1.9,.5,.9,.5,0x2a2a2e,true);
    furn(O.x,1.8,r.z1-.05,4,1.6,.04,0x1a2a4a,false,true);for(let k=0;k<14;k++)furn(O.x-1.8+k*.28,1.3+rand(0,.9),r.z1-.07,.12,.12,.02,0xffd890,false,true);
    furn(r.x0+.3,1.4,O.z,.06,.9,1.6,0x101418);furn(O.x+4.2,.9,O.z-1,.4,.8,.4,0xffe2a0,false,true);
    r.spots=[
      {pos:new V3(O.x+2.2,0,r.z1-4.4),color:0x7ff3ff,label:()=>'침대에서 자기 · 아침 7시까지 · 체력 회복',act:sleepHotel},
      {pos:new V3(O.x-3,0,r.z1-2.6),color:0xb48cff,label:'노트북 · 웹 서핑',act:()=>openMenu({type:'web',T:{title:'',sub:''},title:'하버넷 브라우저',sub:'호텔 Wi-Fi 연결됨'})}
    ];
    r.staff=[];
  },
  terminal(r,O){
    // check-in desks, departures board, seat rows and the security arches
    furn(O.x,.55,r.z1-5,14,1.1,1.2,0xdfe4ec,true);furn(O.x,1.13,r.z1-5,14.2,.06,1.3,0x2e6fd8);
    for(let k=-2;k<=2;k++)furn(O.x+k*3,1.7,r.z1-5.6,.6,.4,.05,0x10141f);
    furn(O.x,4.6,r.z1-.2,16,3.2,.1,0x0d1a3a,false,true);
    signPlane(['출발 DEPARTURES','NI-001 본토 · 정시 | NI-207 서울 · 탑승 중 | NI-330 도쿄 · 지연'],'#0d1a3a','#7ff3ff',O.x,4.6,r.z1-.28,15,3,PI);
    r.counter=new V3(O.x,0,r.z1-6.9);
    for(let row=0;row<3;row++)for(const sx of [-1,1])for(let k=0;k<5;k++)furn(O.x+sx*(5+k*1.1),.45,r.z0+5+row*2.6,.9,.9,.8,0x2e6fd8,true);
    for(const x of [r.x0+4,r.x1-4]){furn(x-1,1.2,O.z+2,.2,2.4,.4,0xb8bcc4,true);furn(x+1,1.2,O.z+2,.2,2.4,.4,0xb8bcc4,true);furn(x,2.5,O.z+2,2.2,.2,.4,0xb8bcc4);}
    for(const x of [r.x0+1.2,r.x1-1.2])for(const z of [r.z0+2,r.z1-2]){furn(x,.4,z,.8,.8,.8,0xd8dde6,true);furn(x,1.4,z,1.2,1.4,1.2,0x3f7a3a);}
    r.staff=[{role:'agent1',kind:'civ',x:O.x-3,z:r.z1-3.6,yaw:PI,look:{shirt:0x2e6fd8,pants:0x1a1a22,vest:0xf4f6f8}},
      {role:'agent2',kind:'civ',x:O.x+3,z:r.z1-3.6,yaw:PI,look:{shirt:0x2e6fd8,pants:0x1a1a22,vest:0xf4f6f8}},
      {role:'guard',kind:'cop',weapon:'pistol',x:r.x0+3,z:O.z+4,yaw:PI/2,hpMul:1.4,look:{vest:0x1f4fa8,hat:0x1f4fa8}},
      {role:'trav1',kind:'civ',x:O.x+6,z:r.z0+5.6,yaw:PI},{role:'trav2',kind:'civ',x:O.x-7.2,z:r.z0+8.2,yaw:PI}];
  },
  gun(r,O,L){
    furn(O.x,.55,r.z1-3,9,1.1,1,0x4a3020,true);furn(O.x,1.13,r.z1-3,9.2,.06,1.1,0x2a1a10);
    furn(O.x,2.2,r.z1-.25,9.4,2.6,.05,0x3a2a22);
    for(let k=-3;k<=3;k++){furn(O.x+k*1.25,2.25,r.z1-.32,.14,1.5,.1,0x1b1b20);furn(O.x+k*1.25,1.6,r.z1-.32,.22,.42,.12,0x6a4426);}
    for(let k=-2;k<=2;k++)furn(O.x+k*1.6+.8,3.25,r.z1-.32,1.1,.14,.1,0x26262c);
    furn(r.x0+.9,.5,O.z,1.2,1,6,0x2b2f38,true);furn(r.x1-.9,.5,O.z,1.2,1,6,0x2b2f38,true);
    const g1=mesh(UNIT,glassMat,r.x0+.9,1.25,O.z);g1.scale.set(1.2,.5,6);scene.add(g1);
    const g2=mesh(UNIT,glassMat,r.x1-.9,1.25,O.z);g2.scale.set(1.2,.5,6);scene.add(g2);
    for(let k=-2;k<=2;k++){furn(r.x0+.9,1.06,O.z+k*1.1,.5,.08,.2,0x1b1b20);furn(r.x1-.9,1.06,O.z+k*1.1,.7,.1,.14,0x1d2119);}
    furn(O.x,4.1,r.z1-.28,10,.12,.06,0xff4d5e,false,true);
    signPlane([L.sign[0],L.sign[1]],'#160b0d','#ff4d5e',O.x,3.75,r.z1-.3,2.6,.8,PI);
    r.counter=new V3(O.x,0,r.z1-4.7);
    r.staff=[{role:'owner',kind:'civ',weapon:'shotgun',x:O.x,z:r.z1-1.9,yaw:PI,hpMul:2,look:{shirt:0x5a3b2a,pants:0x2b2620,hair:0x2a2a2a,vest:0x3a4a2a}}];
  },
  hospital(r,O){
    furn(O.x,.55,r.z1-5,7,1.1,1.2,0xe8ecf2,true);furn(O.x,1.13,r.z1-5,7.2,.06,1.3,0x5fb7ff);
    furn(O.x,3.1,r.z1-.25,.5,1.6,.05,0xff3344,false,true);furn(O.x,3.1,r.z1-.25,1.6,.5,.05,0xff3344,false,true);
    for(const k of [-1,0,1])for(const sx of [r.x0+1.5,r.x1-1.5]){
      const bz=O.z-.6+k*3.4;
      furn(sx,.35,bz,1.4,.5,2.4,0xd8dde6,true);furn(sx,.64,bz+.35,1.42,.08,1.6,0x7fb2d6);furn(sx,.66,bz-.9,1,.12,.45,0xffffff);
      furn(sx+(sx<O.x?1.2:-1.2),.9,bz-.9,.06,1.8,.06,0x9aa3b2);
    }
    for(let k=-1;k<=1;k++)furn(O.x+k*1.2,.25,O.z-2.4,.9,.5,.9,0x5fb7ff,true);
    r.counter=new V3(O.x,0,r.z1-6.9);
    r.wake=new V3(r.x0+3.1,0,O.z-.6);
    r.staff=[
      {role:'nurse',kind:'civ',x:O.x,z:r.z1-3.8,yaw:PI,look:{shirt:0xf4f6fa,pants:0x8fc3dc}},
      {role:'doctor',kind:'civ',x:r.x1-4,z:O.z+2.4,yaw:-PI/2,look:{shirt:0xffffff,pants:0x3a4256,vest:0xf2f2f2}}
    ];
  },
  bank(r,O){
    furn(O.x,.6,r.z1-6,16,1.2,1,0x6b4a2e,true);furn(O.x,1.23,r.z1-6,16.2,.06,1.1,0x2c241c);
    const gl=mesh(UNIT,glassMat,O.x,1.95,r.z1-6);gl.scale.set(16,1.4,.06);scene.add(gl);
    for(let k=-2;k<=2;k++)furn(O.x+k*4,1.95,r.z1-6,.1,1.4,1,0x4a3020);
    const v=mesh(vaultG,imat(0x8f8a7a),O.x,2.6,r.z1-.3);v.rotation.x=PI/2;scene.add(v);
    furn(O.x,2.6,r.z1-.6,.2,2.4,.1,0x5b574c);furn(O.x,2.6,r.z1-.6,2.4,.2,.1,0x5b574c);
    for(const x of [r.x0+4,r.x1-4])for(const z of [O.z-3.5,O.z+1]){scene.add(mesh(innerColG,imat(0xece4d0),x,3,z));addCollider(x-.5,x+.5,z-.5,z+.5,6,true);}
    furn(O.x,5.6,r.z1-.25,20,.15,.05,0xe8c66a,false,true);
    furn(O.x,.02,O.z-3,5,.02,7,0x8a2632);
    r.counter=new V3(O.x,0,r.z1-7.8);
    r.staff=[
      {role:'teller1',kind:'civ',x:O.x-4,z:r.z1-4.8,yaw:PI,look:{shirt:0xf2efe6,vest:0x2b3346}},
      {role:'teller2',kind:'civ',x:O.x+4,z:r.z1-4.8,yaw:PI,look:{shirt:0xf2efe6,vest:0x2b3346}},
      {role:'guard',kind:'civ',weapon:'pistol',x:r.x0+2.6,z:r.z0+4.2,yaw:PI/2,hpMul:1.8,look:{shirt:0x2c3a55,pants:0x1c2233,hat:0x1c2233,vest:0x22304a}}
    ];
  },
  conv(r,O,L){
    const cx=r.x0+3.2;
    furn(cx,.55,r.z1-2.6,4.2,1.1,1,0x6b5a8a,true);furn(cx,1.13,r.z1-2.6,4.4,.06,1.1,0x2a2433);
    furn(cx-.8,1.33,r.z1-2.6,.6,.35,.45,0x222222);
    const cols=[0xff5a5a,0xffc53d,0x4ec27a,0x3fa2ff,0xff8fd0,0xffffff];
    for(const sx of [O.x+1.6,O.x+4.2]){
      furn(sx,.85,O.z-.5,1,1.7,5.5,0xdcd8e2,true);
      for(const lv of [.45,.95,1.45])for(let k=0;k<5;k++)furn(sx,lv,O.z-2.7+k*1.1,1.06,.28,.9,pick(cols));
    }
    furn(r.x1-.45,1.15,O.z,.8,2.3,8,0xbfe6ff,true,true);
    for(let k=0;k<=4;k++)furn(r.x1-.87,1.15,O.z-4+k*2,.04,2.3,.1,0x333344);
    for(const lv of [.5,1.1,1.7])furn(r.x1-.6,lv,O.z,.4,.3,7.6,pick(cols));
    signPlane([L.title,'OPEN 24H'],'#1a0f2e','#d9b8ff',O.x,3.2,r.z1-.25,3.6,1.1,PI);
    r.counter=new V3(cx,0,r.z1-4.2);
    r.staff=[{role:'clerk',kind:'civ',x:cx,z:r.z1-1.5,yaw:PI,look:{shirt:0xeae6f2,vest:0x8f4dff}}];
  },
  jail(r,O){
    const bz=O.z+1;
    addCollider(r.x0,r.x1,bz-.1,bz+.1,r.h);
    for(let x=r.x0+.3;x<r.x1;x+=.45)furn(x,r.h/2,bz,.07,r.h,.07,0x2a2e36);
    furn(O.x,.06,bz,r.w,.12,.16,0x2a2e36);furn(O.x,2.6,bz,r.w,.1,.12,0x2a2e36);
    for(const x of [O.x-3,O.x+3])furn(x,r.h/2,(bz+r.z1)/2,.3,r.h,r.z1-bz,0x9aa0aa,true);
    for(const cx of [O.x-6,O.x,O.x+6]){
      furn(cx-1.8,.45,r.z1-1.4,1,.3,2.2,0x5a6270,true);furn(cx-1.8,.62,r.z1-1.2,1.02,.08,1.6,0xc87a3a);
      furn(cx+2.2,.35,r.z1-.5,.55,.7,.6,0xe8e8e8,true);
    }
    furn(O.x+.8,.45,r.z1-.24,1,.6,.05,0x3a3f48);
    for(let k=0;k<4;k++)furn(O.x+.8,.25+k*.14,r.z1-.27,.9,.04,.03,0x1a1d22);
    furn(O.x+5,.6,O.z-3,3,1.2,1,0x2f3d5c,true);furn(O.x+5,1.23,O.z-3,3.2,.06,1.1,0x1a2238);
    signPlane(['하버 교도소','HARBOR JAIL'],'#1a1d22','#ffb53d',O.x-4,3.6,r.z0+.1,3.4,1,0);
    r.spawn=new V3(O.x-.6,0,O.z+3.4);
    r.counter=new V3(O.x+.8,0,r.z1-1.3);
    r.staff=[
      {role:'warden1',kind:'cop',weapon:'pistol',x:O.x+5,z:O.z-4.2,yaw:0},
      {role:'warden2',kind:'cop',weapon:'shotgun',x:O.x-5,z:O.z-1.5,yaw:0}
    ];
  },
  diner(r,O,L){
    const cx=r.x0+3.2;
    furn(cx,.55,r.z1-2.6,4.4,1.1,1,0x8a3b24,true);furn(cx,1.13,r.z1-2.6,4.6,.06,1.1,0x2a1a10);
    furn(cx-1,1.33,r.z1-2.6,.6,.35,.45,0x222222);
    furn(O.x+3,1.9,r.z1-.25,5,1.2,.05,0xffd9a0,false,true);
    furn(O.x+3,1.28,r.z1-.55,5.2,.08,.6,0xcfc4b0);
    for(const tx of [O.x-2,O.x+2.6])for(const tz of [O.z-2,O.z+1.5]){
      furn(tx,.76,tz,1.3,.06,1.3,0xb07a4a,true);furn(tx,.38,tz,.12,.74,.12,0x3a2a22);
      for(const s of [-1,1]){furn(tx+s*1.05,.45,tz,.45,.08,.45,0xc0392b,true);furn(tx+s*1.3,.8,tz,.06,.7,.45,0xc0392b);}
    }
    signPlane([L.title,'KOREAN DINER'],'#2a0f08','#ffb47a',O.x+3,3.3,r.z1-.28,3.6,1.1,PI);
    r.counter=new V3(cx,0,r.z1-4.2);
    r.staff=[
      {role:'cashier',kind:'civ',x:cx,z:r.z1-1.5,yaw:PI,look:{shirt:0xffffff,vest:0xc0392b}},
      {role:'cook',kind:'civ',x:O.x+3,z:r.z1-1.3,yaw:PI,look:{shirt:0xffffff,pants:0x2b2b33,hat:0xffffff}}
    ];
  },
  police(r,O,L){
    furn(O.x,.6,r.z1-5,8,1.2,1.2,0x2f3d5c,true);furn(O.x,1.23,r.z1-5,8.2,.06,1.3,0x1a2238);
    for(const k of [-1,1]){furn(r.x0+.8,.45,O.z+k*2.6,.9,.12,3,0x6b5a4a,true);furn(r.x0+.42,.9,O.z+k*2.6,.08,.9,3,0x6b5a4a);}
    furn(O.x+5,2.4,r.z1-.25,4,2.2,.05,0x5a4a3a);
    for(let a=0;a<3;a++)for(let b=0;b<2;b++)furn(O.x+3.8+a*1.2,1.9+b*1.05,r.z1-.29,.85,.8,.03,0xf2ead2);
    furn(r.x1-.25,2.4,O.z+2,.05,2,5,0x1a2238);
    for(let k=0;k<5;k++)furn(r.x1-.3,2.4,O.z+.2+k*.9,.05,2,.06,0x9aa3b2);
    signPlane([L.sign[0],L.sign[1]],'#0d1a3a','#ffffff',O.x-4,3.2,r.z1-.28,3.6,1.1,PI);
    r.counter=new V3(O.x,0,r.z1-6.9);
    r.staff=[
      {role:'desk',kind:'cop',weapon:'pistol',x:O.x,z:r.z1-3.8,yaw:PI},
      {role:'officer',kind:'cop',weapon:'shotgun',x:r.x1-2.6,z:O.z-1.5,yaw:-PI/2}
    ];
  },
  mine(r,O){
    // timber sets every 5m, rails down the middle, lamps on the cap pieces, scrap heaps in side niches
    for(let z=r.z0+4;z<r.z1-1;z+=5){
      for(const x of [r.x0+.35,r.x1-.35])furn(x,r.h/2,z,.4,r.h,.4,0x6a4a2a,true);
      furn(O.x,r.h-.3,z,r.w,.45,.45,0x5a3c22);
      furn(O.x,r.h-.62,z,.3,.18,.2,0xffc070,false,true);
    }
    for(const sx of [-.7,.7])furn(O.x+sx,.06,O.z+2,.12,.1,r.d-6,0x5a5a60);
    for(let z=r.z0+5;z<r.z1-1;z+=1.2)furn(O.x,.03,z,2,.06,.3,0x4a3424);
    for(const z of [O.z-8,O.z+14]){furn(O.x,.9,z,1.6,1.1,2.2,0x4a4a52,true);furn(O.x,1.55,z,1.3,.35,1.6,0x6a5a48);}
    furn(O.x,r.h/2,r.z1-.6,r.w,r.h,.8,0x3e362e,true);
    for(let k=0;k<6;k++)furn(O.x+rand(-3.5,3.5),rand(1,4),r.z1-1.05,rand(.4,.9),rand(.3,.6),.1,0xc9a24a,false,true);
    r.heaps=[];
    for(const [sx,z] of [[-1,O.z-14],[1,O.z+2],[-1,O.z+18]]){
      const hx=sx<0?r.x0+1.4:r.x1-1.4;
      for(let k=0;k<3;k++){const m=mesh(rockG,imat(pick([0x7a4a2a,0x5a5048,0x6a6a72])),hx+rand(-.4,.4),.45,z+rand(-1,1));m.scale.set(1.1,.7,1.3);scene.add(m);}
      addCollider(hx-1,hx+1,z-1.2,z+1.2,1);
      const at=new V3(O.x+(sx<0?-1.6:1.6),0,z);heaps.push({pos:at,cd:0,room:null,roomOf:true,loot:'mine'});r.heaps.push(heaps[heaps.length-1]);
    }
    r.staff=[{role:'miner',kind:'civ',x:O.x+3.6,z:O.z-4,yaw:-PI/2,look:{shirt:0x4a5a6a,pants:0x2b2b33,hat:0xe8c547}}];
    furn(O.x+2.6,.5,O.z-4,.9,1,2.4,0x5a3c22,true);furn(O.x+2.6,1.03,O.z-4,1,.06,2.5,0x3a2a1a);
    for(let k=0;k<3;k++)furn(O.x+2.6,1.12,O.z-4.8+k*.8,.4,.14,.4,pick([0xc9a24a,0xb87333,0x9a9aa2]));
    r.counter=new V3(O.x+1.4,0,O.z-4);
    // ore veins: glinting seams in the rock that a pickaxe can work
    r.spots=[];
    for(const [sx,z] of [[1,O.z-20],[-1,O.z-8],[1,O.z+8],[-1,O.z+12],[1,O.z+21],[-1,O.z+24]]){
      const vx=sx<0?r.x0+.55:r.x1-.55,col=pick([0xc9a24a,0xb87333,0xd8d8e0,0x6a6a72]);
      for(let k=0;k<5;k++)furn(vx,rand(.4,2.6),z+rand(-1,1),.25,rand(.2,.45),rand(.2,.5),col,false,true);
      furn(vx,1.4,z,.5,2.8,2.4,0x4a4038,true);
      const V={pos:new V3(vx-sx*1.3,0,z),color:0xd8a84a,cd:0,label:()=>V.cd>0?'광맥 · 다시 캘 수 있을 때까지 '+Math.ceil(V.cd)+'초':player.pickaxe?'광맥 캐기 · 3초 · 곡괭이 내구도 '+player.pickaxe.dur:'광맥 · 곡괭이가 필요하다 (광부에게 구매)',act:()=>mineVein(V)};
      r.spots.push(V);ORE_VEINS.push(V);
    }
  }
};
const ORE_VEINS=[];
const HOTEL_PRICE=L=>L.look==='city'?120:L.look==='army'?80:50;
LOCS.forEach(buildRoom);
const GUEST={type:'guest',T:{room:{w:10,d:9,h:3.2,floor:0x8a6a4a,wall:0xd8ccb4,ceil:0xf0e8d8},color:0xf0c060},name:'객실',title:'객실',door:new V3(),out:{x:1,z:0},robCD:0,room:null,parent:null};
buildRoom(GUEST);
for(const L of LOCS)if(L.room&&L.room.heaps){for(const h of L.room.heaps){h.room=L;addRing(h.pos.x,h.pos.z,0xc9a26a,.75);}}
const POLICE=LOCS.find(l=>l.type==='police'&&l.look==='city');
const JAIL={type:'jail',T:LOC_TYPES.jail,name:'감옥',door:POLICE.door,out:POLICE.out,robCD:0,room:null};
buildRoom(JAIL);

// ---------- collision ----------
function collideCircle(p,r,skipTrees,sea){
  let hit=false;
  forColliders(p.x-r,p.z-r,p.x+r,p.z+r,b=>{
    if(skipTrees&&b.tree) return;
    if(p.x<b.x0-r||p.x>b.x1+r||p.z<b.z0-r||p.z>b.z1+r) return;
    const cx=clamp(p.x,b.x0,b.x1), cz=clamp(p.z,b.z0,b.z1); const dx=p.x-cx, dz=p.z-cz, q=dx*dx+dz*dz;
    if(q>r*r) return;
    if(q<1e-8){const l=p.x-b.x0,rr=b.x1-p.x,t=p.z-b.z0,bb=b.z1-p.z,m=Math.min(l,rr,t,bb);
      if(m===l)p.x=b.x0-r;else if(m===rr)p.x=b.x1+r;else if(m===t)p.z=b.z0-r;else p.z=b.z1+r;}
    else{const d=Math.sqrt(q);p.x=cx+dx/d*r;p.z=cz+dz/d*r;}
    hit=true;
  });
  if(p.x<ROOM_X&&clampWorld(p,r,sea))hit=true;
  return hit;
}
// the playable area: the city square plus the quay and the naval pier (and the harbour sea for a swimmer);
// the rectangles overlap so you can cross from one into the next
const ALLOW=[[-EDGE,EDGE,-EDGE,EDGE_S],[QUAY.x0,-540,QUAY.z0,QUAY.z1],[540,PIER_W.x1,PIER_W.z0,PIER_W.z1],[PIER_H.x0,PIER_H.x1,PIER_H.z0,PIER_H.z1],[JETTY.x0,-575,JETTY.z0,JETTY.z1],
  [BRIDGE.x0-6,-540,BRIDGE.z0+.5,BRIDGE.z1-.5],[FERRY_A.x0,-575,FERRY_A.z0,FERRY_A.z1],[FERRY_B.x0-4,FERRY_B.x1,FERRY_B.z0,FERRY_B.z1],[AFB_DOCK.x0,AFB_DOCK.x1+4,AFB_DOCK.z0,AFB_DOCK.z1]]
  .concat(ISLANDS.map(I=>[I.x0,I.x1,I.z0,I.z1]));
const ALLOW_SEA=ALLOW.concat(SEA_STRIPS);
function clampWorld(p,r,sea){
  const list=sea?ALLOW_SEA:ALLOW;
  for(const A of list)if(p.x>A[0]+r&&p.x<A[1]-r&&p.z>A[2]+r&&p.z<A[3]-r)return false;
  let bx=p.x,bz=p.z,bd=1e9;
  for(const A of list){const x=clamp(p.x,A[0]+r,A[1]-r),z=clamp(p.z,A[2]+r,A[3]-r),d=Math.hypot(x-p.x,z-p.z);if(d<bd){bd=d;bx=x;bz=z;}}
  p.x=bx;p.z=bz;return true;
}
function segEntry(ax,az,bx_,bz,c,m){
  const dx=bx_-ax,dz=bz-az;let t0=0,t1=1;const x0=c.x0-m,x1=c.x1+m,z0=c.z0-m,z1=c.z1+m;
  if(Math.abs(dx)<1e-9){if(ax<x0||ax>x1)return null;}else{let a=(x0-ax)/dx,b=(x1-ax)/dx;if(a>b){const s=a;a=b;b=s;}if(a>t0)t0=a;if(b<t1)t1=b;if(t0>t1)return null;}
  if(Math.abs(dz)<1e-9){if(az<z0||az>z1)return null;}else{let a=(z0-az)/dz,b=(z1-az)/dz;if(a>b){const s=a;a=b;b=s;}if(a>t0)t0=a;if(b<t1)t1=b;if(t0>t1)return null;}
  return t0;
}
function hasLOS(a,b){return !forColliders(a.x,a.z,b.x,b.z,c=>!c.tree&&c.h>=1.4&&segEntry(a.x,a.z,b.x,b.z,c,0)!==null)&&!terrainBlocks(a,b);}
function rayBox(o,d,x0,y0,z0,x1,y1,z1){
  let t0=0,t1=1e9;const ax=[[o.x,d.x,x0,x1],[o.y,d.y,y0,y1],[o.z,d.z,z0,z1]];
  for(const [oo,dd,mn,mx] of ax){
    if(Math.abs(dd)<1e-9){if(oo<mn||oo>mx)return null;}
    else{let a=(mn-oo)/dd,b=(mx-oo)/dd;if(a>b){const s=a;a=b;b=s;}if(a>t0)t0=a;if(b<t1)t1=b;if(t0>t1)return null;}
  }
  return t0;
}

// ---------- soft contact shadows ----------
const shadowMat=new THREE.MeshBasicMaterial({map:radialTex([[0,'rgba(0,0,0,.6)'],[.55,'rgba(0,0,0,.35)'],[1,'rgba(0,0,0,0)']]),transparent:true,depthWrite:false});
const shadowG=new THREE.PlaneGeometry(1,1);shadowG.rotateX(-Math.PI/2);
function blob(sx,sz){const m=new THREE.Mesh(shadowG,shadowMat);m.scale.set(sx,1,sz);m.renderOrder=1;scene.add(m);return m;}
function groundY(x,z){
  if(x>ROOM_X)return .025;
  if(!onMainXZ(x,z,553.01)){if(onDeck({x,z}))return floorH(x,z)+.03;return onIsland({x,z})?.03:-5;}
  const th=terrainH(x,z);if(th>0)return th+.05;
  if(inBase({x,z}))return .225;
  const i=Math.floor((x-R[0])/CELL),j=Math.floor((z-R[0])/CELL);
  if(i<0||j<0||i>=N||j>=NZ)return .025;
  const b=blocks[i*NZ+j];
  if(x<b.bx0||x>b.bx1||z<b.bz0||z>b.bz1)return .025;
  const inner=x>b.bx0+3&&x<b.bx1-3&&z>b.bz0+3&&z<b.bz1-3;
  return inner&&b.park?.32:inner&&b.kind==='suburb'?.27:.235;
}

// ---------- characters ----------
const skins=[0xf1c9a5,0xdcae86,0xb27d55,0x7a4e30];
const shirts=[0xd9534f,0x3f7fbf,0xe8c547,0x6aa84f,0xa266c9,0xe58b3a,0xdedede,0x2b2b33,0x46b3a6];
const pantsC=[0x2b3346,0x3d3a36,0x5b4a3a,0x1f2430,0x6a6f7d];
const hairs=[0x1b1410,0x3d2a1c,0x7a5a3a,0xc9b48a,0x2a2a2a];
function makePerson(o){
  const g=new THREE.Group(); g.rotation.order='YXZ';
  const skin=mat(o.skin);
  g.add(mesh(bx(.56,.66,.32),mat(o.shirt),0,1.15,0));
  g.add(mesh(bx(.34,.36,.34),skin,0,1.68,0));
  if(o.hat) g.add(mesh(bx(.42,.13,.44),mat(o.hat),0,1.9,.02)); else g.add(mesh(bx(.37,.1,.37),mat(o.hair||0x1b1410),0,1.88,-.01));
  g.add(mesh(bx(.24,.05,.02),mat(0x111111),0,1.72,.176));
  if(o.vest) g.add(mesh(bx(.6,.42,.36),mat(o.vest),0,1.25,0));
  const limb=(x,y,w,h,d,c)=>{const p=new THREE.Group();p.position.set(x,y,0);p.add(mesh(bx(w,h,d),mat(c),0,-h/2,0));g.add(p);return p;};
  const legL=limb(-.14,.82,.22,.82,.26,o.pants),legR=limb(.14,.82,.22,.82,.26,o.pants);
  const armL=limb(-.37,1.44,.17,.62,.19,o.shirt),armR=limb(.37,1.44,.17,.62,.19,o.shirt);
  armL.add(mesh(bx(.15,.14,.17),skin,0,-.68,0)); armR.add(mesh(bx(.15,.14,.17),skin,0,-.68,0));
  scene.add(g);
  return {g,legL,legR,armL,armR};
}
function animPerson(b,phase,amp){const s=Math.sin(phase)*amp;b.legL.rotation.x=s;b.legR.rotation.x=-s;b.armL.rotation.x=-s*.8;b.armR.rotation.x=s*.8;b.armL.rotation.z=0;}
function gunMesh(w){
  const g=new THREE.Group();
  if(w==='pistol') g.add(mesh(bx(.09,.32,.14),mat(0x1b1b20),0,-.86,.05));
  else if(w==='shotgun'){g.add(mesh(bx(.1,.95,.12),mat(0x26262c),0,-1.08,.04));g.add(mesh(bx(.13,.36,.16),mat(0x6a4426),0,-.78,.03));}
  else if(w==='rifle'){g.add(mesh(bx(.09,1.05,.13),mat(0x1d2119),0,-1.12,.04));g.add(mesh(bx(.08,.1,.24),mat(0x111111),0,-.98,-.12));}
  else if(w==='molotov'){g.add(mesh(bx(.11,.26,.11),mat(0x3f8a5a),0,-.86,.04));g.add(mesh(bx(.05,.12,.05),mat(0x3f8a5a),0,-1.04,.04));g.add(mesh(bx(.07,.1,.07),mat(0xd8c8a0),0,-1.13,.04));}
  else if(w==='rpg'){g.add(mesh(bx(.13,1.25,.13),mat(0x4a5a2a),0,-1.05,.08));g.add(mesh(bx(.2,.32,.2),mat(0x3a3a30),0,-1.82,.08));g.add(mesh(bx(.08,.22,.12),mat(0x1a1a1a),0,-.82,-.06));}
  return g;
}

// ---------- weapons ----------
const WEAPONS={
  fist:{name:'주먹'},
  pistol:{name:'권총',mag:12,dmg:25,rate:.22,spread:.006,range:90,reload:1.4,pellets:1,auto:false,magName:'탄창',price:250,ammoPrice:60,desc:'반자동 · 12발',len:.85},
  shotgun:{name:'산탄총',mag:6,dmg:8,rate:.85,spread:.06,range:30,reload:2.1,pellets:7,auto:false,magName:'탄 상자',price:900,ammoPrice:90,desc:'근거리 산탄 · 6발',len:1.3},
  rifle:{name:'소총',mag:30,dmg:20,rate:.1,spread:.01,range:120,reload:1.9,pellets:1,auto:true,magName:'탄창',price:1800,ammoPrice:150,desc:'연사 · 30발',len:1.35},
  // black-market items: thrown / launched projectiles, illegal to carry in view of the police
  molotov:{name:'화염병',mag:1,rate:.75,reload:.55,proj:'molotov',magName:'병',illegal:true,len:.4},
  rpg:{name:'RPG',mag:1,rate:1,reload:2.6,proj:'rpg',magName:'로켓',illegal:true,len:1.1}
};
const ORDER=['fist','pistol','shotgun','rifle','molotov','rpg'];
// no cap on how many magazines you can carry
const NPC_W={
  fist:{range:1.7,cd:[.9,1.2],dmg:4},
  pistol:{range:26,cd:[1.1,1.6],dmg:5,acc:.42},
  shotgun:{range:14,cd:[1.5,2],dmg:11,acc:.55},
  rifle:{range:38,cd:[.14,.14],burst:[3,4],pause:[1.2,1.9],dmg:3.8,acc:.36}
};
const UNIT_OF={cop:'police',swat:'swat',soldier:'army'};
const KILL_MSG={cop:'경찰의 총격에 쓰러졌습니다.',swat:'특수부대의 사격에 쓰러졌습니다.',soldier:'군인의 총격에 쓰러졌습니다.',civ:'시민의 반격에 쓰러졌습니다.'};
const CRIME={
  civ:{base:1,fist:'폭행',gun:'총격',car:'보행자 충돌'},
  cop:{base:3,fist:'경찰 폭행',gun:'경찰 총격',car:'경찰 충돌'},
  swat:{base:4,fist:'특수부대 폭행',gun:'특수부대 총격',car:'특수부대 충돌'},
  soldier:{base:5,fist:'군인 폭행',gun:'군인 총격',car:'군인 충돌'}
};

// ---------- entities ----------
const peds=[], cars=[], particles=[], tracers=[];
let heli=null;
const player={pos:new V3(OLD_C-8.5,0,OLD_C-22),vy:0,yaw:0,health:100,car:null,inside:null,punchT:0,punchAnim:0,phase:0,hitCD:0,body:null,
  weapon:'pistol',owned:{fist:true,pistol:true,shotgun:false,rifle:false,molotov:false,rpg:false},
  ammo:{pistol:{mag:12,mags:7},shotgun:{mag:0,mags:0},rifle:{mag:0,mags:0},molotov:{mag:0,mags:0},rpg:{mag:0,mags:0}},
  mats:{scrap:0,pipe:0,tape:0,battery:0,motor:0,bit:0},bank:0,kits:{car:0,mil:0},ores:{coal:0,iron:0,copper:0,silver:0,gold:0},pickaxe:null,hotel:null,tools:{crowbar:false,drill:false},grounded:true,keys:{mil:0,heli:0,boat:0},pass:false,
  reloadT:0,fireT:0,money:1000,crouch:false,jailed:false,jailT:0,prevWeapon:null,hunger:100,hungerWarn:0,trash:0,buffs:{speed:0,reload:0,armor:0},moving:false};
player.body=makePerson({skin:0xe0b08a,shirt:0x1fb5a8,pants:0x22263a,hair:0x1b1410,vest:0x14806f});
player.shadow=blob(.95,.95);
const pGuns={};for(const k of ['pistol','shotgun','rifle','molotov','rpg']){pGuns[k]=gunMesh(k);player.body.armR.add(pGuns[k]);}
let recoil=0,heliCD=0,robbing=null,menu=null,hitT=0,hitKill=false,camSnap=false;
const playerSpace=()=>player.car?null:player.inside;
const actualPos=()=>player.car?player.car.pos:player.pos;
const playerPos=()=>player.car?player.car.pos:(player.inside?player.inside.door:player.pos);

// first-person viewmodels
const vm=new THREE.Group();vm.position.set(.24,-.22,-.5);camera.add(vm);
const vmG={};
(function(){
  const sk=mat(0xe0b08a);
  let g=new THREE.Group();g.add(mesh(bx(.07,.09,.32),mat(0x1d1d22)));g.add(mesh(bx(.06,.16,.08),mat(0x2a2a30),0,-.1,.09));g.add(mesh(bx(.1,.08,.13),sk,0,-.16,.12));vmG.pistol=g;
  g=new THREE.Group();g.add(mesh(bx(.08,.08,.8),mat(0x26262c),0,0,-.15));g.add(mesh(bx(.1,.1,.3),mat(0x6a4426),0,-.07,-.1));g.add(mesh(bx(.11,.16,.32),mat(0x6a4426),0,-.08,.32));g.add(mesh(bx(.1,.08,.13),sk,0,-.15,-.05));vmG.shotgun=g;
  g=new THREE.Group();g.add(mesh(bx(.07,.1,.85),mat(0x1d2119),0,0,-.15));g.add(mesh(bx(.06,.18,.09),mat(0x111111),0,-.14,-.08));g.add(mesh(bx(.08,.12,.3),mat(0x2a2e24),0,-.04,.34));g.add(mesh(bx(.1,.08,.13),sk,0,-.13,.14));vmG.rifle=g;
  g=new THREE.Group();g.add(mesh(bx(.1,.24,.1),mat(0x3f8a5a),0,.02,-.05));g.add(mesh(bx(.05,.1,.05),mat(0x3f8a5a),0,.18,-.05));g.add(mesh(bx(.06,.09,.06),mat(0xd8c8a0),0,.26,-.05));g.add(mesh(bx(.12,.1,.13),sk,0,-.08,0));vmG.molotov=g;
  g=new THREE.Group();g.add(mesh(bx(.14,.14,1.2),mat(0x4a5a2a),.06,.06,-.2));g.add(mesh(bx(.2,.2,.34),mat(0x3a3a30),.06,.06,-.92));g.add(mesh(bx(.06,.16,.1),mat(0x1a1a1a),.06,-.08,.02));g.add(mesh(bx(.1,.08,.13),sk,.06,-.16,.02));vmG.rpg=g;
  for(const k in vmG){vmG[k].visible=false;vm.add(vmG[k]);}
})();

const HP={civ:60,cop:100,swat:140,soldier:150};
const LOOKS={
  cop:()=>({skin:pick(skins),shirt:0x1f3366,pants:0x151b30,hat:0x0f1630,vest:0x2a2f3c}),
  swat:()=>({skin:pick(skins),shirt:0x1c1f28,pants:0x1c1f28,hat:0x0c0d12,vest:0x2d323d}),
  soldier:()=>({skin:pick(skins),shirt:0x52603a,pants:0x434b2e,hat:0x3a4426,vest:0x3b4429}),
  civ:()=>({skin:pick(skins),shirt:pick(shirts),pants:pick(pantsC),hair:pick(hairs)})
};
function makePed(kind,x,z,o){
  o=o||{};
  const LD=Object.assign(LOOKS[kind](),o.look||{}),body=makePerson(LD);
  const weapon=o.weapon!==undefined?o.weapon:(kind==='civ'?(RNG()<.08?'pistol':null):kind==='cop'?(RNG()<.3?'shotgun':'pistol'):'rifle');
  let gm=null;if(weapon){gm=gunMesh(weapon);body.armR.add(gm);}
  const hp=HP[kind]*(o.hpMul||1), yaw=o.yaw!==undefined?o.yaw:rand(0,6.28);
  const p={kind,lookData:LD,body,gm,weapon,pos:new V3(x,0,z),yaw,state:o.state||'walk',vel:new V3(),phase:rand(0,6),downT:0,fleeT:0,fireT:rand(.6,1.4),lifeT:0,
    threat:new V3(),ci:0,dirc:1,corners:null,spin:0,dead:false,hp,maxHp:hp,stunT:0,burst:0,fightT:0,out:false,punchAnim:0,
    room:o.room||null,role:o.role||null,home:new V3(x,0,z),homeYaw:yaw,provokeOnUp:false,animAmp:0,shadow:blob(.95,.95)};
  peds.push(p);return p;
}
function blockOf(x,z){return [clamp(Math.floor((x-R[0])/CELL),0,N-1),clamp(Math.floor((z-R[0])/CELL),0,NZ-1)];}
function cornersOf(i,j){const a=R[i]+HALF_ROAD+1.5,b=R[i+1]-HALF_ROAD-1.5,c=R[j]+HALF_ROAD+1.5,d=R[j+1]-HALF_ROAD-1.5;return [[a,c],[b,c],[b,d],[a,d]];}
function setWalk(p){const [i,j]=blockOf(p.pos.x,p.pos.z);p.corners=cornersOf(i,j);let best=0,bd=1e9;p.corners.forEach((c,k)=>{const q=(c[0]-p.pos.x)**2+(c[1]-p.pos.z)**2;if(q<bd){bd=q;best=k;}});p.ci=best;p.dirc=RNG()<.5?1:-1;p.state='walk';}
// a random block within ~3 blocks of the player whose kind passes the filter
function nearBlock(ok,spread){
  const tp=playerPos(),bi=Math.floor((tp.x-R[0])/CELL),bj=Math.floor((tp.z-R[0])/CELL);spread=spread||3;
  for(let tries=0;tries<14;tries++){
    const i=clamp(bi+randi(-spread,spread),0,N-1),j=clamp(bj+randi(-spread,spread),0,NZ-1),b=blocks[i*NZ+j];
    if(ok(b))return [i,j];
  }
  return null;
}
function spawnCivWalker(minD){
  const ij=nearBlock(b=>WALKABLE.has(b.kind),2);if(!ij)return null;
  const tp=playerPos(),cs=cornersOf(ij[0],ij[1]),k=randi(0,3),dir=RNG()<.5?1:-1,a=cs[k],b=cs[(k+dir+4)%4],t=RNG();
  const x=a[0]+(b[0]-a[0])*t,z=a[1]+(b[1]-a[1])*t;
  if(minD&&Math.hypot(x-tp.x,z-tp.z)<minD)return null;
  const p=makePed('civ',x,z); p.corners=cs; p.ci=(k+dir+4)%4; p.dirc=dir; p.state='walk'; return p;
}
function populateRoom(loc){
  if(!loc.room)return;
  for(const s of loc.room.staff){
    let p=peds.find(q=>q.room===loc&&q.role===s.role&&!q.dead);
    if(p&&p.out){p.dead=true;p=null;}
    if(!p)makePed(s.kind,s.x,s.z,{room:loc,role:s.role,weapon:s.weapon||null,yaw:s.yaw,state:'idle',look:s.look,hpMul:s.hpMul});
    else if(p.state==='idle')p.hp=p.maxHp;
  }
}

// ---------- cars ----------
const carColors=[0xc0392b,0x2e86c1,0xf1c40f,0x27ae60,0x8e44ad,0xecf0f1,0x34495e,0xe67e22,0x16a085,0x7f8c8d,0xd35400];
const wheelG=new THREE.CylinderGeometry(.38,.38,.3,12); wheelG.rotateZ(Math.PI/2);
const bigWheelG=new THREE.CylinderGeometry(.55,.55,.42,12); bigWheelG.rotateZ(Math.PI/2);
const wreckMat=new THREE.MeshLambertMaterial({color:0x1d1b1f});
const headMat=new THREE.SpriteMaterial({map:WHITE_GLOW,color:0xfff1c4,transparent:true,blending:THREE.AdditiveBlending,depthWrite:false});
const tailMat=new THREE.SpriteMaterial({map:WHITE_GLOW,color:0xff2a2a,transparent:true,blending:THREE.AdditiveBlending,depthWrite:false});
const poolMat=new THREE.MeshBasicMaterial({map:WHITE_GLOW,color:0xffe2a8,transparent:true,opacity:.22,blending:THREE.AdditiveBlending,depthWrite:false});
const poolG=new THREE.PlaneGeometry(1,1);poolG.rotateX(-Math.PI/2);
function carGlows(g,fx,fy,fz,ry){
  const list=[];
  for(const s of [-1,1]){
    const h=new THREE.Sprite(headMat);h.position.set(s*fx,fy,fz+.08);h.scale.set(1.1,1.1,1);g.add(h);list.push(h);
    const t=new THREE.Sprite(tailMat);t.position.set(s*fx,ry,-fz-.08);t.scale.set(.6,.6,1);g.add(t);list.push(t);
  }
  const pool=new THREE.Mesh(poolG,poolMat);pool.position.set(0,.06,fz+4.5);pool.scale.set(4.5,1,8);g.add(pool);list.push(pool);
  return list;
}
function sirenLights(g,y,z){const r=new THREE.MeshBasicMaterial({color:0x550010}),b=new THREE.MeshBasicMaterial({color:0x001055});g.add(mesh(bx(.6,.18,.34),r,-.32,y,z));g.add(mesh(bx(.6,.18,.34),b,.32,y,z));return [r,b];}
function makeCarMesh(type,color,model){
  const g=new THREE.Group(); let lights=null;
  if(type==='bus'){
    const air=model==='air';
    g.add(mesh(bx(2.6,2.4,11),mat(color),0,1.75,0));
    g.add(mesh(bx(2.64,.85,9.4),mat(0x18202e),0,2.3,-.4));
    g.add(mesh(bx(2.5,.06,9),bmat(0xfff0c8),0,2.92,-.4));
    g.add(mesh(bx(2.63,.22,11.02),mat(0xf2f2f2),0,1.05,0));
    g.add(mesh(bx(2.3,1.15,.06),mat(0x10141f),0,2.2,5.52));
    g.add(mesh(bx(1.7,.34,.07),bmat(air?0x7ff3ff:0xffb53d),0,2.98,5.53));
    g.add(mesh(bx(2.5,.22,10.6),mat(0xdedede),0,3.06,0));
    g.add(mesh(bx(.06,1.7,1.1),mat(0x10141f),1.31,1.65,4.2));g.add(mesh(bx(.06,1.7,1.1),mat(0x10141f),1.31,1.65,-.6));
    [3.8,-3.4].forEach(z=>[-1.2,1.2].forEach(x=>g.add(mesh(bigWheelG,mat(0x111111),x,.55,z))));
    g.add(mesh(bx(.45,.2,.05),bmat(0xfff1c4),-.9,1,5.52));g.add(mesh(bx(.45,.2,.05),bmat(0xfff1c4),.9,1,5.52));
    g.add(mesh(bx(.4,.3,.05),bmat(0xff2a2a),-1,1.1,-5.52));g.add(mesh(bx(.4,.3,.05),bmat(0xff2a2a),1,1.1,-5.52));
    g.scale.z=.85;
  } else if(type==='army'){
    g.add(mesh(bx(2.5,1,6),mat(0x4a5530),0,1.05,0));
    g.add(mesh(bx(2.4,1.3,1.9),mat(0x56623a),0,2.1,1.9));
    g.add(mesh(bx(2.2,.55,.06),mat(0x10141f),0,2.35,2.87));
    g.add(mesh(bx(2.5,1.8,3.8),mat(0x3f4a2a),0,2.4,-1.05));
    [2,-.6,-2.1].forEach(z=>[-1.2,1.2].forEach(x=>g.add(mesh(bigWheelG,mat(0x111111),x,.55,z))));
    g.add(mesh(bx(.5,.2,.06),bmat(0xfff1c4),-.8,1.2,3.02)); g.add(mesh(bx(.5,.2,.06),bmat(0xfff1c4),.8,1.2,3.02));
  } else if(type==='gang'){
    g.add(mesh(bx(2.2,1.9,5),mat(0x121214),0,1.35,0));g.add(mesh(bx(2.24,.22,5.04),mat(0x7a1418),0,.82,0));
    g.add(mesh(bx(2.25,.6,3.6),mat(0x05060a),0,1.85,-.4));g.add(mesh(bx(2,.62,.06),mat(0x05060a),0,1.85,2.52));
    g.add(mesh(bx(1.6,.12,2.2),mat(0x2a2a2e),0,2.36,-.6));
    [[-1.05,1.6],[1.05,1.6],[-1.05,-1.6],[1.05,-1.6]].forEach(w=>g.add(mesh(bigWheelG,mat(0x111111),w[0],.55,w[1])));
    g.add(mesh(bx(.42,.16,.05),bmat(0xfff1c4),-.7,.95,2.52));g.add(mesh(bx(.42,.16,.05),bmat(0xfff1c4),.7,.95,2.52));
  } else if(type==='swat'){
    g.add(mesh(bx(2.3,2,5.2),mat(0x1a1d26),0,1.4,0));
    g.add(mesh(bx(2.34,.3,5.24),mat(0x2b3242),0,.9,0));
    g.add(mesh(bx(2.1,.6,.06),mat(0x0d1018),0,1.95,2.62));
    [[-1.1,1.7],[1.1,1.7],[-1.1,-1.7],[1.1,-1.7]].forEach(w=>g.add(mesh(bigWheelG,mat(0x111111),w[0],.55,w[1])));
    g.add(mesh(bx(.45,.18,.05),bmat(0xfff1c4),-.75,.95,2.62)); g.add(mesh(bx(.45,.18,.05),bmat(0xfff1c4),.75,.95,2.62));
    lights=sirenLights(g,2.5,.6);
  } else if(type==='fire'){
    g.add(mesh(bx(2.5,2.1,1.7),mat(0xc0221c),0,1.55,2.95));
    g.add(mesh(bx(2.3,.8,.06),mat(0x10141f),0,2.05,3.82));
    g.add(mesh(bx(2.5,1.9,5.9),mat(0xc0221c),0,1.45,-.85));
    g.add(mesh(bx(2.54,.2,7.6),mat(0xf2f2f2),0,1.05,0));
    for(const z of [-3.1,-1.6,-.1])for(const x of [-1.27,1.27])g.add(mesh(bx(.04,1.2,1.3),mat(0xb8bcc4),x,1.6,z));
    for(const x of [-.5,.5])g.add(mesh(bx(.12,.12,6.2),mat(0xd8dce4),x,2.6,-.7));
    for(let z=-3.6;z<=2.3;z+=.55)g.add(mesh(bx(1,.08,.08),mat(0xd8dce4),0,2.6,z));
    g.add(mesh(new THREE.CylinderGeometry(.6,.6,.3,12),mat(0x8a8e96),0,2.5,-3.2));
    [2.6,-1.6,-2.9].forEach(z=>[-1.2,1.2].forEach(x=>g.add(mesh(bigWheelG,mat(0x111111),x,.55,z))));
    g.add(mesh(bx(.45,.22,.05),bmat(0xfff1c4),-.85,.95,3.82)); g.add(mesh(bx(.45,.22,.05),bmat(0xfff1c4),.85,.95,3.82));
    lights=sirenLights(g,2.72,3.1);
  } else if(type==='apc'){
    g.add(mesh(bx(2.8,1.4,6.6),mat(0x56603e),0,1.25,0));
    const nose=mesh(bx(2.78,.9,1.6),mat(0x4f5838),0,1.55,3.2);nose.rotation.x=.55;g.add(nose);
    g.add(mesh(bx(1.5,.65,1.8),mat(0x4a5234),0,2.25,-.4));g.add(mesh(bx(.16,.16,2.2),mat(0x1a1a1a),0,2.3,1.4));
    g.add(mesh(bx(.6,.4,.06),mat(0x10141f),-.7,1.75,3.15));g.add(mesh(bx(.6,.4,.06),mat(0x10141f),.7,1.75,3.15));
    [-2.4,-.8,.8,2.4].forEach(z=>[-1.45,1.45].forEach(x=>g.add(mesh(bigWheelG,mat(0x111111),x,.55,z))));
    g.add(mesh(bx(.4,.18,.05),bmat(0xfff1c4),-.95,1.3,3.32));g.add(mesh(bx(.4,.18,.05),bmat(0xfff1c4),.95,1.3,3.32));
  } else if(type==='pheli'){
    const med=model==='med',hc=med?0xf4f6f8:0x4a5234;
    g.add(mesh(bx(2.4,1.8,5),mat(hc),0,1.5,0));g.add(mesh(bx(2.2,1,1.6),mat(0x111826),0,1.6,2.2));
    g.add(mesh(bx(.45,.45,4.4),mat(hc),0,1.8,-4.4));g.add(mesh(bx(.15,1.4,.8),mat(med?0xd23a2a:0x4a5234),0,2.4,-6.4));
    if(med){g.add(mesh(bx(2.44,.35,5.02),mat(0xd23a2a),0,1.05,0));for(const sx of [-1,1]){g.add(mesh(bx(.04,.9,.3),bmat(0xff3344),sx*1.23,1.75,-.6));g.add(mesh(bx(.04,.3,.9),bmat(0xff3344),sx*1.23,1.75,-.6));}
      g.add(mesh(bx(.5,.18,.5),bmat(0xff2a2a),0,2.5,.8));}
    g.add(mesh(bx(.2,.2,4),mat(0x222222),-1,.15,0));g.add(mesh(bx(.2,.2,4),mat(0x222222),1,.15,0));
    for(const z of [-1.2,1.2])for(const x of [-1,1])g.add(mesh(bx(.1,.6,.1),mat(0x222222),x,.5,z));
    const rotor=new THREE.Group();rotor.position.y=2.7;rotor.add(mesh(bx(12,.08,.45),mat(0x1a1a1a)));rotor.add(mesh(bx(.45,.08,12),mat(0x1a1a1a)));g.add(rotor);g.userData.rotor=rotor;
    const tail=new THREE.Group();tail.position.set(.25,2.4,-6.5);tail.add(mesh(bx(.05,2,.2),mat(0x1a1a1a)));g.add(tail);g.userData.tail=tail;
    // chin turret: a three-barrel rotary cannon that swings toward the aim point
    const gun=new THREE.Group();gun.position.set(0,.5,2.75);g.add(gun);g.userData.gun=gun;
    gun.add(mesh(bx(.62,.5,.7),mat(0x2a2c30)));
    const brl=new THREE.Group();brl.position.z=.35;gun.add(brl);g.userData.barrels=brl;
    for(let k=0;k<3;k++){const a=k*Math.PI*2/3,b=mesh(bx(.09,.09,1.5),mat(0x18191c),Math.cos(a)*.12,Math.sin(a)*.12,.75);brl.add(b);}
    brl.add(mesh(bx(.3,.3,.08),mat(0x3a3c40),0,0,1.45));
    if(model==='med'){g.remove(gun);g.userData.gun=null;}
  } else if(type==='mboat'){
    const hc=model==='speed'?0xd23a2a:color;
    g.add(mesh(bx(2.2,.9,4.4),mat(hc),0,.3,-.3));
    const bow=mesh(bx(1.55,.9,1.55),mat(hc),0,.3,1.9);bow.rotation.y=Math.PI/4;g.add(bow);
    g.add(mesh(bx(2.24,.18,4.4),mat(model==='speed'?0x1a1a1e:0x2e86c1),0,.05,-.3));
    g.add(mesh(bx(2,.1,3.6),mat(0xd8cbb0),0,.78,-.6));
    const ws=mesh(bx(1.9,.5,.06),glassMat,0,1.05,.7);ws.rotation.x=-.45;g.add(ws);
    g.add(mesh(bx(1.6,.45,.9),mat(0x2a2a30),0,1,-.9));g.add(mesh(bx(.45,1,.45),mat(0x1a1a1e),0,.55,-2.7));
  } else if(type==='navyboat'){
    const nb=boatMesh();for(const ch of [...nb.g.children])g.add(ch);scene.remove(nb.g);lights=nb.lights;
  } else if(type==='amb'){
    g.add(mesh(bx(2.3,1.6,1.8),mat(0xf2f2f0),0,1.25,2.05));
    g.add(mesh(bx(2.1,.7,.06),mat(0x10141f),0,1.65,2.96));
    g.add(mesh(bx(2.4,2.4,4),mat(0xf2f2f0),0,1.6,-.8));
    g.add(mesh(bx(2.44,.35,5.8),mat(0xd23a2a),0,1.05,0));
    for(const x of [-1.23,1.23]){g.add(mesh(bx(.04,.9,.3),bmat(0xd23a2a),x,2.1,-.8));g.add(mesh(bx(.04,.3,.9),bmat(0xd23a2a),x,2.1,-.8));}
    g.add(mesh(bx(.9,.3,.04),bmat(0xd23a2a),0,2.1,-2.82));g.add(mesh(bx(.3,.9,.04),bmat(0xd23a2a),0,2.1,-2.82));
    [[-1.1,1.8],[1.1,1.8],[-1.1,-1.9],[1.1,-1.9]].forEach(w=>g.add(mesh(bigWheelG,mat(0x111111),w[0],.55,w[1])));
    g.add(mesh(bx(.42,.2,.05),bmat(0xfff1c4),-.75,1,2.96)); g.add(mesh(bx(.42,.2,.05),bmat(0xfff1c4),.75,1,2.96));
    lights=sirenLights(g,2.9,.6);
  } else if(type==='tow'){
    const city=model==='city',cab=city?0xf4f6f8:0xf08a24,trim=city?0x2fa35a:0xd8a020;
    g.add(mesh(bx(2.3,1.8,2.2),mat(cab),0,1.45,1.95));
    g.add(mesh(bx(2.1,.7,.06),mat(0x10141f),0,1.95,3.06));
    g.add(mesh(bx(2.34,.25,6.1),mat(trim),0,.75,0));
    g.add(mesh(bx(2.32,.18,2.22),mat(city?0x2fa35a:0x2a2a2e),0,.95,1.95));
    g.add(mesh(bx(2.3,.45,3.9),mat(city?0x2fa35a:0x2a2a2e),0,1.05,-1.05));
    if(city){g.add(mesh(bx(2.36,.12,2.24),mat(0x1f4fa8),0,1.62,1.95));g.add(mesh(bx(1.4,.28,.5),bmat(0x9fe8c8),0,2.5,1.4));}
    else g.add(mesh(bx(1.4,.28,.5),bmat(0xffb53d),0,2.5,1.4));
    const boom=mesh(bx(.32,.32,3.4),mat(city?0xdfe4ec:0xd8a020),0,1.85,-1.4);boom.rotation.x=-.32;g.add(boom);
    g.add(mesh(bx(.1,.9,.1),mat(0x1a1a1a),0,2,-3.05));g.add(mesh(bx(.5,.2,.3),mat(0x3a3a40),0,1.5,-3.05));
    [1.9,-.9,-2.1].forEach(z=>[-1.1,1.1].forEach(x=>g.add(mesh(bigWheelG,mat(0x111111),x,.55,z))));
    g.add(mesh(bx(.42,.2,.05),bmat(0xfff1c4),-.75,1,3.06)); g.add(mesh(bx(.42,.2,.05),bmat(0xfff1c4),.75,1,3.06));
    lights=sirenLights(g,2.42,1.6);
  } else if(model==='truck'){ // box delivery truck in the courier's orange and white
    g.add(mesh(bx(2.4,2.1,2.2),mat(0xf2f2f0),0,1.45,2.55));
    g.add(mesh(bx(2.2,.8,.06),mat(0x10141f),0,1.95,3.66));
    g.add(mesh(bx(2.42,.35,2.22),mat(color),0,.85,2.55));
    g.add(mesh(bx(2.6,2.9,5.1),mat(0xf4f2ee),0,2.05,-.95));
    for(const x of [-1.31,1.31]){g.add(mesh(bx(.04,.55,5),bmat(color),x,1.3,-.95));g.add(mesh(bx(.04,.7,2.2),bmat(color),x,2.6,-.95));}
    g.add(mesh(bx(2.5,2.6,.05),mat(0xdedad2),0,2.05,-3.52));g.add(mesh(bx(2.5,.3,.06),bmat(color),0,1,-3.53));
    g.add(mesh(bx(2.5,.3,7.3),mat(0x2a2a2e),0,.55,0));
    [2.4,-1.6,-2.8].forEach(z=>[-1.15,1.15].forEach(x=>g.add(mesh(bigWheelG,mat(0x111111),x,.55,z))));
    g.add(mesh(bx(.42,.2,.05),bmat(0xfff1c4),-.8,1.05,3.66)); g.add(mesh(bx(.42,.2,.05),bmat(0xfff1c4),.8,1.05,3.66));
  } else if(model==='sport'){
    g.add(mesh(bx(2,.5,4.6),mat(color),0,.55,0));
    g.add(mesh(bx(1.7,.42,1.9),mat(0x161c2b),0,.98,-.35));
    g.add(mesh(bx(1.74,.08,1.6),mat(color),0,1.22,-.45));
    g.add(mesh(bx(1.9,.08,.42),mat(0x111111),0,1.12,-2.15));
    for(const x of [-.7,.7])g.add(mesh(bx(.08,.32,.1),mat(0x111111),x,.92,-2.15));
    [[-1,1.5],[1,1.5],[-1,-1.5],[1,-1.5]].forEach(w=>g.add(mesh(wheelG,mat(0x111111),w[0],.38,w[1])));
    g.add(mesh(bx(.5,.12,.05),bmat(0xfff1c4),-.62,.62,2.32)); g.add(mesh(bx(.5,.12,.05),bmat(0xfff1c4),.62,.62,2.32));
    g.add(mesh(bx(1.6,.1,.05),bmat(0xff2a2a),0,.68,-2.32));
  } else if(model==='suv'){
    g.add(mesh(bx(2.2,.95,4.8),mat(color),0,.95,0));
    g.add(mesh(bx(2,.62,3),mat(0x161c2b),0,1.72,-.3));
    g.add(mesh(bx(2.04,.1,2.8),mat(color),0,2.07,-.3));
    [[-1.1,1.6],[1.1,1.6],[-1.1,-1.6],[1.1,-1.6]].forEach(w=>g.add(mesh(bigWheelG,mat(0x111111),w[0],.55,w[1])));
    g.add(mesh(bx(.5,.2,.05),bmat(0xfff1c4),-.7,1.05,2.42)); g.add(mesh(bx(.5,.2,.05),bmat(0xfff1c4),.7,1.05,2.42));
    g.add(mesh(bx(.45,.2,.05),bmat(0xff2a2a),-.75,1.1,-2.42)); g.add(mesh(bx(.45,.2,.05),bmat(0xff2a2a),.75,1.1,-2.42));
  } else {
    const body=type==='police'?0xf2f2f4:color;
    g.add(mesh(bx(2,.7,4.4),mat(body),0,.68,0));
    if(type==='police'){g.add(mesh(bx(2.04,.32,2),mat(0x1a2b5e),0,.72,-.1));}
    if(type==='taxi'){g.add(mesh(bx(.8,.25,.4),bmat(0xffe08a),0,1.72,-.3));}
    g.add(mesh(bx(1.78,.5,2.2),mat(0x161c2b),0,1.27,-.25));
    g.add(mesh(bx(1.82,.12,1.9),mat(body),0,1.57,-.3));
    [[-1,1.4],[1,1.4],[-1,-1.4],[1,-1.4]].forEach(w=>g.add(mesh(wheelG,mat(0x111111),w[0],.38,w[1])));
    g.add(mesh(bx(.45,.18,.05),bmat(0xfff1c4),-.62,.75,2.22)); g.add(mesh(bx(.45,.18,.05),bmat(0xfff1c4),.62,.75,2.22));
    g.add(mesh(bx(.45,.16,.05),bmat(0xff2a2a),-.62,.78,-2.22)); g.add(mesh(bx(.45,.16,.05),bmat(0xff2a2a),.62,.78,-2.22));
    if(type==='police')lights=sirenLights(g,1.72,-.3);
  }
  const L=type==='bus'?[.9,1,4.7,1.1]:type==='gang'?[.75,.95,2.52,1]:type==='apc'?[.95,1.3,3.32,1.2]:type==='pheli'?[.6,1,2.9,1.6]:type==='mboat'?[.5,.6,2.6,.6]:type==='navyboat'?[1,1.4,5.4,1.4]:type==='amb'?[.75,1,2.96,1.1]:type==='tow'?[.75,1,3.06,1]:type==='fire'?[.85,.95,3.82,1.1]:type==='army'?[.8,1.2,3.02,1.2]:type==='swat'?[.75,.95,2.62,1.2]:model==='truck'?[.8,1.05,3.66,1]:model==='sport'?[.62,.62,2.32,.68]:model==='suv'?[.7,1.05,2.42,1.1]:[.62,.75,2.22,.78];
  const glows=carGlows(g,L[0],L[1],L[2],L[3]);
  scene.add(g); return {g,lights,glows};
}
const CAR_STATS={
  civ:{hp:260,max:30,acc:13,turn:1.9,w:2,half:2.2,rad:1,top:1.65},
  police:{hp:340,max:28,acc:13,turn:1.9,w:2,half:2.2,rad:1,top:1.65},
  swat:{hp:460,max:27,acc:11,turn:1.6,w:2.3,half:2.6,rad:1.15,top:2.4},
  army:{hp:560,max:27,acc:10,turn:1.35,w:2.5,half:3,rad:1.25,top:3.2},
  fire:{hp:640,max:25,acc:9.5,turn:1.3,w:2.5,half:3.8,rad:1.25,top:3},
  tow:{hp:420,max:24,acc:10,turn:1.6,w:2.3,half:3.1,rad:1.15,top:2.8},
  amb:{hp:380,max:28,acc:12,turn:1.7,w:2.4,half:3,rad:1.15,top:2.8},
  apc:{hp:1500,max:22,acc:8,turn:1.25,w:2.8,half:3.4,rad:1.4,top:2.9},
  pheli:{hp:700,max:46,acc:16,turn:1.5,w:2.4,half:3.2,rad:1.4,top:2.6},
  mboat:{hp:260,max:26,acc:9,turn:1.5,w:2.2,half:2.8,rad:1.1,top:1.6},
  mspeed:{hp:220,max:34,acc:12,turn:1.7,w:2,half:2.9,rad:1,top:1.4},
  navyboat:{hp:900,max:22,acc:7,turn:1.05,w:3.6,half:5.6,rad:1.8,top:3},
  bus:{hp:900,max:21.6,acc:7.8,turn:1.25,w:2.6,half:4.7,rad:1.3,top:3.2},
  gang:{hp:420,max:30,acc:12,turn:1.7,w:2.2,half:2.5,rad:1.1,top:2.3}
};
const MODEL_STATS={
  compact:CAR_STATS.civ,
  suv:{hp:440,max:29,acc:12,turn:1.7,w:2.2,half:2.4,rad:1.1,top:2.1},
  sport:{hp:300,max:40,acc:20,turn:2.2,w:2,half:2.3,rad:1,top:1.3},
  truck:{hp:620,max:24,acc:8,turn:1.35,w:2.5,half:3.7,rad:1.25,top:3.3}
};
function makeCar(type,x,z,heading,ai,opts){
  opts=opts||{};
  let model=opts.model||null;
  if(type==='civ'&&!model){const r=RNG();model=opts.taxi||r>=.2?'compact':r<.06?'sport':'suv';}
  const t=type==='civ'&&opts.taxi?'taxi':type;
  const col=opts.color||(t==='taxi'?0xf4c430:pick(carColors)),{g,lights,glows}=makeCarMesh(t,col,model);g.rotation.order='YXZ';
  const S=(type==='civ'&&MODEL_STATS[model])||(type==='mboat'&&model==='speed'&&CAR_STATS.mspeed)||CAR_STATS[type];
  const c={type,model,mesh:g,lights,glows,glowOn:true,shadow:blob(S.w+.7,S.half*2+.9),pos:new V3(x,0,z),heading,vis:heading,speed:0,ai,hasDriver:ai!=='parked',
    health:S.hp,maxHealth:S.hp,w:S.w,half:S.half,rad:S.rad,top:S.top,maxSpeed:S.max,accel:S.acc,turn:S.turn,
    stuckT:0,revT:0,revSteer:0,waitT:0,ghostT:0,lifeT:0,crew:0,smokeT:0,wreckT:0,dead:false,fixed:false,
    dx:0,dz:1,li:0,ni:0,choice:'S',nd:null,zone:null,color:col};
  cars.push(c); return c;
}
const fwdOf=c=>({x:Math.sin(c.heading),z:Math.cos(c.heading)});

function setAlong(c,v){if(c.dx!==0)c.pos.x=v;else c.pos.z=v;}
// lane cars only take road segments that exist; patrol cars are also fenced to their zone's intersections
// road segments with a wreck or a crashed car on them; drivers pick another way at the next junction
const BLOCKED=new Set();
function segKeyAt(p){
  const ix=gridIdx(p.x),iz=gridIdxZ(p.z),ax=Math.abs(p.x-R[ix]),az=Math.abs(p.z-R[iz]);
  if(az<HALF_ROAD&&ax>HALF_ROAD)return 'h'+clamp(Math.floor((p.x-R[0])/CELL),0,N-1)+','+iz;
  if(ax<HALF_ROAD&&az>HALF_ROAD)return 'v'+ix+','+clamp(Math.floor((p.z-R[0])/CELL),0,NZ-1);
  return null;
}
function chooseTurn(c){
  const Z=c.zone,inX=k=>!Z||(k>=Z.i0&&k<=Z.i1),inZ=k=>!Z||(k>=Z.j0&&k<=Z.j1);
  const h=c.dx!==0,s=h?c.dx:c.dz,opts=[];
  if(h){const i=s>0?c.ni:c.ni-1;if(segH(i,c.li)&&inX(c.ni+s))opts.push([null,'h'+i+','+c.li,2]);}
  else{const j=s>0?c.ni:c.ni-1;if(segV(c.li,j)&&inZ(c.ni+s))opts.push([null,'v'+c.li+','+j,2]);}
  for(const t of [1,-1]){
    if(h){const j=t>0?c.li:c.li-1;if(segV(c.ni,j)&&inZ(c.li+t))opts.push([[0,t],'v'+c.ni+','+j,1]);}
    else{const i=t>0?c.li:c.li-1;if(segH(i,c.ni)&&inX(c.li+t))opts.push([[t,0],'h'+i+','+c.ni,1]);}
  }
  if(!opts.length){c.choice='U';c.nd=null;return;} // dead end: turn around
  const clear=opts.filter(o=>!BLOCKED.has(o[1])),use=clear.length?clear:opts;
  let tot=0;for(const o of use)tot+=o[2];let r=RNG()*tot,pk=use[0];for(const o of use){r-=o[2];if(r<=0){pk=o;break;}}
  if(pk[0]){c.choice='T';c.nd=pk[0];}else{c.choice='S';c.nd=null;}
}
function laneAdvance(c,step){
  const ax=c.dx!==0, sign=ax?c.dx:c.dz, cur=ax?c.pos.x:c.pos.z;
  const trig=c.choice==='S'?R[c.ni]:c.choice==='U'?R[c.ni]-sign*LANE:(ax?R[c.ni]-LANE*c.nd[1]:R[c.ni]+LANE*c.nd[0]);
  const next=cur+sign*step;
  if((next-trig)*sign>=0){
    if(c.choice==='S'){setAlong(c,next);c.ni+=sign;chooseTurn(c);}
    else if(c.choice==='U'){setAlong(c,trig);c.dx=-c.dx;c.dz=-c.dz;c.ni-=sign;c.ov=0;c.ovState=0;chooseTurn(c);}
    else{const old=c.li;setAlong(c,trig);c.li=c.ni;c.dx=c.nd[0];c.dz=c.nd[1];c.ni=old+(c.dx!==0?c.dx:c.dz);c.ov=0;c.ovState=0;chooseTurn(c);}
  } else setAlong(c,next);
  // lateral place: own lane, the oncoming lane while overtaking (ov→1), toward the kerb when pulling over
  const lat=LANE*(1-2*(c.ov||0))+1.6*(c.pull||0);
  if(c.dx!==0)c.pos.z=R[c.li]+lat*c.dx;else c.pos.x=R[c.li]-lat*c.dz;
}
const segAt=(horiz,li,t)=>{const k=clamp(Math.floor((t-R[0])/CELL),0,(horiz?N:NZ)-1);return horiz?segH(k,li):segV(li,k);};
function spawnRoadPos(minD,maxD){
  const tp=playerPos();
  for(let tries=0;tries<60;tries++){
    const horiz=RNG()<.5,s=RNG()<.5?1:-1;
    const li=clamp((horiz?nearestIdxZ(tp.z):nearestIdx(tp.x))+randi(-3,3),0,horiz?NZ:N),t=clamp((horiz?tp.x:tp.z)+rand(-maxD,maxD),R[0]+10,(horiz?R[N]:R[NZ])-10); const near=Math.round((t-R[0])/CELL); if(Math.abs(t-R[near])<11) continue;
    if(!segAt(horiz,li,t))continue;
    const dx=horiz?s:0,dz=horiz?0:s;
    const x=horiz?t:R[li]-LANE*dz, z=horiz?R[li]+LANE*dx:t;
    const d=Math.hypot(x-tp.x,z-tp.z); if(d<minD||d>maxD) continue;
    let ni; if(s>0){ni=0;while(R[ni]<=t)ni++;} else {ni=R.length-1;while(R[ni]>=t)ni--;}
    return {x,z,dx,dz,li,ni};
  }
  return null;
}
function makeTraffic(sp){
  const c=makeCar('civ',sp.x,sp.z,Math.atan2(sp.dx,sp.dz),'traffic');
  c.dx=sp.dx;c.dz=sp.dz;c.li=sp.li;c.ni=sp.ni;c.speed=8;chooseTurn(c);
  // a few bad drivers: some run red lights (and drive fast), some pull over and leave the car where it isn't allowed
  if(RNG()<.08){c.reckless=true;c.cruise=rand(13,16);}
  if(RNG()<.05)c.parkAt=rand(12,60);
  return c;
}
// where a car may be left: the outskirts beyond the street lamps, the airport, bays, car parks, garages, city hall
function legalPark(p){
  if(p.x<AIR.x1+4&&p.x>AIR.x0-4&&p.z>AIR.z0-4&&p.z<AIR.z1+4)return true;
  if(Math.abs(p.x)<=EDGE+60&&p.z>=-EDGE-60&&p.z<=EDGE_S+60&&(Math.abs(p.x)>R[N]+HALF_ROAD+2.5||p.z<R[0]-HALF_ROAD-2.5||p.z>R[NZ]+HALF_ROAD+2.5))return true;
  for(const Z of PARK_ZONES)if(p.x>=Z.x0&&p.x<=Z.x1&&p.z>=Z.z0&&p.z<=Z.z1)return true;
  return false;
}
function makeParked(minD,maxD){
  const tp=playerPos();minD=minD||8;maxD=maxD||170;
  for(let tries=0;tries<30;tries++){
    const q=pick(PARK_SPOTS);if(!q)break;const dd=Math.hypot(q.x-tp.x,q.z-tp.z);if(dd<minD||dd>maxD||!freeAt(q.x,q.z,3))continue;
    const c=makeCar('civ',q.x,q.z,q.h,'parked');c.locked=RNG()<.5;c.spot=q;return c;
  }
  return null;
  for(let tries=0;tries<30;tries++){
    const horiz=RNG()<.5,li=clamp((horiz?nearestIdxZ(tp.z):nearestIdx(tp.x))+randi(-3,3),0,horiz?NZ:N),t=clamp((horiz?tp.x:tp.z)+rand(-maxD,maxD),R[0]+12,(horiz?R[N]:R[NZ])-12),near=Math.round((t-R[0])/CELL);
    if(Math.abs(t-R[near])<13||!segAt(horiz,li,t)) continue; const side=RNG()<.5?1:-1;
    const x=horiz?t:R[li]+side*6, z=horiz?R[li]+side*6:t; // kerbside, clear of the driving lane
    const dd=Math.hypot(x-tp.x,z-tp.z);if(dd<minD||dd>maxD) continue;
    if(stationSpots.some(s=>Math.hypot(s.x-x,s.z-z)<6)||fireSpots.some(s=>Math.hypot(s.x-x,s.z-z)<8)) continue;
    const h=horiz?(side>0?Math.PI/2:-Math.PI/2):(side>0?Math.PI:0);
    return makeCar('civ',x,z,h,'parked');
  }
}

// ---------- particles / fx ----------
const sphG=new THREE.SphereGeometry(1,10,8);
// heavy-gun rounds: a glowing streak flying to the impact, a muzzle flash, a spray of brass
const STREAK_MAT=new THREE.MeshBasicMaterial({color:0xffe08a,transparent:true,opacity:.95}),FLASH_MAT=new THREE.MeshBasicMaterial({color:0xfff0b0,transparent:true,opacity:.9});
const streaks=[],flashes=[];
function bulletStreak(a,b){
  if(streaks.length>48)return;
  const m=new THREE.Mesh(UNIT,STREAK_MAT),L=a.distanceTo(b);m.position.copy(a);m.scale.set(.16,.16,Math.min(7,Math.max(1.5,L*.2)));
  if(m.lookAt)m.lookAt(b);scene.add(m);streaks.push({m,a:a.clone(),b:b.clone(),t:0,dur:Math.max(.05,L/650)});
}
function muzzleFlash(p,big){
  const m=new THREE.Mesh(sphG,FLASH_MAT);m.position.copy(p);const r=(big?.75:.5)*rand(.8,1.2);m.scale.set(r,r,r*1.6);scene.add(m);flashes.push({m,t:.05});
}
function puff(pos,color,size,vel,life,additive){
  if(particles.length>160) return;
  const m=new THREE.MeshBasicMaterial({color,transparent:true,opacity:additive?.9:.55,depthWrite:false,blending:additive?THREE.AdditiveBlending:THREE.NormalBlending});
  const o=new THREE.Mesh(sphG,m); o.position.copy(pos); o.scale.setScalar(size); scene.add(o);
  particles.push({o,vel,life,max:life,size,grow:additive?6:2.2});
}
function tracer(a,b,color){
  if(tracers.length>60)return;
  const g=new THREE.BufferGeometry().setFromPoints([a,b]);
  const l=new THREE.Line(g,new THREE.LineBasicMaterial({color:color||0xffd27a,transparent:true}));
  scene.add(l); tracers.push({l,t:.07});
}
let shake=0;

// ---------- pickups: dropped guns, wallets, street trash ----------
const pickups=[],bins=[];
const TRASH_N=45,TRASH_MAX=10,HUNGER_RATE=.2,SCRAP_N=14; // hunger empties in ~8 minutes
// crafting materials: rusty street scrap, junkyard heaps and the mine tunnel give these
const MATS={scrap:'고철',pipe:'파이프',tape:'절연테이프',battery:'배터리',motor:'모터',bit:'드릴 비트'};
const LOOT={street:[['scrap',35],['pipe',27],['tape',20],['battery',9],['motor',5],['bit',4]],
  junk:[['scrap',22],['pipe',22],['tape',16],['battery',15],['motor',13],['bit',12]],
  mine:[['scrap',20],['pipe',14],['tape',12],['battery',16],['motor',12],['bit',26]]};
function rollMat(table){let t=0;for(const e of table)t+=e[1];let r=RNG()*t;for(const e of table){r-=e[1];if(r<=0)return e[0];}return table[0][0];}
const pRingG=new THREE.RingGeometry(.4,.55,24);pRingG.rotateX(-Math.PI/2);
const canG=new THREE.CylinderGeometry(.08,.08,.24,8),bottleG=new THREE.CylinderGeometry(.06,.09,.32,8),bagG=new THREE.IcosahedronGeometry(.2,0),cupG=new THREE.CylinderGeometry(.1,.07,.22,8);
function addPickup(kind,x,z,data){
  const g=new THREE.Group();g.position.set(x,0,z);
  if(kind==='weapon'){
    const h=new THREE.Group(),m=gunMesh(data.weapon);m.rotation.z=Math.PI/2;m.position.set(-1,.2,0);h.add(m);g.add(h);g.userData.spin=h;
    g.add(mesh(pRingG,new THREE.MeshBasicMaterial({color:0xffb53d,transparent:true,opacity:.75,depthWrite:false}),0,.06,0));
  } else if(kind==='cash'){
    const h=new THREE.Group();for(let k=0;k<3;k++)h.add(mesh(bx(.32,.05,.16),bmat(0x61e08e),0,.08+k*.06,0));g.add(h);g.userData.spin=h;
    g.add(mesh(pRingG,new THREE.MeshBasicMaterial({color:0x61e08e,transparent:true,opacity:.75,depthWrite:false}),0,.06,0));
  } else if(kind==='scrap'){
    const h=new THREE.Group();
    const pp=mesh(cylG,imat(0x8a5a32),0,.09,0);pp.scale.set(.07,.7,.07);pp.rotation.z=Math.PI/2;h.add(pp);
    const pl=mesh(UNIT,imat(0x6a6a72),.12,.06,.18);pl.scale.set(.34,.05,.24);pl.rotation.y=.5;h.add(pl);
    const bt=mesh(UNIT,imat(0x5a3a2a),-.15,.08,-.12);bt.scale.set(.16,.16,.16);h.add(bt);
    h.rotation.y=rand(0,6.28);g.add(h);
    g.add(mesh(pRingG,new THREE.MeshBasicMaterial({color:0xc9a26a,transparent:true,opacity:.6,depthWrite:false}),0,.06,0));
  } else {
    const t=randi(0,3);let m;
    if(t===0){m=mesh(canG,imat(pick([0xd23a2a,0xc8ccd4,0x3f7fbf])),0,.08,0);m.rotation.z=Math.PI/2;}
    else if(t===1){m=mesh(bottleG,imat(0x3f8a5a),0,.09,0);m.rotation.z=Math.PI/2;}
    else if(t===2){m=mesh(bagG,imat(0xe8e2d4),0,.15,0);m.scale.set(1,.7,1.2);}
    else{m=mesh(cupG,imat(0xf4f4f4),0,.11,0);m.rotation.x=Math.PI/2;}
    m.rotation.y=rand(0,6.28);g.add(m);
  }
  scene.add(g);
  const p=Object.assign({kind,g,pos:new V3(x,0,z),t:0,life:kind==='trash'||kind==='scrap'?1e9:75},data);pickups.push(p);return p;
}
function removePickup(i){scene.remove(pickups[i].g);pickups.splice(i,1);}
const litter=k=>k==='trash'||k==='scrap';
function spawnTrash(minD,kind){
  const tp=playerPos();
  for(let tries=0;tries<20;tries++){
    const ij=nearBlock(b=>WALKABLE.has(b.kind));if(!ij)return;
    const cs=cornersOf(ij[0],ij[1]),k=randi(0,3),a=cs[k],b=cs[(k+1)%4],t=RNG();
    const ex=b[0]-a[0],ez=b[1]-a[1],el=Math.hypot(ex,ez)||1,off=rand(-1,1);
    const x=a[0]+ex*t-ez/el*off,z=a[1]+ez*t+ex/el*off;
    if(Math.hypot(x-tp.x,z-tp.z)<minD)continue;
    addPickup(kind||'trash',x,z,{});return;
  }
}
for(let i=0;i<N;i++)for(let j=0;j<NZ;j++){
  if((i+j)%2||!WALKABLE.has(blocks[i*NZ+j].kind))continue;
  const x=R[i]+HALF_ROAD+.9,z=R[j]+HALF_ROAD+4.5;
  inst('bin',UNIT,PLAIN,x,.52,z,.8,1.05,.8,0,0x2f6b45);inst('binLid',UNIT,PLAIN,x,1.08,z,.86,.08,.86,0,0x1f4a30);
  inst('binMark',UNIT,UNLIT,x,.8,z-.41,.5,.07,.02,0,0x7dffa8);inst('binMark',UNIT,UNLIT,x+.41,.8,z,.02,.07,.5,0,0x7dffa8);
  addCollider(x-.4,x+.4,z-.4,z+.4,1.1);bins.push(new V3(x,0,z));
}
// mailboxes and cash machines on street corners
const pois=[];
for(let i=0;i<N;i++)for(let j=0;j<NZ;j++){
  const b=blocks[i*NZ+j];if(!WALKABLE.has(b.kind))continue;
  if(RNG()<.42){
    const x=b.bx1-.9,z=b.bz0+4.5;
    inst('mailBody',UNIT,PLAIN,x,.75,z,.6,1.05,.5,0,0xc0392b);inst('mailTop',cylG,PLAIN,x,1.28,z,.3,.5,.3,0,0xa82a20);
    inst('mailSlot',UNIT,UNLIT,x+.31,1.02,z,.02,.06,.32,0,0x1a0a08);inst('mailLeg',UNIT,PLAIN,x,.32,z,.18,.2,.18,0,0x2a2a2e);
    addCollider(x-.3,x+.3,z-.25,z+.25,1.5);pois.push({type:'mail',pos:new V3(x,0,z),at:new V3(x+1,0,z),cd:0});
  }
  const atmP=['city','midcity','apartments','park','harbor'].includes(b.kind)?.42:.2;
  if(RNG()<atmP){
    const x=b.bx1-.9,z=b.bz1-4.5;
    inst('atmBody',UNIT,PLAIN,x,1.17,z,.9,1.9,.8,0,0x3a4250);inst('atmTop',UNIT,UNLIT,x,2.2,z,1.05,.16,.95,0,0x2e86c1);
    inst('atmScr',UNIT,UNLIT,x+.46,1.55,z,.03,.38,.5,0,0x5fd0ff);inst('atmKey',UNIT,UNLIT,x+.48,1.12,z,.03,.18,.36,0,0x7dffa8);
    addCollider(x-.45,x+.45,z-.4,z+.4,2.1);pois.push({type:'atm',pos:new V3(x,0,z),at:new V3(x+1.1,0,z),cd:0});
  }
}
flushBatches();
let trashWarnT=0;
function collect(p){
  if(p.kind==='cash'){player.money+=p.amt;feed('+ $'+p.amt+' 주움');return true;}
  if(p.kind==='scrap'){const k=rollMat(LOOT.street);player.mats[k]++;feed('폐품 · '+MATS[k]+' +1');return true;}
  if(p.kind==='trash'){
    if(player.trash>=TRASH_MAX){if(trashWarnT<=0){trashWarnT=4;toast('쓰레기를 더 들 수 없다 · 쓰레기통에 버리세요');}return false;}
    player.trash++;feed('쓰레기 주움 '+player.trash+'/'+TRASH_MAX);return true;
  }
  const W=WEAPONS[p.weapon],A=player.ammo[p.weapon];
  if(!player.owned[p.weapon]){player.owned[p.weapon]=true;player.ammo[p.weapon]={mag:W.mag,mags:1};toast(W.name+' 획득');feed(W.name+' 획득');return true;}
  A.mags++;feed(W.name+' '+W.magName+' +1');return true;
}
function updatePickups(dt){
  trashWarnT-=dt;
  for(let i=pickups.length-1;i>=0;i--){
    const p=pickups[i];p.t+=dt;
    if(p.g.userData.spin){p.g.userData.spin.rotation.y+=dt*1.6;p.g.userData.spin.position.y=Math.sin(p.t*3)*.05;}
    if(p.t>p.life){removePickup(i);continue;}
    if(!started||dead||player.car||!player.grounded||d2(player.pos,p.pos)>1.25)continue;
    if(collect(p))removePickup(i);
  }
}
function dropLoot(p){
  if(p.dropped)return;p.dropped=true;
  if(p.weapon)addPickup('weapon',p.pos.x+rand(-.4,.4),p.pos.z+rand(-.4,.4),{weapon:p.weapon});
  if(p.wallet)addPickup('cash',p.pos.x+rand(-.5,.5),p.pos.z+rand(-.5,.5),{amt:p.wallet});
  let n=0;for(let i=pickups.length-1;i>=0;i--)if(!litter(pickups[i].kind)&&++n>30)removePickup(i);
}
function dumpTrash(){
  let amt=0;for(let i=0;i<player.trash;i++)amt+=randi(2,6);
  player.money+=amt;feed('쓰레기 '+player.trash+'개 버림 +$'+amt);toast('분리수거 완료 · +$'+amt);player.trash=0;
}
function nearestMark(){
  if(player.car||player.inside)return null;let best=null,bd=1.7;
  for(const p of peds){if(p.kind!=='civ'||p.room||p.role||p.out||p.dead||p.picked||p.state!=='walk')continue;const d=d2(p.pos,player.pos);if(d<bd){bd=d;best=p;}}
  return best;
}
function pickpocket(p){
  p.picked=true;
  if(RNG()<.5){const amt=randi(10,200);player.money+=amt;feed('소매치기 +$'+amt);toast('들키지 않았다 · +$'+amt);return;}
  p.wallet=randi(10,200);p.state='fight';p.fightT=0;p.fireT=rand(.3,.6);
  toast('들켰다! 쓰러뜨리면 지갑을 떨어뜨린다');crime(.5,p.pos,'소매치기');
}

// ---------- HUD helpers ----------
const starEls=[...$('stars').children];
let toastT=0;
function toast(msg){$('toast').textContent=msg;$('toast').style.opacity=1;toastT=2.4;}
function feed(msg){const d=document.createElement('div');d.textContent=msg;$('feed').prepend(d);setTimeout(()=>d.remove(),2700);while($('feed').children.length>4)$('feed').lastChild.remove();}
let flashT=0; function hurtFlash(){flashT=.35;}
function hitMarker(kill){hitT=.16;hitKill=!!kill;}

// ---------- wanted system ----------
const wanted={stars:0,heat:0,unseen:0,seen:false};
const TH=[0,1,12,32,60,100]; // heat needed per star: each extra star takes several serious crimes
const LOSE_TIME=20;
function setStars(n){
  const old=wanted.stars; n=clamp(n,0,5); wanted.stars=n; wanted.heat=Math.max(TH[n],Math.min(wanted.heat,n<5?TH[n+1]-.01:wanted.heat)); if(n===0)wanted.heat=0;
  if(n===5&&old<5) toast('공격 헬기 접근 중');
  else if(n>=4&&old<4) toast('군대가 투입됐다');
  else if(n>=3&&old<3) toast('특수부대 출동');
  else if(n===0&&old>0) toast('추격을 따돌렸다');
  else if(n>old&&old===0) toast('경찰이 출동했다');
}
// ramming a private car: half the time the other driver settles for $90 and city hall sends a tow, instead of reporting a hit-and-run
const SETTLE_FEE=90;
function crashCivil(o){
  const now=performance.now()/1000;
  if(o.accDec&&now-o.accDec.t<4){if(!o.accDec.settled)crime(.5,o.pos,null);return;} // same crash, already decided
  const settled=!o.isTaxi&&RNG()<.5;o.accDec={t:now,settled};
  if(!settled){crime(.5,o.pos,'뺑소니');return;}
  if(o.ai==='traffic'){o.ai='parked';o.crashed=true;}
  const paid=charge(SETTLE_FEE,'교통사고 합의금');
  toast('교통사고 · 상대 운전자와 합의했다 ($'+paid+') · 시청 견인차가 사고 차량을 치우러 온다');
  if(!(o.tow&&!o.tow.dead)&&o.ai==='parked'&&!o.dead)dispatchCityTow(o,true);
}
function crime(amount,where,label){
  wanted.heat+=amount; let s=0; for(let k=1;k<=5;k++) if(wanted.heat>=TH[k]) s=k;
  if(s>wanted.stars) setStars(s);
  wanted.unseen=0; if(label) feed('+ '+label);
  scare(where,26);
  for(const p of peds){
    if(p.dead||p.out||(p.state!=='idle'&&p.state!=='patrol')||d2(p.pos,where)>28)continue;
    if(p.kind!=='civ'){if(wanted.stars>0){p.state='chase';p.fireT=rand(.3,.8);}}
    else if(p.weapon&&p.role){p.state='fight';p.fightT=0;p.fireT=rand(.3,.6);}
  }
}
function scare(where,rad){
  for(const p of peds){
    if(p.kind!=='civ'||p.dead||p.out||p.ff||p.medic)continue;
    if(p.state==='down'||p.state==='fly'||p.state==='fight'||p.state==='cower'||p.state==='brawl'||p.state==='cuffed'||p.state==='escorted')continue;
    if(p.weapon&&p.role)continue;
    if(d2(p.pos,where)>=rad)continue;
    if(p.room){p.state='cower';p.fleeT=rand(10,14);}
    else{p.state='flee';p.fleeT=rand(5,8);p.threat.copy(where);}
  }
}
const unitInvalid=type=>type==='police'?wanted.stars===0:type==='swat'?wanted.stars<3:wanted.stars<4;

// ---------- damage ----------
let dead=false;
function damagePlayer(d,reason){
  if(dead) return;
  if(GOD){if(player.car)player.car.health-=d*.8;hurtFlash();return;}
  if(player.buffs.armor>0)d*=.75;
  if(player.car){player.car.health-=d*.8;player.health-=d*.3;}else player.health-=d;
  hurtFlash();
  if(player.health<=0){player.health=0;die(reason||'추격대에게 당했습니다.');}
}
function die(msg){
  MP.died();
  dead=true; closeMenu(); closePhone(); robbing=null;
  for(let i=pickups.length-1;i>=0;i--)if(!litter(pickups[i].kind))removePickup(i); // dropped guns and wallets vanish
  job=null;
  $('deadMsg').textContent=msg+' 최고 수배 단계 '+'★'.repeat(Math.max(1,wanted.stars))+'. 돈은 그대로 남아 있어요.';
  $('dead').hidden=false; try{document.exitPointerLock&&document.exitPointerLock();}catch(e){}
}
function respawn(){
  closeMenu(); robbing=null; job=null; player.surrender=null; player.ride=null;
  for(const pr of projs)scene.remove(pr.g);projs.length=0;
  for(const p of peds){
    if(p.role){
      if(p.out)p.dead=true;
      else{p.state='idle';p.pos.copy(p.home);p.yaw=p.homeYaw;p.hp=p.maxHp;p.stunT=0;p.fightT=0;}
    } else if(p.kind!=='civ'||p.room||p.state==='fight') p.dead=true;
  }
  for(const c of cars) if((c.type!=='civ'&&!c.fixed&&!c.owned)||c.ai==='wreck'||c.ai==='towed') c.dead=true;
  if(heli){scene.remove(heli.g);scene.remove(heli.cone);heli=null;}
  if(player.car){player.car.ai='parked';player.car.hasDriver=false;player.car=null;}
  const H=nearestLoc('hospital').L; // wake up in the hospital nearest to where you fell
  populateRoom(H); player.inside=H;
  player.pos.copy(H.room.wake); player.health=100; player.vy=0; camYaw=Math.PI/2; camPitch=-.12; player.yaw=camYaw;
  if(player.jailed)freeFromJail();
  player.reloadT=0;player.crouch=false;player.hunger=Math.max(player.hunger,70);player.hungerWarn=0;
  const A=player.ammo.pistol; if(A.mag===0&&A.mags===0)A.mags=1;
  wanted.stars=0;wanted.heat=0;wanted.unseen=0; dead=false; $('dead').hidden=true; camSnap=true; canvas.focus();
  toast('병원에서 깨어났다');
}

function knock(p,vx,vy,vz){
  p.state='fly';p.vel.set(vx,vy,vz);p.spin=rand(5,10)*(RNG()<.5?1:-1);p.stunT=0;
  p.downT=p.out?30:rand(2.5,4);
}
const guardOff=p=>p.role==='gate'?wanted.stars===0:unitInvalid(UNIT_OF[p.kind]);
function provoke(p){
  if(p.kind==='civ'){
    if(p.state==='fight')return;
    const brave=p.weapon||p.ff||(!p.role&&RNG()<.45);
    if(brave){p.state='fight';p.fightT=0;p.fireT=rand(.25,.6);}
    else if(p.room){p.state='cower';p.fleeT=rand(10,14);}
    else{p.state='flee';p.fleeT=rand(5,8);p.threat.copy(actualPos());}
  } else if(p.state!=='chase'&&(p.role==='gate'||!unitInvalid(UNIT_OF[p.kind]))){p.state='chase';p.fireT=rand(.3,.8);}
}
function playerHurtsPed(p,dmg,dir,how){
  if(p.dead||p.out||p.state==='fly'||p.state==='down')return false;
  p.hp-=dmg; const killed=p.hp<=0, C=CRIME[p.kind];
  if(p.crim&&p.kind==='civ'){if(killed)feed('수배자를 제압했다');} // stopping a wanted criminal is not a crime
  else if(p.aggro&&p.kind==='civ'){if(!p.sdNote){p.sdNote=true;feed('정당방위 · 먼저 공격한 상대');}if(killed)feed('정당방위로 제압했다');}
  else crime(C.base*(killed?2.5:1)+(how==='gun'?.5:0),p.pos,C[how]);
  if(killed){p.out=true;knock(p,dir.x*(how==='gun'?3:4.5),2.6,dir.z*(how==='gun'?3:4.5));return 'kill';}
  p.stunT=how==='fist'?.42:.3;
  p.pos.x+=dir.x*.25;p.pos.z+=dir.z*.25;collideCircle(p.pos,.35);
  provoke(p);
  return 'hit';
}
function getUp(p){
  if(p.provokeOnUp){p.provokeOnUp=false;p.state='walk';provoke(p);if(p.state==='walk')calm(p);return;}
  if(p.ff){calm(p);return;}
  if(p.medic){p.state='medic';return;}
  if(p.foe&&!p.foe.dead&&!p.foe.out&&(p.crim||isLaw(p))){p.state=isLaw(p)?'arrest':'brawl';return;}
  if(p.role==='gate'){if(wanted.stars>0)p.state='chase';else calm(p);return;}
  if(p.kind==='civ'){
    if(p.role){p.state='idle';return;}
    if(p.room){p.state='leave';p.lifeT=0;return;}
    p.state='flee';p.fleeT=rand(5,8);p.threat.copy(actualPos());
  } else if(unitInvalid(UNIT_OF[p.kind]))calm(p);
  else p.state='chase';
}
function calm(p){
  p.fightT=0;
  if(p.ff){const t=p.truck;p.state=t&&!t.dead&&t.ai==='fireWait'?'firefight':'leave';p.lifeT=0;return;}
  if(p.medic){p.state='medReturn';return;}
  p.foe=null;
  if(p.car2&&isLaw(p)){p.state='copReturn';return;}
  if(p.role){p.state='idle';if(p.room!==playerSpace()){p.pos.copy(p.home);p.yaw=p.homeYaw;}return;}
  if(p.room||p.kind!=='civ'){p.state='leave';p.lifeT=0;return;}
  setWalk(p);
}
function explode(c){
  c.ai='wreck';c.speed=0;c.hasDriver=false;c.wreckT=16;
  c.mesh.traverse(o=>{if(o.isMesh)o.material=wreckMat;});
  const at=c.pos.clone();at.y=1.2;
  puff(at,0xffa040,1.2,new V3(),.55,true); puff(at,0xff5a20,.8,new V3(0,2,0),.7,true);
  for(let i=0;i<10;i++) puff(at,0x333038,rand(1,1.8),new V3(rand(-3,3),rand(2,5),rand(-3,3)),rand(1.2,2.2));
  shake=Math.max(shake,.9); scare(at,40);
  for(const p of peds){if(p.dead||p.state==='fly')continue;const d=d2(p.pos,at);if(d<8){const dx=(p.pos.x-at.x)/(d||1),dz=(p.pos.z-at.z)/(d||1);p.hp-=90*(1-d/8);if(p.hp<=0)p.out=true;knock(p,dx*10,7,dz*10);}}
  for(const o of cars){if(o!==c&&o.ai!=='wreck'&&d2(o.pos,at)<6)o.health-=60;}
  if(player.car===c){exitCar(true);damagePlayer(32,'타고 있던 차가 폭발했습니다.');}
  else if(!player.car&&!player.inside){const d=d2(player.pos,at);if(d<8)damagePlayer(45*(1-d/8),'폭발에 휘말렸습니다.');}
  if(c.pos.x<ROOM_X)addFire(c.pos.x,c.pos.z,2.6,38,false);
}

// ---------- units ----------
const CREW_KIND={police:'cop',swat:'swat',army:'soldier'};
// every pursuing unit rolls out from the lanes in front of the police station
const STATION_SLOTS=[[3.5,0],[-3.5,0],[-3.5,-7],[-3.5,7],[3.5,-6],[3.5,6]];
function nearestStation(){
  const tp=playerPos();let best=POLICE,bd=1e9;
  for(const L of LOCS)if(L.type==='police'){const d=d2(L.door,tp);if(d<bd){bd=d;best=L;}}
  return best;
}
function stationSpawn(){
  const S=nearestStation(),sp=rampSpawn(S);
  if(sp)return sp;
  for(const [dx,dz] of STATION_SLOTS){
    const x=S.roadX+dx,z=S.cz+dz;
    if(!cars.some(c=>!c.dead&&Math.hypot(c.pos.x-x,c.pos.z-z)<4.5))return {x,z};
  }
  return null;
}
// ---------- underground car parks ----------
const freeAt=(x,z,r)=>!cars.some(c=>!c.dead&&Math.hypot(c.pos.x-x,c.pos.z-z)<(r||4.5));
// a fresh vehicle rolls up out of the ramp, or failing that waits at the kerb in front of it
function rampSpawn(L){
  const R_=L&&L.ramp;if(!R_)return null;
  if(freeAt(R_.in.x,R_.in.z,5))return {x:R_.in.x,z:R_.in.z,h:R_.out,ramp:R_};
  for(const dz of [-7,7,-14,14]){const x=R_.mouth.x,z=R_.mouth.z+dz;if(freeAt(x,z))return {x,z,h:L.spawnSpot.h};}
  return null;
}
function placeFromRamp(c,sp){if(sp.ramp){c.rampOut=sp.ramp;c.rampT=0;}return c;}
// first seconds of a ramp spawn: drive straight up onto the street
function rampOutDrive(c,dt){
  const m=c.rampOut.mouth;c.rampT+=dt;
  if(d2(c.pos,m)<3.5||c.rampT>8){c.rampOut=null;return false;}
  smartDrive(c,m,dt,5,{});return true;
}
// heading home into the ramp; true while it is handling the car
function rampIn(c,L,dt){
  const R_=L&&L.ramp;if(!R_)return false;
  if(!c.inRamp){
    const dm=d2(c.pos,R_.mouth);
    if(dm<5){c.inRamp=true;c.rampT=0;}
    else if(dm<30&&drivable(c.pos,R_.mouth,1.2)){smartDrive(c,R_.mouth,dt,6,{});return true;}
    else return false;
  }
  c.rampT+=dt;
  if(d2(c.pos,R_.in)<3.4||c.rampT>12){c.dead=true;goneHome(c,L);return true;}
  smartDrive(c,R_.in,dt,4,{});return true;
}
// what happens once a vehicle has gone down the ramp
const hospRelease=[];
function goneHome(c,L){
  if(c.type==='amb'&&c.loaded&&c.loaded.length){
    let H=L&&L.type==='hospital'?L:null;
    if(!H){let bd=1e9;for(const Q of LOCS)if(Q.type==='hospital'){const d=d2(Q.door,c.pos);if(d<bd){bd=d;H=Q;}}}
    if(H)hospRelease.push({H,looks:c.loaded.slice(),t:rand(4,8)});c.loaded=null;
  }
  if(c.type==='tow')towArrive(c);
}
// patients patched up at the hospital walk back out of the front door
function updateHospRelease(dt){
  for(let k=hospRelease.length-1;k>=0;k--){
    const r=hospRelease[k];r.t-=dt;if(r.t>0)continue;
    const H=r.H,lk=r.looks.shift();
    if(lk){
      const x=H.door.x+H.out.x*1.2,z=H.door.z+rand(-1,1),p=makePed('civ',x,z,{look:lk,weapon:null});
      const i=clamp(Math.floor((H.door.x-H.out.x*4-R[0])/CELL),0,N-1),j=clamp(Math.floor((H.door.z-R[0])/CELL),0,NZ-1),cs=cornersOf(i,j);
      let bk=0,bd=1e9;cs.forEach((q,n)=>{const d=Math.hypot(q[0]-x,q[1]-z);if(d<bd){bd=d;bk=n;}});
      p.corners=cs;p.ci=bk;p.dirc=RNG()<.5?1:-1;p.state='walk';p.yaw=Math.atan2(H.out.x,0);p.healed=true;
      if(d2(H.door,actualPos())<90)feed('퇴원한 시민이 '+(H.title||'병원')+'을 나선다');
    }
    if(r.looks.length)r.t=rand(1.5,3);else hospRelease.splice(k,1);
  }
}
// ---------- the Harbor Crew ----------
const GANG_LOOK={shirt:0x141414,pants:0x202028,hat:0xb3202a};
const RAID_TYPES={conv:1,diner:1,gun:1,bank:1,junk:1,garage:1,hotel:1,realty:1,gas:1};
function gangPed(x,z,state){const p=makePed('civ',x,z,{weapon:RNG()<.3?'shotgun':'pistol',look:GANG_LOOK,hpMul:1.3});p.gang=true;p.role='gang';p.state=state;p.lifeT=0;return p;}
function updateGang(dt){
  const G=GANG;if(!G)return;
  const tp=actualPos(),near=Math.hypot((G.x0+G.x1)/2-tp.x,G.cz-tp.z)<170,inside=!player.inside&&tp.x>G.x0&&tp.x<G.x1&&tp.z>G.z0&&tp.z<G.z1;
  // guards at the gate and the warehouse door: they open fire on anyone who walks into the yard
  for(const S of G.guards){
    if(S.p&&(S.p.dead||S.p.out))S.p=null;
    if(!S.p&&near&&d2(S,tp)>30){S.p=gangPed(S.x,S.z,'idle');S.p.home=new V3(S.x,0,S.z);S.p.homeYaw=Math.PI/2;}
    else if(S.p&&!near&&S.p.state==='idle'&&d2(S,tp)>240){S.p.dead=true;S.p=null;}
    if(S.p&&inside&&S.p.state==='idle'&&hasLOS(S.p.pos,tp)){provoke(S.p);if(!G.warned){G.warned=true;toast('하버 갱단 구역이다! 갱단원들이 총을 꺼낸다');}}
  }
  if(!inside)G.warned=false;
  // every few minutes a black van goes out to hold up a building somewhere in the city
  if(G.van&&(G.van.dead||!/^gang/.test(G.van.ai)))G.van=null;
  if(!G.van){G.raidT-=dt;if(G.raidT<=0){G.raidT=rand(90,240);launchRaid();}}
}
function launchRaid(){
  const G=GANG,tp=actualPos();
  const list=LOCS.filter(L=>RAID_TYPES[L.type]&&L.robCD<=0&&L.door&&Math.hypot(L.door.x,L.door.z)<560);
  if(!list.length||freeAt(G.gate.x,G.gate.z,6)===false)return false;
  // a target the player is likely to hear about, but anywhere on the island
  const T=RNG()<.6?list.sort((a,b)=>d2(a.door,tp)-d2(b.door,tp))[randi(0,Math.min(5,list.length-1))]:pick(list);
  const c=makeCar('gang',G.gate.x,G.gate.z,Math.PI,'gangRun');c.target=T;c.crew=randi(5,6);c.lifeT=0;c.speed=3;c.hasDriver=true;
  const n=nearNode(T.door);c.field=n?nodeField(n[0],n[1]):null;G.van=c;
  if(d2(G.gate,tp)<250)feed('하버 갱단 승합차가 본거지를 나섰다');
  return c;
}
function gangVanAI(c,dt){
  c.lifeT+=dt;const T=c.target,G=GANG;
  if(c.ai==='gangRun'){
    const stop=T.noDoor?{x:R[nearestIdx(T.door.x+T.out.x*30)]-T.out.x*LANE,z:T.door.z}:{x:T.door.x+T.out.x*9,z:T.door.z+T.out.z*9},d=d2(c.pos,stop); // yards: pull up on the street outside the gate
    if(c.lifeT>200){c.ai='gangBack';c.lifeT=0;return;}
    if(d<7){driveCar(c,c.speed>1?-1:0,0,true,dt);
      if(Math.abs(c.speed)<1.5){c.ai='gangWait';c.lifeT=0;c.hasDriver=false;
        const f=fwdOf(c),r={x:-f.z,z:f.x};
        for(let k=0;k<c.crew;k++){const sd=k%2?1:-1,row=(k>>1)*1.1-c.half*.4,p=gangPed(c.pos.x+r.x*sd*(c.w/2+.9)-f.x*row,c.pos.z+r.z*sd*(c.w/2+.9)-f.z*row,'raid');p.car2=c;p.raidLoc=T;collideCircle(p.pos,.35);}
        T.robCD=240;scare(T.door,30);if(RNG()<.5)c.arsonT=rand(5,10);
        if(d2(T.door,actualPos())<300)toast('하버 갱단이 '+(T.title||T.name)+'을 습격했다!');feed('갱단 습격 · '+(T.title||T.name));}
      return;}
    const direct=d<40&&drivable(c.pos,stop,1.2);
    smartDrive(c,direct?stop:routeTarget(c.pos,c.field,stop),dt,direct?8:15,{lane:!direct});
  } else if(c.ai==='gangWait'){
    driveCar(c,0,0,true,dt);
    if(c.arsonT!=null){c.arsonT-=dt;if(c.arsonT<=0){c.arsonT=null;
      const o=T.out||{x:1,z:0},W=T.T&&T.T.d?T.T.d:10,H=T.T&&T.T.h?T.T.h:6,f=fireAtWall(T.door.x+o.x*(T.noDoor?0:1.4),T.door.z+o.z*(T.noDoor?0:1.4),o.x,o.z,W,H,rand(160,230));
      if(f){f.arson=true;const crew=peds.filter(p=>p.car2===c&&!p.dead&&!p.out);const thrower=crew[0];if(thrower)thrower.yaw=Math.atan2(f.pos.x-thrower.pos.x,f.pos.z-thrower.pos.z);
        if(d2(f.pos,actualPos())<350)toast('하버 갱단이 '+(T.title||T.name)+'에 불을 질렀다!');feed('방화 · '+(T.title||T.name));}}}
    c.chk=(c.chk||0)-dt;if(c.chk>0)return;c.chk=.5;
    const crew=peds.filter(p=>p.car2===c&&!p.dead&&!p.out&&p.gang);
    const back=crew.filter(p=>p.state==='raidBack'||p.state==='raid'||p.state==='raidHold');
    if(!crew.length||(back.length===0&&c.lifeT>8)||c.lifeT>70){
      for(const p of crew)if(p.state==='raidBack'||p.state==='raidHold'){p.dead=true;}
      c.ai='gangBack';c.lifeT=0;c.hasDriver=true;c.field=null;}
  } else {
    const g=G.gate,d=d2(c.pos,g);
    if(!c.field){const n=nearNode(g);c.field=n?nodeField(n[0],n[1]):null;}
    if(d<9||c.lifeT>240&&d2(c.pos,actualPos())>200){c.dead=true;return;}
    const direct=d<40&&drivable(c.pos,g,1.2);
    smartDrive(c,direct?g:routeTarget(c.pos,c.field,g),dt,direct?8:15,{lane:!direct});
  }
}
// raiders: run to the door, hold it at gunpoint while the till is emptied, run back to the van
function raidMove(p,dt){
  const c=p.car2,L=p.raidLoc;p.lifeT+=dt;
  if(!c||c.dead||!L){p.state='fight';return [0,0,0];}
  if(p.state==='raid'){
    const t={x:L.door.x+L.out.x*1.6+rand(-.05,.05),z:L.door.z+L.out.z*1.6},dx=t.x-p.pos.x,dz=t.z-p.pos.z,d=Math.hypot(dx,dz)||1;
    if(d<1.2||p.lifeT>25){p.state='raidHold';p.holdT=rand(9,13);flagCriminal(p,'무장 강도');witnessCalls.push({q:p,t:rand(1,3)});return null;}
    p.yaw=Math.atan2(dx,dz);return [dx/d,dz/d,4];
  }
  if(p.state==='raidHold'){
    p.yaw=Math.atan2(L.out.x,L.out.z);p.holdT-=dt;
    if(p.holdT<=0){p.state='raidBack';if(RNG()<.5)scare(p.pos,25);}
    return null;
  }
  const dx=c.pos.x-p.pos.x,dz=c.pos.z-p.pos.z,d=Math.hypot(dx,dz)||1;
  if(d<c.half+1.3){p.dead=true;return null;}
  p.yaw=Math.atan2(dx,dz);return [dx/d,dz/d,4.4];
}
// ---------- pedestrians step round mailboxes, cash machines, bus shelters and each other ----------
const AVOID_ST={walk:1,cross:1,board:1,leave:1,medic:1,medReturn:1,firefight:1,ffReturn:1,patrol:1,arrest:1,copReturn:1,chase:1,raid:1,raidBack:1};
const AVOID_LAW={patrol:1,arrest:1,copReturn:1,chase:1};
function blockedAt(p,x,z){
  for(const gx of [Math.floor((x-.5)/2),Math.floor((x+.5)/2)])for(const gz of [Math.floor((z-.5)/2),Math.floor((z+.5)/2)]){const L=SIG_POLES.get(gx+','+gz);if(L)for(const q of L)if(Math.abs(q[0]-x)<.5&&Math.abs(q[1]-z)<.5)return true;}
  if(forColliders(x-.45,z-.45,x+.45,z+.45,b=>x>b.x0-.4&&x<b.x1+.4&&z>b.z0-.4&&z<b.z1+.4))return true;
  for(const o of peds){if(o===p||o.dead||o.room||o.out||o.state==='fly'||o.state==='down'||o===p.task||o===p.target||o===p.q)continue;const dx=o.pos.x-x,dz=o.pos.z-z;if(dx*dx+dz*dz<.6)return true;}
  if(!player.car&&!player.inside&&p.task!=='player'&&p.kind==='civ'&&p.state!=='fight'&&p.state!=='brawl'){const dx=player.pos.x-x,dz=player.pos.z-z;if(dx*dx+dz*dz<.6)return true;}
  return false;
}
function avoidDir(p,mx,mz,dt){
  p.avT=(p.avT||0)-dt;
  if(p.avT<=0){p.avT=.22;p.avA=0;const L=1.15;
    if(blockedAt(p,p.pos.x+mx*L,p.pos.z+mz*L)){
      const sd=p.avSide||(RNG()<.5?1:-1);
      for(const a of [.55,1.0,1.45,-.55,-1.0,-1.45]){const t=a*sd,c=Math.cos(t),sn=Math.sin(t),dx=mx*c-mz*sn,dz=mx*sn+mz*c;
        if(!blockedAt(p,p.pos.x+dx*L,p.pos.z+dz*L)){p.avA=t;p.avSide=Math.sign(t);break;}}
    } else p.avSide=0;
  }
  if(!p.avA)return [mx,mz];
  const c=Math.cos(p.avA),sn=Math.sin(p.avA);return [mx*c-mz*sn,mx*sn+mz*c];
}
// ---------- pedestrians use the crossings at the corners ----------
function tryCross(p){
  if(RNG()>.55)return false;
  const t=p.corners[p.ci],i=Math.floor((t[0]-R[0])/CELL),j=Math.floor((t[1]-R[0])/CELL);if(i<0||j<0||i>=N||j>=NZ)return false;
  const ok=(a,b)=>a>=0&&b>=0&&a<N&&b<NZ&&WALKABLE.has(blocks[a*NZ+b].kind)&&!blocks[a*NZ+b].closed,o=[];
  {const north=t[1]<(R[j]+R[j+1])/2,rz=north?j:j+1,nj=north?j-1:j+1;
    if(ok(i,nj)&&segAt(true,rz,t[0])&&(rz!==IND_J||indGate(t[0])))o.push({to:[t[0],2*R[rz]-t[1]],ni:i,nj,axis:'ew',node:sigKey(gridIdx(t[0]),rz)});}
  {const west=t[0]<(R[i]+R[i+1])/2,cx=west?i:i+1,ni=west?i-1:i+1;
    if(ok(ni,j)&&segAt(false,cx,t[1]))o.push({to:[2*R[cx]-t[0],t[1]],ni,nj:j,axis:'ns',node:sigKey(cx,gridIdxZ(t[1]))});}
  if(!o.length)return false;
  p.xing=pick(o);p.xing.from=[t[0],t[1]];p.xing.t=0;p.state='crossWait';
  if(RNG()<.12){const X=p.xing;X.jay=true;p.state='cross';
    if(X.axis==='ew'){const dir=Math.sign((R[i]+R[i+1])/2-t[0])||1;X.to=[X.to[0]+dir*rand(8,15),X.to[1]];}
    else{const dir=Math.sign((R[j]+R[j+1])/2-t[1])||1;X.to=[X.to[0],X.to[1]+dir*rand(8,15)];}}
  return true;
}
function crossMove(p,dt){
  const X=p.xing;if(!X){p.state='walk';return [0,0,0];}
  X.t+=dt;
  if(p.state==='crossWait'){
    const dx=X.to[0]-X.from[0],dz=X.to[1]-X.from[1];p.yaw=Math.atan2(dx,dz);
    let go;
    if(sigOn&&SIG.has(X.node))go=sigWalk(X.axis);
    else{const mx=(X.from[0]+X.to[0])/2,mz=(X.from[1]+X.to[1])/2;go=!cars.some(c=>!c.dead&&Math.abs(c.speed)>2&&Math.abs(c.pos.x-mx)<20&&Math.abs(c.pos.z-mz)<20)&&!(player.car&&Math.abs(player.car.speed)>2&&d2(player.car.pos,{x:mx,z:mz})<22);}
    if(go){p.state='cross';X.t=0;}
    else if(X.t>40){p.state='walk';p.xing=null;p.ci=(p.ci+p.dirc+4)%4;}
    return null;
  }
  const dx=X.to[0]-p.pos.x,dz=X.to[1]-p.pos.z,d=Math.hypot(dx,dz)||1;
  if(d<.45||X.t>25){const cs=cornersOf(X.ni,X.nj);let bk=0,bd=1e9;cs.forEach((q,n)=>{const e=Math.hypot(q[0]-p.pos.x,q[1]-p.pos.z);if(e<bd){bd=e;bk=n;}});
    p.corners=cs;p.ci=(bk+p.dirc+4)%4;p.state='walk';p.xing=null;return [0,0,0];}
  return [dx/d,dz/d,1.9];
}
// ---------- traffic police: hand out $10 fines for running a red light ----------
let rlNode=null,rlCD=0,tpT=0;
function updateTraffic(dt){
  updateSignals(dt);
  tpT-=dt;if(tpT<=0){tpT=1;const tp=actualPos();
    for(const P of TRAFFIC_POSTS){
      const d=Math.hypot(P.x-tp.x,P.z-tp.z);
      if(P.p&&(P.p.dead||P.p.out)){P.p=null;}
      if(!P.p&&d<170&&d>35&&!player.inside){P.p=makePed('cop',P.x,P.z,{weapon:'pistol',state:'idle',role:'traffic',yaw:Math.atan2(R[P.i]-P.x,R[P.j]-P.z),look:{vest:0xd8ff3a,hat:0xf4f4f4}});}
      else if(P.p&&d>260&&P.p.state==='idle'){P.p.dead=true;P.p=null;}
    }}
  if(rlCD>0)rlCD-=dt;
  const c=player.car;
  if(!c||isBoat(c)||c.type==='pheli'||!sigOn){rlNode=null;return;}
  const i=gridIdx(c.pos.x),j=gridIdxZ(c.pos.z),k=Math.abs(c.pos.x-R[i])<HALF_ROAD&&Math.abs(c.pos.z-R[j])<HALF_ROAD?sigKey(i,j):null;
  if(k!==null&&k!==rlNode&&SIG.has(k)&&Math.abs(c.speed)>3){
    const f=fwdOf(c);
    if(sigState(Math.abs(f.x)>Math.abs(f.z)?'ew':'ns')==='r'&&rlCD<=0){
      const cop=TRAFFIC_POSTS.find(P=>P.p&&!P.p.dead&&P.p.state==='idle'&&d2(P.p.pos,c.pos)<60&&hasLOS(P.p.pos,c.pos));
      if(cop){rlCD=4;const paid=charge(10,'신호 위반 벌금');toast('신호 위반 적발! 교통경찰이 벌금 $'+paid+'을 부과했다');}
    }
  }
  rlNode=k;
}
// ---------- buses ----------
// a walker who belongs to the block around (x,z) and strolls its pavement loop
function walkerAt(x,z,look,state){
  const p=makePed('civ',x,z,look?{look,weapon:null}:{weapon:null});
  const i=clamp(Math.floor((x-R[0])/CELL),0,N-1),j=clamp(Math.floor((z-R[0])/CELL),0,NZ-1),cs=cornersOf(i,j);
  let bk=0,bd=1e9;cs.forEach((q,n)=>{const d=Math.hypot(q[0]-x,q[1]-z);if(d<bd){bd=d;bk=n;}});
  p.corners=cs;p.ci=bk;p.dirc=RNG()<.5?1:-1;p.state=state||'walk';return p;
}
function makeBus(R_,S,atStop){
  const p=atStop?S.ap:DEPOT;if(!p)return null;
  const c=makeCar('bus',p.x,p.z,atStop?S.h:DEPOT.h,'bus',{color:R_.color,model:R_.air?'air':'city'});
  c.route=R_;c.si=R_.stops.indexOf(S);c.dwell=atStop?rand(1,4):0;c.best=1e9;c.progT=0;c.lifeT=0;c.speed=0;c.served=false;
  return c;
}
function busDrive(c,dt){
  const R_=c.route,S=R_.stops[c.si];if(!S){c.ai='leave';return;}
  c.lifeT+=dt;
  if(c.dwell>0||c.dwelling){
    // dwelling at the stop: wait out the timer, then up to 6 s more for anyone still climbing aboard
    c.dwelling=true;driveCar(c,c.speed>.5?-1:0,0,true,dt);
    if(!c.served){c.served=true;serveStop(c,S);}
    c.dwell-=dt;
    if(c.dwell>0)return;
    if(c.dwell>-6&&peds.some(p=>p.state==='board'&&p.bus===c&&!p.dead))return;
    c.dwell=0;c.dwelling=false;c.si=(c.si+1)%R_.stops.length;c.served=false;c.best=1e9;c.progT=0;
    for(const p of peds)if(p.state==='board'&&p.bus===c){p.state='waitBus';p.bus=null;}
    return;
  }
  const d=d2(c.pos,S.ap);
  if(d<4.5&&Math.abs(c.speed)<5){c.dwell=S.dwell||rand(4,6);c.leg='exit';c.exitPt=S.dn||null;return;}
  if(d<c.best-1){c.best=d;c.progT=0;c.unT=0;}else c.progT+=dt;
  // wedged: back off at an angle and try again; stuck where nobody can see, the dispatcher quietly moves it on
  if(c.progT>12&&!(c.unT>0)&&!(c.revT>0)){c.unT=8;c.revT=2.4;const des=Math.atan2(S.ap.x-c.pos.x,S.ap.z-c.pos.z);c.revSteer=angDiff(c.heading,des)>0?-1:1;}
  if(c.unT>0)c.unT-=dt;
  const tp=playerPos(),dp=d2(c.pos,tp);
  if(c.progT>30&&(dp>110||(dp>40&&!hasLOS(c.pos,tp)))&&(d2(S.ap,tp)>90||!hasLOS(S.ap,tp))){c.pos.set(S.ap.x,0,S.ap.z);c.heading=c.vis=S.h;c.speed=0;c.progT=0;c.best=1e9;return;}
  stopNodes(S);
  if(!S.up){ // the airport forecourt: drive straight in once on the island
    if(!S.air&&!S.field){const n=nearNode(S.ap);S.field=n?nodeField(n[0],n[1]):null;}
    const air=onAirSide(c.pos)&&onAirSide(S.ap),direct=d<50&&(air||(!onAirSide(c.pos)&&drivable(c.pos,S.ap,1.4)));
    smartDrive(c,direct?S.ap:routeTarget(c.pos,S.field,S.ap),dt,direct?8:13,{lane:!direct,stopAt:direct?.5:null});return;
  }
  // leaving a stop: carry on down the same lane to the next junction instead of turning round
  if(c.leg==='exit'){const E=c.exitPt;if(!E||d2(c.pos,E)<10||c.progT>20)c.leg=null;else{smartDrive(c,E,dt,10,{lane:true});return;}}
  // on the stop's own lane, short of the stop: roll up to the kerb; otherwise route to the junction the lane starts from
  const rx=c.pos.x-S.ap.x,rz=c.pos.z-S.ap.z,along=rx*S.dir.x+rz*S.dir.z,lat=Math.abs(rx*S.dir.z-rz*S.dir.x);
  const fw=fwdOf(c),aligned=fw.x*S.dir.x+fw.z*S.dir.z>.5;
  if(lat<3.2&&along<1&&along>-CELL&&aligned){smartDrive(c,S.ap,dt,Math.max(3,Math.min(12,-along*.7+3)),{lane:true,stopAt:.5});return;}
  if(d2(c.pos,S.up)<15){smartDrive(c,{x:S.ap.x-S.dir.x*6,z:S.ap.z-S.dir.z*6},dt,7,{lane:true});return;}
  smartDrive(c,routeTarget(c.pos,S.field,S.up),dt,13,{lane:true});
}
// the junctions at either end of a stop's lane: buses arrive from `up`, leave toward `dn`
function stopNodes(S){
  if(S.up!==undefined)return;
  if(S.air||S.i==null||S.o==null){S.up=null;S.dn=null;return;}
  const {o,i,j,side}=S;let up,dn;
  if(o==='h'){up=side>0?[i,j]:[i+1,j];dn=side>0?[i+1,j]:[i,j];}
  else{up=side>0?[i,j+1]:[i,j];dn=side>0?[i,j]:[i,j+1];}
  S.up={x:R[up[0]],z:R[up[1]]};S.dn={x:R[dn[0]],z:R[dn[1]]};S.field=nodeField(up[0],up[1]);
  S.dir=o==='h'?{x:side,z:0}:{x:0,z:-side};
}
// at a stop: a passenger or two steps off, the people waiting walk to the door
function serveStop(c,S){
  if(d2(S.ap,actualPos())>140)return;
  const off=S.air?randi(1,3):randi(0,2);
  for(let k=0;k<off;k++){const p=walkerAt(S.sh.x+rand(-1.5,1.5),S.sh.z+rand(-.5,.5));p.yaw=rand(0,6.28);}
  for(const p of peds)if(p.state==='waitBus'&&p.stop===S&&!p.dead){p.state='board';p.bus=c;}
  if(d2(S.ap,actualPos())<60)feed((c.route.air?'공항버스':'버스 '+c.route.id+'번')+' · '+S.name+' 정류장');
}
function busPedMove(p,dt){
  p.lifeT=(p.lifeT||0)+dt;
  if(p.state==='waitBus'){
    const S=p.stop;if(!S||p.lifeT>150){p.state='walk';return [0,0,0];}
    p.yaw=Math.atan2(S.ap.x-p.pos.x,S.ap.z-p.pos.z);return null;
  }
  const c=p.bus;
  if(!c||c.dead||c.ai!=='bus'||c.dwell===0&&d2(c.pos,p.pos)>12){p.state='waitBus';p.bus=null;return null;}
  const f=fwdOf(c),r={x:f.z,z:-f.x},side=d2({x:c.pos.x+r.x,z:c.pos.z+r.z},p.pos)<d2({x:c.pos.x-r.x,z:c.pos.z-r.z},p.pos)?1:-1;
  const door={x:c.pos.x+f.x*(c.half-1.4)+r.x*side*(c.w/2+.5),z:c.pos.z+f.z*(c.half-1.4)+r.z*side*(c.w/2+.5)};
  const dx=door.x-p.pos.x,dz=door.z-p.pos.z,d=Math.hypot(dx,dz)||1;
  if(d<.8){p.dead=true;return null;}
  p.yaw=Math.atan2(dx,dz);return [dx/d,dz/d,2.6];
}
// riding the bus: $1, sit tight, press E at any stop to get off
const BUS_FARE=1;
function boardBus(c){
  if(player.money<BUS_FARE){toast('버스비 $'+BUS_FARE+'이 없다');return;}
  player.money-=BUS_FARE;feed((c.route.air?'공항버스':'버스 '+c.route.id+'번')+' 승차 −$'+BUS_FARE);
  player.ride={bus:c};player.crouch=false;job=null;player.surrender=null;camSnap=true;
  toast('버스에 탔다 · 정류장에 서면 E로 내리기');
}
function busRide(dt){
  if(player.ride.taxi){taxiRide(dt);return;}
  const c=player.ride.bus;
  if(c.dead||c.ai!=='bus'){ // the bus was wrecked or taken: tumble out of the door
    const f=fwdOf(c);player.ride=null;player.pos.set(c.pos.x+f.z*(c.w/2+1.2),0,c.pos.z-f.x*(c.w/2+1.2));collideCircle(player.pos,.35);player.vy=0;camSnap=true;toast('버스에서 내렸다');return;}
  player.pos.set(c.pos.x,c.pos.y+1.2,c.pos.z);player.vy=0;player.yaw=c.heading;
  if((input.e||input.f)&&(c.dwell>0||c.dwelling)){
    const S=c.route.stops[c.si];const at=S&&d2(S.sh,c.pos)<16?S.sh:null,f=fwdOf(c);
    player.ride=null;input.e=false;input.f=false;
    if(at)player.pos.set(at.x,0,at.z);else player.pos.set(c.pos.x+f.z*(c.w/2+1.2),0,c.pos.z-f.x*(c.w/2+1.2));
    collideCircle(player.pos,.35);player.pos.y=floorH(player.pos.x,player.pos.z);camYaw=c.heading;player.yaw=camYaw;camSnap=true;
    toast((S?S.name+' 정류장':'정류장')+'에서 내렸다');
  }
}
let busT=0;
function updateBuses(dt){
  busT-=dt;if(busT>0)return;busT=2;
  const tp=actualPos();
  for(const R_ of BUS_ROUTES){
    const n=cars.filter(c=>!c.dead&&c.ai==='bus'&&c.route===R_).length;
    if(n<R_.n&&DEPOT&&!cars.some(c=>!c.dead&&Math.hypot(c.pos.x-DEPOT.x,c.pos.z-DEPOT.z)<8)){
      const c=makeBus(R_,R_.stops[0],false);if(c)c.si=R_.air?1:0;
    }
  }
  // people turn up at the stops near the player
  for(const S of BUS_STOPS){
    if(S.depot)continue;
    const d=d2(S.sh,tp);if(d>130||d<14)continue;
    const n=peds.filter(p=>p.stop===S&&(p.state==='waitBus'||p.state==='board')&&!p.dead).length;
    if(n<(S.air?4:3)&&RNG()<.35){const p=walkerAt(S.sh.x+rand(-2,2),S.sh.z+rand(-.4,.4),null,'waitBus');p.stop=S;p.lifeT=0;}
  }
}
// ---------- taxi: phone for one, get in with E, it drives you to the place marked on the map ----------
const TAXI={c:null},TAXI_BASE=4,TAXI_PER_M=.03;
const taxiLive=()=>TAXI.c&&!TAXI.c.dead&&(/^taxi/.test(TAXI.c.ai)||TAXI.c.ai==='depOut')?TAXI.c:null;
const taxiArea=p=>Math.abs(p.x)<EDGE-4&&p.z>-EDGE+4&&p.z<EDGE_S-4&&!onAirSide(p);
function kerbPoint(p){ // the nearest bit of open road around the block a place stands in
  const ib=clamp(Math.floor((p.x-R[0])/CELL),0,N-1),jb=clamp(Math.floor((p.z-R[0])/CELL),0,NZ-1);
  const xs=clamp(p.x,R[ib]+HALF_ROAD+2,R[ib+1]-HALF_ROAD-2),zs=clamp(p.z,R[jb]+HALF_ROAD+2,R[jb+1]-HALF_ROAD-2);
  const c=[];
  for(const j of [jb,jb+1])if(segH(ib,j))c.push({x:xs,z:R[j]});
  for(const i of [ib,ib+1])if(segV(i,jb))c.push({x:R[i],z:zs});
  if(c.length){c.sort((u,v)=>d2(u,p)-d2(v,p));return c[0];}
  const n=nearNode(p);return n?{x:R[n[0]],z:R[n[1]]}:{x:p.x,z:p.z};
}
function callTaxi(){
  if(phoneCD.taxi>0||taxiLive())return;
  const ap=actualPos();
  if(player.inside){phoneSay('택시: "건물 밖으로 나와서 불러 주세요."');return;}
  if(!taxiArea(ap)){phoneSay('택시: "거기까지는 못 가요. 본섬 안에서 불러 주세요."');phoneCD.taxi=5;return;}
  if(wanted.stars>0){phoneSay('택시: "죄송합니다, 지금은 배차가 어렵네요." (수배 중)');phoneCD.taxi=8;return;}
  {const k=kerbPoint(ap);if(d2(k,ap)>40){phoneSay('택시: "거긴 차가 못 들어가요. 큰길 가까이에서 불러 주세요."');phoneCD.taxi=4;return;}}
  let c=null;
  for(const q of cars)if(!q.dead&&q.isTaxi&&q.fleet&&q.ai==='traffic'&&(!c||d2(q.pos,ap)<d2(c.pos,ap)))c=q;
  {const D0=TAXI_DEPOTS.slice().sort((u,v)=>Math.hypot(u.cx-ap.x,u.cz-ap.z)-Math.hypot(v.cx-ap.x,v.cz-ap.z))[0];if(c&&D0&&d2(c.pos,ap)>Math.hypot(D0.cx-ap.x,D0.cz-ap.z)+60)c=null;}
  if(c){c.ai='taxiRun';c.lifeT=0;}
  else{
    const D=TAXI_DEPOTS.slice().sort((u,v)=>Math.hypot(u.cx-ap.x,u.cz-ap.z)-Math.hypot(v.cx-ap.x,v.cz-ap.z))[0];
    if(!D){phoneSay('택시: "근처에 빈 차가 없어요."');phoneCD.taxi=6;return;}
    let s=D.slots.find(s=>s.car&&!s.car.dead&&s.car.ai==='parked'&&!s.car.jobTaxi);
    if(!s){s=D.slots.find(s=>!s.car&&freeAt(s.x,s.z,2.6));if(s)makeFleetTaxi(D,s);}
    if(!s){phoneSay('택시: "지금은 차가 다 나갔어요. 잠시 뒤 다시 걸어 주세요."');phoneCD.taxi=6;return;}
    c=s.car;taxiDepart(c,'taxiRun');
  }
  c.speed=Math.max(c.speed,0);c.meter=0;c.pick=kerbPoint(ap);{const n=nearNode(c.pick);c.field=n?nodeField(n[0],n[1]):null;}
  TAXI.c=c;phoneCD.taxi=10;
  {const dd=Math.round(d2(c.pos,ap));phoneSay('택시: "'+(c.fleet&&c.ai==='depOut'?c.fleet.name+'에서 ':'근처 택시를 ')+'보내 드릴게요. 길가에서 기다려 주세요." · '+dd+'m');feed('택시 호출 · '+dd+'m');}
}
const taxiFare=c=>Math.round(TAXI_BASE+c.meter*TAXI_PER_M);
function taxiDrive(c,dt){
  c.lifeT+=dt;const tp=actualPos();
  const giveUp=msg=>{if(msg&&d2(c.pos,tp)<300)toast(msg);c.ai='leave';c.lifeT=0;c.goal=null;if(TAXI.c===c)TAXI.c=null;};
  if(c.ai==='taxiRun'){
    if(player.car&&player.car!==c||player.inside&&c.lifeT>20){giveUp('택시가 돌아갔다 · 손님이 안 보여서');return;}
    if(c.lifeT>220){giveUp('택시가 길이 막혀서 못 온다고 한다');return;}
    if(c.lifeT%3<dt){c.pick=kerbPoint(tp);const n=nearNode(c.pick);c.field=n?nodeField(n[0],n[1]):null;}
    const d=d2(c.pos,c.pick),dp=d2(c.pos,tp);
    if(dp<9||d<5){c.ai='taxiWait';c.lifeT=0;toast('택시 도착 · 다가가서 '+(coarse?'이용 버튼':'E')+'로 타기');return;}
    const direct=d<40&&drivable(c.pos,c.pick,1.2);
    smartDrive(c,direct?c.pick:routeTarget(c.pos,c.field,c.pick),dt,direct?8:15,{lane:!direct,stopAt:direct?1:null});
    return;
  }
  if(c.ai==='taxiWait'){
    driveCar(c,c.speed>.5?-1:0,0,true,dt);
    if(c.lifeT>90||d2(c.pos,tp)>80){giveUp('기다리던 택시가 떠났다');}
    return;
  }
  // taxiRide: the meter runs while the cab moves
  c.meter+=Math.abs(c.speed)*dt;
  if(c.stopReq||!nav||!taxiArea(nav)){driveCar(c,c.speed>.5?-1:0,0,true,dt);if(c.stopReq&&Math.abs(c.speed)<1)taxiDrop(c,false);return;}
  if(!c.dest||c.dest.nx!==nav.x||c.dest.nz!==nav.z){const k=kerbPoint(nav);c.dest={x:k.x,z:k.z,nx:nav.x,nz:nav.z};const n=nearNode(k);c.field=n?nodeField(n[0],n[1]):null;c.best=1e9;c.progT=0;}
  const D=c.dest,d=d2(c.pos,D);
  if(d<6||d2(c.pos,nav)<12){driveCar(c,c.speed>.5?-1:0,0,true,dt);if(Math.abs(c.speed)<1)taxiDrop(c,true);return;}
  if(d<c.best-1){c.best=d;c.progT=0;}else c.progT+=dt;
  if(c.progT>14&&!(c.revT>0)){c.progT=0;c.revT=2;c.revSteer=RNG()<.5?1:-1;}
  const direct=d<40&&drivable(c.pos,D,1.2);
  smartDrive(c,direct?D:routeTarget(c.pos,c.field,D),dt,direct?9:15,{lane:!direct,stopAt:direct?1:null});
}
function boardTaxi(c){
  if(wanted.stars>0){toast('택시 기사: "경찰에 쫓기는 손님은 못 태워요!"');c.ai='leave';c.lifeT=0;TAXI.c=null;return;}
  c.ai='taxiRide';c.lifeT=0;c.meter=0;c.dest=null;c.stopReq=false;c.hasDriver=true;
  player.ride={bus:c,taxi:true};player.crouch=false;job=null;player.surrender=null;camSnap=true;
  toast(nav&&taxiArea(nav)?'택시 출발 · '+nav.label+' · '+(coarse?'이용 버튼':'E')+'로 언제든 내리기':'택시에 탔다 · M 지도에서 목적지를 찍어 주세요');
}
function taxiDrop(c,arrived){
  const fare=taxiFare(c),f=fwdOf(c);
  player.ride=null;input.e=false;input.f=false;
  player.pos.set(c.pos.x+f.z*(c.w/2+1.2),0,c.pos.z-f.x*(c.w/2+1.2));collideCircle(player.pos,.35);player.pos.y=floorH(player.pos.x,player.pos.z);player.vy=0;
  camYaw=c.heading;player.yaw=camYaw;camSnap=true;
  const paid=charge(fare,'택시 요금');
  toast((arrived?'도착했습니다 · ':'택시에서 내렸다 · ')+'요금 $'+paid+(paid<fare?' (돈이 모자라 있는 만큼만 냈다)':''));
  if(arrived&&nav)clearNav();
  c.ai='leave';c.lifeT=0;c.goal=null;c.stopReq=false;if(TAXI.c===c)TAXI.c=null;
}
function taxiRide(dt){
  const c=player.ride.bus;
  if(c.dead||c.ai!=='taxiRide'){const f=fwdOf(c);player.ride=null;player.pos.set(c.pos.x+f.z*(c.w/2+1.2),0,c.pos.z-f.x*(c.w/2+1.2));collideCircle(player.pos,.35);player.vy=0;camSnap=true;toast('택시에서 내렸다');if(TAXI.c===c)TAXI.c=null;return;}
  player.pos.set(c.pos.x,c.pos.y+1.2,c.pos.z);player.vy=0;player.yaw=c.heading;
  if(wanted.stars>0&&!c.stopReq){c.stopReq=true;toast('택시 기사: "경찰이라니요! 여기서 내려 주세요!"');}
  if(input.e||input.f){input.e=false;input.f=false;if(!c.stopReq){c.stopReq=true;toast('택시를 세운다');}}
}
// ---------- freight: trucks come up out of the courier's basement, 70% deliver to the estate, the rest around town ----------
const FREIGHT_TYPES={conv:1,diner:1,gun:1,hotel:1,hospital:1,garage:1,gas:1,junk:1,cityoffice:1,cityhall:1,bank:1,realty:1,police:1,fire:1};
const BOXES=[];const boxG=new THREE.BoxGeometry(1,1,1);
function freightDest(estate){
  if(estate==null)estate=RNG()<.7;
  if(estate&&FACTORY_DOCKS.length){const D=pick(FACTORY_DOCKS);return {x:D.x,z:D.z,name:D.name,dock:D,estate:true};}
  const opts=LOCS.filter(L=>L.door&&FREIGHT_TYPES[L.type]&&taxiArea(L.door)&&L.door.z<IND_FZ);
  if(!opts.length)return freightDest(true);
  const L=pick(opts),k=kerbPoint(L.door);return {x:k.x,z:k.z,name:L.title||L.name,estate:false};
}
function dropBoxes(c,F){
  const D=F.dest.dock,f=fwdOf(c),n=randi(2,4);
  for(let k=0;k<n;k++){
    const x=D?D.ax+rand(-4,4):c.pos.x-f.x*(c.half+1.2)+rand(-1,1),z=D?D.az+rand(-1.2,1.2):c.pos.z-f.z*(c.half+1.2)+rand(-1,1);
    const m=new THREE.Mesh(boxG,mat(pick([0xb08a5a,0xc49a64,0x9a7a4a])));const sz=rand(.6,.95);m.scale.set(sz,sz*.8,sz);m.position.set(x,floorH(x,z)+.25+sz*.4,z);m.rotation.y=rand(0,3);scene.add(m);
    BOXES.push({m,t:50});
  }
  while(BOXES.length>36){const b=BOXES.shift();scene.remove(b.m);}
}
function spawnFreight(dest){
  const L=LOGI.L;if(!L)return null;const sp=rampSpawn(L);if(!sp)return null;
  const c=placeFromRamp(makeCar('civ',sp.x,sp.z,sp.h,'freight',{model:'truck',color:0xff8a3d}),sp);
  c.freight={stage:'go',dest:dest||freightDest(),t:0};c.hasDriver=true;c.locked=false;c.speed=3;c.lifeT=0;
  const n=nearNode(c.freight.dest);c.field=n?nodeField(n[0],n[1]):null;c.best=1e9;c.progT=0;
  return c;
}
function updateFreight(dt){
  if(LOGI.decor){for(const q of LOGI.decor){const {g}=makeCarMesh('civ',0xff8a3d,'truck');g.position.set(q.x,0,q.z);g.rotation.y=-Math.PI/2;}LOGI.decor=null;} // trucks backed up to the docks
  for(let k=BOXES.length-1;k>=0;k--){const b=BOXES[k];b.t-=dt;if(b.t<=0){scene.remove(b.m);BOXES.splice(k,1);}}
  LOGI.T-=dt;if(LOGI.T>0)return;LOGI.T=rand(25,50);
  const n=cars.filter(c=>!c.dead&&c.freight&&(c.ai==='freight'||c.ai==='leave')).length;
  if(n<4)spawnFreight();
}
function freightDrive(c,dt){
  const F=c.freight;F.t+=dt;
  if(F.stage==='unload'){driveCar(c,c.speed>.5?-1:0,0,true,dt);if(F.t>F.unT){c.ai='leave';c.lifeT=0;c.goal=null;}return;}
  const D=F.dest,d=d2(c.pos,D);
  if(d<7){driveCar(c,c.speed>.5?-1:0,0,true,dt);if(Math.abs(c.speed)<.8){F.stage='unload';F.t=0;F.unT=rand(8,13);dropBoxes(c,F);}return;}
  if(F.t>300){c.ai='leave';c.lifeT=0;c.goal=null;return;}
  if(d<c.best-1){c.best=d;c.progT=0;}else c.progT+=dt;
  if(c.progT>14&&!(c.revT>0)){c.progT=0;c.revT=2;c.revSteer=RNG()<.5?1:-1;}
  const direct=d<40&&drivable(c.pos,D,1.3);
  smartDrive(c,direct?D:routeTarget(c.pos,c.field,D),dt,direct?7:13,{lane:!direct,stopAt:direct?1:null});
}
// ---------- the courier's job: sign on at the dispatch window, drive a truck to each drop, come back to load the next ----------
const DJOB={on:false,car:null,stage:null,order:null,t:0,earned:0,drops:0};
function courierDesk(){
  if(DJOB.on){endCourier();return;}
  if(wanted.stars>0){toast('배차실: "경찰에 쫓기는 사람한테 짐은 못 맡겨요."');return;}
  const q=LOGI.spot;if(!freeAt(q.x,q.z,3.5)){toast('배차실: "마당에 차가 막혀 있어요. 잠깐 뒤에 다시 와 주세요."');return;}
  const c=makeCar('civ',q.x,q.z,q.h,'parked',{model:'truck',color:0xff8a3d});c.locked=false;c.hasDriver=false;c.jobTruck=true;c.fleetLogi=true;
  Object.assign(DJOB,{on:true,car:c,stage:'load',order:null,t:0,earned:0,drops:0});
  courierOrder();
  toast('배송 기사로 취업! 마당의 주황색 화물차를 타고 지도의 배송지로 · 그만둘 땐 배차실 창구에서 E');feed('네온 익스프레스 배송 기사 근무 시작');
}
function courierNav(x,z,label){setWaypoint(x,z,label);if(nav)nav.job=true;}
function courierOrder(){
  const dest=freightDest(),from=DJOB.car?DJOB.car.pos:LOGI.load,dist=Math.hypot(dest.x-from.x,dest.z-from.z);
  DJOB.order={dest,pay:Math.round(25+dist*.08),limit:dist/9+35,t:0,unload:0};DJOB.stage='deliver';
  courierNav(dest.x,dest.z,'배송 · '+dest.name);
}
function endCourier(why){
  const c=DJOB.car;
  if(nav&&nav.job)clearNav();
  if(c&&!c.dead){c.jobTruck=false;c.mine=false;c.owned=false;
    if(c!==player.car&&LOGI.L&&inRect(c.pos,{x0:LOGI.L.roadX-8,x1:LOGI.L.roadX+60,z0:LOGI.L.cz-30,z1:LOGI.L.cz+30}))c.dead=true;}
  toast((why==='wreck'?'화물차가 부서져서 근무가 끝났다':'배송 근무 끝')+' · 배송 '+DJOB.drops+'건 · 번 돈 $'+DJOB.earned);
  Object.assign(DJOB,{on:false,car:null,stage:null,order:null});
}
function updateCourier(dt){
  if(!DJOB.on)return;
  const c=DJOB.car;if(!c||c.dead||c.ai==='wreck'){endCourier('wreck');return;}
  const inCab=player.car===c,O=DJOB.order;
  if(DJOB.stage==='deliver'&&O){
    O.t+=dt;
    if(inCab&&d2(c.pos,O.dest)<9&&Math.abs(c.speed)<1.5){
      O.unload+=dt;
      if(O.unload>=4){
        const tip=O.t<=O.limit?Math.round(O.pay*.25):0,sum=O.pay+tip;player.money+=sum;DJOB.earned+=sum;DJOB.drops++;
        dropBoxes(c,{dest:O.dest});
        toast('배송 완료 · '+O.dest.name+' · +$'+O.pay+(tip?' · 빨리 와서 보너스 +$'+tip:'')+' · 물류센터로 돌아가 다음 짐 싣기');feed('배송 수당 +$'+sum);
        DJOB.stage='return';DJOB.order=null;if(nav&&nav.job)clearNav();courierNav(LOGI.load.x,LOGI.load.z,'물류센터 · 짐 싣기');
      }
    } else O.unload=0;
    return;
  }
  if(DJOB.stage==='return'){
    if(inCab&&d2(c.pos,LOGI.load)<14&&Math.abs(c.speed)<1.5){DJOB.t+=dt;if(DJOB.t>=3){DJOB.t=0;if(nav&&nav.job)clearNav();courierOrder();toast('짐 싣기 완료 · 다음 배송지: '+DJOB.order.dest.name+' · 수당 $'+DJOB.order.pay);}}
    else DJOB.t=0;
  }
}
// ---------- ten cabs on the road at all times, spread over the whole map ----------
const CABS={T:0,N:10};
function spreadCabs(){ // farthest-point sampling over street midpoints, so the first ten start evenly apart
  const pts=[];
  for(let k=0;k<=NZ;k++)for(let s2=0;s2<N;s2++)if(segH(s2,k))pts.push({x:(R[s2]+R[s2+1])/2,z:R[k],horiz:true,li:k});
  for(let i=0;i<=N;i++)for(let j=0;j<NZ;j++)if(segV(i,j))pts.push({x:R[i],z:(R[j]+R[j+1])/2,horiz:false,li:i});
  const pickd=[pick(pts)];
  while(pickd.length<CABS.N){let best=null,bd=-1;for(const q of pts){let m=1e9;for(const o of pickd)m=Math.min(m,Math.hypot(q.x-o.x,q.z-o.z));if(m>bd){bd=m;best=q;}}pickd.push(best);}
  for(const q of pickd)cabOnRoad(q);
}
function cabOnRoad(q){
  const s=RNG()<.5?1:-1,dx=q.horiz?s:0,dz=q.horiz?0:s;
  const x=q.horiz?q.x:R[q.li]-LANE*dz,z=q.horiz?R[q.li]+LANE*dx:q.z,t=q.horiz?x:z;
  let ni;if(s>0){ni=0;while(R[ni]<=t)ni++;}else{ni=R.length-1;while(R[ni]>=t)ni--;}
  const c=makeCar('civ',x,z,Math.atan2(dx,dz),'traffic',{taxi:true});
  c.dx=dx;c.dz=dz;c.li=q.li;c.ni=ni;c.speed=8;chooseTurn(c);
  c.isTaxi=true;c.keep=true;c.locked=false;
  c.fleet=TAXI_DEPOTS.slice().sort((u,v)=>Math.hypot(u.cx-x,u.cz-z)-Math.hypot(v.cx-x,v.cz-z))[0]||null;
  return c;
}
function updateCabs(dt){
  if(!CABS.spread){CABS.spread=true;spreadCabs();return;}
  CABS.T-=dt;if(CABS.T>0)return;CABS.T=6;
  const n=cars.filter(c=>!c.dead&&c.keep&&c.isTaxi&&(c.ai==='traffic'||c.ai==='depOut'||/^taxi/.test(c.ai))).length;
  if(n>=CABS.N)return;
  // a yard sends one out: the yard with the fewest of its cabs on the road
  const D=TAXI_DEPOTS.slice().sort((u,v)=>cars.filter(c=>!c.dead&&c.keep&&c.fleet===u).length-cars.filter(c=>!c.dead&&c.keep&&c.fleet===v).length)[0];if(!D)return;
  let s2=D.slots.find(q=>q.car&&!q.car.dead&&q.car.ai==='parked'&&!q.car.jobTaxi);
  if(!s2){s2=D.slots.find(q=>!q.car&&freeAt(q.x,q.z,2.6));if(s2)makeFleetTaxi(D,s2);}
  if(!s2||!s2.car)return;const c=s2.car;taxiDepart(c,'traffic');c.keep=true;
}
// ---------- car parks: now and then a passing car turns in and parks, or someone walks up to a parked car and drives off ----------
const lotSpotFree=q=>!q.res&&!cars.some(o=>!o.dead&&o.spot===q&&o.ai==='parked')&&freeAt(q.x,q.z,2.4);
function lotPath(L,q,inbound){ // gate → cross aisle → bay aisle → in front of the bay
  const w=[L.gateOut,L.gateIn,{x:q.aisle,z:L.cz},{x:q.aisle,z:q.z}];return inbound?w:w.slice().reverse();
}
function startLotIn(c,L,q){
  q.res=c;c.ai='lotIn';c.lot=L;c.spot=q;c.wps=lotPath(L,q,true);c.wi=0;c.lotMove=true;c.lifeT=0;L.busy=c;
}
function startLotOut(c){
  const q=c.spot,L=q&&q.lot;if(!L){toTraffic(c);return;}
  c.ai='lotOut';c.lot=L;c.lotMove=true;c.hasDriver=true;c.lifeT=0;L.busy=c;
  const A={x:q.aisle,z:q.z},toward=L.cz>q.z?1:-1,hEnd=Math.atan2(0,toward);
  c.lotAnim={fx:c.pos.x,fz:c.pos.z,fh:c.heading,tx:A.x,tz:A.z+toward*.01,th:hEnd,t:0,dur:2.8};
  c.north=segAt(false,L.li,L.cz-12)&&(RNG()<.5||!segAt(false,L.li,L.cz+12));
  c.wps=[{x:q.aisle,z:L.cz},L.gateIn,L.gateOut,{x:R[L.li]+(c.north?LANE:-LANE),z:L.cz+(c.north?-6:6)}];c.wi=0;
}
function lotSteer(c,t,cap,dt){
  const dx=t.x-c.pos.x,dz=t.z-c.pos.z,d=Math.hypot(dx,dz)||1,diff=angDiff(c.heading,Math.atan2(dx,dz));
  let want=Math.min(cap,d*.9+1.2);if(Math.abs(diff)>.6)want=Math.min(want,3);
  // don't drive into the player or anyone walking
  const f=fwdOf(c),blk=p=>{const ax=p.x-c.pos.x,az=p.z-c.pos.z,ah=ax*f.x+az*f.z;return ah>0&&ah<c.half+3.5&&Math.abs(ax*f.z-az*f.x)<c.w/2+.8;};
  if(blk(actualPos())||peds.some(p=>!p.dead&&!p.out&&Math.abs(p.pos.x-c.pos.x)<9&&Math.abs(p.pos.z-c.pos.z)<9&&blk(p.pos)))want=0;
  const thr=c.speed<want-.3?.6:c.speed>want+.5?-.7:0;
  driveCar(c,thr,clamp(-diff*2.4,-1,1),want===0&&c.speed>.3,dt);
  return d;
}
function lotAnimStep(c,dt){
  const A=c.lotAnim;A.t+=dt;const k=clamp(A.t/A.dur,0,1),e=k*k*(3-2*k);
  const x=A.fx+(A.tx-A.fx)*e,z=A.fz+(A.tz-A.fz)*e,h=A.fh+angDiff(A.fh,A.th)*e;
  c.speed=Math.hypot(A.tx-A.fx,A.tz-A.fz)/A.dur*(1.5-Math.abs(k-.5))*(c.ai==='lotOut'?-1:1)*.6;
  c.pos.x=x;c.pos.z=z;c.heading=c.vis=h;if(c.mesh)c.mesh.rotation.y=h;
  return k>=1;
}
function toTraffic(c){ // a car at the kerb or a car-park gate merges into the nearest lane
  const fw=fwdOf(c),horiz=Math.abs(fw.x)>Math.abs(fw.z),s2=horiz?Math.sign(fw.x)||1:Math.sign(fw.z)||1;
  const li=horiz?nearestIdxZ(c.pos.z):nearestIdx(c.pos.x),t=horiz?c.pos.x:c.pos.z,off=horiz?c.pos.z-R[li]:c.pos.x-R[li];
  if(Math.abs(off)>HALF_ROAD+3||!segAt(horiz,li,t)){c.ai='leave';c.lifeT=0;c.goal=null;return;}
  c.dx=horiz?s2:0;c.dz=horiz?0:s2;c.li=li;
  let ni;if(s2>0){ni=0;while(R[ni]<=t)ni++;}else{ni=R.length-1;while(R[ni]>=t)ni--;}
  c.ni=ni;c.ai='traffic';c.hasDriver=true;c.speed=Math.max(c.speed,2);c.ov=0;c.ovState=0;c.pull=clamp((Math.abs(off)-LANE)/1.6,0,1);chooseTurn(c);
}
function lotDrive(c,dt){
  c.lifeT+=dt;const L=c.lot;
  if(c.lifeT>70){ // something went wrong: give up quietly
    if(c.spot&&c.spot.res===c)c.spot.res=null;c.lotMove=false;if(L&&L.busy===c)L.busy=null;c.ai='leave';c.lifeT=0;c.goal=null;return;}
  if(c.ai==='lotIn'){
    if(c.lotAnim){if(lotAnimStep(c,dt)){const q=c.spot;c.lotAnim=null;c.lotMove=false;c.ai='parked';c.hasDriver=false;c.speed=0;q.res=null;if(L.busy===c)L.busy=null;
        c.pos.set(q.x,0,q.z);c.heading=c.vis=q.h;c.lotCar=true;const r={x:-Math.cos(q.h),z:Math.sin(q.h)};walkerAt(q.x+Math.sin(q.h)*0+(q.aisle-q.x)*.55,q.z+1.6);}
      return;}
    const w=c.wps[c.wi],d=lotSteer(c,w,c.wi===0?7:4.5,dt);
    if(d<(c.wi===0?3:1.8)){c.wi++;if(c.wi>=c.wps.length){const q=c.spot;c.lotAnim={fx:c.pos.x,fz:c.pos.z,fh:c.heading,tx:q.x,tz:q.z,th:q.h,t:0,dur:2.8};c.speed=0;}}
    return;
  }
  // lotOut
  if(c.lotAnim){if(lotAnimStep(c,dt)){c.lotAnim=null;c.speed=0;if(c.spot){c.spot.res=null;}c.spot=null;}return;}
  const w=c.wps[c.wi],d=lotSteer(c,w,c.wi>=c.wps.length-2?6:4.5,dt);
  if(d<(c.wi>=c.wps.length-2?2.6:1.8)){c.wi++;if(c.wi>=c.wps.length){c.lotMove=false;if(L&&L.busy===c)L.busy=null;
    // out of the gate: pull into the near lane, heading whichever way the street goes
    c.heading=c.vis=c.north?Math.PI:0;c.pos.x=R[L.li]+(c.north?LANE:-LANE);toTraffic(c);}}
}
// someone walks up to a parked car: the owner coming back for it, or a thief
function toCarMove(p,dt){
  const c=p.car3;
  if(!c||c.dead||c.ai!=='parked'||c===player.car||c.owned||c.jobTaxi||c.jobTruck||(c.tow&&!c.tow.dead)){p.state='walk';p.car3=null;if(p.thief)p.thief=false;return [0,0,0];}
  const f=fwdOf(c),side={x:f.z,z:-f.x},door={x:c.pos.x+side.x*(c.w/2+.6),z:c.pos.z+side.z*(c.w/2+.6)};
  // a car in a railed car park: walk in through the gate first
  const L=c.spot&&c.spot.lot;
  if(L&&!(p.pos.x>L.bx0+3.4&&p.pos.x<L.bx1-3.4&&p.pos.z>L.bz0+3.4&&p.pos.z<L.bz1-3.4)){
    const atGate=Math.abs(p.pos.z-L.cz)<2.2&&p.pos.x>L.bx0-1.5,g=atGate?{x:L.bx0+5,z:L.cz}:{x:L.bx0+1,z:L.cz};
    const gx=g.x-p.pos.x,gz=g.z-p.pos.z,gd=Math.hypot(gx,gz)||1;p.yaw=Math.atan2(gx,gz);return [gx/gd,gz/gd,p.thief?3.2:2.2];}
  const dx=door.x-p.pos.x,dz=door.z-p.pos.z,d=Math.hypot(dx,dz)||1;
  if(d>.9){p.yaw=Math.atan2(dx,dz);return [dx/d,dz/d,p.thief?3.2:2.2];}
  p.yaw=Math.atan2(c.pos.x-p.pos.x,c.pos.z-p.pos.z);
  if(p.thief){p.breakT=(p.breakT||0)+dt;
    if(!p.alarmed){p.alarmed=true;c.alarmT=8;scare(c.pos,16);p.state='toCar';p.car3=c;/* the alarm sends bystanders running, not the thief */if(d2(c.pos,actualPos())<90)feed('차량 절도 · 누군가 주차된 차 문을 따고 있다');}
    if(p.breakT<2.6)return null;}
  p.dead=true;c.hasDriver=true;c.locked=false;
  if(p.thief){c.stolenNPC=true;c.reckless=true;c.cruise=rand(14,17);if(d2(c.pos,actualPos())<120)toast('차량 절도! 도둑이 차를 몰고 달아난다');}
  if(c.spot&&c.spot.lot)startLotOut(c);else toTraffic(c);
  return null;
}
function sendForCar(c,thief){ // a walker appears out of sight 12–25 m off and heads for the car
  const tp=actualPos(),L=c.spot&&c.spot.lot;
  for(let k=0;k<10;k++){const a=rand(0,6.28),r=rand(12,25);let x=c.pos.x+Math.cos(a)*r,z=c.pos.z+Math.sin(a)*r;
    if(L){x=L.bx0+rand(.6,1.6);z=L.cz+(RNG()<.5?-1:1)*rand(9,20);} // along the pavement outside the car park
    if(!isLand({x,z})||forColliders(x-.3,z-.3,x+.3,z+.3,o=>!o.tree&&o.h>1&&x>o.x0&&x<o.x1&&z>o.z0&&z<o.z1))continue;
    if(Math.hypot(x-tp.x,z-tp.z)<14)continue;
    const p=makePed('civ',x,z,{weapon:null});p.state='toCar';p.car3=c;p.thief=!!thief;p.lifeT=0;return p;}
  return null;
}
const THEFT={T:rand(60,120)};
function updateLots(dt){
  // car alarms
  for(const c of cars)if(c.alarmT>0){c.alarmT-=dt;if(c.lights&&c.lights.length)for(const l of c.lights)l.color.setHex(Math.floor(c.alarmT*4)%2?0xffb020:0x221100);}
  const tp=actualPos();
  for(const L of LOTS){
    const dl=Math.hypot(L.cx-tp.x,L.cz-tp.z);
    if(dl>320&&L.live){L.live=false;for(const c of cars)if(!c.dead&&c.lotCar&&c.spot&&c.spot.lot===L&&c.ai==='parked'&&!c.owned&&!c.mine&&c!==player.car)c.dead=true;}
    if(dl>230)continue;
    if(!L.live){L.live=true; // coming into range: the car park is already part full
      for(const q of L.spots)if(RNG()<.4&&lotSpotFree(q)){const c=makeCar('civ',q.x,q.z,q.h,'parked');c.spot=q;c.lotCar=true;c.locked=RNG()<.5;}}
    L.t-=dt;if(L.t>0)continue;L.t=rand(10,24);
    if(L.busy&&!L.busy.dead&&(L.busy.ai==='lotIn'||L.busy.ai==='lotOut'||L.busy.ai==='parked'))continue;L.busy=null;
    const free=L.spots.filter(lotSpotFree),taken=cars.filter(c=>!c.dead&&c.ai==='parked'&&c.spot&&c.spot.lot===L&&c.type==='civ'&&!c.owned&&!c.mine&&!c.fleet&&!(c.tow&&!c.tow.dead));
    if(free.length&&(RNG()<.55||!taken.length)){
      // a car coming along the street outside turns in
      const cand=cars.find(c=>!c.dead&&c.ai==='traffic'&&c.type==='civ'&&!c.keep&&!c.isTaxi&&c.dx===0&&c.li===L.li&&!c.parking&&
        ((c.dz<0&&c.pos.z>L.cz+6&&c.pos.z<L.cz+45)||(c.dz>0&&c.pos.z<L.cz-6&&c.pos.z>L.cz-45)));
      if(cand)startLotIn(cand,L,pick(free));
      else{ // nobody passing: one comes up the street from out of sight
        const north=RNG()<.5,x=R[L.li]+(north?LANE:-LANE),z=L.cz+(north?1:-1)*rand(45,70);
        if(segAt(false,L.li,z)&&Math.hypot(x-tp.x,z-tp.z)>45&&!hasLOS({x,z},tp)&&freeAt(x,z,6)){const c=makeCar('civ',x,z,north?Math.PI:0,'traffic');c.speed=7;startLotIn(c,L,pick(free));}
        else L.t=rand(4,9);}
    } else if(taken.length){
      const c=pick(taken);if(!peds.some(p=>p.car3===c&&!p.dead))sendForCar(c,false);
    }
  }
  // now and then a thief goes for a parked car within sight
  THEFT.T-=dt;if(THEFT.T<=0){THEFT.T=rand(70,150);
    const list=cars.filter(c=>!c.dead&&c.ai==='parked'&&c.type==='civ'&&!c.owned&&!c.mine&&!c.fleet&&!c.jobTaxi&&!c.jobTruck&&!(c.tow&&!c.tow.dead)&&!c.illegal&&
      d2(c.pos,tp)>30&&d2(c.pos,tp)<140);
    if(list.length){list.sort((a,b)=>(hasLOS(b.pos,tp)?1:0)-(hasLOS(a.pos,tp)?1:0));const c=list[Math.floor(RNG()*Math.min(4,list.length))];sendForCar(c,true);}
    else THEFT.T=rand(15,30);}
}
// ---------- taxi yards: cabs park in the bays, pull out to cruise or answer a call, come back at the end ----------
function makeFleetTaxi(D,s){const c=makeCar('civ',s.x,s.z,s.h,'parked',{taxi:true});c.isTaxi=true;c.fleet=D;c.slot=s;c.locked=true;c.hasDriver=false;s.car=c;return c;}
function taxiDepart(c,next){
  const s=c.slot;if(s&&s.car===c){s.car=null;s.cd=rand(30,70);}c.slot=null;
  c.ai='depOut';c.next=next;c.hasDriver=true;c.locked=false;c.lifeT=0;c.outZ=c.pos.z;
}
function depotOutDrive(c,dt){
  c.lifeT+=dt;const D=c.fleet;if(!D){c.ai=c.next||'leave';return;}
  const li=clamp(nearestIdx(D.roadX),0,N),north=segAt(false,li,c.outZ-10),dz=north?-1:1,lane={x:R[li]-LANE*dz,z:c.outZ+dz*7};
  if(c.next!=='traffic'&&c.pos.x<D.bx0-1){c.ai=c.next;c.lifeT=0;return;}
  if(d2(c.pos,lane)<3||c.lifeT>25){
    if(c.next!=='traffic'){c.ai=c.next;c.lifeT=0;return;}
    if(!segAt(false,li,c.pos.z)){c.ai='leave';c.lifeT=0;return;}
    c.pos.x=R[li]-LANE*dz;c.dx=0;c.dz=dz;c.li=li;c.heading=c.vis=Math.atan2(0,dz);
    let ni;if(dz>0){ni=0;while(ni<NZ&&R[ni]<=c.pos.z)ni++;}else{ni=NZ;while(ni>0&&R[ni]>=c.pos.z)ni--;}
    c.ni=ni;c.ai='traffic';c.speed=Math.max(c.speed,3);c.lifeT=0;chooseTurn(c);return;
  }
  smartDrive(c,c.pos.x>D.bx0+1?{x:D.bx0-2,z:c.outZ}:lane,dt,6,{});
}
let tdT=0;
function updateTaxiDepots(dt){
  tdT-=dt;if(tdT>0)return;tdT=1;
  const tp=actualPos();
  for(const D of TAXI_DEPOTS){
    const d=Math.hypot(D.cx-tp.x,D.cz-tp.z);
    for(const s of D.slots){
      const c=s.car;
      if(c&&(c.dead||c.slot!==s||(c.ai!=='parked'&&!c.jobTaxi)||(!c.jobTaxi&&d2(c.pos,s)>2.5))){if(c.slot===s)c.slot=null;s.car=null;s.cd=rand(30,70);}
      if(s.cd>0)s.cd-=1;
    }
    if(d<260){
      const first=!D.live;D.live=true; // coming into range: the yard is already full; later gaps refill out of sight
      for(const s of D.slots)if(!s.car&&(first||s.cd<=0&&(d2(s,tp)>40||!hasLOS(s,tp)))&&freeAt(s.x,s.z,2.6))makeFleetTaxi(D,s);
    } else if(d>330){D.live=false;
      for(const s of D.slots)if(s.car&&!s.car.jobTaxi&&s.car.ai==='parked'&&s.car!==player.car){s.car.dead=true;s.car=null;s.cd=0;}
    }
  }
}
// ---------- the taxi driver's job: sign on at a dispatcher's booth, take calls, drive people where they want to go ----------
const TJOB={on:false,D:null,car:null,fare:null,cd:0,earned:0,trips:0};
function taxiDesk(D){
  if(TJOB.on){endTaxiShift();return;}
  if(wanted.stars>0){toast('배차실: "경찰에 쫓기는 사람은 못 써요."');return;}
  let s=D.slots.find(s=>s.car&&!s.car.dead&&s.car.ai==='parked');
  if(!s){s=D.slots.find(s=>!s.car&&freeAt(s.x,s.z,2.6));if(s)makeFleetTaxi(D,s);}
  if(!s){toast('배차실: "지금은 남는 차가 없어요. 조금 뒤에 다시 오세요."');return;}
  const c=s.car;c.jobTaxi=true;c.locked=false;
  Object.assign(TJOB,{on:true,D,car:c,fare:null,cd:3,earned:0,trips:0});
  toast('택시 기사로 취업! 노란 택시에 타면 콜이 들어와요 · 그만둘 땐 배차실 창구에서 E');feed('택시 기사 근무 시작 · '+D.name);
}
function endTaxiShift(why){
  const c=TJOB.car,F=TJOB.fare;
  if(F){if(F.p&&!F.p.dead&&F.stage==='pickup'){F.p.state='walk';F.p.stop=null;}if(nav&&nav.fare)clearNav();}
  if(c&&!c.dead){
    c.jobTaxi=false;c.mine=false;c.owned=false;
    const D=c.fleet,home=D&&c!==player.car&&c.pos.x>D.bx0-4&&c.pos.x<D.bx1&&c.pos.z>D.bz0&&c.pos.z<D.bz1;
    const s=home&&(c.slot&&c.slot.car===c?c.slot:D.slots.find(s=>!s.car));
    if(s&&c.ai==='parked'){c.pos.set(s.x,0,s.z);c.heading=c.vis=s.h;c.speed=0;s.car=c;c.slot=s;c.locked=true;}
    else if(c!==player.car){if(c.slot&&c.slot.car===c)c.slot.car=null;c.slot=null;c.fleet=null;}
  }
  toast(why==='wreck'?'택시가 부서져서 근무가 끝났다 · 손님 '+TJOB.trips+'명 · 번 돈 $'+TJOB.earned:'택시 근무 끝 · 손님 '+TJOB.trips+'명 · 번 돈 $'+TJOB.earned);
  Object.assign(TJOB,{on:false,D:null,car:null,fare:null});
}
function fareNav(x,z,label){setWaypoint(x,z,label);if(nav)nav.fare=true;}
function newFare(){
  const c=TJOB.car;let sp=null;
  for(let k=0;k<12&&!sp;k++){const q=spawnRoadPos(90,260);if(!q)continue;const o=HALF_ROAD-LANE+1.6,x=q.x-q.dz*o,z=q.z+q.dx*o;if(taxiArea({x,z})&&isLand({x,z}))sp={x,z,rx:q.x,rz:q.z};}
  if(!sp){TJOB.cd=3;return;}
  const p=makePed('civ',sp.x,sp.z,{weapon:null});p.state='waitBus';p.stop={ap:{x:sp.rx,z:sp.rz}};p.lifeT=0;p.fareP=true;p.yaw=Math.atan2(sp.rx-sp.x,sp.rz-sp.z);
  TJOB.fare={stage:'pickup',p,t:0};
  fareNav(sp.x,sp.z,'택시 손님');
  toast('콜! 손님이 기다려요 · '+Math.round(d2(sp,c.pos))+'m · 지도의 보라색 표시로');feed('택시 콜 · 손님 대기');
}
function fareGone(msg){const F=TJOB.fare;TJOB.fare=null;TJOB.cd=rand(4,8);if(nav&&nav.fare)clearNav();if(F&&F.p&&!F.p.dead&&F.stage==='pickup'){F.p.state='walk';F.p.stop=null;}if(msg)toast(msg);}
function updateTaxiJob(dt){
  if(!TJOB.on)return;
  const c=TJOB.car;
  if(!c||c.dead||c.ai==='wreck'){if(TJOB.fare)fareGone();endTaxiShift('wreck');return;}
  const F=TJOB.fare,inCab=player.car===c;
  if(!F){if(!inCab)return;TJOB.cd-=dt;if(TJOB.cd<=0)newFare();return;}
  F.t+=dt;
  if(F.stage==='pickup'){
    const p=F.p;
    if(!p||p.dead||p.out||p.state==='down'){fareGone('콜 취소 · 손님이 사라졌다');return;}
    if(p.state!=='waitBus'&&p.state!=='flee'){fareGone('콜 취소 · 손님이 걸어가 버렸다');return;}
    if(F.t>150){fareGone('콜 취소 · 손님이 기다리다 다른 차를 탔다');return;}
    if(inCab&&d2(c.pos,p.pos)<8.5&&Math.abs(c.speed)<1.6){
      if(wanted.stars>0){p.state='flee';p.fleeT=6;p.threat.copy(c.pos);fareGone('손님이 수배차를 보고 도망갔다');return;}
      p.dead=true;
      const here=c.pos,opts=LOCS.filter(L=>L.door&&L.type!=='parking'&&L.type!=='taxidepot'&&taxiArea(L.door)&&d2(L.door,here)>180&&d2(L.door,here)<650);
      let L=opts.length?pick(opts):null,dest,name;
      if(L){dest=kerbPoint(L.door);name=L.title||L.name;}
      else{const q=spawnRoadPos(200,500);dest=q?{x:q.x,z:q.z}:kerbPoint({x:-here.x*.5,z:-here.z*.5});name='시내';}
      const dist=Math.hypot(dest.x-here.x,dest.z-here.z);
      Object.assign(F,{stage:'ride',dest,name,t:0,pay:Math.round(10+dist*.06),limit:dist/8+25});
      fareNav(dest.x,dest.z,name);
      toast('손님 탑승 · "'+name+'으로 가 주세요" · '+Math.round(dist)+'m · 요금 $'+F.pay+' · '+Math.round(F.limit)+'초 안에 가면 팁');
    }
    return;
  }
  // ride: the passenger is in the back
  if(wanted.stars>0){const f=fwdOf(c),q=makePed('civ',c.pos.x+f.z*(c.w/2+1),c.pos.z-f.x*(c.w/2+1),{weapon:null});q.state='flee';q.fleeT=6;q.threat.copy(c.pos);fareGone('손님이 겁먹고 내려서 도망갔다 · 요금 못 받음');return;}
  if(!inCab){F.away=(F.away||0)+dt;if(F.away>15){const f=fwdOf(c);walkerAt(c.pos.x+f.z*(c.w/2+1.2),c.pos.z-f.x*(c.w/2+1.2));fareGone('손님이 기다리다 내려 버렸다');}return;}
  F.away=0;
  if(d2(c.pos,F.dest)<11&&Math.abs(c.speed)<1.6){
    const tip=F.t<=F.limit?Math.round(F.pay*.3):0,sum=F.pay+tip;
    player.money+=sum;TJOB.earned+=sum;TJOB.trips++;
    const f=fwdOf(c);walkerAt(c.pos.x+f.z*(c.w/2+1.2),c.pos.z-f.x*(c.w/2+1.2));
    toast('도착 · 요금 +$'+F.pay+(tip?' · 빨리 와서 팁 +$'+tip:'')+' · 오늘 $'+TJOB.earned);feed('택시 요금 +$'+sum);
    TJOB.fare=null;TJOB.cd=rand(5,10);if(nav&&nav.fare)clearNav();
  }
}
// ---------- parking enforcement: city hall tows cars left where parking is not allowed ----------
let parkT=0;
function nearestCityOffice(p){let b=null,bd=1e9;for(const L of LOCS)if((L.type==='cityhall'||L.type==='cityoffice')&&L.ramp&&L.lot){const d=d2(L.door,p);if(d<bd){bd=d;b=L;}}return b;}
function parkCandidate(c){return !c.dead&&c.ai==='parked'&&!c.fixed&&!c.crashed&&!c.impound&&!isBoat(c)&&c.type!=='pheli'&&c!==player.car&&(c.type==='civ'||c.mine||c.owned)&&!(c.tow&&!c.tow.dead)&&!c.milLock;}
function updateParking(dt){
  parkT-=dt;if(parkT>0)return;parkT=1;
  const tp=actualPos();let tows=cars.filter(c=>!c.dead&&c.city&&c.ai!=='leave').length;
  for(const c of cars){
    if(c.dead)continue;
    if(c.impound){ // NPC cars wait out their time in the city car park, then most are collected
      if(!c.mine&&c.ai==='parked'&&!c.impound.abandon){c.impound.t-=1;if(c.impound.t<=0&&c.garage){c.impound=null;c.ai='rejoin';c.hasDriver=true;c.waitT=1;c.lifeT=0;}}
      continue;}
    if(!parkCandidate(c)||d2(c.pos,tp)>330||legalPark(c.pos)){c.illT=0;continue;}
    c.illT=(c.illT||0)+1;
    if(c.mine&&c.illT===150&&d2(c.pos,tp)<150)toast('불법 주정차 · 30초 뒤 시청 견인차가 옵니다 · 주차장이나 갓길 주차 구역(P)에 세우세요');
    if(c.illT>=180&&tows<2&&dispatchCityTow(c))tows++;
  }
}
function dispatchCityTow(t,acc){
  const H=nearestCityOffice(t.pos);if(!H||!H.ramp)return false;
  const sp=rampSpawn(H);if(!sp)return false;
  const c=placeFromRamp(makeCar('tow',sp.x,sp.z,sp.h,'towRun',{model:'city'}),sp);
  c.target=t;c.home={x:H.ramp.mouth.x,z:H.ramp.mouth.z};c.garage=H;c.city=true;c.acc=!!acc;c.lifeT=0;c.speed=3;
  const n=nearNode(t.pos);c.field=n?nodeField(n[0],n[1]):null;t.tow=c;
  if(d2(t.pos,actualPos())<200)feed(acc?'시청 견인차 출동 · 교통사고 차량':'시청 견인차 출동 · 불법 주정차 단속');
  return true;
}
// the city tow is down its ramp: the car is left in the city hall car park
function impoundArrive(c){
  const t=c.target,H=c.garage;if(!t||t.ai!=='towed'||t.dead)return;
  const q=H.lot.spots.find(q=>freeAt(q.x,q.z,2.4))||H.lot.spots[randi(0,H.lot.spots.length-1)];
  t.towedBy=null;t.tow=null;t.speed=0;t.pos.set(q.x,0,q.z);t.heading=t.vis=q.h;t.ai='parked';t.hasDriver=false;t.garage=H;t.illT=0;
  if(c.acc){t.crashed=false;t.health=Math.max(t.health,t.maxHealth*.6);}
  t.impound={t:90,abandon:!t.mine&&RNG()<.15};
  if(t.mine){const nm=H.type==='cityoffice'?'시청 동부 출장소':'시청';toast('내 차가 불법 주정차로 견인됐다 · '+nm+' 주차장에서 보관료 $20을 내고 찾아가세요');feed('내 차 견인 → '+nm+' 주차장');}
}
// the garage's repair yard
function lotSpot(G){
  if(!G||!G.lot)return null;
  for(const q of G.lot.spots)if(freeAt(q.x,q.z,3))return {x:q.x,z:q.z,h:G.lot.h};
  return null;
}
// a repaired NPC car pulls out of the yard and slots back into traffic
function rejoinDrive(c,dt){
  c.lifeT+=dt;
  if(c.waitT>0){c.waitT-=dt;driveCar(c,0,0,true,dt);return;}
  const G=c.garage,E=G.lot.exit,dz=G.ramp?G.ramp.lane:1,tgt={x:E.x,z:E.z+dz*5};
  if(d2(c.pos,tgt)<3||c.lifeT>40){
    const li=clamp(nearestIdx(G.roadX),0,N);
    if(!segAt(false,li,c.pos.z)){c.ai='leave';c.lifeT=0;return;}
    c.pos.x=R[li]-LANE*dz;c.dx=0;c.dz=dz;c.li=li;c.heading=Math.atan2(0,dz);
    let ni;if(dz>0){ni=0;while(ni<NZ&&R[ni]<=c.pos.z)ni++;}else{ni=NZ;while(ni>0&&R[ni]>=c.pos.z)ni--;}
    c.ni=ni;c.ai='traffic';c.speed=Math.max(c.speed,3);c.lifeT=0;chooseTurn(c);return;
  }
  smartDrive(c,tgt,dt,5,{});
}
// soldiers roll out of the military base, through whichever gate is nearest the player
function baseSpawn(){
  const tp=playerPos(),G=[
    {x:BASE.x0+14,z:0,dx:12,dz:0,h:-Math.PI/2},
    {x:R[16],z:BASE.z0+12,dx:0,dz:12,h:Math.PI},
    {x:R[17],z:BASE.z1-12,dx:0,dz:-12,h:0}
  ].sort((a,b)=>Math.hypot(a.x-tp.x,a.z-tp.z)-Math.hypot(b.x-tp.x,b.z-tp.z));
  for(const g of G)for(let k=0;k<3;k++){const x=g.x+g.dx*k,z=g.z+g.dz*k;if(!cars.some(c=>!c.dead&&Math.hypot(c.pos.x-x,c.pos.z-z)<5))return {x,z,h:g.h};}
  return null;
}
function spawnUnit(type){
  const sp=type==='army'?baseSpawn():stationSpawn(); if(!sp) return;
  const tp=playerPos();
  const c=placeFromRamp(makeCar(type,sp.x,sp.z,sp.h!=null?sp.h:Math.atan2(tp.x-sp.x,tp.z-sp.z),'chase'),sp);
  c.crew=type==='police'?2:3; c.speed=4;
}
function makeHeli(){
  const g=new THREE.Group();
  g.add(mesh(bx(2.4,1.8,5),mat(0x3d4430),0,0,0));
  g.add(mesh(bx(2.2,1,1.6),mat(0x111826),0,.1,2.2));
  g.add(mesh(bx(.45,.45,4.4),mat(0x3d4430),0,.3,-4.4));
  g.add(mesh(bx(.15,1.4,.8),mat(0x3d4430),0,.9,-6.4));
  g.add(mesh(bx(.2,.2,3.4),mat(0x222222),-1,-1.2,0)); g.add(mesh(bx(.2,.2,3.4),mat(0x222222),1,-1.2,0));
  const rotor=new THREE.Group(); rotor.position.y=1.2; rotor.add(mesh(bx(12,.08,.45),mat(0x1a1a1a))); rotor.add(mesh(bx(.45,.08,12),mat(0x1a1a1a))); g.add(rotor);
  g.add(mesh(bx(.25,.25,.25),bmat(0xff2030),0,-.9,2.4));
  scene.add(g);
  const cg=new THREE.ConeGeometry(5,1,20,1,true); cg.translate(0,-.5,0);
  const cone=new THREE.Mesh(cg,new THREE.MeshBasicMaterial({color:0xfff2c2,transparent:true,opacity:.1,depthWrite:false,side:THREE.DoubleSide,blending:THREE.AdditiveBlending}));
  scene.add(cone);
  const tp=playerPos();
  return {g,rotor,cone,pos:new V3(505,30,38),t:rand(0,6),fireT:2,burst:0,state:'hunt',lifeT:0,health:420};
}
function deployCrew(c){
  const onFoot=peds.filter(p=>p.kind!=='civ'&&!p.dead&&!p.out&&!p.role).length;
  c.ai='parked';c.hasDriver=false;
  if(onFoot>=10) return;
  const f=fwdOf(c),r={x:-f.z,z:f.x};
  for(let k=0;k<c.crew;k++){
    const s=k%2===0?1:-1, back=k>=2?-2.2:0;
    const p=makePed(CREW_KIND[c.type],c.pos.x+r.x*s*(c.w/2+.9)+f.x*back,c.pos.z+r.z*s*(c.w/2+.9)+f.z*back);
    collideCircle(p.pos,.35); p.state='chase'; p.fireT=rand(.6,1.4);
  }
}

// ---------- fire: burning patches, the fire brigade and its trucks ----------
const fires=[],projs=[];
const flameMat=new THREE.SpriteMaterial({map:WHITE_GLOW,color:0xff6a1a,transparent:true,blending:THREE.AdditiveBlending,depthWrite:false});
const flameCore=new THREE.SpriteMaterial({map:WHITE_GLOW,color:0xffd36a,transparent:true,blending:THREE.AdditiveBlending,depthWrite:false});
function addFire(x,z,r,life,byPlayer,wall){
  if(x>ROOM_X)return null;
  for(const f of fires)if(Math.hypot(f.pos.x-x,f.pos.z-z)<f.r+1){f.life=Math.max(f.life,life);f.max=Math.max(f.max,f.life);f.r=Math.max(f.r,r);f.byPlayer=f.byPlayer||!!byPlayer;return f;}
  if(fires.length>=14){const o=fires.shift();scene.remove(o.g);o.dead=true;}
  const y=terrainH(x,z),g=new THREE.Group();g.position.set(x,y,z);const sp=[];
  const n=Math.round(5+r*1.6);
  for(let k=0;k<n;k++){const s=new THREE.Sprite(k%3?flameMat:flameCore);const a=rand(0,6.28),d=Math.sqrt(RNG())*r*.85;
    s.position.set(Math.cos(a)*d,rand(.5,1.3),Math.sin(a)*d);s.userData={b:rand(1.3,2.4)*(1-d/(r*1.4)),ph:rand(0,6)};g.add(s);sp.push(s);}
  // a building on fire: flames licking up the facade and out of the windows
  if(wall){const n2=Math.round(6+wall.w*.5);
    for(let k=0;k<n2;k++){const s=new THREE.Sprite(k%3?flameMat:flameCore),a=rand(-wall.w*.42,wall.w*.42),y0=rand(.5,Math.min(wall.h,14)*.9);
      s.position.set(wall.tx*a-wall.nx*1.1,y0,wall.tz*a-wall.nz*1.1);s.userData={b:rand(2,3.6),ph:rand(0,6),y0};g.add(s);sp.push(s);}}
  scene.add(g);scare(new V3(x,0,z),14);
  const f={pos:new V3(x,y,z),r,life,max:life,g,sp,byPlayer:!!byPlayer,dead:false,smokeT:0,truck:null,t:0,top:wall?Math.min(wall.h,14):0};fires.push(f);return f;
}
function updateFires(dt){
  for(let i=fires.length-1;i>=0;i--){
    const f=fires[i];f.t+=dt;f.life-=dt;
    if(f.life<=0){scene.remove(f.g);f.dead=true;fires.splice(i,1);
      for(let k=0;k<4;k++)puff(new V3(f.pos.x+rand(-1,1),f.pos.y+1,f.pos.z+rand(-1,1)),0x8a8a90,rand(.6,1),new V3(rand(-.3,.3),rand(1.5,2.5),rand(-.3,.3)),rand(1.2,1.8));
      continue;}
    const k=clamp(f.life/3,.25,1);
    for(const s of f.sp){const u=s.userData,fl=1+.28*Math.sin(f.t*9+u.ph)+.16*Math.sin(f.t*23+u.ph*2),sc=u.b*fl*k;s.scale.set(sc*.8,sc*1.35,1);s.position.y=(u.y0||0)+sc*.55;}
    f.smokeT-=dt;
    if(f.smokeT<=0){f.smokeT=f.top?.18:.32;puff(new V3(f.pos.x+rand(-f.r*.5,f.r*.5),f.pos.y+2.4+(f.top?rand(0,f.top+2):0),f.pos.z+rand(-f.r*.5,f.r*.5)),0x2e2b33,rand(.7,1.2)*(f.top?1.6:1),new V3(rand(-.3,.3),rand(2,3.2),rand(-.3,.3)),rand(1.8,2.6)*(f.top?1.5:1));}
    for(const p of peds){
      if(p.dead||p.out||p.room||p.state==='fly'||Math.abs(p.pos.x-f.pos.x)>f.r||Math.abs(p.pos.z-f.pos.z)>f.r)continue;
      if(d2(p.pos,f.pos)>f.r)continue;
      p.hp-=(p.ff?4:14)*dt;
      if(p.hp<=0){p.out=true;knock(p,rand(-1,1),2,rand(-1,1));if(f.byPlayer){const C=CRIME[p.kind];crime(C.base*2,p.pos,'방화 사망');}}
      else if(p.kind==='civ'&&!p.ff&&(p.state==='walk'||p.state==='idle')&&!p.role){p.state='flee';p.fleeT=rand(4,6);p.threat.copy(f.pos);}
    }
    if(!player.car&&!player.inside&&!dead&&d2(player.pos,f.pos)<f.r&&player.pos.y-f.pos.y<1.6)damagePlayer(12*dt,'불길에 휩싸였습니다.');
    for(const c of cars)if(!c.dead&&c.ai!=='wreck'&&d2(c.pos,f.pos)<f.r+c.w/2)c.health-=16*dt;
  }
}
// ---------- building fires: now and then one starts by itself somewhere in town (never the base or the airport) ----------
const NATFIRE={T:rand(240,480)};
function fireAtWall(px,pz,nx,nz,w,h,life){ // a fire against a wall whose outward normal is (nx,nz)
  return addFire(px,pz,clamp(w*.18,2.6,4.2),life,false,{w,h,nx,nz,tx:-nz,tz:nx});
}
function buildingFire(B,life){
  const cx=(B.x0+B.x1)/2,cz=(B.z0+B.z1)/2,sides=[[B.x0-1.6,cz,-1,0,B.z1-B.z0],[B.x1+1.6,cz,1,0,B.z1-B.z0],[cx,B.z0-1.6,0,-1,B.x1-B.x0],[cx,B.z1+1.6,0,1,B.x1-B.x0]];
  const ok=sides.filter(([x,z])=>onMainXZ(x,z,553)&&!forColliders(x-.4,z-.4,x+.4,z+.4,c=>!c.tree&&c.h>1&&x>c.x0&&x<c.x1&&z>c.z0&&z<c.z1));
  if(!ok.length)return null;const [x,z,nx,nz,w]=pick(ok);
  return fireAtWall(x,z,nx,nz,w,B.h,life||rand(150,220));
}
function updateNatFire(dt){
  NATFIRE.T-=dt;if(NATFIRE.T>0)return;NATFIRE.T=rand(240,480);
  if(fires.length>=10)return;
  const tp=actualPos(),ok=B=>{const c={x:(B.x0+B.x1)/2,z:(B.z0+B.z1)/2};return !inBase(c)&&onMainXZ(c.x,c.z,553)&&!terrainH(c.x,c.z);};
  let list=BLDGS.filter(B=>{const d=Math.hypot((B.x0+B.x1)/2-tp.x,(B.z0+B.z1)/2-tp.z);return d>50&&d<420&&ok(B);});
  if(!list.length)list=BLDGS.filter(ok);
  for(let k=0;k<6;k++){const B=pick(list),f=B&&buildingFire(B);if(f){f.natural=true;
    const d=d2(f.pos,tp);if(d<220)toast('근처 건물에서 불이 났다! 연기가 치솟는다');else if(d<450)feed('화재 발생 · 건물에서 연기가 난다');break;}}
}
// thrown bottles and rockets
const bottleMeshG=new THREE.CylinderGeometry(.07,.09,.3,8),rocketG=new THREE.CylinderGeometry(.09,.09,.9,8),noseG=new THREE.ConeGeometry(.11,.3,8);
function launchProj(kind){
  const dir=new V3();camera.getWorldDirection(dir);
  const fp=view==='first',r={x:-Math.cos(camYaw),z:Math.sin(camYaw)};
  const start=fp?camera.position.clone().addScaledVector(dir,.9):new V3(player.pos.x+r.x*.4+dir.x*.9,player.pos.y+(player.crouch?1.1:1.6),player.pos.z+r.z*.4+dir.z*.9);
  const g=new THREE.Group();g.position.copy(start);
  if(kind==='molotov'){
    const b=mesh(bottleMeshG,mat(0x3f8a5a));b.rotation.x=Math.PI/2;g.add(b);
    const fl=new THREE.Sprite(flameCore);fl.scale.set(.5,.5,1);fl.position.z=.22;g.add(fl);
  } else {
    const b=mesh(rocketG,mat(0x4a5a2a));b.rotation.x=Math.PI/2;g.add(b);
    const n=mesh(noseG,mat(0x2a2a26));n.rotation.x=Math.PI/2;n.position.z=.6;g.add(n);
    const fl=new THREE.Sprite(flameMat);fl.scale.set(.9,.9,1);fl.position.z=-.55;g.add(fl);
  }
  scene.add(g);
  const vel=kind==='molotov'?dir.clone().multiplyScalar(17).add(new V3(0,4.2,0)):dir.clone().multiplyScalar(58);
  projs.push({kind,g,pos:start.clone(),vel,t:0,trailT:0});
  MP.proj(kind,start,vel);
  recoil=kind==='rpg'?2.2:.5;shake=Math.max(shake,kind==='rpg'?.35:.05);
  if(kind==='rpg'){for(let k=0;k<5;k++)puff(start.clone().addScaledVector(dir,-1.6),0x6a6a70,rand(.4,.7),new V3(-dir.x*rand(2,5)+rand(-1,1),rand(.3,1.5),-dir.z*rand(2,5)+rand(-1,1)),rand(.7,1.2));scare(player.pos,40);}
}
function projHits(np,pr){
  if(MP.projTouch(np,pr&&pr.owner))return true;
  if(pr&&pr.remote&&MP.touchesMe(np))return true;
  if(np.y<=surfaceH(np.x,np.z)+.04)return true;
  for(const b of boats)if(b&&!b.dead&&inBoat(np,b))return true;
  if(forColliders(np.x-.15,np.z-.15,np.x+.15,np.z+.15,c=>np.x>c.x0-.12&&np.x<c.x1+.12&&np.z>c.z0-.12&&np.z<c.z1+.12&&np.y<c.h))return true;
  for(const p of peds){if(p.dead||p.out||p.room||p.state==='fly'||p.state==='down')continue;if(Math.abs(p.pos.x-np.x)<.55&&Math.abs(p.pos.z-np.z)<.55&&np.y>p.pos.y&&np.y<p.pos.y+1.9)return true;}
  for(const c of cars){if(c.dead||c===player.car)continue;const f=fwdOf(c),dx=np.x-c.pos.x,dz=np.z-c.pos.z;
    if(Math.abs(dx*f.x+dz*f.z)<c.half&&Math.abs(-dx*f.z+dz*f.x)<c.w/2&&np.y<c.pos.y+c.top)return true;}
  if(heli&&heli.pos.distanceTo?heli.pos.distanceTo(np)<3:false)return true;
  return false;
}
function updateProjs(dt){
  for(let i=projs.length-1;i>=0;i--){
    const pr=projs[i];pr.t+=dt;
    pr.vel.y-=(pr.kind==='molotov'?20:1.2)*dt;
    const steps=pr.kind==='rpg'?4:2;let hit=false;
    for(let k=0;k<steps&&!hit;k++){const np=pr.pos.clone().addScaledVector(pr.vel,dt/steps);if(projHits(np,pr))hit=true;else pr.pos.copy(np);}
    pr.g.position.copy(pr.pos);
    pr.g.lookAt(pr.pos.x+pr.vel.x,pr.pos.y+pr.vel.y,pr.pos.z+pr.vel.z);
    if(pr.kind==='molotov')pr.g.rotation.z+=dt*10;
    pr.trailT-=dt;if(pr.kind==='rpg'&&pr.trailT<=0){pr.trailT=.025;puff(pr.pos.clone(),0x8a8a90,rand(.25,.4),new V3(rand(-.4,.4),rand(.2,.8),rand(-.4,.4)),rand(.8,1.2));}
    if(hit||pr.t>5||pr.pos.x>ROOM_X){scene.remove(pr.g);projs.splice(i,1);if(pr.pos.x<ROOM_X)detonate(pr);}
  }
}
function detonate(pr){
  if(pr.remote){MP.blastBy=pr.owner;try{detonateFx(pr,false);}finally{MP.blastBy=null;}return;} // another player's: no wanted level for me
  detonateFx(pr,true);
}
function detonateFx(pr,mine){
  const at=pr.pos.clone();
  if(at.y<WATER_Y+.3){ // fell in the sea
    for(let k=0;k<8;k++)puff(at,0xe6f2ff,rand(.3,.6),new V3(rand(-2,2),rand(2,5),rand(-2,2)),.6);
    if(pr.kind==='rpg')blast(at,7.5,150,mine);
    return;
  }
  if(pr.kind==='molotov'){
    for(let k=0;k<6;k++)puff(at,0xffa040,rand(.2,.4),new V3(rand(-3,3),rand(1,4),rand(-3,3)),.35,true);
    addFire(at.x,at.z,3.2,34,mine);if(mine)crime(3,at,'방화');
  } else {
    blast(at,7.5,150,mine);addFire(at.x,at.z,2.2,16,mine);
  }
}
function downHeli(){
  const at=heli.pos.clone();puff(at,0xffa040,2,new V3(),.7,true);
  for(let j=0;j<12;j++)puff(at,0x333038,rand(1.2,2.2),new V3(rand(-5,5),rand(-2,4),rand(-5,5)),rand(1.5,2.5));
  scene.remove(heli.g);scene.remove(heli.cone);heli=null;heliCD=30;shake=Math.max(shake,.6);
  crime(8,player.pos,'헬기 격추');toast('헬기 격추!');
}
// an explosion that is not a car blowing up (rockets)
function blast(at,r,power,byPlayer){
  puff(at,0xffa040,1.6,new V3(),.6,true);puff(at,0xff5a20,1.1,new V3(0,2,0),.75,true);
  for(let i=0;i<12;i++)puff(at,0x333038,rand(1,2),new V3(rand(-4,4),rand(2,6),rand(-4,4)),rand(1.2,2.4));
  shake=Math.max(shake,1);scare(at,45);
  for(const p of peds){
    if(p.dead||p.out||p.state==='fly'||p.room)continue;const d=d2(p.pos,at);if(d>=r)continue;
    const k=1-d/r,dx=(p.pos.x-at.x)/(d||1),dz=(p.pos.z-at.z)/(d||1);
    p.hp-=power*k;const killed=p.hp<=0;if(killed)p.out=true;else if(byPlayer)p.provokeOnUp=true;
    knock(p,dx*12*k+dx*2,5+5*k,dz*12*k+dz*2);
    if(byPlayer&&!(p.kind==='civ'&&(p.aggro||p.crim))){const C=CRIME[p.kind];crime(C.base*(killed?2.5:1),p.pos,null);}
  }
  for(const c of cars){if(c.dead||c.ai==='wreck')continue;const d=d2(c.pos,at);if(d>=r+c.half*.5)continue;
    c.health-=power*2.7*clamp(1.15-d/(r+c.half*.5),.25,1);if(c.ai==='traffic'){c.ai='parked';c.crashed=true;}
    if(byPlayer&&c.type!=='civ')crime(2,c.pos,null);}
  if(!player.inside&&!dead&&!(MP.blastBy&&!NET.pvp())){const ap=actualPos(),d=d2(ap,at);if(MP.blastBy&&d<r)MP.noteHit(MP.blastBy);
    if(d<r){if(player.car)player.car.health-=power*1.4*(1-d/r);else{damagePlayer(power*.55*(1-d/r),'폭발에 휘말렸습니다.');player.vy=5;player.grounded=false;}}}
  if(heli&&heli.pos.distanceTo&&heli.pos.distanceTo(at)<r+4){heli.health-=power*2.4;if(heli.health<=0)downHeli();}
  for(const b of boats){if(!b||b.dead)continue;const d=Math.hypot(b.pos.x-at.x,b.pos.z-at.z);if(d<r+5)hurtBoat(b,power*2.2*clamp(1.2-d/(r+5),.3,1));}
  if(byPlayer)crime(2,at,'폭발물 사용');
}
// fire brigade: the nearest fire station rolls a truck; two firefighters hose the fire down, then ride back
const FF_LOOK={shirt:0xc9a35a,pants:0xb8923f,hat:0xc0221c,vest:0x2b2b2b};
function dispatchTruck(f){
  let st=null,bd=1e9;for(const L of LOCS)if(L.type==='fire'){const d=d2(L.door,f.pos);if(d<bd){bd=d;st=L;}}
  if(!st)return false;
  {const sp=rampSpawn(st);if(!sp)return false;
    const c=placeFromRamp(makeCar('fire',sp.x,sp.z,sp.h,'fireRun'),sp);c.fire=f;c.speed=3;c.crew=2;c.lifeT=0;
    const n=nearNode(f.pos);c.field=n?nodeField(n[0],n[1]):null;f.truck=c;
    if(d2(f.pos,actualPos())<160)feed('소방차 출동 · '+st.sign[1]);
    return true;
  }
}
function deployFF(c){
  const f=fwdOf(c),r={x:-f.z,z:f.x};
  for(let k=0;k<2;k++){const s=k?1:-1;
    const p=makePed('civ',c.pos.x+r.x*s*(c.w/2+.9),c.pos.z+r.z*s*(c.w/2+.9),{look:FF_LOOK,weapon:null,hpMul:1.4});
    collideCircle(p.pos,.35);p.ff=true;p.truck=c;p.fire=c.fire;p.state='firefight';p.sprayT=0;}
}
function fireDrive(c,dt){
  c.lifeT+=dt;const f=c.fire;
  if(c.ai==='fireRun'){
    if(!f||f.dead||c.lifeT>160){c.ai='leave';c.lifeT=0;return;}
    const d=d2(c.pos,f.pos);
    if(d<15){driveCar(c,c.speed>1?-1:0,0,true,dt);if(Math.abs(c.speed)<1.5){deployFF(c);c.ai='fireWait';c.hasDriver=false;c.lifeT=0;}return;}
    const direct=d<45&&drivable(c.pos,f.pos,1.3);
    smartDrive(c,direct?f.pos:routeTarget(c.pos,c.field,f.pos),dt,direct?8:15,{lane:!direct,siren:true,stopAt:direct?12:null});
  } else {
    driveCar(c,0,0,true,dt);
    c.chk=(c.chk||0)-dt;
    if(c.chk<=0){c.chk=.5;
      const crew=peds.filter(p=>p.truck===c&&!p.dead&&!p.out).length;
      if(crew===0&&(!f||f.dead||c.lifeT>8)){c.ai='leave';c.lifeT=0;c.hasDriver=true;}
      if(c.lifeT>120)for(const p of peds)if(p.truck===c&&p.state==='firefight')p.state='ffReturn';
    }
  }
}
// tow trucks: a garage sends one to haul away wrecks and crashed cars blocking the road
function dispatchTow(t,forPlayer,road){
  let G=null,bd=1e9;for(const L of LOCS)if(L.type==='garage'){const d=d2(L.door,t.pos);if(d<bd){bd=d;G=L;}}
  if(!G)return false;
  const H=road?nearestCityOffice(t.pos):G;if(!H)return false;
  {const sp=rampSpawn(H);if(!sp)return false;
    const c=placeFromRamp(makeCar('tow',sp.x,sp.z,sp.h,'towRun',{model:road?'city':'garage'}),sp);c.target=t;c.road=!!road;c.home={x:G.ramp.mouth.x,z:G.ramp.mouth.z};c.garage=G;c.lifeT=0;c.speed=3;c.forPlayer=!!forPlayer;
    const n=nearNode(t.pos);c.field=n?nodeField(n[0],n[1]):null;t.tow=c;
    if(d2(t.pos,actualPos())<200)feed(road?'시청 도로정비과 견인차 출동 · 사고 처리 지원':'견인차 출동 · '+(G.title||'카센터'));
    return true;
  }
}
function steerTo(c,tgt,dt,slowAt){
  if(c.revT>0){c.revT-=dt;driveCar(c,-1,c.revSteer,false,dt);return;}
  const desired=Math.atan2(tgt.x-c.pos.x,tgt.z-c.pos.z),diff=angDiff(c.heading,desired),d=d2(c.pos,tgt);
  let thr=d<(slowAt||0)?.5:1;if(Math.abs(diff)>1.1&&c.speed>9)thr=.1;
  driveCar(c,thr,clamp(-diff*2.6,-1,1),false,dt);
  if(thr>.4&&Math.abs(c.speed)<1.2)c.stuckT+=dt;else c.stuckT=0;
  if(c.stuckT>1.2){c.stuckT=0;c.revT=1.1;c.revSteer=RNG()<.5?1:-1;}
}
function towDrive(c,dt){
  c.lifeT+=dt;const t=c.target;
  const waiting=c.forPlayer&&t&&t===player.car; // customer still sitting in it
  const lost=c.city?(!t||t.dead||t===player.car||t.impound||(c.ai==='towRun'&&(t.ai!=='parked'||(!c.acc&&(t.crashed||legalPark(t.pos)))))||(c.ai==='towHook'&&t.ai!=='parked')||(c.ai==='towBack'&&t.ai!=='towed')):!t||t.dead||(t.owned&&!c.forPlayer)||(t===player.car&&!c.forPlayer)||(!waiting&&c.ai!=='towBack'&&t.ai!=='wreck'&&t.ai!=='parked')||(c.ai==='towBack'&&t.ai!=='towed');
  if(c.ai==='towRun'){
    if(lost||c.lifeT>180){if(t&&t.tow===c)t.tow=null;c.target=null;c.ai='leave';c.lifeT=0;return;}
    const d=d2(c.pos,t.pos);
    if(d<11){
      driveCar(c,c.speed>1?-1:0,0,true,dt);
      const burning=fires.some(f=>!f.dead&&d2(f.pos,t.pos)<f.r+3);
      if(waiting){if(!c.toldOut){c.toldOut=true;toast('견인차 도착 · 차에서 내려 주세요');}return;}
      if(Math.abs(c.speed)<1.2&&!burning){c.ai='towHook';c.hookT=2.5;}
      return;
    }
    {const direct=d<40&&drivable(c.pos,t.pos,1.2);smartDrive(c,direct?t.pos:routeTarget(c.pos,c.field,t.pos),dt,direct?6:13,{lane:!direct,siren:true,ignore:t});}
  } else if(c.ai==='towHook'){
    driveCar(c,0,0,true,dt);
    if(lost){c.ai='leave';c.lifeT=0;return;}
    c.hookT-=dt;
    if(c.hookT<=0){t.wasWreck=t.ai==='wreck';t.ai='towed';t.speed=0;t.hasDriver=false;t.towedBy=c;c.ai='towBack';
      const n=nearNode(c.home);c.field=n?nodeField(n[0],n[1]):null;if(d2(c.pos,actualPos())<120)feed('사고 차량 견인 중');}
  } else { // towBack: haul it to the garage, where both disappear into the yard
    const dh=Math.hypot(c.home.x-c.pos.x,c.home.z-c.pos.z);
    if(c.lifeT>240&&d2(c.pos,playerPos())>150){c.dead=true;towArrive(c);return;}
    if(rampIn(c,c.garage,dt))return;
    {const direct=dh<40&&drivable(c.pos,c.home,1.2);smartDrive(c,direct?c.home:routeTarget(c.pos,c.field,c.home),dt,direct?6:12,{lane:!direct});}
  }
}
// the tow truck is down the ramp: the car it hauled comes back fixed in the repair yard
function towArrive(c){
  if(c.city){impoundArrive(c);return;}
  const t=c.target,G=c.garage;
  if(!t||t.ai!=='towed'||t.dead)return;
  const sp=lotSpot(G)||(G.ramp&&rampSpawn(G))||{x:G.spawnSpot.x,z:G.spawnSpot.z+9,h:G.spawnSpot.h};
  let n=t;
  if(t.wasWreck||!CAR_STATS[t.type]){ // burnt out: rebuilt from scratch in the same model and colour
    t.dead=true;
    if(!CAR_STATS[t.type]||isBoat(t))return;
    n=makeCar(t.type,sp.x,sp.z,sp.h,'parked',{model:t.model,color:t.color});
    n.owned=t.owned;n.mine=t.mine;n.price=t.price;
  }
  const fee=TOW_FEE+(t.wasWreck?400:repairCost(t));
  n.health=n.maxHealth;n.towedBy=null;n.tow=null;n.crashed=false;n.speed=0;n.pos.set(sp.x,0,sp.z);n.heading=n.vis=sp.h;n.garage=G;
  if(c.forPlayer){
    n.ai='parked';n.hasDriver=false;
    const paid=charge(fee,t.wasWreck?'견인 · 차량 복구':'견인 · 수리비');
    toast('내 차 '+(t.wasWreck?'복구':'수리')+' 완료 · '+(G.title||'카센터')+' 주차장 · −$'+paid.toLocaleString());
  } else if(n.type==='civ'&&G.lot){n.ai='rejoin';n.hasDriver=true;n.waitT=rand(2,4);n.lifeT=0;}
  else n.dead=true;
}
// a towed car rides behind its truck, front wheels up
function placeTowed(c){
  const T=c.towedBy;
  if(!T||T.dead||T.ai!=='towBack'){c.ai=c.wasWreck?'wreck':'parked';c.towedBy=null;c.tow=null;c.speed=0;return;}
  const f=fwdOf(T);c.heading=T.heading;c.vis=T.heading;c.pos.x=T.pos.x-f.x*(T.half+c.half+.4);c.pos.z=T.pos.z-f.z*(T.half+c.half+.4);
}

// spraying a jet of water: firefighters at fires, the player from a stolen fire truck
let cannonT=0,cannonCrimeT=0;
function sprayCannon(c,dt){
  const yaw=c.heading+carYawOff,dir={x:Math.sin(yaw),z:Math.cos(yaw)},f=fwdOf(c);
  const o=new V3(c.pos.x+f.x*c.half*.55,c.pos.y+3.1,c.pos.z+f.z*c.half*.55);
  cannonT-=dt;if(cannonT<=0){cannonT=.035;puff(o.clone(),0xcfe8ff,rand(.18,.28),new V3(dir.x*rand(24,30)+rand(-1,1),rand(2,4),dir.z*rand(24,30)+rand(-1,1)),rand(.6,.8));}
  cannonCrimeT-=dt;
  for(const p of peds){
    if(p.dead||p.out||p.room||p.state==='fly'||p.state==='down')continue;
    const dx=p.pos.x-o.x,dz=p.pos.z-o.z,d=Math.hypot(dx,dz);if(d>24||d<.5||(dx*dir.x+dz*dir.z)/d<.94)continue;
    if((p.wetCD||0)>clock)continue;p.wetCD=clock+1;
    p.hp-=3;if(p.hp<=0)p.hp=1;
    knock(p,dir.x*9,3,dir.z*9);p.provokeOnUp=p.kind==='civ'&&!p.ff?RNG()<.3:true;
    if(cannonCrimeT<=0){cannonCrimeT=1.2;crime(p.kind==='civ'?.4:1.5,p.pos,'물대포 사용');}
  }
  for(const fr of fires){const dx=fr.pos.x-o.x,dz=fr.pos.z-o.z,d=Math.hypot(dx,dz);if(d<28&&(dx*dir.x+dz*dir.z)/(d||1)>.9)fr.life-=12*dt;}
}

// ---------- navy patrol boats: moored at the naval pier, patrol the east coast, hunt you on the water at ★4+ ----------
const boats=[];
const BOAT_HOME=[{x:600,z:13,h:Math.PI/2},{x:600,z:41,h:Math.PI/2},{x:912,z:-175,h:Math.PI},{x:912,z:-95,h:0}];
const AFB_WP=[[880,-500],[1470,-500],[1470,180],[880,180]];
const inAfbZone=(p,m)=>p.x>AFB.x0-m&&p.x<AFB.x1+m&&p.z>AFB.z0-m&&p.z<AFB.z1+m;
const BOAT_WP=[[700,-300],[780,-60],[780,180],[700,330],[620,120]];
const LANDB=EDGE+30;
// things boats must steer around: the city (with quay and sea walls), the pier, the moored cargo ships
const SEA_OBS=[{x0:-LANDB,x1:LANDB,z0:-LANDB,z1:LANDB+LAND_S},{x0:PIER_W.x0,x1:PIER_W.x1+2,z0:PIER_W.z0-2,z1:PIER_W.z1+2},{x0:PIER_H.x0-2,x1:PIER_H.x1+2,z0:PIER_H.z0-2,z1:PIER_H.z1+2},
  {x0:-610,x1:-586,z0:R[6]+24,z1:R[6]+116},{x0:-610,x1:-586,z0:R[12]-126,z1:R[12]-34},{x0:JETTY.x0-1,x1:JETTY.x1,z0:JETTY.z0-1.8,z1:JETTY.z1+1.8},
  {x0:FERRY_A.x0-1,x1:FERRY_A.x1,z0:FERRY_A.z0-1,z1:FERRY_A.z1+1},{x0:FERRY_B.x0,x1:FERRY_B.x1+1,z0:FERRY_B.z0-1,z1:FERRY_B.z1+1},{x0:AFB_DOCK.x0-1,x1:AFB_DOCK.x1,z0:AFB_DOCK.z0-1,z1:AFB_DOCK.z1+1},
  {x0:-672,x1:-553,z0:BRIDGE.z0-2,z1:BRIDGE.z1+2},{x0:BRIDGE.x0,x1:-843,z0:BRIDGE.z0-2,z1:BRIDGE.z1+2}] // low ends of the bridge (boats pass under the arch)
  .concat(ISLANDS.map(I=>({x0:I.x0-8,x1:I.x1+8,z0:I.z0-8,z1:I.z1+8})));
const seaClear=(a,b)=>SEA_OBS.every(o=>segEntry(a.x,a.z,b.x,b.z,o,1.5)===null);
// shortest sea route: a visibility graph over points just off each obstacle's corners
const SEA_NODES=[];
for(const o of SEA_OBS)for(const [cx,cz] of [[o.x0-16,o.z0-16],[o.x1+16,o.z0-16],[o.x0-16,o.z1+16],[o.x1+16,o.z1+16]])
  if(!SEA_OBS.some(q=>cx>q.x0-3&&cx<q.x1+3&&cz>q.z0-3&&cz<q.z1+3))SEA_NODES.push({x:cx,z:cz});
const SEA_ADJ=SEA_NODES.map((a,i)=>SEA_NODES.map((b,j)=>i!==j&&seaClear(a,b)?Math.hypot(a.x-b.x,a.z-b.z):0));
function seaPath(from,to){
  if(seaClear(from,to))return [to];
  const n=SEA_NODES.length,dist=new Array(n).fill(1e9),prev=new Array(n).fill(-1),done=new Array(n).fill(false);
  for(let i=0;i<n;i++)if(seaClear(from,SEA_NODES[i]))dist[i]=Math.hypot(SEA_NODES[i].x-from.x,SEA_NODES[i].z-from.z);
  let bestEnd=-1,bestCost=1e9;
  for(;;){let u=-1,ud=1e9;for(let i=0;i<n;i++)if(!done[i]&&dist[i]<ud){ud=dist[i];u=i;}
    if(u<0)break;done[u]=true;
    if(seaClear(SEA_NODES[u],to)){const c=ud+Math.hypot(to.x-SEA_NODES[u].x,to.z-SEA_NODES[u].z);if(c<bestCost){bestCost=c;bestEnd=u;}}
    for(let v=0;v<n;v++){const w=SEA_ADJ[u][v];if(w&&ud+w<dist[v]){dist[v]=ud+w;prev[v]=u;}}}
  if(bestEnd<0)return [to];
  const path=[to];for(let u=bestEnd;u>=0;u=prev[u])path.unshift(SEA_NODES[u]);
  return path;
}
function boatMesh(){
  const g=new THREE.Group(),H=0x6d747c;
  g.add(mesh(bx(3.6,1.5,10),mat(H),0,.55,-.5));
  const bow=mesh(bx(2.55,1.5,2.55),mat(H),0,.55,4.5);bow.rotation.y=Math.PI/4;g.add(bow);
  g.add(mesh(bx(3.64,.3,10),mat(0x2a2e34),0,-.05,-.5));
  g.add(mesh(bx(3.3,.12,9.6),mat(0x8a9098),0,1.32,-.4));
  g.add(mesh(bx(2.4,1.6,3.4),mat(0xc8ccd2),0,2.1,-1.6));
  g.add(mesh(bx(2.42,.45,.06),mat(0x10141f),0,2.5,.12));
  g.add(mesh(bx(.15,2.6,.15),mat(0x3a3e44),0,4.1,-2));g.add(mesh(bx(1.4,.12,.3),mat(0x3a3e44),0,4.9,-2));
  g.add(mesh(bx(.9,.6,.9),mat(0x4a5058),0,1.7,2.6));g.add(mesh(bx(.14,.14,1.6),mat(0x1a1a1a),0,1.85,3.5));
  g.add(mesh(bx(.04,.5,.8),bmat(0x2e4a8a),0,4,-3.2));
  g.add(mesh(bx(.06,.5,1.6),bmat(0xf2f2f2),1.83,.9,1.8));g.add(mesh(bx(.06,.5,1.6),bmat(0xf2f2f2),-1.83,.9,1.8));
  const lights=sirenLights(g,3.05,-1.6);
  scene.add(g);return {g,lights};
}
function makeBoat(i){
  const H=BOAT_HOME[i],m=boatMesh();
  const b={i,g:m.g,lights:m.lights,pos:new V3(H.x,WATER_Y-.3,H.z),heading:H.h,speed:0,health:520,state:i===1?'moor':'patrol',wp:i===3?2:0,wps:i>=2?AFB_WP:BOAT_WP,afb:i>=2,fireT:2,burst:0,dead:false,t:rand(0,6),wakeT:0};
  boats[i]=b;return b;
}
const boatRespawn=[0,0,0,0];
function boatPushOut(b){
  for(const o of SEA_OBS){const m=1.9;
    if(b.pos.x>o.x0-m&&b.pos.x<o.x1+m&&b.pos.z>o.z0-m&&b.pos.z<o.z1+m){
      const l=b.pos.x-(o.x0-m),r=(o.x1+m)-b.pos.x,t=b.pos.z-(o.z0-m),bt=(o.z1+m)-b.pos.z,mn=Math.min(l,r,t,bt);
      if(mn===l)b.pos.x=o.x0-m;else if(mn===r)b.pos.x=o.x1+m;else if(mn===t)b.pos.z=o.z0-m;else b.pos.z=o.z1+m;
      b.speed*=.92;}
  }
}
function boatSail(b,to,dt,maxSp,stopAt){
  // keep heading for the chosen corner until it is reached, so the boat does not dither between two
  b.pathT=(b.pathT||0)-dt;
  if(seaClear(b.pos,to))b.cur=null;
  else if(!b.cur||b.pathT<=0||Math.hypot(b.cur.x-b.pos.x,b.cur.z-b.pos.z)<14){
    const path=seaPath(b.pos,to);b.pathT=1.5;
    b.cur=path.length>1&&Math.hypot(path[0].x-b.pos.x,path[0].z-b.pos.z)<14?path[1]:path[0];
    if(b.cur===to)b.cur=null;}
  const w=b.cur||to,desired=Math.atan2(w.x-b.pos.x,w.z-b.pos.z),diff=angDiff(b.heading,desired);
  const d=Math.hypot(to.x-b.pos.x,to.z-b.pos.z);
  b.heading+=clamp(diff*1.6,-1,1)*dt*clamp(.55+b.speed/10,0,1.1);b.heading=Math.atan2(Math.sin(b.heading),Math.cos(b.heading));
  let want=d<(stopAt||6)?0:Math.min(maxSp,(b.cur?Math.max(d,40):d)*.5+2);if(Math.abs(diff)>1.2)want=Math.min(want,3);
  b.speed+=clamp(want-b.speed,-7*dt,4*dt);
  b.pos.x+=Math.sin(b.heading)*b.speed*dt;b.pos.z+=Math.cos(b.heading)*b.speed*dt;
  boatPushOut(b);
  return d;
}
const openWater=(x,z)=>!SEA_OBS.some(o=>x>o.x0-4&&x<o.x1+4&&z>o.z0-4&&z<o.z1+4);
// a firing position ~22m from the target, in open water, on the side nearest the boat
function standOff(p,b){
  let best=null,bd=1e9;
  for(let k=0;k<12;k++){const a=k/12*Math.PI*2;for(const r of [22,34,48]){const x=p.x+Math.cos(a)*r,z=p.z+Math.sin(a)*r;
    if(!openWater(x,z))continue;const d=Math.hypot(x-b.pos.x,z-b.pos.z)+r*2;if(d<bd){bd=d;best={x,z};}}}
  return best||{x:p.x,z:p.z};
}
// the patch of water nearest a point on land (or the point itself if it is already at sea)
function waterNear(p){
  if(Math.abs(p.x)<LANDB&&p.z>-LANDB&&p.z<LANDB+LAND_S){
    const dl=[LANDB-p.x,LANDB+p.x,LANDB+LAND_S-p.z,LANDB+p.z],m=Math.min(...dl);
    if(m===dl[0])return {x:LANDB+18,z:p.z,d:m};if(m===dl[1])return {x:-LANDB-18,z:p.z,d:m};
    if(m===dl[2])return {x:p.x,z:LANDB+LAND_S+18,d:m};return {x:p.x,z:-LANDB-18,d:m};
  }
  return {x:p.x,z:p.z,d:0};
}
function downBoat(b,byPlayer){
  const at=b.pos.clone();at.y=WATER_Y+1;
  puff(at,0xffa040,2,new V3(),.7,true);for(let j=0;j<12;j++)puff(at,0x333038,rand(1.2,2.2),new V3(rand(-4,4),rand(1,5),rand(-4,4)),rand(1.5,2.5));
  scene.remove(b.g);b.dead=true;boatRespawn[b.i]=90;shake=Math.max(shake,.4);
  if(byPlayer){crime(6,actualPos(),'경비정 격파');toast('경비정 격파!');}
}
function hurtBoat(b,dmg){
  if(b.dead)return;b.health-=dmg;
  if(b.state!=='hunt'&&wanted.stars<4){b.angry=20;}
  if(b.health<=0)downBoat(b,true);
}
function updateBoats(dt){
  for(let i=0;i<BOAT_HOME.length;i++){
    if(boats[i]&&!boats[i].dead)continue;
    boatRespawn[i]-=dt;if(boatRespawn[i]<=0&&d2(BOAT_HOME[i],actualPos())>120)makeBoat(i);
  }
  const ap=actualPos(),wn=waterNear(ap),swim=player.swim;
  const huntable=!dead&&!player.inside&&(wanted.stars>=4||boats.some(b=>b&&!b.dead&&b.angry>0))&&(swim||wn.d<140);
  for(const b of boats){
    if(!b||b.dead)continue;
    b.t+=dt;if(b.angry>0)b.angry-=dt;
    const hunt=b.afb?(!dead&&!player.inside&&wanted.stars>0&&inAfbZone(ap,320)):huntable&&(wanted.stars>=4||b.angry>0);
    b.state=hunt?'hunt':b.state==='hunt'?'return':b.state;
    if(b.state==='hunt'){
      boatSail(b,standOff(wn.d>0?wn:ap,b),dt,19,4);
      const d3=Math.hypot(ap.x-b.pos.x,(ap.y||0)-b.pos.y,ap.z-b.pos.z);
      b.fireT-=dt;
      if(b.fireT<=0&&d3<100&&!player.surrender){
        const from=new V3(b.pos.x+Math.sin(b.heading)*3.5,b.pos.y+3.4,b.pos.z+Math.cos(b.heading)*3.5);
        if(hasLOS(from,ap)){
          if(b.burst<=0)b.burst=8;b.burst--;b.fireT=b.burst>0?.12:rand(1.4,2);
          const hit=RNG()<.2*(player.car&&Math.abs(player.car.speed)>14?.5:1)*(swim?1.2:1),spr=hit?.4:2.6;
          tracer(from,new V3(ap.x+rand(-spr,spr),(ap.y||0)+1,ap.z+rand(-spr,spr)),0xffe9a8);
          scare(from,20);if(hit)damagePlayer(3,'해군 경비정의 기관포에 쓰러졌습니다.');
        } else b.fireT=.4;
      }
    } else if(b.state==='return'){
      const pat=b.i!==1,H=pat?{x:b.wps[b.wp][0],z:b.wps[b.wp][1]}:BOAT_HOME[b.i];
      if(boatSail(b,H,dt,14,pat?20:2)<(pat?20:3))b.state=pat?'patrol':'moor';
    } else if(b.state==='patrol'){
      const w=b.wps[b.wp];if(boatSail(b,{x:w[0],z:w[1]},dt,9,15)<20)b.wp=(b.wp+1)%b.wps.length;
    } else { // moored
      const H=BOAT_HOME[b.i];b.speed*=Math.max(0,1-dt*2);b.pos.x+=(H.x-b.pos.x)*Math.min(1,dt*.5);b.pos.z+=(H.z-b.pos.z)*Math.min(1,dt*.5);b.heading+=angDiff(b.heading,H.h)*Math.min(1,dt);
    }
    const bob=Math.sin(b.t*1.3)*.12;b.pos.y=WATER_Y-.3+bob;
    b.g.position.copy(b.pos);b.g.rotation.set(Math.sin(b.t*.9)*.03-(b.speed>8?.05:0),b.heading,Math.sin(b.t*1.1)*.04);
    const on=b.state==='hunt',fl=Math.floor(clock*6)%2===0;
    b.lights[0].color.setHex(on&&fl?0xff2a3a:0x550010);b.lights[1].color.setHex(on&&!fl?0x2a6bff:0x001055);
    b.wakeT-=dt;if(b.speed>5&&b.wakeT<=0){b.wakeT=.12;const f={x:Math.sin(b.heading),z:Math.cos(b.heading)};
      puff(new V3(b.pos.x-f.x*5.5+rand(-.8,.8),WATER_Y+.1,b.pos.z-f.z*5.5+rand(-.8,.8)),0xe6f2ff,rand(.4,.7),new V3(rand(-.5,.5),.3,rand(-.5,.5)),rand(.8,1.3));}
  }
}
// ray test against a boat's hull and cabin (in the boat's own frame)
function rayBoat(o,dir,b){
  const f={x:Math.sin(b.heading),z:Math.cos(b.heading)},r={x:-f.z,z:f.x},rx=o.x-b.pos.x,rz=o.z-b.pos.z;
  return rayBox({x:rx*r.x+rz*r.z,y:o.y-b.pos.y,z:rx*f.x+rz*f.z},{x:dir.x*r.x+dir.z*r.z,y:dir.y,z:dir.x*f.x+dir.z*f.z},-1.9,-.3,-5.6,1.9,3.2,6);
}
const inBoat=(p,b)=>{const f={x:Math.sin(b.heading),z:Math.cos(b.heading)},dx=p.x-b.pos.x,dz=p.z-b.pos.z;return Math.abs(dx*f.x+dz*f.z)<6&&Math.abs(-dx*f.z+dz*f.x)<2&&p.y<b.pos.y+3.2&&p.y>b.pos.y-.5;};

// ---------- boats, a flyable helicopter, armed vehicles ----------
function isBoat(c){return c.type==='mboat'||c.type==='navyboat';}
const GUN_VEH={apc:1,pheli:1,navyboat:1};
// boats stay in open water: pushed off the island, the decks, the moored ships and the jetty
function boatDrive(c,thr,steer,brake,dt){
  if(thr>0)c.speed+=thr*c.accel*dt;else if(thr<0)c.speed+=thr*(c.speed>0?14:6)*dt;else c.speed*=Math.max(0,1-.45*dt);
  if(brake)c.speed*=Math.max(0,1-1.6*dt);
  c.speed=clamp(c.speed,-6,c.maxSpeed*(c.ai==='player'?1.1:1));
  c.heading-=steer*c.turn*clamp(.35+Math.abs(c.speed)/10,0,1)*(c.speed<-.2?-1:1)*dt;
  const f=fwdOf(c);c.pos.x+=f.x*c.speed*dt;c.pos.z+=f.z*c.speed*dt;
  const m=c.w/2+.3;let hit=false;
  for(const o of SEA_OBS){
    if(c.pos.x>o.x0-m&&c.pos.x<o.x1+m&&c.pos.z>o.z0-m&&c.pos.z<o.z1+m){
      const l=c.pos.x-(o.x0-m),r=(o.x1+m)-c.pos.x,t=c.pos.z-(o.z0-m),b=(o.z1+m)-c.pos.z,mn=Math.min(l,r,t,b);
      if(mn===l)c.pos.x=o.x0-m;else if(mn===r)c.pos.x=o.x1+m;else if(mn===t)c.pos.z=o.z0-m;else c.pos.z=o.z1+m;hit=true;}
  }
  if(Math.abs(c.pos.x)>1640||Math.abs(c.pos.z)>1640){c.pos.x=clamp(c.pos.x,-1640,1640);c.pos.z=clamp(c.pos.z,-1640,1640);hit=true;}
  if(hit){if(Math.abs(c.speed)>9){c.health-=(Math.abs(c.speed)-8)*6;if(c===player.car)shake=Math.max(shake,.3);}c.speed*=.35;}
}
// what a helicopter can set down on: ground, mountain, decks, rooftops; the sea is not an option
function heliFloor(x,z){
  let h=onDeck({x,z})?floorH(x,z):onMainXZ(x,z,561)?terrainH(x,z):onIsland({x,z})?0:WATER_Y+.4;
  forColliders(x-.1,z-.1,x+.1,z+.1,cc=>{if(!cc.tree&&x>cc.x0&&x<cc.x1&&z>cc.z0&&z<cc.z1)h=Math.max(h,cc.h);});
  return h;
}
function heliFly(c,fwd,turn,climb,dt){
  const mine=c===player.car,down=mine&&(input.keys.ShiftLeft||input.keys.ShiftRight||input.keys.KeyC||input.descend);
  if(c.vy==null)c.vy=0;
  const fl=heliFloor(c.pos.x,c.pos.z),air=c.pos.y>fl+.25;
  const wantV=!mine?(air?-3.5:0):climb?7.5:down?-6:0;
  c.vy+=(wantV-c.vy)*Math.min(1,dt*2.4);
  c.pos.y+=c.vy*dt;
  if(c.pos.y<=fl){if(c.vy<-9){c.health-=(-c.vy-8)*28;if(mine)shake=Math.max(shake,.6);}c.pos.y=fl;if(c.vy<0)c.vy=0;}
  if(c.pos.y>160){c.pos.y=160;if(c.vy>0)c.vy=0;}
  if(c.pos.y>fl+.25&&mine){c.speed+=fwd*15*dt;c.speed*=Math.max(0,1-.42*dt);c.heading-=turn*1.5*dt;}
  else{c.speed*=Math.max(0,1-3.5*dt);if(mine)c.heading-=turn*.7*dt;}
  c.speed=clamp(c.speed,-14,46);
  const f=fwdOf(c);c.pos.x+=f.x*c.speed*dt;c.pos.z+=f.z*c.speed*dt;
  // anything taller than our altitude shoves us back out (buildings, towers, the mountain flank)
  const r=c.rad*1.6;let hit=false;
  forColliders(c.pos.x-r,c.pos.z-r,c.pos.x+r,c.pos.z+r,b=>{
    if(b.h<c.pos.y+.3)return;
    const cx=clamp(c.pos.x,b.x0,b.x1),cz=clamp(c.pos.z,b.z0,b.z1),dx=c.pos.x-cx,dz=c.pos.z-cz,q=dx*dx+dz*dz;if(q>r*r)return;
    if(q<1e-6){c.pos.x+=(c.pos.x<(b.x0+b.x1)/2?-1:1)*.5;}else{const dd=Math.sqrt(q);c.pos.x=cx+dx/dd*r;c.pos.z=cz+dz/dd*r;}hit=true;});
  if(onMainXZ(c.pos.x,c.pos.z,561)){const th=terrainH(c.pos.x,c.pos.z);if(c.pos.y<th){c.pos.y=th;hit=true;}}
  if(hit&&Math.abs(c.speed)>12){c.health-=(Math.abs(c.speed)-10)*5;if(mine)shake=Math.max(shake,.4);}
  if(hit)c.speed*=.4;
  if(Math.abs(c.pos.x)>1640||Math.abs(c.pos.z)>1640){c.pos.x=clamp(c.pos.x,-1640,1640);c.pos.z=clamp(c.pos.z,-1640,1640);c.speed*=.5;}
}
// mounted guns: APC turret, helicopter chin gun, patrol boat deck gun, all aimed with the camera
function vehicleGun(c,dt){
  c.gunT=(c.gunT||0)-dt;if(c.gunT>0)return;c.gunT=c.type==='pheli'?.075:.11;
  const dir=new V3();camera.getWorldDirection(dir);
  dir.x+=rand(-.01,.01);dir.y+=rand(-.01,.01);dir.z+=rand(-.01,.01);dir.normalize();
  const o=camera.position.clone().addScaledVector(dir,camera.position.distanceTo?camera.position.distanceTo(c.pos)+c.half+.6:c.half+12);
  const res=castShot(o,dir,160),end=o.clone().addScaledVector(dir,res.t),f=fwdOf(c);
  let mz=new V3(c.pos.x+f.x*(c.type==='pheli'?2.6:c.type==='apc'?3.6:4.2),c.pos.y+(c.type==='pheli'?.9:c.type==='apc'?2.2:2),c.pos.z+f.z*(c.type==='pheli'?2.6:c.type==='apc'?3.6:4.2));
  const G=c.mesh&&c.mesh.userData.gun,B=c.mesh&&c.mesh.userData.barrels;
  if(G){ // swing the chin turret toward the shot and spin the barrels; the round leaves its muzzle
    const aimYaw=Math.atan2(end.x-c.pos.x,end.z-c.pos.z);G.rotation.y=clamp(angDiff(c.vis,aimYaw),-1.6,1.6);
    G.rotation.x=clamp(Math.atan2(c.pos.y-end.y,Math.hypot(end.x-c.pos.x,end.z-c.pos.z)),-.2,1.2);
    if(B)B.rotation.z+=1.2;
    if(G.localToWorld){mz=G.localToWorld(new V3(0,0,2));}
  }
  bulletStreak(mz,end);tracer(mz,end,0xfff0c0);muzzleFlash(mz,c.type==='pheli');
  puff(mz,0xffd27a,.28,new V3(),.08,true);puff(mz,0xb8902a,.08,new V3(f.z*3,-2,-f.x*3),.4,false);
  shake=Math.max(shake,c.type==='pheli'?.08:.05);scare(c.pos,40);
  const dmg=26,hd={x:dir.x,z:dir.z},hl=Math.hypot(hd.x,hd.z)||1;hd.x/=hl;hd.z/=hl;
  if(!res.hit){puff(end,0xffc070,.3,new V3(0,1,0),.2,true);puff(end,0x8a7a60,.5,new V3(0,2,0),.5,false);crime(.4,c.pos,wanted.stars===0?'중화기 발사':null);return;}
  const h=res.hit;
  if(h.kind==='ped'){if(playerHurtsPed(h.p,dmg,hd,'gun')==='kill')hitMarker(true);else hitMarker(false);}
  else if(h.kind==='car'){h.c.health-=dmg*(h.c.type==='apc'?.2:.7);if(h.c.ai==='traffic'){h.c.ai='parked';h.c.crashed=true;}crime(h.c.type==='civ'?.5:2,h.c.pos,null);hitMarker(false);}
  else if(h.kind==='boat'){hurtBoat(h.b,dmg);crime(1,h.b.pos,null);hitMarker(h.b.dead);}
  else if(heli){heli.health-=dmg;crime(.5,c.pos,null);if(heli.health<=0)downHeli();hitMarker(!heli);}
  puff(end,0xffe0a0,.12,new V3(rand(-2,2),rand(1,3),rand(-2,2)),.2,true);
}
// keys for military hardware
const LOCK_INFO={mil:['군용 차량 키','기지 정비고 키 보관함'],heli:['헬기 시동 코드','관제탑 단말기'],boat:['경비정 키','해군 부두 초소 키함']};
// military vehicles: a key from the base, or a one-shot military wiring kit and 5 seconds
function milUnlock(k,then){
  if((player.keys[k]||0)>0){player.keys[k]--;then();return;}
  if(player.kits.mil>0){startJob({label:'군용 배선 따는 중',dur:5,at:player.pos.clone(),room:null,start:'군용 차량 배선 따개로 시동을 거는 중… 5초',done:()=>{player.kits.mil--;then();}});return;}
  toast('군용 차량 배선 따개(총포상 암시장)나 '+LOCK_INFO[k][0]+'가 필요하다');
}
// half the parked cars are locked: a wiring kit (10 uses) gets you in in 3 seconds
const isLocked=c=>c.locked&&c.ai==='parked'&&!c.hasDriver&&!c.owned&&!c.mine;
function hotwire(c){
  if(player.kits.car<=0){toast('잠긴 차다 · 차량 배선 따개가 필요하다 (총포상 주인과 대화)');return;}
  startJob({label:'배선 따는 중',dur:3,at:player.pos.clone(),room:null,start:'차량 배선 따개로 시동을 거는 중… 3초',done:()=>{if(c.dead||player.car)return;player.kits.car--;c.locked=false;enterCar(c);toast('시동 성공 · 배선 따개 '+player.kits.car+'회 남음');}});
}
function unlockFor(k){
  if((player.keys[k]||0)>0){player.keys[k]--;return true;}
  toast(LOCK_INFO[k][0]+'가 필요하다 · '+LOCK_INFO[k][1]+'에서 구하세요');return false;
}
const TERMINALS=[
  {id:'mil',name:'정비고 키 보관함',at:new V3(432.6,0,72),need:['crowbar','drill'],dur:7,give:'군용 차량 키'},
  {id:'heli',name:'관제탑 단말기',at:new V3(539,0,65.4),need:['drill'],dur:9,give:'헬기 시동 코드'},
  {id:'boat',name:'해군 부두 초소 키함',at:new V3(PIER_H.x0+5.5,0,PIER_H.z1-11.4),need:['crowbar'],dur:5,give:'경비정 키'}
];
for(const T of TERMINALS){T.cd=0;addRing(T.at.x,T.at.z,0xffb53d,.8);}
const TOOL_NAME={crowbar:'크로우바',drill:'드릴'};
const TOOL_DUR={crowbar:8,drill:5};
// a crafted tool wears out after a few jobs; the gun shop's hardware never does
function wearTool(k){let t=player.tools[k];if(!t||t.pro)return;if(t===true)t=player.tools[k]={dur:TOOL_DUR[k]};t.dur--;if(t.dur<=0){player.tools[k]=false;toast((k==='crowbar'?'크로우바':'조잡한 드릴')+'가 망가졌다 · 다시 만들거나 총포상에서 튼튼한 걸 사세요');}}
const toolTxt=k=>{const t=player.tools[k];return !t?'없음':t.pro?(k==='crowbar'?'단단한 크로우바':'전동 드릴')+' · 무한':(k==='crowbar'?'크로우바':'조잡한 드릴')+' '+t.dur+'/'+TOOL_DUR[k];};
function useTerminal(T){
  if(T.cd>0){toast(T.name+' · 비어 있다 ('+Math.ceil(T.cd)+'초 뒤)');return;}
  const miss=T.need.filter(k=>!player.tools[k]);
  if(miss.length){toast(miss.map(k=>TOOL_NAME[k]).join(' · ')+'가 필요하다 · I로 제작');return;}
  startJob({label:T.name+' 여는 중',dur:T.dur,at:T.at,room:null,mil:true,start:T.name+'을(를) 여는 중… 군인 눈에 띄지 마세요',done:()=>{
    player.keys[T.id]=(player.keys[T.id]||0)+1;T.cd=240;for(const k of T.need)wearTool(k);toast(T.give+' 획득!');feed(T.give+' +1');}});
}
// parked military vehicles in the base; marina boats on the jetty. Each slot is refilled once you are well away
const MIL_SLOTS=[
  {type:'army',x:449,z:79,h:Math.PI/2,lock:'mil'},{type:'army',x:449,z:88,h:Math.PI/2,lock:'mil'},
  {type:'apc',x:466,z:22,h:-Math.PI/2,lock:'mil'},{type:'pheli',x:505,z:38,h:.6,lock:'heli'}
];
const MARINA_SLOTS=[{x:-597,z:-12.2},{x:-615,z:-12.2},{x:-633,z:-12.2},{x:-606,z:2.2},{x:-624,z:2.2}];
const BOAT_COL=[0xf2f2f0,0xd23a2a,0x2e86c1,0xf1c40f,0x16a085];
function fillSlot(S,kind){
  let c;
  if(kind==='mil'){c=makeCar(S.type,S.x,S.z,S.h,'parked');c.milLock=S.lock;if(S.type==='pheli')c.pos.y=heliFloor(S.x,S.z);}
  else c=makeCar('mboat',S.x,S.z,-Math.PI/2,'parked',{model:RNG()<.3?'speed':'runabout',color:pick(BOAT_COL)});
  c.fixed=true;c.hasDriver=false;S.c=c;return c;
}
function refillSlots(force){
  const tp=actualPos();
  for(const S of MIL_SLOTS){if(S.c&&!S.c.dead&&S.c.fixed)continue;if(!force&&Math.hypot(S.x-tp.x,S.z-tp.z)<170)continue;if(cars.some(c=>!c.dead&&Math.hypot(c.pos.x-S.x,c.pos.z-S.z)<5))continue;fillSlot(S,'mil');}
  MARINA_SLOTS.forEach((S,i)=>{if(i===4)return;if(S.c&&!S.c.dead&&S.c.fixed)return;if(!force&&Math.hypot(S.x-tp.x,S.z-tp.z)<150)return;if(cars.some(c=>!c.dead&&Math.hypot(c.pos.x-S.x,c.pos.z-S.z)<4))return;fillSlot(S,'boat');});
}
function buyBoat(M){
  let S=MARINA_SLOTS.find(S=>!cars.some(c=>!c.dead&&Math.hypot(c.pos.x-S.x,c.pos.z-S.z)<4));
  if(!S){S=MARINA_SLOTS[4];for(const c of cars)if(!c.dead&&c.fixed&&Math.hypot(c.pos.x-S.x,c.pos.z-S.z)<4)c.dead=true;}
  if(player.car)exitCar(false);
  const c=makeCar('mboat',S.x,S.z,-Math.PI/2,'parked',{model:M.id,color:M.id==='speed'?0xd23a2a:0xf2f2f0});
  c.owned=true;c.mine=true;c.price=M.price;
  player.pos.set(S.x,JETTY.y,S.z<JETTY.z0?JETTY.z0+.8:JETTY.z1-.8);
  enterCar(c);toast(M.name+' 인수 완료 · 바다로 나가 보세요');feed(M.name+' 구매 −$'+M.price.toLocaleString());
}
const BOAT_MODELS=[{id:'runabout',name:'모터보트',price:2500,desc:'튼튼한 소형 보트 · 최고 시속 약 95km'},{id:'speed',name:'스피드보트',price:5500,desc:'빠르고 날렵함 · 최고 시속 약 125km'}];
// stealing a navy patrol boat moored at the pier
function nearNavyBoat(){for(const b of boats){if(b&&!b.dead&&b.state==='moor'&&d2(b.pos,player.pos)<7)return b;}return null;}
function stealNavyBoat(b){
  scene.remove(b.g);b.dead=true;boatRespawn[b.i]=300;
  const c=makeCar('navyboat',b.pos.x,b.pos.z,b.heading,'parked');c.milLock='boat';
  enterCar(c);
}
// boats bob on the swell; the helicopter tilts with its speed and spins its rotor
function syncAirSea(c,dt){
  if(c.type==='pheli'){
    c.mesh.position.set(c.pos.x,c.pos.y,c.pos.z);c.mesh.rotation.set(clamp(c.speed/46,-.4,1)*.22,c.vis,0);
    const on=c===player.car||c.pos.y>heliFloor(c.pos.x,c.pos.z)+.3;c.spin=clamp((c.spin||0)+(on?dt*.8:-dt*.3),0,1);
    const R=c.mesh.userData.rotor;if(R)R.rotation.y+=dt*30*c.spin;const T=c.mesh.userData.tail;if(T)T.rotation.x+=dt*40*c.spin;
  } else {
    if(c.bobPh==null)c.bobPh=rand(0,6);
    c.pos.y=WATER_Y-(c.type==='navyboat'?.3:.1)+Math.sin(clock*1.3+c.bobPh)*.08;
    c.mesh.position.set(c.pos.x,c.pos.y,c.pos.z);
    c.mesh.rotation.set(-Math.min(.1,Math.max(0,c.speed)/260),c.vis,Math.sin(clock*1.1+c.bobPh)*.03);
    if(Math.abs(c.speed)>5&&RNG()<dt*14){const f=fwdOf(c);puff(new V3(c.pos.x-f.x*c.half,WATER_Y+.1,c.pos.z-f.z*c.half),0xe6f2ff,rand(.3,.55),new V3(rand(-.6,.6),.4,rand(-.6,.6)),rand(.7,1.1));}
  }
}

// ---------- the ferry: a scheduled shuttle between the harbour quay and the airport island ----------
const FERRY={A:new V3(-614,0,21),B:new V3(-926,0,-213),state:'dockA',t:0,s:0,riders:false};
FERRY.len=Math.hypot(FERRY.B.x-FERRY.A.x,FERRY.B.z-FERRY.A.z);FERRY.heading=Math.atan2(FERRY.B.x-FERRY.A.x,FERRY.B.z-FERRY.A.z);
const FERRY_DOCK=25,FERRY_TRIP=46,FERRY_FARE=20;
{
  const g=new THREE.Group();
  g.add(mesh(bx(8,2.6,26),mat(0xf2f2f0),0,.6,0));g.add(mesh(bx(8.04,.6,26.04),mat(0x1f3a6a),0,-.4,0));
  g.add(mesh(bx(8.1,.12,26.1),mat(0x8a9098),0,1.95,0));
  g.add(mesh(bx(6.4,2.6,15),mat(0xe8eef2),0,3.3,-1));
  g.add(mesh(bx(6.45,.8,14.6),bmat(0xbfe6ff),0,3.4,-1));
  g.add(mesh(bx(5,2,7),mat(0xf2f2f0),0,5.6,-3));g.add(mesh(bx(5.05,.6,6.6),bmat(0xbfe6ff),0,5.8,-3));
  g.add(mesh(bx(1.6,2.6,1.6),mat(0x2e86c1),0,7.6,-5));g.add(mesh(bx(1.65,.5,1.65),mat(0x1a1a1e),0,9,-5));
  for(const z of [-12.6,12.6])g.add(mesh(bx(7.6,.9,.15),mat(0xc8ccd4),0,2.5,z));
  const sg=signPlane(['NEON FERRY','하버 ↔ 국제공항'],'#062a33','#7ff3ff',0,0,0,6,1.6,0);scene.remove(sg);sg.position.set(3.25,4.6,-1);sg.rotation.y=Math.PI/2;g.add(sg);
  const sg2=signPlane(['NEON FERRY','하버 ↔ 국제공항'],'#062a33','#7ff3ff',0,0,0,6,1.6,0);scene.remove(sg2);sg2.position.set(-3.25,4.6,-1);sg2.rotation.y=-Math.PI/2;g.add(sg2);
  scene.add(g);FERRY.g=g;
}
const ferryPos=()=>new V3(FERRY.A.x+(FERRY.B.x-FERRY.A.x)*FERRY.s,0,FERRY.A.z+(FERRY.B.z-FERRY.A.z)*FERRY.s);
const ferryDocked=side=>FERRY.state==='dock'+side;
function ferryWait(side){ // seconds until the ferry can be boarded at this side
  const T=FERRY_DOCK,J=FERRY_TRIP;
  if(ferryDocked(side))return 0;
  if(FERRY.state==='go')return side==='B'?J-FERRY.t:J-FERRY.t+T+J;
  if(FERRY.state==='back')return side==='A'?J-FERRY.t:J-FERRY.t+T+J;
  return side==='A'?T-FERRY.t+J:T-FERRY.t+J; // docked at the other side
}
function updateFerry(dt){
  FERRY.t+=dt;
  if(FERRY.state==='dockA'||FERRY.state==='dockB'){if(FERRY.t>FERRY_DOCK){FERRY.t=0;FERRY.state=FERRY.state==='dockA'?'go':'back';}}
  else{
    const u=Math.min(1,FERRY.t/FERRY_TRIP),e=u*u*(3-2*u);FERRY.s=FERRY.state==='go'?e:1-e;
    if(u>=1){FERRY.t=0;FERRY.state=FERRY.state==='go'?'dockB':'dockA';if(player.ride&&!player.ride.bus){ // arrive: step ashore
      const R=FERRY.state==='dockB'?FERRY_RING_B:FERRY_RING_A;player.ride=null;player.pos.set(R.x,.5,R.z);player.vy=0;camSnap=true;toast(FERRY.state==='dockB'?'국제공항 페리 터미널 도착':'하버 페리 터미널 도착');}}
  }
  const p=ferryPos();p.y=WATER_Y-.4+Math.sin(clock*.9)*.12;FERRY.pos=p;
  FERRY.g.position.copy(p);FERRY.g.rotation.set(Math.sin(clock*.7)*.012,FERRY.heading,Math.sin(clock*.8)*.02);
  if(FERRY.state==='go'||FERRY.state==='back'){if(RNG()<dt*10){const f={x:Math.sin(FERRY.heading),z:Math.cos(FERRY.heading)},sg=FERRY.state==='go'?-1:1;
    puff(new V3(p.x+f.x*13*sg+rand(-2,2),WATER_Y+.1,p.z+f.z*13*sg+rand(-2,2)),0xe6f2ff,rand(.5,.9),new V3(rand(-.5,.5),.4,rand(-.5,.5)),rand(1,1.6));}}
  if(player.ride&&!player.ride.bus){player.pos.set(p.x,p.y+2.05,p.z);player.vy=0;}
}
function boardFerry(side){
  if(!ferryDocked(side)){toast('페리가 아직 안 왔다 · '+Math.ceil(ferryWait(side))+'초 뒤');return;}
  if(player.money<FERRY_FARE){toast('뱃삯 $'+FERRY_FARE+'이 부족하다');return;}
  player.money-=FERRY_FARE;feed('페리 승선 −$'+FERRY_FARE);player.ride={side};player.crouch=false;job=null;
  toast('페리 탑승 · '+(side==='A'?'국제공항':'하버')+'행 · '+Math.ceil(FERRY_DOCK-FERRY.t+FERRY_TRIP)+'초 소요');
}

// ---------- aircraft: an airliner on a takeoff/landing loop, a fighter circling the air base ----------
const PLANES={};
{
  PLANES.air=makeAirliner(0x2e86c1,0x2e86c1,true);PLANES.jet=makeFighter(true);PLANES.jet2=makeFighter(true);PLANES.jet3=makeFighter(true);
  PLANES.t=0;PLANES.ph=0;
}
function updatePlanes(dt){
  // airliner: hold at the runway threshold, take off south over the sea, later land from the north and taxi back
  const P=PLANES.air,x=-1280;PLANES.t+=dt;let t=PLANES.t,y=1.7,z=-520,h=0,vis=true;
  const seg=[25,32,40,34,20,30];let k=0;while(k<seg.length&&t>seg[k]){t-=seg[k];k++;}
  if(k>=seg.length){PLANES.t=0;k=0;t=0;}
  if(k===0){z=-520;}
  else if(k===1){const u=t/seg[1];z=-520+u*u*1900;y=1.7+Math.max(0,z+300)*.12;}
  else if(k===2){vis=false;}
  else if(k===3){const u=t/seg[3];z=-1700+u*1180;y=1.7+Math.max(0,(-540-z))*.11;}
  else if(k===4){const u=Math.min(1,t/seg[4]),e=1-(1-u)*(1-u);z=-520+e*220;}
  else{const u=t/seg[5];z=-300-u*220;h=Math.PI;}
  P.visible=vis;P.position.set(x,y+1.65,z);P.userData.gear.visible=y<18;P.rotation.set(k===1&&z>-300?-.12:k===3?.06:0,h,0);
  // fighter jet circling the air base
  PLANES.ph+=dt*.16;const J=PLANES.jet,cx=1175,cz=-160,r=330;
  J.position.set(cx+Math.cos(PLANES.ph)*r,140+Math.sin(PLANES.ph*2)*15,cz+Math.sin(PLANES.ph)*r);
  J.rotation.set(0,Math.atan2(-Math.sin(PLANES.ph),Math.cos(PLANES.ph)),.5);
  // two wingmen in echelon behind the lead
  for(const [P,dp,dr,dy] of [[PLANES.jet2,-.05,28,5],[PLANES.jet3,-.1,-28,10]]){if(!P)continue;const ph=PLANES.ph+dp,rr=r+dr;
    P.position.set(cx+Math.cos(ph)*rr,140+dy+Math.sin(ph*2)*15,cz+Math.sin(ph)*rr);P.rotation.set(0,Math.atan2(-Math.sin(ph),Math.cos(ph)),.5);}
}

// ---------- street justice: NPC crimes, arrests, the phone, ambulances ----------
const isLaw=p=>p.kind!=='civ';
const MEDIC_LOOK={shirt:0xeef4f6,pants:0x2a5a4a,vest:0x2e8a5a,hat:0xeef4f6};
const crimTex=(()=>{const c=document.createElement('canvas');c.width=c.height=64;const g=c.getContext('2d');
  g.fillStyle='#ff3b4e';g.beginPath();g.moveTo(32,4);g.lineTo(58,32);g.lineTo(32,60);g.lineTo(6,32);g.closePath();g.fill();
  g.fillStyle='#fff';g.fillRect(28,16,8,22);g.fillRect(28,42,8,8);return new THREE.CanvasTexture(c);})();
const crimMat=new THREE.SpriteMaterial({map:crimTex,transparent:true,depthTest:false});
// mark an NPC as a wanted criminal: law units that see them move in to arrest
function flagCriminal(q,label){
  if(!q||q.dead||q.out||isLaw(q))return;
  if(!q.crim){q.crim=true;const m=new THREE.Sprite(crimMat);m.scale.set(.55,.55,1);m.position.y=2.35;q.body.g.add(m);q.crimMark=m;
    if(d2(q.pos,actualPos())<120)feed('수배 · 시민 ('+label+')');}
  q.crimT=150;
}
function clearCriminal(q){q.crim=false;if(q.crimMark){q.body.g.remove(q.crimMark);q.crimMark=null;}}
// an NPC hurts another NPC; law units never become criminals, everyone else does if the victim dies
function hurtNpc(v,dmg,att,dir){
  if(!v||v.dead||v.out||v.state==='fly'||v.room)return null;
  v.hp-=dmg;
  if(v.hp<=0){
    v.out=true;knock(v,dir.x*3.5,2.6,dir.z*3.5);
    if(att&&!isLaw(att))npcMurder(att,v);
    return 'kill';
  }
  if(v.state==='down')return 'hit';
  v.stunT=.3;
  if(isLaw(v)){if(att&&!isLaw(att)){flagCriminal(att,'경찰 공격');if(v.state!=='chase'){v.state='arrest';v.foe=att;}}}
  else if(v.kind==='civ'&&!v.role&&!v.ff&&!v.medic&&att&&v.state!=='brawl'&&v.state!=='fight'&&v.state!=='cuffed'&&v.state!=='escorted'){
    if(!v.weapon&&RNG()<.5&&!isLaw(att)){v.state='brawl';v.foe=att;v.fightT=0;} // some shove back
    else if(v.weapon&&!isLaw(att)){v.state='brawl';v.foe=att;v.fightT=0;v.fireT=rand(.3,.6);}
    else{v.state='flee';v.fleeT=rand(5,8);v.threat.copy(att.pos);}
  }
  return 'hit';
}
function npcMurder(att,v){
  flagCriminal(att,'살인');
  // law units in sight respond at once; otherwise a witness phones it in
  let seen=false;
  for(const p of peds){if(!isLaw(p)||p.dead||p.out||p.room||p.state==='chase'||p.state==='arrest')continue;
    if(d2(p.pos,att.pos)<50&&hasLOS(p.pos,att.pos)){p.state='arrest';p.foe=att;seen=true;}}
  if(!seen&&(officialOf(att.pos,50,att)||(peds.some(p=>p.kind==='civ'&&p!==att&&p!==v&&!p.dead&&!p.out&&!p.room&&d2(p.pos,att.pos)<35)&&RNG()<.6)))witnessCalls.push({q:att,t:rand(1,3)});
}
const witnessCalls=[];
// one NPC attacking another: fists up close, guns at range
function npcStrike(p,q,W,d){
  const dir={x:(q.pos.x-p.pos.x)/(d||1),z:(q.pos.z-p.pos.z)/(d||1)};
  if(!p.weapon){p.fireT=rand(W.cd[0],W.cd[1]);if(d>W.range+.3)return;p.punchAnim=.25;hurtNpc(q,W.dmg*2.6,p,dir);return;}
  if(W.burst){if(p.burst<=0)p.burst=randi(W.burst[0],W.burst[1]);p.burst--;p.fireT=p.burst>0?W.cd[0]:rand(W.pause[0],W.pause[1]);}
  else p.fireT=rand(W.cd[0],W.cd[1]);
  const hit=RNG()<Math.min(.9,W.acc*(1-d/70)+.2),spr=hit?.25:2;
  const fx=new V3(p.pos.x+dir.x*.6,p.pos.y+1.35,p.pos.z+dir.z*.6);
  tracer(fx,new V3(q.pos.x+rand(-spr,spr),q.pos.y+1.1+rand(-.4,.4),q.pos.z+rand(-spr,spr)));
  puff(fx,0xffd27a,.12,new V3(),.06,true);scare(fx,16);
  if(hit)hurtNpc(q,W.dmg*(isLaw(p)?4:3),p,dir);
}
// p goes after its foe; returns a move or null when the foe is no longer a target
function fightNpc(p,dt,run){
  const q=p.foe;
  if(!q||q.dead||q.out||q.room||q.state==='cuffed'||q.state==='escorted'){p.foe=null;return null;}
  const dx=q.pos.x-p.pos.x,dz=q.pos.z-p.pos.z,d=Math.hypot(dx,dz)||1;p.yaw=Math.atan2(dx,dz);
  const W=NPC_W[p.weapon&&!p.dropped?p.weapon:'fist'],armed=W!==NPC_W.fist;
  const los=d<W.range+2&&hasLOS(p.pos,q.pos);
  p.fireT-=dt;
  if(los&&d<=W.range&&p.fireT<=0)npcStrike(p,q,W,d);
  const want=armed?Math.min(W.range*.55,11):1.2;
  return !los||d>want?[dx/d,dz/d,run]:[0,0,0];
}
// a law unit making an arrest: shoot it out with an armed suspect, tackle and cuff an unarmed one
function arrestMove(p,dt){
  const q=p.foe;
  if(!q||q.dead||q.out||q.room||q.state==='cuffed'||q.state==='escorted'||!q.crim){p.foe=null;endArrest(p);return null;}
  const run=p.kind==='cop'?5.3:5.8,armed=q.weapon&&!q.dropped;
  if(!armed||q.state==='down'){
    const dx=q.pos.x-p.pos.x,dz=q.pos.z-p.pos.z,d=Math.hypot(dx,dz)||1;p.yaw=Math.atan2(dx,dz);
    if(d<1.5){cuff(q,p);return [0,0,0];}
    if(d>140){p.foe=null;endArrest(p);return null;}
    return [dx/d,dz/d,run];
  }
  return fightNpc(p,dt,run)||[0,0,0];
}
function cuff(q,cop){
  q.state='cuffed';q.cuffT=1.6;q.cop=cop;q.foe=null;q.vel.set(0,0,0);
  if(q.weapon&&!q.dropped){q.dropped=true;}
  if(d2(q.pos,actualPos())<120){feed('경찰이 범인을 체포했다');}
}
function endArrest(p){
  if(p.car2&&!p.car2.dead&&p.car2.ai==='respondWait'){p.state='copReturn';return;}
  const q=peds.find(o=>o.crim&&!o.dead&&!o.out&&!o.room&&o.state!=='cuffed'&&o.state!=='escorted'&&d2(o.pos,p.pos)<50);
  if(q){p.foe=q;return;}
  if(p.role==='gate'){p.state='idle';return;}
  if(p.zone){p.state='patrol';setWalk(p);p.state='patrol';return;}
  p.state='leave';p.lifeT=0;
}
// police car answering a call: drive to the suspect, two officers get out
function dispatchPolice(q){
  if(cars.some(c=>!c.dead&&(c.ai==='respond'||c.ai==='respondWait')&&c.target===q))return true;
  let S=POLICE,bd=1e9;for(const L of LOCS)if(L.type==='police'){const d=d2(L.door,q.pos);if(d<bd){bd=d;S=L;}}
  const sp=rampSpawn(S);if(!sp)return false;
  const c=placeFromRamp(makeCar('police',sp.x,sp.z,sp.h,'respond'),sp);c.target=q;c.crew=2;c.speed=4;c.lifeT=0;c.fieldT=0;
  return true;
}
// ambulance answering a call: to a body lying in the street, or to the player
function dispatchAmbulance(patient){
  const at=patient==='player'?actualPos():patient.pos;
  let H=null,bd=1e9;for(const L of LOCS)if(L.type==='hospital'){const d=d2(L.door,at);if(d<bd){bd=d;H=L;}}
  if(!H)return false;
  // far away, off the road network, or the roads blocked by wrecks: the medical helicopter goes instead
  if(needsAir(H,at)){
    const M=[H,...LOCS.filter(L=>L.type==='hospital'&&L!==H)].map(L=>L.medheli).find(c=>c&&!c.dead&&c.medevac&&c.ai==='parked');
    if(M){M.ai='medRun';M.patient=patient;M.crew=2;M.lifeT=0;M.land=null;M.fixed=false;M.loaded=null;M.treated=false;
      if(patient!=='player'){patient.amb=M;patient.downT=Math.max(patient.downT,220);}
      if(d2(at,actualPos())<400)feed('병원 헬기 출동 · '+(M.home.title||'병원'));return true;}
  }
  {const sp=rampSpawn(H);if(!sp)return false;
    const c=placeFromRamp(makeCar('amb',sp.x,sp.z,sp.h,'ambRun'),sp);c.patient=patient;c.crew=2;c.speed=4;c.lifeT=0;c.fieldT=0;
    if(patient!=='player'){patient.amb=c;patient.downT=Math.max(patient.downT,160);}
    if(d2(at,actualPos())<200)feed('구급차 출동 · '+(H.title||'병원'));
    return true;
  }
}
function needsAir(H,at){
  if(d2(H.door,at)>380||!onMainXZ(at.x,at.z,553.01))return true;
  const dx=at.x-H.door.x,dz=at.z-H.door.z,L=Math.hypot(dx,dz),n=Math.ceil(L/20);
  for(let k=1;k<n;k++){const p={x:H.door.x+dx*k/n,z:H.door.z+dz*k/n},s=segKeyAt(p);if(s&&BLOCKED.has(s))return true;}
  return false;
}
const MED_CRUISE=95;
// an open patch of ground next to the patient, clear of roofs, cars and water
function landSpot(t){
  for(const r of [6,9,12,16,21])for(let k=0;k<10;k++){const a=k/10*Math.PI*2+r,x=t.x+Math.cos(a)*r,z=t.z+Math.sin(a)*r,p={x,z};
    if(inSea(p))continue;const g=onMainXZ(x,z,561)?terrainH(x,z):0;
    if([[0,0],[4,0],[-4,0],[0,4],[0,-4]].every(([ox,oz])=>heliFloor(x+ox,z+oz)<=g+.6)&&freeAt(x,z,5.5)&&hasLOS(new V3(x,1,z),new V3(t.x,1,t.z)))return p;}
  return null;
}
function medFly(c,tx,tz,ty,dt,spd){
  const dx=tx-c.pos.x,dz=tz-c.pos.z,d=Math.hypot(dx,dz);
  if(d>2)c.heading+=clamp(angDiff(c.heading,Math.atan2(dx,dz)),-1.4*dt,1.4*dt);
  const high=c.pos.y>MED_CRUISE-12||d<30,hv=high?Math.min(spd,d*1.1):Math.min(4,d);
  if(d>.01){c.pos.x+=dx/d*hv*dt;c.pos.z+=dz/d*hv*dt;}
  const vy=clamp((ty-c.pos.y)*1.2,-7,9);c.pos.y+=vy*dt;c.speed=hv;c.vy=vy;c.vis=c.heading;
  return Math.hypot(tx-c.pos.x,tz-c.pos.z);
}
function medHeliAI(c,dt){
  c.lifeT+=dt;const H=c.home;
  if(c.ai==='medRun'){
    const tgt=emergTarget(c);
    if(!tgt||c.lifeT>220){c.ai='medBack';c.lifeT=0;return;}
    if(!c.land||d2(c.land,tgt)>24){c.land=landSpot(tgt)||{x:tgt.x+6,z:tgt.z};}
    const fl=heliFloor(c.land.x,c.land.z),dh=medFly(c,c.land.x,c.land.z,d2(c.pos,c.land)<30?fl:MED_CRUISE,dt,34);
    if(dh<1.5&&c.pos.y<=fl+.15){c.pos.y=fl;c.speed=0;deployHelpers(c);c.ai='medWait';c.lifeT=0;}
  } else if(c.ai==='medWait'){
    c.chk=(c.chk||0)-dt;
    if(c.chk<=0){c.chk=.5;const crew=peds.filter(p=>p.car2===c&&!p.dead&&!p.out).length;
      if(crew===0){c.ai='medBack';c.lifeT=0;}
      else if(c.lifeT>90)for(const p of peds)if(p.car2===c&&p.state!=='medReturn')p.state='medReturn';}
  } else {
    const P=H.pad,dh=medFly(c,P.x,P.z,d2(c.pos,P)<25?P.y:MED_CRUISE,dt,34);
    if(dh<1&&c.pos.y<=P.y+.15){c.pos.set(P.x,P.y,P.z);c.speed=0;c.ai='parked';c.fixed=true;c.patient=null;c.land=null;
      if(c.loaded&&c.loaded.length){hospRelease.push({H,looks:c.loaded.slice(),t:rand(4,8)});c.loaded=null;}
      if(d2(c.pos,actualPos())<250)feed('병원 헬기 귀환 · '+(H.title||'병원'));}
  }
}
function spawnMedHeli(L){
  const c=makeCar('pheli',L.pad.x,L.pad.z,0,'parked',{model:'med'});c.pos.y=L.pad.y;c.medevac=true;c.fixed=true;c.home=L;c.hasDriver=false;L.medheli=c;return c;
}
let medT=0;
function updateMedHelis(dt){
  medT-=dt;if(medT>0)return;medT=2;
  for(const L of LOCS){if(L.type!=='hospital'||!L.pad)continue;
    if(L.medheli&&!L.medheli.dead&&L.medheli.medevac)continue;
    L.medheliT=(L.medheliT==null?60:L.medheliT)-2;
    if(L.medheliT<=0&&d2(L.pad,actualPos())>60){L.medheliT=60;spawnMedHeli(L);}}
}
function emergTarget(c){
  if(c.ai==='respond'||c.ai==='respondWait'){const q=c.target;return q&&!q.dead&&!q.room?q.pos:null;}
  const p=c.patient;if(p==='player')return player.inside?null:actualPos();
  return p&&!p.dead?p.pos:null;
}
function emergDrive(c,dt){
  c.lifeT+=dt;
  if(c.ai==='respond'||c.ai==='ambRun'){
    const tgt=emergTarget(c);
    if(!tgt||c.lifeT>150){c.ai='leave';c.lifeT=0;return;}
    const d=d2(c.pos,tgt);
    if(d<(c.ai==='respond'?16:12)){
      driveCar(c,c.speed>1?-1:0,0,true,dt);
      if(Math.abs(c.speed)<1.5){deployHelpers(c);c.ai=c.ai==='respond'?'respondWait':'ambWait';c.hasDriver=false;c.lifeT=0;}
      return;
    }
    c.fieldT-=dt;if(c.fieldT<=0){c.fieldT=2;const n=nearNode(tgt);c.field=n?nodeField(n[0],n[1]):null;}
    {const direct=d<40&&drivable(c.pos,tgt,1.2);smartDrive(c,direct?tgt:routeTarget(c.pos,c.field,tgt),dt,direct?8:16,{lane:!direct,siren:true,ignore:c.patient==='player'?'player':null});}
  } else {
    driveCar(c,0,0,true,dt);
    c.chk=(c.chk||0)-dt;
    if(c.chk<=0){c.chk=.5;
      const crew=peds.filter(p=>p.car2===c&&!p.dead&&!p.out).length;
      if(crew===0){c.ai='leave';c.lifeT=0;c.hasDriver=true;}
      if(c.lifeT>90)for(const p of peds)if(p.car2===c&&p.state!=='copReturn'&&p.state!=='medReturn')p.state=p.medic?'medReturn':'copReturn';
    }
  }
}
function deployHelpers(c){
  const f=fwdOf(c),r={x:-f.z,z:f.x};
  for(let k=0;k<c.crew;k++){
    const s=k?1:-1,x=c.pos.x+r.x*s*(c.w/2+.9),z=c.pos.z+r.z*s*(c.w/2+.9);
    let p;
    if(c.type==='amb'||c.medevac){p=makePed('civ',x,z,{look:MEDIC_LOOK,weapon:null});p.medic=true;p.state='medic';p.task=null;}
    else{p=makePed('cop',x,z,{weapon:RNG()<.3?'shotgun':'pistol'});p.state='arrest';p.foe=c.target;}
    collideCircle(p.pos,.35);p.car2=c;
  }
}
// paramedics: treat the player if they called, then carry away bodies near the ambulance
function medicMove(p,dt){
  const c=p.car2;
  if(!c||c.dead){p.state='leave';p.lifeT=0;return null;}
  if(!p.task){
    if(c.patient==='player'&&!c.treated&&!player.inside&&!player.car&&!dead&&d2(actualPos(),c.pos)<45)p.task='player';
    else{
      const body=peds.find(o=>o.out&&!o.dead&&o.state==='down'&&!o.room&&!o.taken&&d2(o.pos,c.pos)<40&&(o.kind==='civ'));
      if(body){p.task=body;body.taken=p;}else{p.state='medReturn';return null;}
    }
  }
  const t=p.task==='player'?player.pos:p.task.pos;
  if(p.task!=='player'&&p.task.dead){p.task=null;return [0,0,0];}
  const dx=t.x-p.pos.x,dz=t.z-p.pos.z,d=Math.hypot(dx,dz)||1;p.yaw=Math.atan2(dx,dz);
  if(d>1.3){p.kneel=false;return [dx/d,dz/d,3.6];}
  p.kneel=true;p.workT=(p.workT||0)+dt;
  if(p.workT>2.4){
    p.workT=0;p.kneel=false;
    if(p.task==='player'){c.treated=true;if(player.health<100){player.health=100;const paid=charge(TREAT_FEE,'치료비');toast('구급대원이 응급처치를 해줬다 · 치료비 −$'+paid);}else toast('구급대원: 다친 데가 없네요');}
    else{const b=p.task;b.dead=true;(c.loaded||(c.loaded=[])).push(b.lookData);puff(new V3(b.pos.x,b.pos.y+.4,b.pos.z),0xffffff,.4,new V3(0,1,0),.4);p.carrying=true;feed('구급대원이 부상자를 실었다');}
    p.task=null;
  }
  return [0,0,0];
}
// walking back to one's vehicle (escorting a cuffed suspect if there is one)
function returnMove(p){
  const c=p.car2;
  if(!c||c.dead||(c.ai!=='respondWait'&&c.ai!=='ambWait'&&c.ai!=='medWait')){p.state='leave';p.lifeT=0;return null;}
  const dx=c.pos.x-p.pos.x,dz=c.pos.z-p.pos.z,d=Math.hypot(dx,dz)||1;
  if(d<c.half+1.3){
    for(const q of peds)if(q.cop===p&&(q.state==='escorted'||q.state==='cuffed')){q.dead=true;if(d2(q.pos,actualPos())<120)feed('범인 연행 완료');}
    p.dead=true;return null;
  }
  return [dx/d,dz/d,3.2];
}
function escortMove(q,dt){
  const p=q.cop;
  if(!p||p.dead||p.out){q.dead=true;return null;} // walked off with the officer
  if(q.state==='cuffed'){q.cuffT-=dt;if(q.cuffT<=0){q.state='escorted';clearCriminal(q);if(p.state==='arrest')endArrest(p);}return [0,0,0];}
  const dx=p.pos.x-q.pos.x,dz=p.pos.z-q.pos.z,d=Math.hypot(dx,dz)||1;
  return d>1.4?[dx/d,dz/d,Math.min(4,d*1.5)]:[0,0,0];
}
// criminals react to officers closing in: the unarmed run, the armed shoot back
function crimReact(q){
  if(!q.crim||q.state==='cuffed'||q.state==='escorted'||q.state==='down'||q.state==='fly')return;
  const cop=peds.find(p=>p.foe===q&&p.state==='arrest'&&!p.dead&&!p.out&&d2(p.pos,q.pos)<20);
  if(!cop)return;
  if(q.weapon&&!q.dropped){if(q.state!=='brawl'||q.foe!==cop){q.state='brawl';q.foe=cop;q.fightT=0;q.fireT=rand(.3,.7);}}
  else if(q.state!=='flee'){q.state='flee';q.fleeT=rand(6,9);q.threat.copy(cop.pos);}
  else q.threat.copy(cop.pos);
}
// now and then two passers-by get into it
let brawlT=rand(60,95);
function maybeBrawl(dt){
  brawlT-=dt;if(brawlT>0)return;brawlT=rand(75,135);
  if(player.inside||dead)return;
  const tp=actualPos(),walkers=peds.filter(p=>p.kind==='civ'&&p.state==='walk'&&!p.role&&!p.room&&!p.ff&&!p.medic&&!p.dead&&d2(p.pos,tp)>15&&d2(p.pos,tp)<70);
  for(const a of walkers){
    const b=walkers.find(o=>o!==a&&d2(o.pos,a.pos)<18);if(!b)continue;
    a.state='brawl';a.foe=b;a.fightT=0;a.fireT=rand(.4,.8);
    if(RNG()<.6){b.state='brawl';b.foe=a;b.fightT=0;b.fireT=rand(.5,.9);}else{b.state='flee';b.fleeT=rand(5,8);b.threat.copy(a.pos);}
    feed('근처에서 싸움이 붙었다');return;
  }
}
// a public servant who can see the spot: officers, soldiers, firefighters and paramedics on foot, or a crewed emergency vehicle
function officialOf(at,r,not){
  for(const p of peds){if(p===not||p.dead||p.out||p.room||p.state==='down'||p.crim)continue;
    if((p.kind!=='civ'||p.ff||p.medic)&&d2(p.pos,at)<r&&d2(p.pos,at)>1&&hasLOS(p.pos,at))return p;}
  for(const c of cars){if(c.dead||!c.hasDriver||c===player.car||!(c.type==='police'||c.type==='swat'||c.type==='fire'||c.type==='amb'||c.type==='army'))continue;
    if(d2(c.pos,at)<r&&hasLOS(c.pos,at))return c;}
  return null;
}
const offName=o=>o.pos&&o.half?({police:'순찰차',swat:'특공대 차량',fire:'소방차',amb:'구급차',army:'군용 차량'}[o.type]||'공무 차량'):o.ff?'소방관':o.medic?'구급대원':o.kind==='soldier'?'군인':'경찰관';
// a civilian on their feet who can see the spot
function witnessOf(at,r){return peds.find(o=>o.kind==='civ'&&!o.dead&&!o.out&&!o.room&&!o.crim&&!o.ff&&!o.medic&&o.state!=='down'&&d2(o.pos,at)<r&&d2(o.pos,at)>1.2&&hasLOS(o.pos,at));}
const emCalls=[];
function updateJustice(dt){
  maybeBrawl(dt);maybeNpcRob(dt);
  for(let i=emCalls.length-1;i>=0;i--){const e=emCalls[i];e.t-=dt;if(e.t>0)continue;emCalls.splice(i,1);
    const o=e.o,near=d2(o.pos,actualPos())<150;
    if(e.kind==='amb'){
      if(o.dead||o.out||o.state!=='down'||o.amb)continue;
      if(cars.some(c=>!c.dead&&c.type==='amb'&&c.ai==='ambRun'&&c.patient&&c.patient!=='player'&&!c.patient.dead&&d2(c.patient.pos,o.pos)<35))continue;
      if(cars.filter(c=>!c.dead&&c.type==='amb'&&(c.ai==='ambRun'||c.ai==='ambWait')).length>=3){e.t=8;emCalls.push(e);continue;}
      if(dispatchAmbulance(o)&&near)feed(e.off?e.off+'이 구급차를 요청했다':e.w?'목격한 시민이 119에 구급차를 불렀다':'누군가 119에 쓰러진 사람을 신고했다');
    } else {
      if(o.dead)continue;
      if(near)feed(e.off?e.off+'이 화재를 신고했다':e.w?'시민이 119에 화재를 신고했다':'누군가 119에 화재를 신고했다');
    }
  }
  for(let i=witnessCalls.length-1;i>=0;i--){const w=witnessCalls[i];w.t-=dt;if(w.t>0)continue;witnessCalls.splice(i,1);
    if(w.q.crim&&!w.q.dead&&!w.q.out&&!peds.some(p=>p.foe===w.q&&isLaw(p))){dispatchPolice(w.q);if(d2(w.q.pos,actualPos())<120)feed('목격자가 경찰에 신고했다');}}
}
// every so often: law units notice criminals near them, criminals' records cool off, bodies get an ambulance
function justiceScan(){
  const tp=actualPos();
  for(const q of peds){
    if(!q.crim||q.dead)continue;
    if(q.out){clearCriminal(q);continue;}
    q.crimT-=.8;if(q.crimT<=0&&!peds.some(p=>p.foe===q)){clearCriminal(q);continue;}
    crimReact(q);
    for(const p of peds){
      if(!isLaw(p)||p.dead||p.out||p.room||p.foe===q)continue;
      if(!(p.state==='patrol'||p.state==='idle'||p.state==='leave'||p.state==='walk'))continue;
      if(p.role==='gate'&&d2(p.pos,p.home)>60)continue;
      if(d2(p.pos,q.pos)<45&&hasLOS(p.pos,q.pos)){p.state='arrest';p.foe=q;p.fireT=rand(.4,.9);}
    }
    for(const c of cars){if(c.ai!=='patrol'||c.dead||d2(c.pos,q.pos)>50||!hasLOS(c.pos,q.pos))continue;
      c.speed=0;c.ai='respondWait';c.target=q;c.hasDriver=false;c.lifeT=0;deployHelpers(c);break;}
  }
  // bodies: sometimes the hospital sends an ambulance
  let ambs=cars.filter(c=>!c.dead&&c.type==='amb'&&(c.ai==='ambRun'||c.ai==='ambWait')).length;
  // nobody sends an ambulance unless someone phones it in: a passer-by who sees the body usually does
  for(const p of peds){
    if(!p.out||p.dead||p.room||p.kind!=='civ'||p.medic||p.state!=='down'||p.amb||p.reported)continue;
    p.seenT=(p.seenT||0)+.8;
    {const off=officialOf(p.pos,45,p);if(off){p.reported=true;emCalls.push({kind:'amb',o:p,t:rand(1,3),off:offName(off)});continue;}}
    if(p.seenT>40)continue;
    if(!p.wDone&&witnessOf(p.pos,35)){p.wDone=true;if(RNG()<.75){p.reported=true;emCalls.push({kind:'amb',o:p,t:rand(4,8),w:true});}}
    if(!p.fallRolled){p.fallRolled=true;if(RNG()<.1){p.reported=true;emCalls.push({kind:'amb',o:p,t:rand(15,20)});}}
  }
  for(const f of fires){
    if(f.dead||f.reported)continue;
    f.seenT=(f.seenT||0)+.8;
    {const off=officialOf(f.pos,60);if(off){f.reported=true;emCalls.push({kind:'fire',o:f,t:rand(1,3),off:offName(off)});continue;}}
    if(!f.wDone&&witnessOf(f.pos,50)){f.wDone=true;if(RNG()<.8){f.reported=true;emCalls.push({kind:'fire',o:f,t:rand(4,9),w:true});}}
    if(!f.fallRolled&&f.seenT>3){f.fallRolled=true;if(RNG()<.1){f.reported=true;emCalls.push({kind:'fire',o:f,t:rand(12,18)});}}
  }
}

// ---------- phone ----------
let phoneOpen=false,phoneMode='main';const phoneCD={police:0,amb:0,fire:0,tow:0,wreck:0,taxi:0};
const TOW_FEE=120,TREAT_FEE=150;
function charge(amt,label){const paid=Math.min(player.money,amt);player.money-=paid;feed(label+' −$'+paid.toLocaleString());return paid;}
function nearestBody(){const ap=actualPos();let b=null,bd=150;for(const p of peds){if(!p.out||p.dead||p.room||p.state!=='down'||p.kind!=='civ'||p.amb)continue;const d=d2(p.pos,ap);if(d<bd){bd=d;b=p;}}return b?{b,d:bd}:null;}
function myCarToTow(){
  if(player.car&&!isBoat(player.car)&&player.car.type!=='pheli')return player.car;
  const ap=actualPos();let best=null,bd=220;
  for(const c of cars){if(!c.owned||c.dead||c.ai==='towed'||isBoat(c)||c.type==='pheli'||(c.tow&&!c.tow.dead))continue;const d=d2(c.pos,ap);if(d<bd){bd=d;best=c;}}
  return best;
}
// the nearest crashed or burnt-out car that isn't mine and nobody is towing yet
function accidentCar(){
  const ap=actualPos();let best=null,bd=120;
  for(const c of cars){if(c.dead||c.owned||c===player.car||isBoat(c)||c.type==='pheli'||(c.tow&&!c.tow.dead))continue;
    if(!(c.ai==='wreck'||(c.ai==='parked'&&c.crashed)))continue;const d=d2(c.pos,ap);if(d<bd){bd=d;best=c;}}
  return best?{c:best,d:bd}:null;
}
function phoneItems(){
  if(phoneMode==='tow'){
    const my=myCarToTow(),ac=accidentCar();
    return [
      {k:'1',id:'tow',label:'내 차 견인 · 수리',desc:my?'견인비 $'+TOW_FEE+' + 수리비':'근처에 내 차가 없어요',cls:'tow',dis:!my,act:()=>callService('tow')},
      {k:'2',id:'wreck',label:'사고 차량 신고',desc:ac?(ac.c.ai==='wreck'?'불탄 차':'사고 난 차')+' · '+Math.round(ac.d)+'m · 무료':'근처에 사고 차량이 없어요',cls:'tow',dis:!ac,act:()=>callService('wreck')},
      {k:'3',label:'뒤로',desc:'',cls:'back',act:()=>{phoneMode='main';renderPhone();}}
    ];
  }
  if(phoneMode==='amb'){
    const nb=nearestBody();
    return [
      {k:'1',label:'내 위치로',desc:'구급대원이 치료해 줘요 · 치료비 $'+TREAT_FEE,cls:'amb',act:()=>callAmb('me')},
      {k:'2',label:'쓰러진 사람에게',desc:nb?'가장 가까운 부상자 · '+Math.round(nb.d)+'m':'근처에 쓰러진 사람이 없어요',cls:'amb',dis:!nb,act:()=>callAmb('body')},
      {k:'3',label:'뒤로',desc:'',cls:'back',act:()=>{phoneMode='main';renderPhone();}}
    ];
  }
  return [
    {k:'1',id:'police',label:'112 경찰',desc:'날 때리는 사람 · 범죄자를 잡아가요',cls:'',act:()=>callService('police')},
    {k:'2',id:'amb',label:'119 구급대',desc:'내 위치 또는 쓰러진 사람에게',cls:'amb',act:()=>{phoneMode='amb';renderPhone();}},
    {k:'3',id:'fire',label:'119 소방서',desc:'근처 불을 꺼 줘요',cls:'fire',act:()=>callService('fire')},
    {k:'4',label:'카센터',desc:'내 차 견인 · 수리 / 사고 차량 신고',cls:'tow',act:()=>{phoneMode='tow';renderPhone();}},
    {k:'5',id:'taxi',label:'택시 부르기',desc:taxiLive()?'택시가 오는 중 · '+Math.round(d2(TAXI.c.pos,actualPos()))+'m':'내 위치로 · 기본 $'+TAXI_BASE+' + 100m당 $'+Math.round(TAXI_PER_M*100),cls:'taxi',dis:!!taxiLive(),act:callTaxi}
  ];
}
function openPhone(){
  if(!started||dead||paused||phoneOpen)return;
  if(menu)closeMenu();
  phoneOpen=true;phoneMode='main';input.keys={};input.fireHeld=false;input.punch=false;input.joy.x=input.joy.y=0;
  $('phone').hidden=false;$('phStatus').textContent='';renderPhone();
  try{if(document.pointerLockElement)document.exitPointerLock();}catch(e){}
}
function closePhone(){if(!phoneOpen)return;phoneOpen=false;$('phone').hidden=true;canvas.focus();if(!coarse)tryLock(true);}
let phoneShown='';
function renderPhone(){
  const h=Math.floor(tod),m=Math.floor((tod-h)*60);$('phClock').textContent=String(h).padStart(2,'0')+':'+String(m).padStart(2,'0');
  $('phoneTitle').textContent=phoneMode==='amb'?'구급차를 어디로?':phoneMode==='tow'?'카센터 · 하버 모터스':'긴급 전화';
  const items=phoneItems(),sig=phoneMode+items.map(it=>it.desc+(it.dis?1:0)+(it.id?Math.ceil(phoneCD[it.id]):'')).join('|');
  if(sig===phoneShown)return;phoneShown=sig;
  const list=$('phList');list.innerHTML='';
  for(const it of items){
    const b=document.createElement('button');b.type='button';b.className='phBtn '+it.cls;
    const cd=it.id&&phoneCD[it.id]>0;b.disabled=!!it.dis||cd;
    const k=document.createElement('kbd');k.textContent=it.k;
    const sp=document.createElement('span'),bb=document.createElement('b'),sm=document.createElement('small');
    bb.textContent=it.label;sm.textContent=cd?'통화 중 · '+Math.ceil(phoneCD[it.id])+'초 뒤 다시':it.desc;sp.append(bb,sm);
    b.append(k,sp);b.addEventListener('click',()=>{if(!b.disabled)it.act();});list.appendChild(b);
  }
}
function phoneKey(n){const it=phoneItems()[n-1];if(it&&!it.dis&&!(it.id&&phoneCD[it.id]>0))it.act();}
function phoneSay(t){$('phStatus').textContent=t;toast(t);phoneShown='';}
function callAmb(where){
  if(phoneCD.amb>0)return;
  phoneMode='main';
  if(where==='me'){
    if(player.inside){phoneSay('119: "건물 밖으로 나와서 다시 걸어 주세요."');return;}
    if(dispatchAmbulance('player')){phoneSay('119: "구급차가 출동했습니다. 그 자리에 계세요. 치료비는 $'+TREAT_FEE+'입니다."');phoneCD.amb=40;}
    else phoneSay('119: "구급차가 모두 출동 중이에요."');
  } else {
    const nb=nearestBody();if(!nb){phoneSay('119: "부상자가 보이지 않네요."');return;}
    if(dispatchAmbulance(nb.b)){phoneSay('119: "부상자에게 구급차를 보냈습니다."');phoneCD.amb=30;}else phoneSay('119: "구급차가 모두 출동 중이에요."');
  }
  renderPhone();
}
function callService(k){
  if(phoneCD[k]>0)return;
  const ap=actualPos();
  if(k==='police'){
    if(wanted.stars>0){phoneSay('112: "수배자 신고는 본인이 자수하러 오시죠."');phoneCD.police=10;return;}
    const threats=peds.filter(p=>!p.dead&&!p.out&&!p.room&&p.kind==='civ'&&!p.ff&&!p.medic&&d2(p.pos,ap)<80&&
      (p.state==='fight'||p.crim||p.state==='brawl'||p.state==='robPoi'));
    if(!threats.length){phoneSay('112: "출동할 만한 일은 없어 보이네요."');phoneCD.police=8;return;}
    threats.sort((a,b)=>d2(a.pos,ap)-d2(b.pos,ap));
    for(const q of threats)flagCriminal(q,q.state==='fight'?'폭행 신고':q.state==='robPoi'?'절도 신고':'신고');
    let sent=0;for(const q of threats.slice(0,2))if(dispatchPolice(q))sent++;
    phoneSay(sent?'112: "순찰차를 보냈습니다. 안전한 곳에 계세요."':'112: "지금은 보낼 차가 없어요. 잠시 뒤 다시 걸어 주세요."');phoneCD.police=sent?25:6;
  } else if(k==='fire'){
    const f=fires.filter(f=>!f.dead).sort((a,b)=>d2(a.pos,ap)-d2(b.pos,ap))[0];
    if(!f||d2(f.pos,ap)>160){phoneSay('119: "근처에 화재 신고가 들어온 곳이 없네요."');phoneCD.fire=8;return;}
    f.truck=null;f.reported=true;
    if(dispatchTruck(f)){phoneSay('119: "소방차가 출동했습니다."');phoneCD.fire=30;}else phoneSay('119: "소방차가 모두 나가 있어요."');
  } else if(k==='wreck'){
    phoneMode='main';
    const ac=accidentCar();if(ac)ac.c.accRep=true;
    if(!ac){phoneSay('카센터: "근처에 사고 차량이 안 보이네요."');phoneCD.wreck=5;return;}
    if(dispatchTow(ac.c,false)){phoneSay('카센터: "신고 감사합니다. 견인차가 사고 차량을 치우러 갑니다."');phoneCD.wreck=20;}
    else phoneSay('카센터: "지금은 견인차가 다 나갔어요."');
  } else if(k==='tow'){
    phoneMode='main';
    const c=myCarToTow();
    if(!c){phoneSay('카센터: "견인할 손님 차가 근처에 안 보이네요."');phoneCD.tow=5;return;}
    if(dispatchTow(c,true)){phoneSay('카센터: "견인차 보냈습니다. '+(c===player.car?'차에서 내려서 ':'')+'기다려 주세요. 견인비 $'+TOW_FEE+'에 수리비는 따로예요."');phoneCD.tow=30;}
    else phoneSay('카센터: "지금은 견인차가 다 나갔어요."');
  }
  renderPhone();
}

// ---------- surrender: hands up in front of the police, get cuffed, serve a reduced sentence ----------
function trySurrender(){
  if(!started||dead||player.surrender)return;
  if(player.car){toast('차에서 내려서 손을 들어야 한다');return;}
  if(wanted.stars===0){toast('수배 중이 아니다');return;}
  if(player.inside){toast('밖에서 경찰이 보이는 곳에 서서 항복하세요');return;}
  const ap=player.pos,sees=o=>d2(o.pos,ap)<55&&hasLOS(o.pos,ap);
  const law=peds.some(p=>isLaw(p)&&!p.dead&&!p.out&&!p.room&&sees(p))||cars.some(c=>!c.dead&&c.ai==='chase'&&sees(c));
  if(!law){toast('항복할 경찰이 안 보인다 · 경찰이 보이는 곳에서 H');return;}
  player.surrender={t:0,cuffT:-1};player.crouch=false;job=null;robbing=null;
  if(player.weapon!=='fist'){player.prevWeapon2=player.weapon;player.weapon='fist';}
  toast('항복! 손을 들었다 · 움직이거나 공격하면 취소');feed('경찰에게 항복');
}
function cancelSurrender(msg){
  if(!player.surrender)return;player.surrender=null;
  if(player.prevWeapon2&&player.owned[player.prevWeapon2])player.weapon=player.prevWeapon2;player.prevWeapon2=null;
  if(msg)toast(msg);
}
function updateSurrender(dt){
  const S=player.surrender;if(!S)return;
  S.t+=dt;
  if(wanted.stars===0||player.car||player.inside){cancelSurrender();return;}
  if(S.cuffT>=0){
    S.cuffT+=dt;
    if(S.cuffT>1.6&&!transFn){
      const stars=wanted.stars;let L=POLICE,bd=1e9;for(const o of LOCS)if(o.type==='police'){const d=d2(o.door,player.pos);if(d<bd){bd=d;L=o;}}
      if(player.prevWeapon2&&player.owned[player.prevWeapon2])player.weapon=player.prevWeapon2;player.prevWeapon2=null;
      player.surrender=null;
      const sent=Math.max(15,Math.round(sentenceFor(stars)*.7));
      goJail(sent,L);toast('체포됐다 · 자진 항복으로 형기 감경 ('+sent+'초)');
    }
    return;
  }
  if(S.t>35)cancelSurrender('아무도 체포하러 오지 않았다 · 항복 취소');
}

// ---------- now and then someone else robs a mailbox or a cash machine ----------
let npcRobT=rand(80,140);
const poiBusy=P=>P.busy&&!P.busy.dead&&!P.busy.out&&P.busy.state==='robPoi';
function maybeNpcRob(dt){
  npcRobT-=dt;if(npcRobT>0)return;npcRobT=rand(110,200);
  if(player.inside||dead)return;
  const tp=actualPos(),list=pois.filter(q=>q.cd<=0&&!poiBusy(q)&&d2(q.pos,tp)>18&&d2(q.pos,tp)<90);if(!list.length)return;
  const P=pick(list);
  const thief=peds.find(p=>p.kind==='civ'&&p.state==='walk'&&!p.role&&!p.room&&!p.ff&&!p.medic&&!p.dead&&!p.crim&&d2(p.pos,P.at)<35&&drivable(p.pos,P.at,.4));
  if(!thief)return;
  thief.state='robPoi';thief.poi=P;thief.robT=0;thief.seeT=0;thief.lifeT=0;P.busy=thief;
}
function robPoiMove(p,dt){
  const P=p.poi;if(!P){calm(p);return null;}
  const dx=P.at.x-p.pos.x,dz=P.at.z-p.pos.z,d=Math.hypot(dx,dz)||1,mail=P.type==='mail';
  p.lifeT=(p.lifeT||0)+dt;
  if(d>.7){if(p.lifeT>30){P.busy=null;p.poi=null;calm(p);return null;}return [dx/d,dz/d,1.9];}
  p.yaw=Math.atan2(P.pos.x-p.pos.x,P.pos.z-p.pos.z);p.prying=true;p.robT+=dt;
  if(RNG()<dt*3)puff(new V3(P.pos.x+rand(-.2,.2),1.1,P.pos.z+rand(-.2,.2)),0xffd27a,.07,new V3(rand(-1,1),rand(1,2),rand(-1,1)),.2,true);
  p.seeT-=dt;
  if(p.seeT<=0){p.seeT=.5; // anyone in uniform watching?
    if(!p.crim&&peds.some(o=>isLaw(o)&&!o.dead&&!o.out&&!o.room&&d2(o.pos,p.pos)<40&&hasLOS(o.pos,p.pos)))flagCriminal(p,mail?'우체통 털이':'ATM 털이');}
  if(p.robT>(mail?5:9)){
    P.cd=300;P.busy=null;p.poi=null;p.prying=false;p.wallet=(mail?randi(2,12):randi(30,120))*10;
    if(!p.crim&&(officialOf(p.pos,35,p)||(peds.some(o=>o!==p&&o.kind==='civ'&&!o.dead&&!o.out&&!o.room&&d2(o.pos,p.pos)<25)&&RNG()<.35))){flagCriminal(p,'절도');witnessCalls.push({q:p,t:rand(1,3)});}
    if(d2(p.pos,actualPos())<60)feed('누군가 '+(mail?'우체통':'ATM')+'을 털어 달아났다');
    p.state='flee';p.fleeT=rand(7,10);p.threat.copy(P.pos);
    return null;
  }
  return [0,0,0];
}

// ---------- hands-on jobs: prying a mailbox or ATM, digging through scrap ----------
let job=null;
function startJob(o){if(job||robbing||escaping)return;job=Object.assign({t:0},o);toast(o.start);}
function updateJob(dt){
  if(!job||transFn)return;
  if(job.poi&&!job.seen){job.seeT=(job.seeT||0)-dt;if(job.seeT<=0){job.seeT=.4;const ap=player.pos;
    const cop=peds.find(p=>isLaw(p)&&!p.dead&&!p.out&&!p.room&&d2(p.pos,ap)<40&&hasLOS(p.pos,ap))||cars.find(c=>!c.dead&&(c.type==='police'||c.type==='swat')&&c.hasDriver&&d2(c.pos,ap)<40&&hasLOS(c.pos,ap));
    if(cop){job.seen=true;const mail=job.poi.type==='mail';setStars(Math.max(wanted.stars,mail?1:2));crime(0,ap,mail?'우체통 털이':'ATM 털이');toast('순찰 경찰에게 들켰다! 수배');}}}
  if(player.car||player.inside!==job.room||d2(player.pos,job.at)>2.2){toast(job.label+' 중단');job=null;return;}
  if(job.mil){job.seeT=(job.seeT||0)-dt;if(job.seeT<=0){job.seeT=.3;
    const spot=peds.find(p=>p.kind==='soldier'&&!p.dead&&!p.out&&!p.room&&p.state!=='down'&&(()=>{const dx=player.pos.x-p.pos.x,dz=player.pos.z-p.pos.z,d=Math.hypot(dx,dz)||1;
      return d<32&&(d<8||(Math.sin(p.yaw)*dx+Math.cos(p.yaw)*dz)/d>.25)&&hasLOS(p.pos,player.pos);})());
    if(spot){job=null;setStars(Math.max(wanted.stars,3));crime(0,player.pos,'군 시설 침입 발각');toast('군인에게 들켰다! · 수배 ★3');return;}}}
  job.t+=dt;if(job.t>=job.dur){const j=job;job=null;j.done();}
}
function lootHeap(h){
  const n=randi(1,3),got={};
  for(let k=0;k<n;k++){const m=rollMat(LOOT[h.loot]);player.mats[m]++;got[m]=(got[m]||0)+1;}
  const txt=Object.keys(got).map(k=>MATS[k]+' +'+got[k]).join(' · ');
  toast('찾았다 · '+txt);feed('고물 · '+txt);h.cd=90;
}
function useSpot(z){
  if(z.kind==='heap'){
    const h=z.heap;if(h.cd>0){toast('더 쓸 만한 게 없다 · '+Math.ceil(h.cd)+'초 뒤');return;}
    startJob({label:'고물 뒤지는 중',dur:3,at:h.pos,room:player.inside,start:'고물 더미를 뒤지는 중…',done:()=>lootHeap(h)});
    return;
  }
  const P=z.poi,mail=P.type==='mail';
  if(poiBusy(P)){toast('누가 먼저 털고 있다');return;}
  if(P.cd>0){toast((mail?'우체통':'ATM')+'이 비어 있다 · '+Math.ceil(P.cd)+'초 뒤');return;}
  if(!player.tools.crowbar){toast('크로우바가 필요하다 · I로 제작');return;}
  if(!mail&&!player.tools.drill){toast('조잡한 드릴도 필요하다 · I로 제작');return;}
  startJob({label:mail?'우체통 따는 중':'ATM 뚫는 중',dur:mail?2.5:6,at:P.at,room:null,poi:P,start:mail?'크로우바로 우체통을 비트는 중…':'드릴로 ATM 금고를 뚫는 중…',done:()=>{
    const amt=mail?randi(2,12)*10:randi(40,150)*10;player.money+=amt;P.cd=mail?180:300;wearTool('crowbar');if(!mail)wearTool('drill');
    feed((mail?'우체통':'ATM')+' +$'+amt);scare(player.pos,mail?8:20);
    if(RNG()<(mail?.1:.45)){crime(mail?1.5:3,player.pos,mail?'우체통 털이':'ATM 털이');toast((mail?'우체통':'ATM')+' 털기 성공 · +$'+amt+' · 신고가 들어갔다!');}
    else toast((mail?'우체통':'ATM')+' 털기 성공 · +$'+amt);
  }});
}

// ---------- crafting ----------
const RECIPES=[
  {id:'crowbar',name:'크로우바',desc:'우체통을 비틀어 열 수 있다. ATM을 뜯을 때도 필요하다. 8번 쓰면 망가진다.',need:{pipe:2,scrap:2}},
  {id:'drill',name:'조잡한 드릴',desc:'크로우바와 함께 쓰면 ATM 금고를 뚫을 수 있다. 5번 쓰면 망가진다.',need:{motor:1,battery:1,bit:1,tape:2}}
];
let craftOpen=false;
const canCraft=R=>!player.tools[R.id]&&Object.keys(R.need).every(k=>player.mats[k]>=R.need[k]);
function renderCraft(){
  const ml=$('matList');ml.innerHTML='';
  for(const k in MATS){const d=document.createElement('div');d.className='mat'+(player.mats[k]?'':' zero');
    const n=document.createElement('span');n.textContent=MATS[k];const b=document.createElement('b');b.textContent=player.mats[k];d.append(n,b);ml.appendChild(d);}
  const rl=$('recipeList');rl.innerHTML='';
  for(const R of RECIPES){
    const box=document.createElement('div');box.className='recipe';
    const h=document.createElement('h3');h.textContent=R.name;
    const p=document.createElement('p');p.textContent=R.desc;
    const nd=document.createElement('div');nd.className='needs';
    for(const k in R.need){const sp=document.createElement('span');const ok=player.mats[k]>=R.need[k];sp.className=ok?'ok':'no';sp.textContent=MATS[k]+' '+player.mats[k]+'/'+R.need[k];nd.appendChild(sp);}
    box.append(h,p,nd);
    if(player.tools[R.id]){const o=document.createElement('span');o.className='have';o.textContent=player.tools[R.id].pro?'보유 중 · 무한':'보유 중 · 내구도 '+player.tools[R.id].dur+'/'+TOOL_DUR[R.id];box.appendChild(o);}
    else{const b=document.createElement('button');b.type='button';b.className='btn';b.textContent='제작';b.disabled=!canCraft(R);
      b.addEventListener('click',()=>craft(R));box.appendChild(b);}
    rl.appendChild(box);
  }
}
function craft(R){
  if(!canCraft(R))return;
  for(const k in R.need)player.mats[k]-=R.need[k];
  player.tools[R.id]={dur:TOOL_DUR[R.id]};feed(R.name+' 제작 완료');toast(R.name+' 제작 완료');renderCraft();
}
function openCraft(){
  if(!started||dead||craftOpen||mapOpen)return;
  if(menu)closeMenu();
  craftOpen=true;paused=true;input.keys={};input.fireHeld=false;input.punch=false;input.joy.x=input.joy.y=0;
  $('craft').hidden=false;
  try{if(document.pointerLockElement)document.exitPointerLock();}catch(e){}
  renderCraft();
}
function closeCraft(){if(!craftOpen)return;craftOpen=false;paused=false;$('craft').hidden=true;canvas.focus();if(!coarse)tryLock(true);}

// ---------- input ----------
const input={keys:{},joy:{x:0,y:0},punch:false,fireHeld:false,f:false,v:false,e:false,g:false,c:false,q:0,sel:null,reload:false,jumpHeld:false};
let camYaw=0,camPitch=-.18,carYawOff=0,lastLookT=9,view='third',started=false,lockFailed=false;
// ---------- pause ----------
let paused=false,pauseAt=0,phoneT=0;
function setPaused(on){
  if(on===paused)return;
  if(on&&(!started||dead))return;
  if(on&&phoneOpen)closePhone();
  paused=on;$('paused').hidden=!on;if(!on)$('tutorial').hidden=true;
  input.keys={};input.fireHeld=false;input.punch=false;input.joy.x=input.joy.y=0;
  if(on){pauseAt=performance.now();try{if(document.pointerLockElement)document.exitPointerLock();}catch(e){}}
  else{canvas.focus();if(!coarse)tryLock(true);}
}
addEventListener('keydown',e=>{
  if(NET.chatActive())return; // typing in the chat box
  if(e.code==='Tab'&&started){e.preventDefault();NET.togglePlayers();return;}
  if(introOpen){e.preventDefault();
    if(e.code==='ArrowRight'||e.code==='Enter'||e.code==='Space'||e.code==='KeyD')introStep(1);
    else if(e.code==='ArrowLeft'||e.code==='KeyA')introStep(-1);
    else if(e.code==='Escape')closeIntro();
    return;}
  if(phoneOpen){
    const dg=/^(?:Digit|Numpad)([1-9])$/.exec(e.code);if(dg){e.preventDefault();phoneKey(+dg[1]);return;}
    if(e.code==='Backspace'&&phoneMode!=='main'){e.preventDefault();phoneMode='main';renderPhone();return;}
    if(e.code==='KeyP'||e.code==='Escape'){e.preventDefault();pauseAt=performance.now();closePhone();}
    return;}
  if(mapOpen){if(e.code==='KeyM'||e.code==='Escape'){e.preventDefault();pauseAt=performance.now();closeMap();}
    else if(e.code==='Equal'||e.code==='NumpadAdd'){e.preventDefault();bigZoomAt(1.5);}else if(e.code==='Minus'||e.code==='NumpadSubtract'){e.preventDefault();bigZoomAt(1/1.5);}
    else if(/^Arrow|^Key[WASD]$/.test(e.code)&&bigView){e.preventDefault();const st=bigView.H*.25,c=e.code;if(c==='ArrowLeft'||c==='KeyA')BIG.cx-=st;if(c==='ArrowRight'||c==='KeyD')BIG.cx+=st;if(c==='ArrowUp'||c==='KeyW')BIG.cz-=st;if(c==='ArrowDown'||c==='KeyS')BIG.cz+=st;drawBig();}
    return;}
  if(craftOpen){if(e.code==='KeyI'||e.code==='Escape'){e.preventDefault();pauseAt=performance.now();closeCraft();}return;}
  if((((e.code==='Enter'||e.code==='NumpadEnter')&&!paused)||e.code==='KeyT')&&started&&!menu&&$('tutorial').hidden&&!endingOpen&&!NET.offline){e.preventDefault();openChat();return;}
  if(e.code==='KeyM'&&started&&!dead&&!paused&&!menu){e.preventDefault();openMap();return;}
  if(e.code==='KeyI'&&started&&!dead&&!paused&&!menu){e.preventDefault();openCraft();return;}
  if((e.code==='AltLeft'||e.code==='AltRight')&&started&&!dead&&!paused){e.preventDefault();
    if(document.pointerLockElement){hudCursor=true;document.exitPointerLock();toast('마우스 커서 모드 · 미니맵 · 휴대폰 · 키 버튼을 클릭하세요 · 화면을 클릭하면 돌아갑니다');}else if(!coarse)tryLock(true);return;}
  if(e.code==='KeyP'&&started&&!dead&&!paused&&!menu){e.preventDefault();openPhone();return;}
  if(!$('tutorial').hidden){if(e.code==='Escape'){e.preventDefault();pauseAt=performance.now();closeTutorial();}return;}
  if(menu){
    if(/^Digit[1-9]$/.test(e.code)){e.preventDefault();choose(+e.code.slice(5)-1);}
    else if(e.code==='Escape'||e.code==='KeyE'||e.code==='KeyF'){e.preventDefault();closeMenu();}
    return;
  }
  if(e.code==='Escape'){
    if(performance.now()-pauseAt<350)return; // the same Esc that released the mouse already paused
    if(endingOpen)return;
    if(started&&!dead)setPaused(!paused);
    return;
  }
  if(paused)return;
  if(['Space','ArrowUp','ArrowDown','ArrowLeft','ArrowRight'].includes(e.code))e.preventDefault();
  input.keys[e.code]=true; if(e.repeat) return;
  if(e.code==='KeyF')input.f=true; if(e.code==='KeyV')input.v=true; if(e.code==='KeyJ')input.punch=true;
  if(e.code==='KeyE')input.e=true; if(e.code==='KeyQ')input.q=1; if(e.code==='KeyG')input.g=true; if(e.code==='KeyH')input.h=true; if(e.code==='KeyC'||e.code==='ControlLeft')input.c=true;
  const dg=/^Digit([1-6])$/.exec(e.code); if(dg)input.sel=ORDER[+dg[1]-1];
  if(e.code==='KeyR'){if(dead)respawn();else input.reload=true;}
});
addEventListener('keyup',e=>{input.keys[e.code]=false;});
addEventListener('blur',()=>{input.keys={};input.fireHeld=false;});
let wheelT=0;
canvas.addEventListener('wheel',e=>{e.preventDefault();const n=performance.now();if(n-wheelT>200){wheelT=n;input.q=e.deltaY<0?-1:1;}},{passive:false});
function look(dx,dy,s){
  lastLookT=0;
  if(player.car){carYawOff-=dx*s;camPitch=clamp(camPitch-dy*s,-.9,.45);}
  else{camYaw-=dx*s;camPitch=clamp(camPitch-dy*s,-1.25,1.05);}
}
let lockSilent=false;
function tryLock(silent){
  lockSilent=!!silent;
  try{const r=canvas.requestPointerLock&&canvas.requestPointerLock();if(r&&r.catch)r.catch(()=>{if(!silent)lockFailed=true;});}catch(e){if(!silent)lockFailed=true;}
}
document.addEventListener('pointerlockerror',()=>{if(!lockSilent)lockFailed=true;});
let hudCursor=false;
document.addEventListener('pointerlockchange',()=>{
  if(document.pointerLockElement===canvas){hudCursor=false;return;}
  if(hudCursor){input.fireHeld=false;return;} // Alt freed the cursor to click the HUD: keep playing
  input.fireHeld=false;
  // Esc (or leaving the window) released the mouse mid-game: pause instead of leaving the player live
  if(started&&!dead&&!menu&&!paused&&!transFn&&!phoneOpen)setPaused(true);
});
let drag=null;
canvas.addEventListener('mousedown',e=>{
  if(!started||dead||menu||paused||phoneOpen) return; canvas.focus();
  if(document.pointerLockElement===canvas){if(e.button===0){input.punch=true;input.fireHeld=true;}}
  else{drag={x:e.clientX,y:e.clientY,moved:0};if(lockFailed&&e.button===0){input.punch=true;input.fireHeld=true;}}
});
addEventListener('mousemove',e=>{
  if(document.pointerLockElement===canvas) look(e.movementX,e.movementY,.0024);
  else if(drag){const dx=e.clientX-drag.x,dy=e.clientY-drag.y;drag.moved+=Math.abs(dx)+Math.abs(dy);look(dx,dy,.005);drag.x=e.clientX;drag.y=e.clientY;}
});
addEventListener('mouseup',e=>{input.fireHeld=false;if(drag){if(drag.moved<6&&e.button===0&&!lockFailed)tryLock();drag=null;}});
canvas.addEventListener('contextmenu',e=>e.preventDefault());

const coarse=(window.matchMedia&&matchMedia('(pointer: coarse)').matches)||('ontouchstart' in window&&navigator.maxTouchPoints>0);
if(coarse){container.classList.add('coarse');$('touch').hidden=false;$('mapKey').textContent='탭하면 지도';}
let joyId=null,lookId=null,lookLast=null;
const joy=$('joy'),knob=$('joyKnob');
joy.addEventListener('touchstart',e=>{e.preventDefault();const t=e.changedTouches[0];joyId=t.identifier;joyMove(t);},{passive:false});
function joyMove(t){const r=joy.getBoundingClientRect();let x=t.clientX-(r.left+r.width/2),y=t.clientY-(r.top+r.height/2);const m=Math.hypot(x,y),max=50;if(m>max){x=x/m*max;y=y/m*max;}input.joy.x=x/max;input.joy.y=y/max;knob.style.transform='translate('+x+'px,'+y+'px)';}
canvas.addEventListener('touchstart',e=>{e.preventDefault();for(const t of e.changedTouches){if(lookId===null){lookId=t.identifier;lookLast={x:t.clientX,y:t.clientY};}}},{passive:false});
addEventListener('touchmove',e=>{for(const t of e.changedTouches){if(t.identifier===joyId){e.preventDefault();joyMove(t);}else if(t.identifier===lookId){e.preventDefault();look(t.clientX-lookLast.x,t.clientY-lookLast.y,.006);lookLast={x:t.clientX,y:t.clientY};}}},{passive:false});
function endTouch(e){for(const t of e.changedTouches){if(t.identifier===joyId){joyId=null;input.joy.x=input.joy.y=0;knob.style.transform='';}if(t.identifier===lookId)lookId=null;}}
addEventListener('touchend',endTouch);addEventListener('touchcancel',endTouch);
const tb=(id,down,up)=>{const b=$(id);b.addEventListener('touchstart',e=>{e.preventDefault();down();},{passive:false});b.addEventListener('touchend',e=>{e.preventDefault();up&&up();},{passive:false});b.addEventListener('click',()=>{down();up&&setTimeout(up,120);});};
tb('bWeapon',()=>input.q=1);tb('bReload',()=>input.reload=true);
tb('bPunch',()=>{input.punch=true;input.fireHeld=true;},()=>{input.fireHeld=false;});
tb('bEnter',()=>{if(player.car&&currentZone())input.e=true;else input.f=true;});tb('bCrouch',()=>{input.c=true;input.descend=true;},()=>{input.descend=false;});tb('bCraft',()=>{if(!paused)openCraft();});tb('bSurrender',()=>input.h=true);tb('bPhone',()=>{if(phoneOpen)closePhone();else if(!paused)openPhone();});tb('bView',()=>input.v=true);tb('bChat',()=>openChat());tb('bJump',()=>input.jumpHeld=true,()=>input.jumpHeld=false);

function startGame(){started=true;$('start').hidden=true;$('tutorial').hidden=true;canvas.focus();openIntro('start');}
$('startBtn').addEventListener('click',startGame);
// ---------- save / load through a downloaded file ----------
const SAVE_VER=1;
function saveData(){
  const P=player,at=P.inside?{x:P.inside.door.x+P.inside.out.x*2,z:P.inside.door.z+P.inside.out.z*2}:P.car?{x:P.car.pos.x,z:P.car.pos.z}:{x:P.pos.x,z:P.pos.z};
  return {game:'neon-harbor',v:SAVE_VER,savedAt:new Date().toISOString(),money:P.money,bank:P.bank,health:P.health,hunger:P.hunger,weapon:P.weapon,
    owned:P.owned,ammo:P.ammo,mats:P.mats,tools:P.tools,kits:P.kits,keys:P.keys,ores:P.ores,pickaxe:P.pickaxe,tod,pos:at,playT,
    cars:cars.filter(c=>!c.dead&&c.owned&&c.ai!=='wreck'&&c.ai!=='towed').map(c=>({type:c.type,model:c.model||null,color:c.color,x:c.pos.x,y:c.pos.y,z:c.pos.z,h:c.heading,fuel:c.fuel,health:c.health,price:c.price||0,driving:c===P.car}))};
}
// on claude.ai the viewer's download permission goes through the downloads capability; a plain file gets a browser download
let dlCap;
if(window.claude&&window.claude.use)window.claude.use('downloads').then(d=>{dlCap=d;}).catch(()=>{dlCap=null;});
async function downloadSave(){
  const txt=JSON.stringify(saveData()),t=new Date(),pad=n=>String(n).padStart(2,'0');
  const name='neon-harbor-save-'+t.getFullYear()+pad(t.getMonth()+1)+pad(t.getDate())+'-'+pad(t.getHours())+pad(t.getMinutes())+'.json';
  if(dlCap){
    try{await dlCap.save({filename:name,data:txt});toast('저장 파일을 내려받았다');$('saveNote').textContent='저장 완료 · '+name;}
    catch(e){const c=e&&e.code;if(c==='declined')toast('저장을 취소했다');else if(c==='rate_limited')toast('잠시 뒤 다시 저장해 주세요');else toast('이 화면에서는 저장 파일을 받을 수 없어요');}
    return;
  }
  try{
    const b=new Blob([txt],{type:'application/json'}),a=document.createElement('a');
    a.href=URL.createObjectURL(b);a.download=name;
    document.body.appendChild(a);a.click();setTimeout(()=>{URL.revokeObjectURL(a.href);a.remove();},1500);
    toast('저장 파일을 내려받았다');$('saveNote').textContent='저장 완료 · '+name;
  }catch(e){toast('저장 실패 · 브라우저가 파일 내려받기를 막았어요');}
}
function applySave(d){
  if(!d||d.game!=='neon-harbor'){toast('네온 하버 저장 파일이 아니다');return false;}
  const P=player;
  if(P.car)exitCar(false);P.inside=null;P.ride=null;P.hotel=null;job=null;closeMenu();
  for(const k of ['money','bank','health','hunger'])if(typeof d[k]==='number')P[k]=d[k];
  for(const k of ['owned','ammo','mats','kits','keys','ores'])if(d[k])Object.assign(P[k],d[k]);
  if(d.tools)P.tools=Object.assign({},d.tools);P.pickaxe=d.pickaxe||null;
  if(d.weapon&&P.owned[d.weapon])P.weapon=d.weapon;
  for(const c of cars)if(c.owned&&!c.dead)c.dead=true;
  let drive=null;
  for(const q of d.cars||[]){if(!CAR_STATS[q.type])continue;
    const c=makeCar(q.type,q.x,q.z,q.h||0,'parked',{model:q.model||undefined,color:q.color});
    if(q.type==='pheli')c.pos.y=q.y||0;c.owned=true;c.mine=true;c.price=q.price;c.fuel=q.fuel;if(q.health)c.health=q.health;c.ownedAt=clock;if(q.driving)drive=c;}
  if(d.pos){P.pos.set(d.pos.x,0,d.pos.z);P.pos.y=floorH(P.pos.x,P.pos.z);}
  if(typeof d.tod==='number'){tod=d.tod;applyDaylight();}
  if(typeof d.playT==='number')playT=d.playT;
  setStars(0);camSnap=true;
  if(drive){P.pos.set(drive.pos.x+3,0,drive.pos.z);enterCar(drive);}
  toast('불러오기 완료 · '+(d.savedAt?d.savedAt.slice(0,16).replace('T',' '):''));return true;
}
function readSaveFile(file,then){
  const r=new FileReader();r.onload=()=>{let d=null;try{d=JSON.parse(r.result);}catch(e){toast('저장 파일을 읽을 수 없다');return;}then(d);};r.readAsText(file);
}
let loadFrom='pause';
$('saveBtn').addEventListener('click',downloadSave);
$('loadBtn').addEventListener('click',()=>{loadFrom='pause';$('loadFile').value='';$('loadFile').click();});
$('startLoad').addEventListener('click',()=>{loadFrom='start';$('loadFile').value='';$('loadFile').click();});
$('loadFile').addEventListener('change',e=>{const f=e.target.files&&e.target.files[0];if(!f)return;
  readSaveFile(f,d=>{if(!d||d.game!=='neon-harbor'){toast('네온 하버 저장 파일이 아니다');return;}
    if(loadFrom==='start'&&!started){startGame();closeIntro();}
    if(applySave(d)&&paused)setPaused(false);});});
$('tutStart').addEventListener('click',startGame);
// tutorial opens from the main screen or from the pause screen and returns to whichever opened it
let tutFrom='start';
function openTutorial(from){tutFrom=from;$(from).hidden=true;$('tutorial').hidden=false;$('tutStart').hidden=from!=='start';
  $('tutBack').textContent=from==='start'?'메인 화면으로':'일시정지 화면으로';$('tutorial').scrollTop=0;$('tutBack').focus();}
function closeTutorial(){$('tutorial').hidden=true;$(tutFrom).hidden=false;(tutFrom==='start'?$('tutBtn'):$('pauseTut')).focus();}
$('tutBtn').addEventListener('click',()=>openTutorial('start'));
$('pauseTut').addEventListener('click',()=>openTutorial('paused'));
$('endContinue').addEventListener('click',closeEnding);$('endRestart').addEventListener('click',()=>location.reload());
$('tutBack').addEventListener('click',closeTutorial);
// ---------- first-run guide: eight illustrated cards ----------
const C_={amber:'#ffb53d',red:'#ff3b4e',blue:'#3f8cff',green:'#61e08e',purple:'#d35bff',text:'#f4efe4',muted:'#8f8aa6',panel:'#1d2038',line:'#3a3e5c',ink:'#0b0d1c'};
const sv=(inner)=>'<svg viewBox="0 0 320 180" role="img" aria-hidden="true">'+inner+'</svg>';
const keyB=(x,y,w,label,on)=>'<rect x="'+x+'" y="'+y+'" width="'+w+'" height="26" rx="4" fill="'+(on?C_.amber:C_.panel)+'" stroke="'+(on?C_.amber:C_.line)+'" stroke-width="1.5"/><text x="'+(x+w/2)+'" y="'+(y+17.5)+'" text-anchor="middle" font-size="12" font-weight="700" font-family="JetBrains Mono,monospace" fill="'+(on?C_.ink:C_.text)+'">'+label+'</text>';
const lbl=(x,y,t,c,anchor,size)=>'<text x="'+x+'" y="'+y+'" text-anchor="'+(anchor||'middle')+'" font-size="'+(size||11)+'" font-family="Noto Sans KR,sans-serif" font-weight="500" fill="'+(c||C_.muted)+'">'+t+'</text>';
const star=(x,y,r,on)=>{let d='';for(let k=0;k<10;k++){const a=-Math.PI/2+k*Math.PI/5,rr=k%2?r*.45:r;d+=(k?'L':'M')+(x+Math.cos(a)*rr).toFixed(1)+' '+(y+Math.sin(a)*rr).toFixed(1);}return '<path d="'+d+'Z" fill="'+(on?C_.amber:'none')+'" stroke="'+(on?C_.amber:C_.line)+'" stroke-width="1.5"/>';};
const person=(x,y,c,s)=>{s=s||1;return '<g transform="translate('+x+' '+y+') scale('+s+')"><circle cx="0" cy="-30" r="7" fill="'+c+'"/><rect x="-7" y="-22" width="14" height="20" rx="3" fill="'+c+'"/><rect x="-6" y="-2" width="5" height="16" rx="2" fill="'+c+'"/><rect x="1" y="-2" width="5" height="16" rx="2" fill="'+c+'"/></g>';};
const car=(x,y,c,s)=>{s=s||1;return '<g transform="translate('+x+' '+y+') scale('+s+')"><rect x="-30" y="-14" width="60" height="16" rx="5" fill="'+c+'"/><path d="M-18 -14 L-11 -26 L12 -26 L19 -14Z" fill="'+c+'" opacity=".85"/><path d="M-14 -15 L-9 -23 L10 -23 L15 -15Z" fill="'+C_.ink+'" opacity=".6"/><circle cx="-17" cy="3" r="6" fill="#111"/><circle cx="17" cy="3" r="6" fill="#111"/></g>';};
const coin=(x,y,r)=>'<circle cx="'+x+'" cy="'+y+'" r="'+r+'" fill="'+C_.green+'"/><text x="'+x+'" y="'+(y+r*.38)+'" text-anchor="middle" font-size="'+(r*1.1)+'" font-weight="700" font-family="JetBrains Mono,monospace" fill="'+C_.ink+'">$</text>';
const arrow=(x1,y1,x2,y2,c)=>{const a=Math.atan2(y2-y1,x2-x1),h=7;return '<line x1="'+x1+'" y1="'+y1+'" x2="'+x2+'" y2="'+y2+'" stroke="'+(c||C_.amber)+'" stroke-width="2.5" stroke-linecap="round"/><path d="M'+x2+' '+y2+' L'+(x2-h*Math.cos(a-.5))+' '+(y2-h*Math.sin(a-.5))+' L'+(x2-h*Math.cos(a+.5))+' '+(y2-h*Math.sin(a+.5))+'Z" fill="'+(c||C_.amber)+'"/>';};
const k=t=>'<kbd>'+t+'</kbd>';
function introSlides(){
  const T=coarse;
  return [
    {eye:'1 / 기본 조작',title:'걷고, 보고, 타기',
     art:sv(T?
       '<circle cx="70" cy="110" r="44" fill="'+C_.panel+'" stroke="'+C_.line+'" stroke-width="2"/><circle cx="82" cy="98" r="18" fill="'+C_.amber+'" opacity=".8"/>'+lbl(70,170,'왼쪽 조이스틱 · 이동')+
       '<path d="M150 70 q30 -30 60 0" fill="none" stroke="'+C_.muted+'" stroke-width="2" stroke-dasharray="4 4"/>'+lbl(180,52,'화면 드래그 · 시점')+
       ['사격','탑승','점프','시점'].map((t,i)=>'<circle cx="'+(240+(i%2)*46)+'" cy="'+(96+Math.floor(i/2)*46)+'" r="19" fill="'+(i?C_.panel:C_.amber)+'" stroke="'+C_.line+'"/><text x="'+(240+(i%2)*46)+'" y="'+(100+Math.floor(i/2)*46)+'" text-anchor="middle" font-size="11" font-weight="700" fill="'+(i?C_.text:C_.ink)+'" font-family="Noto Sans KR,sans-serif">'+t+'</text>').join('')
      :keyB(64,52,30,'W',1)+keyB(30,82,30,'A',1)+keyB(64,82,30,'S',1)+keyB(98,82,30,'D',1)+lbl(80,128,'이동')+keyB(16,140,58,'Shift')+lbl(45,176,'달리기')+keyB(84,140,90,'Space')+lbl(129,176,'점프 · 브레이크')+
       '<rect x="250" y="34" width="52" height="80" rx="26" fill="'+C_.panel+'" stroke="'+C_.line+'" stroke-width="2"/><line x1="276" y1="34" x2="276" y2="68" stroke="'+C_.line+'" stroke-width="2"/><path d="M250 68 V60 a26 26 0 0 1 26 -26 V68Z" fill="'+C_.amber+'"/>'+lbl(276,134,'움직이면 시점')+lbl(276,150,'왼쪽 클릭 사격')+
       keyB(150,52,26,'E',1)+keyB(182,52,26,'F',1)+keyB(214,52,26,'V')+lbl(195,96,'E 이용 · F 차',C_.muted)+lbl(195,112,'V 시점 전환',C_.muted)),
     body:T?'<li>왼쪽 조이스틱으로 걷고, 화면을 끌어서 둘러봐요.</li><li><b>탑승</b> 버튼으로 차에 타고 내려요. 건물 앞 빛나는 원에서는 같은 버튼이 <b>이용</b>으로 바뀌어요.</li><li><b>시점</b>은 1인칭 ↔ 3인칭.</li>'
       :'<li>'+k('WASD')+' 이동, 마우스로 시점. '+k('Shift')+' 달리기, '+k('Space')+' 점프.</li><li>'+k('F')+' 차 타기 · 뺏기 · 내리기. '+k('E')+' 건물 앞 빛나는 원에서 들어가기 · 이용.</li><li>'+k('V')+' 1인칭 ↔ 3인칭, '+k('Esc')+' 일시정지.</li>'},
    {eye:'2 / 수배 단계',title:'별이 늘수록 더 센 추격대',
     art:sv([0,1,2,3,4].map(i=>star(48+i*56,46,20,true)).join('')+
       lbl(48,86,'경찰',C_.text)+lbl(104,86,'순찰차',C_.text)+lbl(160,86,'특수부대',C_.text)+lbl(216,86,'군대',C_.text)+lbl(272,86,'헬기',C_.text)+
       '<rect x="40" y="110" width="240" height="44" rx="8" fill="'+C_.panel+'" stroke="'+C_.line+'"/><path d="M62 132 q14 -14 28 0 q-14 14 -28 0Z" fill="none" stroke="'+C_.muted+'" stroke-width="2"/><line x1="58" y1="144" x2="94" y2="120" stroke="'+C_.red+'" stroke-width="2.5"/>'+
       lbl(186,129,'추격대 눈에 안 띄고 20초',C_.text,'middle',12)+lbl(186,146,'→ 별 하나 감소',C_.amber,'middle',12)),
     body:'<li>사람을 치거나, 차를 뺏거나, 총을 쏘면 별이 붙어요. 큰 범죄일수록 많이 올라요.</li><li>★1–2 경찰, ★3 특수부대, ★4 군대, ★5 공격 헬기. 해상에선 해군 경비정도 쫓아와요.</li><li>시야에서 <b>20초</b> 사라지면 별이 하나씩 줄어요. 경찰서에서 자수하거나 보석금을 낼 수도 있어요.</li>'},
    {eye:'3 / 돈 벌기 ①',title:'차를 훔쳐 팔고, 주머니를 털고',
     art:sv(car(62,82,'#2e86c1',1.1)+arrow(104,76,148,76)+'<rect x="152" y="46" width="64" height="44" rx="4" fill="'+C_.panel+'" stroke="#37e6ff" stroke-width="2"/>'+lbl(184,74,'카센터','#7ff3ff','middle',12)+arrow(220,68,248,68)+coin(270,68,16)+
       lbl(160,112,'훔친 차를 카센터 원 안에 세우면 팔기',C_.muted,'middle',11)+
       person(60,166,C_.amber,.8)+person(92,166,'#8a9aaa',.8)+'<rect x="78" y="134" width="12" height="9" rx="2" fill="'+C_.green+'"/>'+lbl(190,150,'G · 소매치기  50% 성공',C_.text,'middle',12)+lbl(190,166,'실패하면 시민과 싸움',C_.red,'middle',11)),
     body:'<li>'+(T?'<b>탑승</b> 버튼':k('F'))+'으로 차를 뺏어 <b>카센터</b>로 몰고 가면 팔 수 있어요. 관용차는 더 비싸요. 주차 차의 절반은 잠겨 있어 <b>차량 배선 따개</b>(총포상 암시장)가 필요해요.</li><li>걸어가는 시민 옆에서 '+(T?'<b>이용</b> 버튼':k('G'))+' → 소매치기 $10–200. 반은 들켜서 싸움이 나요.</li><li>은행 · 편의점 · 식당 카운터에서 총을 겨누면 털 수도 있어요.</li>'},
    {eye:'4 / 돈 벌기 ②',title:'쓰레기, 우체통, ATM',
     art:sv('<path d="M30 70 q8 -18 22 -6 q10 -14 18 2 q4 18 -18 20 q-24 2 -22 -16Z" fill="#e8e2d4"/>'+arrow(80,70,108,70)+'<rect x="114" y="46" width="34" height="44" rx="3" fill="#2f6b45"/><rect x="110" y="42" width="42" height="7" rx="2" fill="#1f4a30"/>'+lbl(90,108,'주워서 쓰레기통에',C_.muted)+coin(170,68,12)+
       '<rect x="194" y="40" width="30" height="40" rx="6" fill="#c0392b"/><rect x="202" y="52" width="14" height="3" fill="#1a0a08"/><rect x="202" y="80" width="14" height="14" fill="#2a2a2e"/>'+lbl(209,112,'크로우바',C_.text,'middle',10)+lbl(209,126,'10% 수배',C_.red,'middle',10)+
       '<rect x="262" y="34" width="40" height="60" rx="3" fill="#3a4250"/><rect x="268" y="42" width="28" height="18" fill="#5fd0ff"/><rect x="274" y="66" width="16" height="10" fill="#7dffa8"/>'+lbl(282,112,'크로우바+드릴',C_.text,'middle',10)+lbl(282,126,'45% 수배',C_.red,'middle',10)+
       '<rect x="30" y="140" width="260" height="26" rx="6" fill="'+C_.panel+'" stroke="'+C_.line+'"/>'+lbl(160,157,'도구는 '+(T?'제작 버튼':'I 제작')+'으로 만들어요',C_.amber,'middle',12)),
     body:'<li>바닥의 쓰레기를 주워 초록 쓰레기통에 버리면 개당 $2–6 (최대 10개).</li><li>빨간 <b>우체통</b>: 크로우바로 2.5초 · $20–120 · 10% 확률로 수배.</li><li><b>ATM</b>: 크로우바와 드릴로 6초 · $400–1,500 · 45% 확률로 수배. 순찰 경찰 눈앞에서 따면 바로 수배!</li><li>초록 <b>쓰레기통</b>을 '+(T?'이용':k('E'))+'로 뒤지면 폐품 · 잔돈이 나와요.</li>'},
    {eye:'5 / 허기',title:'배고프면 쓰러져요',
     art:sv('<rect x="40" y="40" width="240" height="18" rx="4" fill="'+C_.panel+'" stroke="'+C_.line+'"/><rect x="42" y="42" width="70" height="14" rx="3" fill="'+C_.red+'"/>'+lbl(40,32,'허기',C_.muted,'start')+lbl(280,32,'0이 되면 쓰러짐',C_.red,'end')+
       '<path d="M70 120 h60 a30 22 0 0 1 -60 0Z" fill="#e8e2d4"/><path d="M78 114 q22 -14 44 0" fill="none" stroke="#ff8a3d" stroke-width="5"/>'+lbl(100,160,'식당 · 한 끼',C_.text,'middle',12)+
       '<rect x="196" y="92" width="56" height="44" rx="3" fill="#e9e6ee"/><rect x="196" y="86" width="56" height="10" fill="#8f4dff"/><rect x="204" y="104" width="16" height="22" fill="#ffc53d"/><rect x="226" y="104" width="16" height="22" fill="#4ec27a"/>'+lbl(224,160,'편의점 · 간식 · 버프',C_.text,'middle',12)),
     body:'<li>허기 바는 약 8분에 걸쳐 줄어요. 25 아래면 경고, <b>0이면 쓰러져요</b>.</li><li>식당은 배를 든든히 채워 주고, 편의점은 싼 간식과 이동속도 · 재장전 · 방어 버프를 팔아요.</li><li>수영하면 배가 더 빨리 고파져요.</li>'},
    {eye:'6 / 제작',title:'폐품을 모아 도구 만들기',
     art:sv('<rect x="30" y="66" width="56" height="10" rx="5" fill="#8a5a32" transform="rotate(-20 58 71)"/><rect x="36" y="92" width="40" height="24" rx="3" fill="#6a6a72"/>'+lbl(58,140,'폐품 · 고물 더미',C_.text,'middle',12)+lbl(58,156,'고물상 · 광산 갱도',C_.muted)+
       '<text x="110" y="100" font-size="30" fill="'+C_.muted+'">→</text>'+
       '<rect x="146" y="50" width="70" height="70" rx="8" fill="'+C_.panel+'" stroke="'+C_.amber+'" stroke-width="2"/><path d="M164 106 L196 66 l8 4 l-4 6" fill="none" stroke="#c0c4cc" stroke-width="6" stroke-linecap="round" stroke-linejoin="round"/>'+lbl(181,140,'크로우바',C_.amber,'middle',12)+lbl(181,156,'파이프2 · 고철2',C_.muted,'middle',10)+
       '<rect x="236" y="50" width="70" height="70" rx="8" fill="'+C_.panel+'" stroke="'+C_.line+'" stroke-width="2"/><rect x="250" y="74" width="30" height="20" rx="4" fill="#d8a020"/><rect x="280" y="80" width="18" height="6" fill="#c0c4cc"/><rect x="258" y="94" width="10" height="16" fill="#3a3a40"/>'+lbl(271,140,'조잡한 드릴',C_.text,'middle',12)+lbl(271,155,'모터·배터리',C_.muted,'middle',10)+lbl(271,169,'비트·테이프2',C_.muted,'middle',10)),
     body:'<li>바닥의 녹슨 <b>폐품</b>을 줍거나, 고물상과 광산 갱도의 <b>고물 더미</b>에서 '+(T?'이용':k('E'))+'로 3초 뒤지면 재료가 나와요.</li><li>'+(T?'<b>제작</b> 버튼':k('I'))+'으로 제작 창을 열어 크로우바(8회)와 조잡한 드릴(5회)을 만들어요. 다 쓰면 망가져요.</li><li>총포상 주인과 대화하면 안 망가지는 <b>단단한 크로우바</b> · <b>전동 드릴</b>, 차량 · 군용 차량 <b>배선 따개</b>를 팔아요.</li>'},
    {eye:'7 / 내비게이션과 운전',title:'지도에 찍으면 길을 알려줘요',
     art:sv('<rect x="24" y="24" width="132" height="132" rx="6" fill="#1c2f52" stroke="'+C_.line+'"/><rect x="34" y="34" width="112" height="112" fill="#4a4c5e"/>'+[0,1,2].map(i=>[0,1,2].map(j=>'<rect x="'+(38+i*37)+'" y="'+(38+j*37)+'" width="30" height="30" fill="#2a2c40"/>').join('')).join('')+
       '<path d="M52 140 V109 H127 V58" fill="none" stroke="'+C_.purple+'" stroke-width="5" stroke-linejoin="round" stroke-linecap="round"/><circle cx="127" cy="52" r="9" fill="'+C_.purple+'" stroke="#fff" stroke-width="2"/><path d="M52 132 l6 12 l-6 -4 l-6 4Z" fill="'+C_.amber+'"/>'+
       keyB(176,40,30,'M',1)+lbl(214,57,'지도 · 장소 고르기',C_.text,'start',12)+car(220,124,'#c0392b',1.05)+lbl(220,160,'사고 난 길은 피해서',C_.muted,'middle',11)),
     body:'<li>'+(T?'미니맵을 탭':k('M'))+'하면 큰 지도가 열려요. 아이콘이나 빈 곳을 누르면 보라색 경로와 빛기둥으로 안내해요.</li><li>운전은 '+(T?'조이스틱':k('W')+k('S')+' 가속 · 후진, '+k('A')+k('D')+' 조향')+', '+(T?'점프 버튼':k('Space'))+'은 핸드브레이크. 훔친 차는 내 차로 남아요(하늘색 네모).</li><li>차를 몰고 카센터 원에 서면 수리 · 판매 · 구매. 기름이 떨어지면 <b>주유소</b>에서 '+(T?'이용':k('E'))+'(1%당 $1). <b>빨간불</b>에는 서고(교통경찰 앞 신호 위반 $10), 차는 <b>파란 P</b> 주차 구역 · 주차장에 세워요. 아무 데나 180초 넘게 두면 시청으로 견인($20).</li>'},
    {eye:'8 / 전투',title:'쏘고, 숨고, 버티기',
     art:sv('<circle cx="80" cy="80" r="34" fill="none" stroke="'+C_.text+'" stroke-width="2.5"/><line x1="80" y1="36" x2="80" y2="56" stroke="'+C_.text+'" stroke-width="2.5"/><line x1="80" y1="104" x2="80" y2="124" stroke="'+C_.text+'" stroke-width="2.5"/><line x1="36" y1="80" x2="56" y2="80" stroke="'+C_.text+'" stroke-width="2.5"/><line x1="104" y1="80" x2="124" y2="80" stroke="'+C_.text+'" stroke-width="2.5"/>'+
       (T?lbl(80,150,'사격 버튼 · 길게 누르면 연사',C_.text,'middle',11):lbl(80,150,'클릭 사격 · 꾹 누르면 연사',C_.text,'middle',11))+
       car(236,96,'#7f8c8d',1.15)+person(196,110,C_.amber,.7)+'<path d="M180 56 l28 -4" stroke="'+C_.red+'" stroke-width="2" stroke-dasharray="3 3"/>'+lbl(236,134,(T?'웅크리기':'C')+' + 차 뒤 = 엄폐',C_.text,'middle',12)+
       [1,2,3,4,5,6].map(i=>keyB(150+(i-1)*27,148,23,String(i),i===2)).join('')),
     body:'<li>'+(T?'<b>무기</b> 버튼':k('1')+'–'+k('6')+' 또는 '+k('Q'))+'으로 무기 선택, '+(T?'<b>장전</b>':k('R'))+' 재장전. 총과 탄창은 총포상에서, 쓰러진 적에게서도 주울 수 있어요.</li><li>'+(T?'<b>웅크리기</b>':k('C'))+'로 웅크리면 덜 맞고, 차나 낮은 벽 뒤면 거의 안 맞아요.</li><li>위험하면 '+(T?'<b>폰</b> 버튼':k('P'))+'으로 112 · 119에 전화하세요. 날 때리는 사람은 경찰이 잡아가요.</li>'},
    {eye:'9 / 도시 생활',title:'버스, 호텔, 은행',
     art:sv('<rect x="20" y="58" width="96" height="40" rx="6" fill="#2fa35a"/><rect x="28" y="64" width="80" height="14" fill="#18202e"/><circle cx="40" cy="100" r="7" fill="#111"/><circle cx="96" cy="100" r="7" fill="#111"/>'+lbl(68,128,'초록 정류장 · 공항버스',C_.text,'middle',11)+
       '<rect x="134" y="34" width="64" height="76" rx="3" fill="#cfc6b4"/>'+[0,1,2,3].map(r=>[0,1,2].map(c=>'<rect x="'+(142+c*18)+'" y="'+(42+r*16)+'" width="10" height="9" fill="#ffd890"/>').join('')).join('')+lbl(166,128,'호텔 · 자고 나면 아침',C_.text,'middle',11)+
       '<path d="M222 56 L262 36 L302 56Z" fill="#d9cfb6"/><rect x="226" y="58" width="72" height="44" fill="#d9cfb6"/>'+[0,1,2,3].map(i=>'<rect x="'+(232+i*17)+'" y="62" width="7" height="36" fill="#ece4d0"/>').join('')+lbl(262,128,'은행 예금 · 이자 1%',C_.text,'middle',11)+
       lbl(160,160,'지도의 P · 주차장, 초록 점 · 버스 정류장',C_.muted,'middle',11)),
     body:'<li>버스 1번 · 2번이 시내를, 파란 <b>공항버스</b>가 다리 건너 공항을 오가요. 정류장(지도의 초록 점)에 선 버스 옆에서 '+(T?'이용':k('E'))+'로 <b>$1</b> 내고 탈 수 있고, 다음 정류장에서 다시 '+(T?'이용':k('E'))+'로 내려요.</li><li><b>호텔</b> 프런트에서 1박 예약 → 엘리베이터로 객실. 침대에서 자면 아침 7시, 체력 회복. 노트북으로 웹 서핑, 1층 라운지에서 식사.</li><li><b>은행</b> 창구에서 예금 · 출금. 매일 자정 이자 1%가 붙어요.</li>'},
    {eye:'10 / 광산과 공항',title:'곡괭이로 캐고, 비행기로 떠나기',
     art:sv('<path d="M40 130 L80 60 L120 130Z" fill="#5a5048"/><path d="M60 110 l14 -10 l10 12Z" fill="#d8a84a"/><path d="M86 116 l10 -8 l8 10Z" fill="#c9c9d2"/>'+
       '<g transform="rotate(-30 150 80)"><rect x="146" y="60" width="8" height="60" rx="2" fill="#8a5a32"/><path d="M126 62 q24 -16 48 0 l-4 6 q-20 -10 -40 0Z" fill="#9aa0a8"/></g>'+lbl(110,154,'곡괭이 $120 · 광석 팔기',C_.text,'middle',11)+
       '<path d="M214 104 l70 -34 l6 6 l-22 18 l10 22 l-6 2 l-16 -18 l-30 14Z" fill="#f4f6f8"/>'+lbl(254,140,'항공권 $100,000',C_.amber,'middle',12)+lbl(254,156,'= 엔딩',C_.text,'middle',11)),
     body:'<li>광산 갱도 안 <b>광부</b>에게 곡괭이(내구도 30)를 사서, 갱도 벽의 <b>광맥</b>(노란 원)에서 석탄 · 철 · 구리 · 은 · 금을 캐고 광부에게 팔아요.</li><li>국제공항 <b>터미널</b> 안 발권 카운터에서 본토행 항공권 <b>$100,000</b>을 사면 섬을 떠나는 엔딩. 수배 중엔 출국할 수 없어요.</li>'}
  ];
}
let introOpen=false,introI=0,introFrom='start',INTRO=null;
function renderIntro(){
  const S=INTRO[introI];
  $('introArt').innerHTML=S.art;$('introEye').textContent=S.eye;$('introTitle').textContent=S.title;$('introBody').innerHTML=S.body;
  $('introCount').textContent=(introI+1)+' / '+INTRO.length;
  $('introDots').innerHTML=INTRO.map((_,i)=>'<button type="button" class="dot'+(i===introI?' on':'')+'" aria-label="'+(i+1)+'번 카드" data-i="'+i+'"></button>').join('');
  $('introPrev').disabled=introI===0;
  $('introNext').textContent=introI===INTRO.length-1?(introFrom==='start'?'시작하기':'닫기'):'다음';
}
function openIntro(from){
  INTRO=INTRO||introSlides();introFrom=from;introOpen=true;paused=true;introI=0;
  input.keys={};input.fireHeld=false;input.punch=false;input.joy.x=input.joy.y=0;
  if(from==='pause')$('paused').hidden=true;
  $('intro').hidden=false;renderIntro();
  try{if(document.pointerLockElement)document.exitPointerLock();}catch(e){}
  setTimeout(()=>{try{$('introNext').focus();}catch(e){}},30);
}
function closeIntro(){
  if(!introOpen)return;introOpen=false;$('intro').hidden=true;pauseAt=performance.now();
  if(introFrom==='pause'){$('paused').hidden=false;$('resumeBtn').focus();return;}
  paused=false;canvas.focus();if(!coarse)tryLock();
}
function introStep(d){const n=introI+d;if(n<0)return;if(n>=INTRO.length){closeIntro();return;}introI=n;renderIntro();}
$('introNext').addEventListener('click',()=>introStep(1));
$('introPrev').addEventListener('click',()=>introStep(-1));
$('introSkip').addEventListener('click',closeIntro);
$('introDots').addEventListener('click',e=>{const b=e.target.closest&&e.target.closest('.dot');if(b){introI=+b.dataset.i;renderIntro();}});
{let sx=null;const el=$('intro');
  el.addEventListener('touchstart',e=>{sx=e.changedTouches[0].clientX;},{passive:true});
  el.addEventListener('touchend',e=>{if(sx===null)return;const dx=e.changedTouches[0].clientX-sx;sx=null;if(Math.abs(dx)>50)introStep(dx<0?1:-1);},{passive:true});}

$('retryBtn').addEventListener('click',respawn);
$('menuClose').addEventListener('click',closeMenu);
$('pauseBtn').addEventListener('click',()=>{if(menu)closeMenu();setPaused(true);});
$('resumeBtn').addEventListener('click',()=>setPaused(false));
$('pauseIntro').addEventListener('click',()=>openIntro('pause'));
$('pauseCraft').addEventListener('click',()=>{paused=false;$('paused').hidden=true;openCraft();});
$('craftClose').addEventListener('click',closeCraft);
$('phClose').addEventListener('click',closePhone);


// ---------- car enter / exit ----------
function nearestCar(maxExtra){
  let best=null,bd=1e9;
  for(const c of cars){if(c.ai==='wreck'||c.dead)continue;const d=d2(c.pos,player.pos)-c.half;if(d<maxExtra&&d<bd){bd=d;best=c;}}
  return best;
}
const HIJACK={civ:[2,'차량 탈취'],police:[6,'경찰차 탈취'],swat:[7,'특수부대 밴 탈취'],army:[8,'군용차 탈취'],fire:[3,'소방차 탈취'],tow:[2,'견인차 탈취'],amb:[3,'구급차 탈취'],bus:[2,'버스 탈취'],gang:[3,'갱단 차량 탈취']};
function enterCar(c){
  closeMenu();
  if(c.impound){if(c.mine){if(player.money<20){toast('보관료 $20이 필요하다');return;}charge(20,'견인 차량 보관료');toast('보관료 $20 납부 · 차를 찾았다');}c.impound=null;}
  const f=fwdOf(c),l={x:f.z,z:-f.x};
  if(c.hasDriver){
    const kind=c.type==='civ'||c.type==='fire'||c.type==='tow'||c.type==='amb'?'civ':CREW_KIND[c.type];
    const p=makePed(kind,c.pos.x+l.x*(c.w/2+1),c.pos.z+l.z*(c.w/2+1),c.type==='fire'?{look:FF_LOOK,weapon:null,hpMul:1.4}:undefined);collideCircle(p.pos,.35);
    if(c.type==='fire'){p.ff=true;p.provokeOnUp=true;}
    else if(kind==='civ'&&RNG()<.4)p.provokeOnUp=true;
    knock(p,l.x*4,2.5,l.z*4);
    crime(HIJACK[c.type][0],c.pos,HIJACK[c.type][1]);
    toast(kind==='civ'?'차를 빼앗았다':'관용차를 빼앗았다');
  } else if(c.milLock){
    c.milLock=null;setStars(Math.max(wanted.stars,4));crime(0,c.pos,c.type==='navyboat'?'경비정 탈취':c.type==='pheli'?'군용 헬기 탈취':'군용 차량 탈취');
  } else if(c.jobTaxi||c.jobTruck){ // the company car you were given
  } else if(c.owned&&c.mine){ // already mine: just get in
  } else if(c.type==='mboat'){if(!c.owned)crime(1,c.pos,'보트 절도');
  } else if(c.type==='tow'){crime(1,c.pos,'견인차 절도');
  } else if(c.type!=='civ'){crime(4,c.pos,'관용차 절도');
    if(c.type==='fire')for(const p of peds)if(p.truck===c&&!p.dead&&!p.out){p.truck=null;provoke(p);}}
  else if(c.ai==='parked'&&!c.mine){if(RNG()<.05){setStars(Math.max(wanted.stars,1));crime(0,c.pos,'차량 절도');toast('누가 봤다! 차량 절도 신고');}}
  if(hasFuel(c)&&c.fuel==null)c.fuel=c.owned&&c.price?100:randi(30,100);
  if(c.medevac){c.medevac=false;if(c.home&&c.home.medheli===c)c.home.medheli=null;}
  c.ai='player';c.hasDriver=false;c.mine=true;c.fixed=false;c.fire=null;player.car=c;player.crouch=false;job=null;
  if(c.type==='fire')toast('소방차 · 클릭(사격)하면 물대포');
  else if(c.type==='pheli')toast('헬기 · Space 상승 · Shift 하강 · W/S 전진·후진 · A/D 회전 · 클릭 기관포');
  else if(GUN_VEH[c.type])toast((c.type==='apc'?'장갑차':'경비정')+' · 클릭하면 기관포');
  if(c.fleet&&!c.jobTaxi){if(c.slot&&c.slot.car===c)c.slot.car=null;c.slot=null;c.fleet=null;}
  if(!c.owned&&!c.jobTaxi&&!c.jobTruck){c.owned=true;c.stolen=!c.price;feed(c.type==='pheli'?'헬기 소유권 획득 · 다음부터는 그냥 탈 수 있다':'차량 소유권 획득');}
  c.ownedAt=clock;capOwned(c);carYawOff=0;camPitch=-.18;
}
const MAX_OWNED=10;
// fuel: land vehicles only (boats and helicopters never run dry) · 1% lasts about 80 m
const hasFuel=c=>!isBoat(c)&&c.type!=='pheli';
const FUEL_HEAVY={bus:1,apc:1,army:1,fire:1,tow:1,swat:1};
function burnFuel(c,dt,thr){
  if(!hasFuel(c))return thr;
  if(c.fuel==null)c.fuel=randi(30,100);
  c.fuel=Math.max(0,c.fuel-Math.abs(c.speed)*dt*.0125*(FUEL_HEAVY[c.type]?1.6:1));
  if(c.fuel<=0){if(!c.emptyWarn){c.emptyWarn=true;toast('기름이 떨어졌다! 주유소(지도의 연료 아이콘)에서 넣어야 다시 달린다');}return 0;}
  if(c.fuel<10&&!c.lowWarn){c.lowWarn=true;toast('연료 부족 · '+Math.ceil(c.fuel)+'% · 가까운 주유소로');}
  return thr;
}
function refuel(){
  const c=player.car;if(!c||!hasFuel(c))return;
  const need=Math.ceil(100-c.fuel);if(need<=0){toast('이미 가득 찼다');return;}
  const amt=Math.min(need,Math.floor(player.money/GAS_PRICE));if(amt<=0){toast('주유할 돈이 없다');return;}
  player.money-=amt*GAS_PRICE;c.fuel=Math.min(100,c.fuel+amt);c.emptyWarn=false;c.lowWarn=false;
  toast('주유 '+amt+'% · −$'+(amt*GAS_PRICE)+' · 연료 '+Math.round(c.fuel)+'%');feed('주유 −$'+(amt*GAS_PRICE));
}
function capOwned(keep){
  const own=cars.filter(c=>c.owned&&!c.dead&&c.ai!=='wreck'&&c!==keep).sort((a,b)=>a.ownedAt-b.ownedAt);
  while(own.length>=MAX_OWNED){const c=own.shift();c.owned=false;}
}
function exitCar(forced){
  const c=player.car;if(!c)return;
  if(c.type==='pheli'&&!forced&&c.pos.y>heliFloor(c.pos.x,c.pos.z)+1.2){toast('착륙한 뒤에 내리세요 · Shift로 하강');return;}
  const f=fwdOf(c),l={x:f.z,z:-f.x};
  player.pos.set(c.pos.x+l.x*(c.w/2+1),0,c.pos.z+l.z*(c.w/2+1));
  if(isBoat(c)){ // step onto a deck right beside the boat if there is one, otherwise into the water
    for(const D of DECKS){const x=clamp(player.pos.x,D.x0+.5,D.x1-.5),z=clamp(player.pos.z,D.z0+.5,D.z1-.5);if(Math.hypot(x-c.pos.x,z-c.pos.z)<c.w/2+4){player.pos.x=x;player.pos.z=z;break;}}
  }
  collideCircle(player.pos,.4,false,true);
  player.pos.y=inSea(player.pos)?SWIM_Y:c.type==='pheli'?Math.max(floorH(player.pos.x,player.pos.z),c.pos.y):floorH(player.pos.x,player.pos.z);player.vy=0;
  if(c.ai!=='wreck'){c.ai='parked';c.hasDriver=false;}
  player.car=null;camYaw=c.heading;player.yaw=c.heading;
  if(!forced)camPitch=-.18;
}

// ---------- driving ----------
function collideCar(c){
  const f=fwdOf(c),o=c.half-c.rad;let px=0,pz=0;const t=new V3();
  for(const s of [1,0,-1]){t.set(c.pos.x+f.x*o*s,0,c.pos.z+f.z*o*s);const ox=t.x,oz=t.z;
    if(collideCircle(t,c.rad,false)){const dx=t.x-ox,dz=t.z-oz;c.pos.x+=dx;c.pos.z+=dz;px+=dx;pz+=dz;}}
  return (px||pz)?[px,pz]:null;
}
function driveCar(c,throttle,steer,brake,dt){
  if(c.type==='pheli'){heliFly(c,throttle,steer,brake,dt);return;}
  if(isBoat(c)){boatDrive(c,throttle,steer,brake,dt);return;}
  const max=c.ai==='player'?c.maxSpeed*1.15:c.maxSpeed;
  if(throttle>0){c.speed+=c.speed<0?throttle*28*dt:throttle*c.accel*dt;}
  else if(throttle<0){c.speed+=c.speed>.3?throttle*28*dt:throttle*9*dt;}
  else c.speed*=Math.max(0,1-.7*dt);
  if(brake)c.speed*=Math.max(0,1-2.6*dt);
  c.speed=clamp(c.speed,-9,max);
  const grip=clamp(Math.abs(c.speed)/7,0,1);
  c.heading-=steer*c.turn*grip*Math.sign(c.speed)*dt*(brake?1.6:1);
  const f=fwdOf(c);c.pos.x+=f.x*c.speed*dt;c.pos.z+=f.z*c.speed*dt;
  const push=collideCar(c);
  if(push){
    const pl=Math.hypot(push[0],push[1])||1,nx=push[0]/pl,nz=push[1]/pl;
    const sg=Math.sign(c.speed)||1, into=-(f.x*sg*nx+f.z*sg*nz);
    if(into>0){
      const vn=Math.abs(c.speed)*into;
      if(vn>11&&c.ai!=='wreck'){c.health-=(vn-10)*1.6;if(c===player.car)shake=Math.max(shake,vn/28);}
      c.speed*=1-.85*into;
    }
  }
}
// lane drivers: keep distance, yield at junctions, pull over for sirens, overtake a stopped car or wreck when the
// oncoming lane is clear, and wait (then squeeze past) if nothing else works
function trafficUpdate(c,dt){
  const f={x:c.dx,z:c.dz},r={x:-f.z,z:f.x};
  if(c.cruise==null)c.cruise=c.ai==='patrol'?9:rand(9,12.5)*(c.isTaxi?1.3:1);
  if(c.ov==null){c.ov=0;c.ovState=0;c.pull=0;}
  let target=c.cruise,blocker=null,bd=1e9,pullT=0;
  const sign=c.dx!==0?c.dx:c.dz,cur=c.dx!==0?c.pos.x:c.pos.z,toNode=(R[c.ni]-cur)*sign;
  if(c.ghostT>0)c.ghostT-=dt;else{
    const look=Math.max(14,c.speed*1.7+9);
    const check=(px,pz,m,o)=>{const dx=px-c.pos.x,dz=pz-c.pos.z,ah=dx*f.x+dz*f.z;if(ah<=0||ah>look)return;
      if(Math.abs(dx*r.x+dz*r.z)<m){const t=Math.max(0,ah-c.half-(o?o.half:.4)-2)*1.3;if(t<target)target=t;if(o&&ah<bd){bd=ah;blocker=o;}}};
    for(const o of cars){if(o===c||o.dead||o.ai==='towed'||Math.abs(o.pos.x-c.pos.x)>look+5||Math.abs(o.pos.z-c.pos.z)>look+5)continue;check(o.pos.x,o.pos.z,(c.w+o.w)/2+.2,o);}
    for(const p of peds){if(p.room||p.state==='fly'||Math.abs(p.pos.x-c.pos.x)>look||Math.abs(p.pos.z-c.pos.z)>look)continue;check(p.pos.x,p.pos.z,1.6,null);}
    if(!player.car&&!player.inside)check(player.pos.x,player.pos.z,1.6,null);
    // traffic lights
    if(c.ov<.05){const sl=sigLimit(c,f.x,f.z,c.speed);if(sl<target){
      if(c.reckless){const k=c.li*1000+c.ni*2+(c.dx!==0?1:0);if(c.rlKey!==k){c.rlKey=k;c.rlRun=RNG()<.75;}if(!c.rlRun)target=sl;}
      else target=sl;}}
    // yield to cross traffic already in the junction ahead
    if(toNode>HALF_ROAD&&toNode<HALF_ROAD+16&&c.ov<.05){
      const nx=c.dx!==0?R[c.ni]:R[c.li],nz=c.dx!==0?R[c.li]:R[c.ni];
      for(const o of cars){
        if(o===c||o.dead||Math.abs(o.speed)<.8||Math.abs(o.pos.x-nx)>HALF_ROAD+1.5||Math.abs(o.pos.z-nz)>HALF_ROAD+1.5)continue;
        const of=fwdOf(o);if(Math.abs(of.x*f.x+of.z*f.z)<.5){target=Math.min(target,Math.max(0,toNode-HALF_ROAD-c.half-.5)*1.2);break;}
      }
    }
    // sirens behind: pull toward the kerb and let them through
    for(const o of cars){
      if(o.dead||(o.ai!=='chase'&&o.ai!=='fireRun'))continue;const dx=o.pos.x-c.pos.x,dz=o.pos.z-c.pos.z;if(dx*dx+dz*dz>1200)continue;
      const ah=dx*f.x+dz*f.z;if(ah<-2&&ah>-34&&Math.abs(dx*r.x+dz*r.z)<6){pullT=1;target=Math.min(target,2.5);break;}
    }
  }
  // pulling over to park where it isn't allowed: a quiet stretch mid-block, then the driver walks off
  if(c.parkAt!=null&&!c.parking){c.parkAt-=dt;
    if(c.parkAt<=0){const px=c.pos.x+r.x*5,pz=c.pos.z+r.z*5; // the first quiet stretch from now on will do
      if(toNode>20&&toNode<CELL-14&&!BUS_STOPS.some(S=>Math.hypot(S.ap.x-px,S.ap.z-pz)<26)&&!cars.some(o=>o!==c&&!o.dead&&o.ai==='parked'&&Math.hypot(o.pos.x-px,o.pos.z-pz)<9)&&!legalPark({x:px,z:pz}))c.parking=true;}}
  if(c.parking){pullT=1;target=Math.min(target,c.pull>.6?0:3);
    if(c.pull>.97&&c.speed<.3){c.ai='parked';c.hasDriver=false;c.speed=0;c.illegal=true;c.parking=false;c.parkAt=null;c.locked=RNG()<.5;
      walkerAt(c.pos.x+r.x*(c.w/2+1.6),c.pos.z+r.z*(c.w/2+1.6));
      if(d2(c.pos,actualPos())<60)feed('불법 주정차 · 차를 길가에 세우고 내려 버렸다');return;}}
  // overtaking a stationary obstacle in our lane
  const stat=o=>o&&(o.ai==='wreck'||o.ai==='parked'||o.crashed||(Math.abs(o.speed)<.3&&o.ai!=='traffic'&&o.ai!=='patrol'));
  if(c.ovState===0&&stat(blocker)&&bd<24&&c.speed<5&&toNode>bd+blocker.half+14&&c.waitT>.4){
    let clear=true;
    for(const o of cars){if(o===c||o===blocker||o.dead)continue;const dx=o.pos.x-c.pos.x,dz=o.pos.z-c.pos.z,ah=dx*f.x+dz*f.z,lt=dx*r.x+dz*r.z;
      if(ah>-8&&ah<bd+30&&Math.abs(lt+2*LANE)<2.6){clear=false;break;}}
    if(clear){c.ovState=1;c.ovObj=blocker;}
  }
  if(c.ovState===1){
    const o=c.ovObj;
    if(!o||o.dead||o.ai==='towed')c.ovState=2;
    else{const ah=(o.pos.x-c.pos.x)*f.x+(o.pos.z-c.pos.z)*f.z;if(ah<-(o.half+c.half+3))c.ovState=2;}
    if(c.ov<.9)target=Math.min(target,4);
  }
  const ovT=c.ovState===1?1:0;
  const latPrev=LANE*(1-2*c.ov)+1.6*c.pull;
  c.ov+=clamp(ovT-c.ov,-dt*.9,dt*.9);if(c.ovState===2&&c.ov<=0)c.ovState=0;
  c.pull+=clamp(pullT-c.pull,-dt*.8,dt*1.2);
  c.speed+=clamp(target-c.speed,-20*dt,6*dt); if(c.speed<0)c.speed=0;
  if(c.speed<.3&&target<.3){c.waitT+=dt;if(c.waitT>6){c.ghostT=1.6;c.waitT=0;}}else c.waitT=Math.max(0,c.waitT-dt*.5);
  laneAdvance(c,c.speed*dt);
  const latNow=LANE*(1-2*c.ov)+1.6*c.pull,dl=(latNow-latPrev)/Math.max(dt,1e-3);
  c.heading=Math.atan2(c.dx*Math.max(c.speed,.5)+r.x*dl,c.dz*Math.max(c.speed,.5)+r.z*dl);
}
function nearestIdx(v){return clamp(Math.round((v-R[0])/CELL),0,N);}
function nearestIdxZ(v){return clamp(Math.round((v-R[0])/CELL),0,NZ);}
// a straight drive from a to b that clears buildings by m metres
function drivable(a,b,m){
  if(onAirSide(a)!==onAirSide(b))return false;
  if(!onMainXZ(a.x,a.z,553.01)||!onMainXZ(b.x,b.z,553.01)){ // never straight across open water
    const n=Math.ceil(Math.hypot(b.x-a.x,b.z-a.z)/12);for(let k=1;k<n;k++){const t=k/n,q={x:a.x+(b.x-a.x)*t,z:a.z+(b.z-a.z)*t};if(!isLand(q)&&!onDeck(q))return false;}
  }
  return !forColliders(Math.min(a.x,b.x)-m,Math.min(a.z,b.z)-m,Math.max(a.x,b.x)+m,Math.max(a.z,b.z)+m,c=>!c.tree&&c.h>=.8&&segEntry(a.x,a.z,b.x,b.z,c,m)!==null)&&!terrainBlocks(a,b);
}
// chase cars follow the road graph toward the intersection nearest the player
let chaseF=null,chaseKey=-2;
function chaseField(){
  const n=nearNode(playerPos()),k=n?n[0]*NS+n[1]:-1;
  if(k!==chaseKey){chaseKey=k;chaseF=n?nodeField(n[0],n[1]):null;}
  return chaseF;
}
// ---------- careful driving: keep right, brake for whatever is ahead, slow for turns and junctions ----------
// distance (bumper to bumper) to the nearest car, pedestrian or player in this car's path
function obstacleAhead(c,look,ignore){
  const f=fwdOf(c),r={x:-f.z,z:f.x};let best=1e9;
  const test=(x,z,m,half)=>{const dx=x-c.pos.x,dz=z-c.pos.z,ah=dx*f.x+dz*f.z;if(ah<=0||ah>look+half)return;if(Math.abs(dx*r.x+dz*r.z)<m){const d=ah-c.half-half;if(d<best)best=d;}};
  for(const o of cars){
    if(o===c||o===ignore||o.dead||o.ai==='towed'||(o.type==='pheli'&&o.pos.y>3)||Math.abs(o.pos.x-c.pos.x)>look+8||Math.abs(o.pos.z-c.pos.z)>look+8)continue;
    test(o.pos.x,o.pos.z,(c.w+o.w)/2+.3,o.half);
  }
  for(const p of peds){
    if(p.room||p.dead||p.state==='fly'||p.car2===c||p.truck===c||Math.abs(p.pos.x-c.pos.x)>look+2||Math.abs(p.pos.z-c.pos.z)>look+2)continue;
    test(p.pos.x,p.pos.z,c.w/2+.6,.3);
  }
  if(!player.car&&!player.inside&&ignore!=='player')test(player.pos.x,player.pos.z,c.w/2+.6,.3);
  return best;
}
const nearJunction=p=>Math.abs(p.x-R[gridIdx(p.x)])<HALF_ROAD+9&&Math.abs(p.z-R[gridIdxZ(p.z)])<HALF_ROAD+9;
// steer for tgt at no more than cap m/s. opts: lane (keep to the right of the road centre), siren (may roll through
// junctions a little faster), ignore (a vehicle or 'player' not to brake for), stopAt (ease to a stop this far out)
function smartDrive(c,tgt,dt,cap,opts){
  opts=opts||{};
  if(c.revT>0){c.revT-=dt;driveCar(c,-.6,c.revSteer,false,dt);return;}
  const dx=tgt.x-c.pos.x,dz=tgt.z-c.pos.z,d=Math.hypot(dx,dz)||1;
  let ax=tgt.x,az=tgt.z;
  if(opts.lane&&d>3){ax+=-dz/d*LANE;az+=dx/d*LANE;} // right-hand lane of the road toward the next junction
  if(c.passT>0){c.passT-=dt;ax+=dz/d*LANE*2;az-=dx/d*LANE*2;} // squeezing past on the other side
  const desired=Math.atan2(ax-c.pos.x,az-c.pos.z),diff=angDiff(c.heading,desired),ad=Math.abs(diff);
  const sk=opts.k||(c.type==='bus'?1.2:c.isTaxi?1.3:1);let want=cap*sk;
  if(ad>.3)want=Math.min(want,(ad>1.3?3.5:ad>.7?7:11)*sk);
  if(opts.stopAt!=null)want=Math.min(want,Math.max(0,d-opts.stopAt)*.7);
  if(opts.lane&&nearJunction(c.pos))want=Math.min(want,(opts.siren?10:7)*sk);
  if(opts.lane&&!opts.siren){const fw=fwdOf(c);want=Math.min(want,sigLimit(c,fw.x,fw.z,c.speed));}
  let ob=1e9;
  if(!(c.passT>0)){ob=obstacleAhead(c,Math.max(10,Math.abs(c.speed)*1.9+6),opts.ignore);if(ob<1e8)want=Math.min(want,Math.max(0,ob-2.2)*.9);}
  let thr=0,brake=false;
  if(ad>2.3&&c.speed<3){thr=-.5;} // facing away: back round
  else if(c.speed<want-.4)thr=Math.min(1,(want-c.speed)*.35+.15);
  else if(c.speed>want+.8){thr=c.speed>1.5?-Math.min(1,(c.speed-want)*.25):0;brake=c.speed-want>6;}
  driveCar(c,thr,clamp((thr<0&&c.speed<0?1:-1)*diff*2.4,-1,1),brake,dt);
  // blocked by something that is not moving: wait a little, then go round it on the other side
  if(ob<4&&Math.abs(c.speed)<.6)c.waitT=(c.waitT||0)+dt;else c.waitT=0;
  if(c.waitT>3){c.waitT=0;c.passT=2.5;}
  if(want>2&&Math.abs(c.speed)<.6&&ob>6)c.stuckT+=dt;else c.stuckT=0;
  if(c.stuckT>1.8){c.stuckT=0;c.revT=1.2;c.revSteer=diff>0?-1:1;}
}
// where a vehicle heads once its job is done
function homeFor(c){
  if(c.freight&&LOGI.L)return {x:LOGI.L.ramp.mouth.x,z:LOGI.L.ramp.mouth.z,L:LOGI.L};
  if(c.fleet)return {x:c.fleet.roadX+LANE,z:c.fleet.cz};
  if(c.type==='army')return {x:BASE.x0+14,z:0};
  if(c.type==='tow'&&c.garage&&c.garage.ramp)return {x:c.garage.ramp.mouth.x,z:c.garage.ramp.mouth.z,L:c.garage};
  const t={police:'police',swat:'police',fire:'fire',amb:'hospital',tow:'garage'}[c.type];
  let best=null,bd=1e9;if(t)for(const L of LOCS)if(L.type===t&&L.spawnSpot){const d=d2(L.door,c.pos);if(d<bd){bd=d;best=L;}}
  if(best&&best.ramp)return {x:best.ramp.mouth.x,z:best.ramp.mouth.z,L:best};
  if(best)return {x:best.spawnSpot.x,z:best.spawnSpot.z};
  // anyone else just drives off toward the far side of town
  const tp=playerPos(),n=nearNode({x:c.pos.x+(c.pos.x-tp.x)*4,z:c.pos.z+(c.pos.z-tp.z)*4});return n?{x:R[n[0]],z:R[n[1]]}:{x:c.pos.x,z:c.pos.z};
}
function leaveDrive(c,dt){
  c.lifeT+=dt;const tp=playerPos(),dp=d2(c.pos,tp);
  if(!c.goal)c.goal=homeFor(c);
  if((dp>130&&!hasLOS(c.pos,tp))||dp>240||c.lifeT>150){c.dead=true;goneHome(c,c.goal.L);return;}
  if(c.goal.L&&rampIn(c,c.goal.L,dt))return;
  if(!c.goal.L&&d2(c.pos,c.goal)<12){if(dp>45||c.lifeT>40)c.dead=true;else{driveCar(c,0,0,true,dt);return;}}
  c.lfT=(c.lfT||0)-dt;if(!c.lfield||c.lfT<=0){c.lfT=4;const n=nearNode(c.goal);c.lfield=n?nodeField(n[0],n[1]):null;}
  const direct=d2(c.pos,c.goal)<40&&drivable(c.pos,c.goal,1.2);
  smartDrive(c,direct?c.goal:routeTarget(c.pos,c.lfield,c.goal),dt,direct?6:11,{lane:!direct});
}
function chaseDrive(c,dt){
  if(unitInvalid(c.type)){c.ai='leave';c.lifeT=0;return;}
  const tp=playerPos(),d=d2(c.pos,tp);
  if(d>1700){c.dead=true;return;}
  if(c.revT>0){c.revT-=dt;driveCar(c,-1,c.revSteer,false,dt);return;}
  const direct=(d<35||hasLOS(c.pos,tp))&&drivable(c.pos,tp,1.3);
  let target,cap=c.maxSpeed;
  if(direct){
    target=tp.clone();
    if(player.car&&player.car.type!=='pheli'){const pf=fwdOf(player.car),ps=player.car.speed;target.x+=pf.x*ps*.35;target.z+=pf.z*ps*.35;
      // shadow the player's car: match its speed and hang back a few metres instead of ramming it
      const gap=d-c.half-player.car.half;cap=clamp(Math.abs(ps)+(gap-7)*.8,0,c.maxSpeed);}
    else cap=clamp((d-12)*.7,0,c.maxSpeed); // on foot: pull up short and let the officers get out
  } else target=routeTarget(c.pos,chaseField(),tp);
  const stopped=!player.car||(Math.abs(player.car.speed)<2&&player.car.type!=='pheli'&&!isBoat(player.car));
  if(stopped&&d<20&&Math.abs(c.speed)<2.5){deployCrew(c);return;}
  smartDrive(c,target,dt,cap,{lane:!direct,siren:true,ignore:player.car||'player'});
}
// ---------- peds ----------
function targetFor(p){
  const ps=playerSpace(), s=p.room||null;
  if(s===ps)return {pos:actualPos(),same:true};
  if(s)return {pos:s.room.exit,same:false};
  return {pos:ps.door,same:false};
}
function transfer(p){
  if(p.room){const L=p.room;p.room=null;p.pos.set(L.door.x+L.out.x*1.4,0,L.door.z+rand(-1.2,1.2));}
  else{const L=player.inside;p.room=L;p.pos.set(L.room.exit.x+rand(-1,1),0,L.room.exit.z+1.4+rand(0,.8));}
}
function npcAttack(p,W,d,tpos){
  if(!p.weapon){
    p.fireT=rand(W.cd[0],W.cd[1]);
    if(d>W.range||player.car)return;
    p.punchAnim=.25;if(p.kind==='civ')p.aggro=true;damagePlayer(W.dmg,'시민에게 얻어맞고 쓰러졌습니다.');shake=Math.max(shake,.15);return;
  }
  if(W.burst){if(p.burst<=0)p.burst=randi(W.burst[0],W.burst[1]);p.burst--;p.fireT=p.burst>0?W.cd[0]:rand(W.pause[0],W.pause[1]);}
  else p.fireT=rand(W.cd[0],W.cd[1]);
  if(p.kind==='civ')p.aggro=true; // drew a gun on the player: anything back is self-defence
  const fast=player.car&&Math.abs(player.car.speed)>14;
  let hc=W.acc*(1-d/70)*(fast?.45:1);
  if(player.crouch&&!player.car){hc*=.55;if(inCover(p.pos,tpos))hc*=.25;}
  const hit=RNG()<hc, spr=hit?.3:2.2;
  const fx=new V3(p.pos.x+Math.sin(p.yaw)*.6,p.pos.y+1.35,p.pos.z+Math.cos(p.yaw)*.6);
  const n=p.weapon==='shotgun'?3:1;
  const ex=tpos.x+rand(-spr,spr),ez=tpos.z+rand(-spr,spr);
  for(let i=0;i<n;i++)tracer(fx,new V3(i?tpos.x+rand(-spr,spr):ex,(tpos.y||0)+1.1+rand(-.4,.4),i?tpos.z+rand(-spr,spr):ez));
  if(!hit&&!p.room){ // a missed round can hit a bystander further down the line
    const lx=(ex-fx.x)*1.8,lz=(ez-fx.z)*1.8,ll=lx*lx+lz*lz||1;
    for(const q of peds){if(q===p||q.dead||q.out||q.room||q.state==='fly'||q.state==='down')continue;
      const t=((q.pos.x-fx.x)*lx+(q.pos.z-fx.z)*lz)/ll;if(t<.05||t>1)continue;
      const qx=fx.x+lx*t-q.pos.x,qz=fx.z+lz*t-q.pos.z;if(qx*qx+qz*qz<.2){hurtNpc(q,W.dmg*3,p,{x:lx/Math.sqrt(ll),z:lz/Math.sqrt(ll)});break;}}
  }
  puff(fx,0xffd27a,p.weapon==='shotgun'?.2:.12,new V3(),.06,true);
  scare(fx,16);
  if(hit){let dmg=W.dmg;if(p.weapon==='shotgun')dmg*=1-d/W.range*.5;damagePlayer(dmg,KILL_MSG[p.kind]);}
}
function combat(p,dt){
  const enemy=p.kind!=='civ';
  if(enemy){if(guardOff(p)){calm(p);return null;}}
  else{p.fightT+=dt;if(dead||p.fightT>25){calm(p);return null;}}
  const tg=targetFor(p);
  if(!tg.same&&p.role){calm(p);return null;}
  const dx=tg.pos.x-p.pos.x,dz=tg.pos.z-p.pos.z,d=Math.hypot(dx,dz)||1;
  const run=p.kind==='civ'?4.6:p.kind==='cop'?5.3:5.8;
  p.yaw=Math.atan2(dx,dz);
  if(!tg.same){if(d<1.4){transfer(p);return null;}return [dx/d,dz/d,run];}
  if(!enemy&&d>45){calm(p);return null;}
  if(enemy&&!p.room&&d>150){if(p.role==='gate')calm(p);else p.dead=true;return null;}
  if(p.role==='gate'&&d2(p.pos,p.home)>90){calm(p);return null;}
  if(player.surrender&&enemy&&tg.same){ // walk up, holster, cuff
    if(d>1.4)return [dx/d,dz/d,run*.55];
    if(player.surrender.cuffT<0){player.surrender.cuffT=0;feed('경찰이 수갑을 채운다');}
    return [0,0,0];
  }
  const W=NPC_W[p.weapon||'fist'];
  const los=d<W.range+2&&hasLOS(p.pos,tg.pos);
  const want=p.weapon?Math.min(W.range*.55,11):1.25;
  p.fireT-=dt;
  if(los&&d<=W.range&&p.fireT<=0&&!dead)npcAttack(p,W,d,tg.pos);
  if(!los||d>want)return [dx/d,dz/d,run];
  return [0,0,0];
}
function pedUpdate(p,dt){
  if(p.punchAnim>0)p.punchAnim-=dt;
  if(p.state==='fly'){
    p.vel.y-=22*dt;p.pos.addScaledVector(p.vel,dt);
    if(collideCircle(p.pos,.35)){p.vel.x*=-.3;p.vel.z*=-.3;}
    const gy=floorH(p.pos.x,p.pos.z);
    if(p.pos.y<=gy&&p.vel.y<0){p.pos.y=gy;p.state='down';if(p.out)dropLoot(p);}
    return;
  }
  if(p.state==='down'){p.downT-=dt;if(p.downT<=0){if(p.out){p.dead=true;return;}getUp(p);}return;}
  if(p.state==='cuffed'||p.state==='escorted'){const r=escortMove(p,dt);if(!r){p.animAmp=0;return;}
    if(r[2]>0){p.pos.x+=r[0]*r[2]*dt;p.pos.z+=r[1]*r[2]*dt;p.yaw=Math.atan2(r[0],r[1]);collideCircle(p.pos,.35);p.phase+=dt*r[2]*2.6;p.pos.y=floorH(p.pos.x,p.pos.z);}
    p.animAmp=r[2]>0?.5:0;return;}
  if(p.stunT>0){p.stunT-=dt;p.animAmp=0;return;}
  let mx=0,mz=0,sp=0;p.spray=false;p.prying=false;
  if(p.state==='walk'||p.state==='patrol'){
    if(!p.corners)setWalk(p);
    const t=p.corners[p.ci],dx=t[0]-p.pos.x,dz=t[1]-p.pos.z,d=Math.hypot(dx,dz);
    if(d<.4){if(!(p.state==='walk'&&p.kind==='civ'&&!p.role&&tryCross(p)))p.ci=(p.ci+p.dirc+4)%4;}else{mx=dx/d;mz=dz/d;sp=p.state==='patrol'?1.6:1.4;}
    if(p.state==='patrol'){ // foot patrol: a wanted player in plain sight gets chased
      p.lifeT+=dt;
      if(p.lifeT>.3){p.lifeT=0;const tp=actualPos();
        if(wanted.stars>0&&!player.inside&&d2(p.pos,tp)<35&&hasLOS(p.pos,tp)){p.state='chase';p.fireT=rand(.4,.9);feed('도보 순찰 경찰이 당신을 발견했다');}}
    }
  } else if(p.state==='flee'){
    const dx=p.pos.x-p.threat.x,dz=p.pos.z-p.threat.z,d=Math.hypot(dx,dz)||1;mx=dx/d;mz=dz/d;sp=4.6;
    p.fleeT-=dt;if(p.fleeT<=0)calm(p);
  } else if(p.state==='cower'){
    p.fleeT-=dt;if(p.fleeT<=0)calm(p);
  } else if(p.state==='firefight'){
    let f=p.fire;if(!f||f.dead){f=p.fire=fires.find(q=>!q.dead&&d2(q.pos,p.pos)<35)||null;}
    if(!f){p.state='ffReturn';}
    else{const dx=f.pos.x-p.pos.x,dz=f.pos.z-p.pos.z,d=Math.hypot(dx,dz)||1;
      if(d>f.r+3.2){mx=dx/d;mz=dz/d;sp=4;}
      else{p.yaw=Math.atan2(dx,dz);p.spray=true;f.life-=3*dt;p.sprayT=(p.sprayT||0)-dt;
        if(p.sprayT<=0){p.sprayT=.07;puff(new V3(p.pos.x+dx/d*.7,p.pos.y+1.25,p.pos.z+dz/d*.7),0xcfe8ff,.14,new V3(dx/d*rand(7,9),rand(1.5,2.5),dz/d*rand(7,9)),.5);}}}
  } else if(p.state==='ffReturn'){
    const t=p.truck;
    if(!t||t.dead||t.ai!=='fireWait'){p.state='leave';p.lifeT=0;}
    else{const dx=t.pos.x-p.pos.x,dz=t.pos.z-p.pos.z,d=Math.hypot(dx,dz)||1;if(d<t.half+1.2){p.dead=true;return;}mx=dx/d;mz=dz/d;sp=3.4;}
  } else if(p.state==='idle'){
    if(p.role==='gate'||p.role==='traffic'){ // sentries open fire on anyone wanted who walks or drives up
      p.lifeT+=dt;
      if(p.lifeT>.35){p.lifeT=0;const tp=actualPos();
        if(wanted.stars>0&&!player.inside&&d2(p.pos,tp)<38&&hasLOS(p.pos,tp)){p.state='chase';p.fireT=rand(.3,.8);}}
    }
    const dh=d2(p.pos,p.home);
    if(dh>.4){mx=(p.home.x-p.pos.x)/dh;mz=(p.home.z-p.pos.z)/dh;sp=1.6;}
    else p.yaw+=angDiff(p.yaw,p.homeYaw)*Math.min(1,dt*5);
  } else if(p.state==='chase'||p.state==='fight'){
    const r=combat(p,dt);if(!r){p.animAmp=0;return;}mx=r[0];mz=r[1];sp=r[2];
  } else if(p.state==='arrest'){
    const r=arrestMove(p,dt);if(!r){p.animAmp=0;return;}mx=r[0];mz=r[1];sp=r[2];
  } else if(p.state==='brawl'){
    p.fightT+=dt;const q=p.foe;
    if(p.fightT>30||!q||(q&&d2(q.pos,p.pos)>32)){p.foe=null;calm(p);p.animAmp=0;return;}
    const r=fightNpc(p,dt,4.4);if(!r){calm(p);p.animAmp=0;return;}mx=r[0];mz=r[1];sp=r[2];
  } else if(p.state==='raid'||p.state==='raidHold'||p.state==='raidBack'){
    const r=raidMove(p,dt);if(!r){p.animAmp=0;return;}mx=r[0];mz=r[1];sp=r[2];
  } else if(p.state==='crossWait'||p.state==='cross'){
    const r=crossMove(p,dt);if(!r){p.animAmp=0;return;}mx=r[0];mz=r[1];sp=r[2];
  } else if(p.state==='waitBus'||p.state==='board'){
    const r=busPedMove(p,dt);if(!r){p.animAmp=0;return;}mx=r[0];mz=r[1];sp=r[2];
  } else if(p.state==='toCar'){
    const r=toCarMove(p,dt);if(!r){p.animAmp=0;return;}mx=r[0];mz=r[1];sp=r[2];
  } else if(p.state==='robPoi'){
    const r=robPoiMove(p,dt);if(!r){p.animAmp=0;return;}mx=r[0];mz=r[1];sp=r[2];
  } else if(p.state==='medic'){
    const r=medicMove(p,dt);if(!r){p.animAmp=0;return;}mx=r[0];mz=r[1];sp=r[2];
  } else if(p.state==='medReturn'||p.state==='copReturn'){
    const r=returnMove(p);if(!r){p.animAmp=0;return;}mx=r[0];mz=r[1];sp=r[2];
  } else if(p.state==='leave'){
    p.lifeT+=dt;
    if(p.room){
      if(p.room!==playerSpace()){p.dead=true;return;}
      const ex=p.room.room.exit,dx=ex.x-p.pos.x,dz=ex.z-p.pos.z,d=Math.hypot(dx,dz)||1;
      if(d<1.4){transfer(p);return;}mx=dx/d;mz=dz/d;sp=3;
    } else {
      const tp=playerPos(),dx=p.pos.x-tp.x,dz=p.pos.z-tp.z,d=Math.hypot(dx,dz)||1;mx=dx/d;mz=dz/d;sp=3;
      if(d>55||p.lifeT>15){p.dead=true;return;}
    }
  }
  if(sp>0&&sp<6&&!p.room&&AVOID_ST[p.state]&&(p.kind==='civ'||AVOID_LAW[p.state])){const a=avoidDir(p,mx,mz,dt);mx=a[0];mz=a[1];}
  if(sp>0){
    p.pos.x+=mx*sp*dt;p.pos.z+=mz*sp*dt;
    if(p.state!=='chase'&&p.state!=='fight'&&p.state!=='arrest'&&p.state!=='brawl')p.yaw=Math.atan2(mx,mz);
    collideCircle(p.pos,.35);p.phase+=dt*sp*2.6;
    p.pos.y=floorH(p.pos.x,p.pos.z);
  }
  p.animAmp=sp>0?Math.min(.9,.35+sp*.11):0;
}

// ---------- player weapons ----------
const curAmmo=()=>player.ammo[player.weapon];
function switchWeapon(k){if(!player.owned[k]||player.weapon===k||(player.jailed&&k!=='fist'))return;player.weapon=k;player.reloadT=0;player.fireT=Math.max(player.fireT,.25);}
function cycleWeapon(dir){const own=ORDER.filter(k=>player.owned[k]);let i=own.indexOf(player.weapon);i=(i+dir+own.length)%own.length;switchWeapon(own[i]);}
function startReload(){
  const k=player.weapon,W=WEAPONS[k],A=player.ammo[k];
  if(!A||player.reloadT>0||A.mag>=W.mag)return;
  if(A.mags<=0){if(A.mag===0)toast(W.magName+(k==='shotgun'?'가':'이')+' 없다 · 총포상에서 사세요');return;}
  player.reloadT=W.reload*(player.buffs.reload>0?.65:1);
}
function castShot(o,dir,range){
  let best=range,hit=null;
  forColliders(o.x,o.z,o.x+dir.x*range,o.z+dir.z*range,b=>{if(b.tree)return;const t=rayBox(o,dir,b.x0,0,b.z0,b.x1,b.h,b.z1);if(t!==null&&t<best){best=t;hit=null;}});
  const ex=o.x+dir.x*best,ez=o.z+dir.z*best;
  if(Math.max(o.x,ex)>-175&&Math.min(o.x,ex)<175&&Math.max(o.z,ez)>-175&&Math.min(o.z,ez)<235){ // march over the mountain
    for(let t=.5;t<best;t+=1.2){if(o.y+dir.y*t<terrainH(o.x+dir.x*t,o.z+dir.z*t)){best=t;hit=null;break;}}
  } else if(dir.y<-1e-4){let t=-o.y/dir.y;const hx=o.x+dir.x*t,hz=o.z+dir.z*t;
    if(!onMainXZ(hx,hz,561)||onDeck({x:hx,z:hz})){t=(surfaceH(hx,hz)-o.y)/dir.y;}
    if(t<best){best=t;hit=null;}}
  const hh=dir.x*dir.x+dir.z*dir.z, ps=playerSpace();
  if(hh>1e-6)for(const p of peds){
    if(p.dead||p.out||p.state==='down'||p.state==='fly'||(p.room||null)!==ps)continue;
    const t=((p.pos.x-o.x)*dir.x+(p.pos.z-o.z)*dir.z)/hh;if(t<0||t>best)continue;
    const qx=o.x+dir.x*t-p.pos.x,qz=o.z+dir.z*t-p.pos.z,y=o.y+dir.y*t;
    if(qx*qx+qz*qz<.2&&y>p.pos.y&&y<p.pos.y+1.95){best=t;hit={kind:'ped',p};}
  }
  {const mh=MP.rayHit(o,dir,best);if(mh){best=mh.t;hit={kind:'mp',R:mh.R};}} // other players (PvP)
  if(!ps){
    for(const c of cars){
      if(c.dead||c===player.car)continue;
      const f=fwdOf(c),r={x:-f.z,z:f.x},rx=o.x-c.pos.x,rz=o.z-c.pos.z;
      const lo={x:rx*r.x+rz*r.z,y:o.y-c.pos.y,z:rx*f.x+rz*f.z},ld={x:dir.x*r.x+dir.z*r.z,y:dir.y,z:dir.x*f.x+dir.z*f.z};
      const t=rayBox(lo,ld,-c.w/2,0,-c.half,c.w/2,c.top,c.half);
      if(t!==null&&t<best){best=t;hit={kind:'car',c};}
    }
    if(heli){const v=heli.pos.clone().sub(o),t=v.dot(dir);if(t>0&&t<best&&v.lengthSq()-t*t<9){best=t;hit={kind:'heli'};}}
    for(const b of boats){if(!b||b.dead)continue;const t=rayBoat(o,dir,b);if(t!==null&&t<best){best=t;hit={kind:'boat',b};}}
  }
  return {t:best,hit};
}
function fire(){
  const k=player.weapon,W=WEAPONS[k],A=player.ammo[k];
  if(!A||player.reloadT>0||player.fireT>0)return;
  if(A.mag<=0){startReload();return;}
  if(W.proj){
    if(player.inside){toast('실내에서는 쓸 수 없다');player.fireT=.6;return;}
    A.mag--;player.fireT=W.rate;player.yaw=camYaw;launchProj(W.proj);return;
  }
  A.mag--;player.fireT=W.rate;recoil=k==='shotgun'?1.5:k==='rifle'?.6:1;player.yaw=camYaw;
  const o=camera.position.clone(),base=new V3();camera.getWorldDirection(base);
  const spread=W.spread*(player.moving?(k==='rifle'?2.6:1.6):1);
  const fp=view==='first',r={x:-Math.cos(player.yaw),z:Math.sin(player.yaw)},pf={x:Math.sin(player.yaw),z:Math.cos(player.yaw)};
  const muzzle=fp?o.clone().addScaledVector(base,.9).add(new V3(r.x*.22,-.17,r.z*.22)):new V3(player.pos.x+r.x*.37+pf.x*W.len,player.pos.y+(player.crouch?.88:1.45),player.pos.z+r.z*.37+pf.z*W.len);
  const hits=new Map(),boatDmg=new Map(),mpHits=new Map(),shotEnds=[];let carHits=[],heliDmg=0,anything=false;
  for(let i=0;i<W.pellets;i++){
    const dir=base.clone();
    if(spread>0){dir.x+=rand(-spread,spread);dir.y+=rand(-spread,spread);dir.z+=rand(-spread,spread);dir.normalize();}
    const res=castShot(o,dir,W.range),end=o.clone().addScaledVector(dir,res.t);
    if(i<3){tracer(muzzle,end,0xfff0c0);shotEnds.push(end);}
    if(res.hit){
      anything=true;
      if(res.hit.kind==='mp'){mpHits.set(res.hit.R,(mpHits.get(res.hit.R)||0)+W.dmg);puff(end,0xff5a5a,.12,new V3(0,1,0),.14,true);}
      else if(res.hit.kind==='ped'){hits.set(res.hit.p,(hits.get(res.hit.p)||0)+W.dmg);puff(end,0xffffff,.1,new V3(0,1,0),.12,true);}
      else if(res.hit.kind==='boat'){boatDmg.set(res.hit.b,(boatDmg.get(res.hit.b)||0)+W.dmg);puff(end,0xffe0a0,.09,new V3(rand(-2,2),rand(1,3),rand(-2,2)),.18,true);}
      else if(res.hit.kind==='car'){carHits.push(res.hit.c);res.hit.c.health-=W.dmg*.6;puff(end,0xffe0a0,.09,new V3(rand(-2,2),rand(1,3),rand(-2,2)),.18,true);}
      else heliDmg+=W.dmg;
    } else if(i<3)puff(end,0xffc070,.1,new V3(0,1,0),.14,true);
  }
  puff(muzzle,0xffd27a,k==='shotgun'?.22:.14,new V3(),.06,true);
  shake=Math.max(shake,k==='shotgun'?.22:.06);
  scare(player.pos,30);
  const hd={x:base.x,z:base.z},hl=Math.hypot(hd.x,hd.z)||1;hd.x/=hl;hd.z/=hl;
  let kill=false;
  for(const [p,dmg] of hits){if(playerHurtsPed(p,dmg,hd,'gun')==='kill')kill=true;}
  for(const [R,dmg] of mpHits)MP.hit(R,dmg,k);
  MP.shot(k,muzzle,shotEnds);
  const seen=new Set();
  for(const c of carHits){if(seen.has(c))continue;seen.add(c);
    if(c.type==='civ')crime(.5,c.pos,wanted.stars===0?'총기 발사':null);else crime(2,c.pos,'관용차 총격');
    if(c.ai==='traffic'){c.ai='parked';c.crashed=true;}}
  for(const [b,dmg] of boatDmg){crime(1,b.pos,wanted.stars<2?'경비정 총격':null);hurtBoat(b,dmg);if(b.dead)kill=true;}
  if(heliDmg&&heli){
    heli.health-=heliDmg;crime(.5,player.pos,null);
    if(heli.health<=0){downHeli();kill=true;}
  }
  if(anything)hitMarker(kill);
  else if(!selfDefence())crime(.4,player.pos,wanted.stars===0?'총기 발사':null);
}
// someone nearby is attacking the player right now
const selfDefence=()=>peds.some(p=>p.aggro&&p.kind==='civ'&&!p.dead&&!p.out&&(p.state==='fight'||p.state==='brawl'||p.state==='chase')&&d2(p.pos,player.pos)<40);
function punch(){
  if(player.punchT>0)return;
  player.punchT=.42;player.punchAnim=.25;player.yaw=camYaw;
  const f={x:Math.sin(player.yaw),z:Math.cos(player.yaw)},ps=playerSpace();
  MP.punchAt(f);
  for(const p of peds){
    if(p.dead||p.out||p.state==='down'||p.state==='fly'||(p.room||null)!==ps)continue;
    const dx=p.pos.x-player.pos.x,dz=p.pos.z-player.pos.z,d=Math.hypot(dx,dz);
    if(d<2.1&&(dx*f.x+dz*f.z)>d*.35){
      const r=playerHurtsPed(p,20,f,'fist');
      puff(new V3(p.pos.x,1.4,p.pos.z),0xffffff,.25,new V3(),.12,true);hitMarker(r==='kill');
      break;
    }
  }
}

// ---------- shops & interiors ----------
let transFn=null,transT=0;
function transition(fn){if(transFn)return;transFn=fn;transT=.2;$('fade').style.opacity=1;}
function enterLoc(loc){
  if(!loc.room){toast((loc.type==='hotel'?loc.title:loc.name)+' · 아직 문을 열지 않았다 (영업 준비 중)');return;}
  job=null;
  transition(()=>{populateRoom(loc);player.inside=loc;player.pos.copy(loc.room.spawn);player.vy=0;camYaw=0;player.yaw=0;camPitch=-.1;camSnap=true;});
}
function exitLoc(){
  const L=player.inside;
  if(L.parent){const P=L.parent;transition(()=>{player.inside=P;player.pos.copy(P.room.elev);player.vy=0;camYaw=-Math.PI/2;player.yaw=camYaw;camSnap=true;});return;}
  if(L.type==='hotel'&&player.hotel&&player.hotel.loc===L&&player.hotel.slept){player.hotel=null;toast('체크아웃 · 또 오세요');}
  transition(()=>{
    player.inside=null;
    player.pos.set(L.door.x,terrainH(L.door.x,L.door.z),L.door.z);
    const y=Math.atan2(L.out.x,L.out.z);camYaw=y;player.yaw=y;camPitch=-.15;camSnap=true;
  });
}
function currentZone(){
  if(player.car){
    for(const L of LOCS)if(L.T.service&&d2(player.car.pos,L.door)<3.6&&Math.abs(player.car.speed)<3)return {kind:'garage',loc:L};
    if(hasFuel(player.car)&&Math.abs(player.car.speed)<2.5){const p=player.car.pos;for(const Z of GAS_ZONES)if(p.x>Z.x0&&p.x<Z.x1&&p.z>Z.z0&&p.z<Z.z1)return {kind:'gas',Z};}
    return null;
  }
  if(player.inside){
    const L=player.inside,r=L.room;
    if(L.type==='jail')return r.counter&&d2(player.pos,r.counter)<1.9?{kind:'vent',loc:L}:null;
    if(d2(player.pos,r.exit)<1.6)return {kind:'exit',loc:L};
    if(r.counter&&d2(player.pos,r.counter)<1.9)return {kind:'counter',loc:L};
    if(r.heaps)for(const h of r.heaps)if(d2(player.pos,h.pos)<1.7)return {kind:'heap',heap:h};
    if(r.spots)for(const q of r.spots)if(d2(player.pos,q.pos)<1.6)return {kind:'spot',spot:q,loc:L};
    return null;
  }
  for(const L of LOCS){if(L.noDoor)continue;const rad=L.T.service?3.2:1.9;if(d2(player.pos,L.door)<rad)return {kind:L.T.service?'garage':L.T.shop?'shop':'door',loc:L};}
  for(const c of cars)if(c.ai==='bus'&&!c.dead&&(c.dwell>0||c.dwelling)&&Math.abs(c.pos.x-player.pos.x)<9&&d2(c.pos,player.pos)<c.half+2.6)return {kind:'bus',bus:c};
  for(const D of TAXI_DEPOTS)if(d2(player.pos,D.desk)<1.8)return {kind:'taxiDesk',D};
  if(LOGI.L&&d2(player.pos,LOGI.L.desk)<1.8)return {kind:'logiDesk'};
  {const t=taxiLive();if(t&&(t.ai==='taxiWait'||t.ai==='taxiRun'&&Math.abs(t.speed)<2)&&d2(t.pos,player.pos)<t.half+3)return {kind:'taxi',taxi:t};}
  for(const T of TERMINALS)if(Math.abs(T.at.x-player.pos.x)<2&&d2(player.pos,T.at)<1.6)return {kind:'term',term:T};
  if(d2(player.pos,FERRY_RING_A)<2)return {kind:'ferry',side:'A'};
  if(d2(player.pos,FERRY_RING_B)<2)return {kind:'ferry',side:'B'};
  for(const h of heaps)if(!h.room&&Math.abs(h.pos.x-player.pos.x)<2&&d2(player.pos,h.pos)<1.7)return {kind:'heap',heap:h};
  for(const P of pois)if(Math.abs(P.at.x-player.pos.x)<2&&d2(player.pos,P.at)<1.5)return {kind:P.type,poi:P};
  for(const b of bins)if(d2(player.pos,b)<1.9)return player.trash>0?{kind:'bin'}:{kind:'binSearch',bin:b};
  return null;
}
function interact(z){if(z.kind==='gas'){refuel();return;}if(z.kind==='bus'){boardBus(z.bus);return;}if(z.kind==='taxi'){boardTaxi(z.taxi);return;}if(z.kind==='taxiDesk'){taxiDesk(z.D);return;}if(z.kind==='logiDesk'){courierDesk();return;}if(z.kind==='spot'){z.spot.act(z.loc);return;}if(z.kind==='binSearch'){searchBin(z.bin);return;}if(z.kind==='door')enterLoc(z.loc);else if(z.kind==='exit')exitLoc();else if(z.kind==='bin')dumpTrash();else if(z.kind==='vent')startEscape();
  else if(z.kind==='heap'||z.kind==='mail'||z.kind==='atm')useSpot(z);else if(z.kind==='term')useTerminal(z.term);else if(z.kind==='ferry')boardFerry(z.side);else openMenu(z.loc);}

// ---------- hotels ----------
function goGuestRoom(L){
  if(!(player.hotel&&player.hotel.loc===L)){toast('프런트 데스크에서 객실을 먼저 예약하세요 · 1박 $'+HOTEL_PRICE(L));return;}
  GUEST.parent=L;GUEST.title=L.title+' · 객실';
  transition(()=>{player.inside=GUEST;player.pos.copy(GUEST.room.spawn);player.vy=0;camYaw=0;player.yaw=0;camPitch=-.1;camSnap=true;});
}
function bankInterest(){if(player.bank<=0)return;const i=Math.min(2000,Math.floor(player.bank*.01));if(i>0){player.bank+=i;feed('은행 이자 +$'+i.toLocaleString()+' · 잔액 $'+player.bank.toLocaleString());}}
function sleepHotel(){
  if(wanted.stars>0){toast('수배 중이라 잠이 오지 않는다');return;}
  if(player.hotel&&player.hotel.slept){toast('오늘 밤은 이미 잤다 · 다시 자려면 새로 예약하세요');return;}
  transition(()=>{
    if(tod>7)bankInterest();tod=7;sigClock=0;applyDaylight();player.health=100;player.hunger=Math.max(20,player.hunger-15);if(player.hotel)player.hotel.slept=true;
    toast('푹 잤다 · 아침 7시 · 체력이 모두 회복됐다');feed('호텔에서 하룻밤');
  });
}
const NEWS=['[속보] 네온 하버 시청, 불법 주정차 단속 강화 · 견인 보관료 $20','항구 페리 증편 · 하버 ↔ 국제공항 정기 운항','국제공항, 본토행 편도 항공권 $100,000 · "섬을 떠날 마지막 기회"','광산 매입소 "금 광석 고가 매입 중"','구도심 교통경찰, 신호 위반 단속 · 벌금 $10','시내버스 1번 · 2번 순환 노선 정상 운행','공인중개사 사무소 곳곳 개업 준비 · "매물은 곧 공개"'];
// ---------- mining ----------
const ORES={coal:['석탄',8],iron:['철광석',18],copper:['구리 광석',30],silver:['은 광석',75],gold:['금 광석',170]};
const ORE_W=[['coal',34],['iron',30],['copper',18],['silver',12],['gold',6]];
const PICK_PRICE=120,PICK_DUR=30;
function mineVein(V){
  if(V.cd>0){toast('이 광맥은 잠시 쉬어야 한다 · '+Math.ceil(V.cd)+'초');return;}
  if(!player.pickaxe){toast('곡괭이가 필요하다 · 갱도 입구 쪽 광부에게 $'+PICK_PRICE);return;}
  startJob({label:'광맥 캐는 중',dur:3,at:V.pos,room:player.inside,start:'곡괭이로 광맥을 캐는 중…',done:()=>{
    const n=randi(1,3),got={};for(let k=0;k<n;k++){const o=rollMat(ORE_W);player.ores[o]++;got[o]=(got[o]||0)+1;}
    const txt=Object.keys(got).map(k=>ORES[k][0]+' +'+got[k]).join(' · ');V.cd=45;
    player.pickaxe.dur--;
    if(player.pickaxe.dur<=0){player.pickaxe=null;toast('캤다 · '+txt+' · 곡괭이가 부러졌다!');}
    else toast('캤다 · '+txt+' · 곡괭이 내구도 '+player.pickaxe.dur+'/'+PICK_DUR);
    feed('광물 · '+txt);
  }});
}
// ---------- bins: rummage for scrap ----------
const BIN_LOOT=[['scrap',44],['pipe',18],['tape',24],['battery',9],['motor',3],['bit',2]];
function searchBin(b){
  if(b.cd>0){toast('방금 뒤진 쓰레기통이다 · '+Math.ceil(b.cd)+'초 뒤');return;}
  startJob({label:'쓰레기통 뒤지는 중',dur:2,at:b,room:null,start:'쓰레기통을 뒤지는 중…',done:()=>{
    b.cd=150;const r=RNG();
    if(r<.5){const m=rollMat(BIN_LOOT);player.mats[m]++;toast('폐품을 찾았다 · '+MATS[m]+' +1');feed('쓰레기통 · '+MATS[m]+' +1');}
    else if(r<.62){const a=randi(1,6);player.money+=a;toast('구겨진 지폐 · +$'+a);}
    else toast('쓸 만한 게 없다');
  }});
}
// ---------- the airport ending ----------
let endingOpen=false,playT=0;
function startEnding(){
  closeMenu();endingOpen=true;paused=true;input.keys={};input.fireHeld=false;
  const m=Math.floor(playT/60);
  $('endText').textContent='본토행 NI-001 편이 활주로를 박차고 오릅니다. 창밖으로 네온 하버의 불빛이 점점 작아집니다. 훔친 차, 쫓기던 밤, 부두의 바닷바람… 이제 모두 뒤에 남았습니다.';
  $('endStats').innerHTML='';
  for(const [k,v] of [['플레이 시간',m+'분'],['남은 돈','$'+player.money.toLocaleString()],['출발 시각',String(Math.floor(tod)).padStart(2,'0')+':'+String(Math.floor((tod%1)*60)).padStart(2,'0')]]){const d=document.createElement('div');const b=document.createElement('b');b.textContent=v;const sm=document.createElement('small');sm.textContent=k;d.append(b,sm);$('endStats').appendChild(d);}
  $('ending').hidden=false;
  try{if(document.pointerLockElement)document.exitPointerLock();}catch(e){}
}
function closeEnding(){if(!endingOpen)return;endingOpen=false;paused=false;$('ending').hidden=true;canvas.focus();if(!coarse)tryLock(true);toast('공항에 남기로 했다 · 표는 환불됐다');player.money+=TICKET_PRICE;}
const TICKET_PRICE=100000;
// ---------- car center ----------
const CAR_MODELS=[
  {id:'compact',name:'소형차',price:1500,desc:'무난한 시내용 · 최고 시속 약 125km'},
  {id:'suv',name:'SUV',price:3000,desc:'튼튼한 차체 · 내구도 최고'},
  {id:'sport',name:'스포츠카',price:6000,desc:'최고 시속 약 165km · 가속 최상'}
];
const CAR_BASE={compact:400,suv:700,sport:1500,police:1200,swat:1600,army:2000,fire:1800,tow:900,amb:1300};
function carValue(c){
  const hf=clamp(c.health/c.maxHealth,0,1);
  if(c.price)return Math.round(c.price*.5*(.4+.6*hf)/10)*10;
  const base=c.type==='civ'?CAR_BASE[c.model||'compact']:CAR_BASE[c.type];
  return Math.round(base*(.35+.65*hf)/10)*10;
}
function repairCost(c){const miss=1-c.health/c.maxHealth;return miss<.01?0:Math.max(50,Math.ceil(miss*500/10)*10);}
function sellCar(c,val){exitCar(false);c.dead=true;player.money+=val;toast('차를 팔았다 · +$'+val.toLocaleString());feed('차량 판매 +$'+val.toLocaleString());}
function buyCar(loc,M){
  const s=lotSpot(loc)||loc.spawnSpot;if(player.car)exitCar(false);
  const c=makeCar('civ',s.x,s.z,s.h,'parked',{model:M.id,color:pick(carColors)});
  c.owned=true;c.mine=true;c.price=M.price;
  enterCar(c);toast(M.name+' 인수 완료');feed(M.name+' 구매 −$'+M.price.toLocaleString());
}

// ---------- jail ----------
let escaping=null;
const sentenceFor=s=>20+15*s;
function goJail(sent,at){
  setStars(0);
  if(at){JAIL.door=at.door;JAIL.out=at.out;}
  transition(()=>{
    populateRoom(JAIL);player.inside=JAIL;player.pos.copy(JAIL.room.spawn);player.vy=0;camYaw=0;player.yaw=0;camPitch=-.1;camSnap=true;
    player.jailed=true;player.jailT=sent;player.prevWeapon=player.weapon;player.weapon='fist';player.reloadT=0;player.crouch=false;
    player.hunger=Math.max(player.hunger,60);
    toast('수감됐다 · 형기 '+sent+'초');
  });
}
function freeFromJail(){
  player.jailed=false;player.jailT=0;escaping=null;
  if(player.prevWeapon&&player.owned[player.prevWeapon])player.weapon=player.prevWeapon;
  player.prevWeapon=null;
}
function releaseJail(escaped){
  const D=JAIL.door;
  transition(()=>{
    freeFromJail();player.inside=null;
    player.pos.set(D.x+JAIL.out.x*(escaped?2.5:0),0,D.z+(escaped?9:0));collideCircle(player.pos,.4);
    const y=Math.atan2(JAIL.out.x,JAIL.out.z);camYaw=y;player.yaw=y;camPitch=-.15;camSnap=true;
    if(escaped){crime(12,player.pos,'탈옥');toast('탈옥 성공! 수배 ★2');}
    else toast('출소했다');
  });
}
function startEscape(){if(escaping)return;escaping={t:0,dur:8};toast('환풍구를 뜯는 중 · 8초 버텨라');}
function updateJail(dt){
  if(!player.jailed||transFn)return;
  player.jailT-=dt;
  if(player.jailT<=0){releaseJail(false);return;}
  if(!escaping)return;
  if(player.inside!==JAIL||d2(player.pos,JAIL.room.counter)>2.2){escaping=null;toast('탈옥 중단');return;}
  escaping.t+=dt;
  if(escaping.t>=escaping.dur){escaping=null;releaseJail(true);}
}

// ---------- crouch & cover ----------
function inCover(a,b){
  if(forColliders(a.x,a.z,b.x,b.z,c=>c.h>=.7&&c.h<1.4&&segEntry(a.x,a.z,b.x,b.z,c,0)!==null))return true;
  for(const c of cars){
    if(c.dead||c===player.car||Math.abs(c.pos.x-b.x)>8||Math.abs(c.pos.z-b.z)>8)continue;
    const r=Math.max(c.w/2,c.half)*.7;
    if(segEntry(a.x,a.z,b.x,b.z,{x0:c.pos.x-r,x1:c.pos.x+r,z0:c.pos.z-r,z1:c.pos.z+r},0)!==null)return true;
  }
  return false;
}
function coverNow(){
  const ps=playerSpace();let best=null,bd=40;
  for(const p of peds){
    if(p.dead||p.out||(p.state!=='chase'&&p.state!=='fight')||(p.room||null)!==ps)continue;
    const d=d2(p.pos,player.pos);if(d<bd){bd=d;best=p;}
  }
  return best?inCover(best.pos,player.pos):false;
}

function robItem(loc,label,desc,dur,range){
  return {label,desc,crime:true,close:true,
    dis:robbing?'이미 털고 있다':loc.robCD>0?'금고가 비어 있다 · '+Math.ceil(loc.robCD)+'초 뒤':(player.weapon==='fist'||WEAPONS[player.weapon].proj)?'총을 꺼내야 한다 (2–4)':null,
    act:()=>startRob(loc,dur,range)};
}
function menuItems(loc){
  const t=loc.type,it=[];
  if(t==='gun'){
    if(!menu.talk)for(const k of ['pistol','shotgun','rifle']){
      const W=WEAPONS[k];if(player.owned[k])continue;
      it.push({label:W.name+' 구매',desc:W.desc+' · '+W.magName+' 2개 포함',price:W.price,act:()=>{player.owned[k]=true;player.ammo[k]={mag:W.mag,mags:2};switchWeapon(k);feed(W.name+' 구매');}});
    }
    if(!menu.talk)for(const k of ['pistol','shotgun','rifle']){
      if(!player.owned[k])continue;const W=WEAPONS[k],A=player.ammo[k];
      it.push({label:W.name+' '+W.magName,desc:W.mag+'발 · 보유 '+A.mags+'개',price:W.ammoPrice,act:()=>{A.mags++;}});
    }
    // the owner keeps a few things under the counter for customers who ask
    if(!menu.talk)it.push({label:'주인과 대화하기',desc:'"…혹시 특별한 물건 찾으시나?"',talk:true,act:()=>{menu.talk=true;feed('총포상 주인이 목소리를 낮춘다');}});
    else{
      const M=player.ammo.molotov,mc=M.mag+M.mags,R=player.ammo.rpg,rc=R.mag+R.mags;
      it.push({label:'화염병',desc:'불법 · 던지면 불바다 · 보유 '+mc+'/5',price:150,crime:true,dis:mc>=5?'더 들 수 없다 (5/5)':null,
        act:()=>{if(!player.owned.molotov){player.owned.molotov=true;M.mag=1;M.mags=0;switchWeapon('molotov');}else if(M.mag===0)M.mag=1;else M.mags++;feed('화염병 구매');}});
      it.push({label:'RPG 발사기',desc:'불법 · 로켓 2발 포함 · 일반 차는 한 방',price:4500,crime:true,dis:player.owned.rpg?'이미 가지고 있다':null,
        act:()=>{player.owned.rpg=true;R.mag=1;R.mags=1;switchWeapon('rpg');feed('RPG 구매');}});
      it.push({label:'RPG 로켓',desc:'불법 · 보유 '+rc+'/7',price:400,crime:true,dis:!player.owned.rpg?'발사기가 먼저 필요하다':rc>=7?'더 들 수 없다 (7/7)':null,
        act:()=>{if(R.mag===0)R.mag=1;else R.mags++;feed('RPG 로켓 +1');}});
      it.push({label:'위조 군 출입증',desc:'군사 기지 정문을 수배 없이 통과 · 군인 눈앞에서 수상한 짓을 하면 소용없음',price:2000,crime:true,dis:player.pass?'이미 가지고 있다':null,act:()=>{player.pass=true;feed('위조 군 출입증 구매');}});
      const TC=player.tools.crowbar,TD=player.tools.drill;
      it.push({label:'단단한 크로우바',desc:'불법 · 절대 안 망가짐 · 지금 '+toolTxt('crowbar'),price:600,crime:true,dis:TC&&TC.pro?'이미 가지고 있다':null,act:()=>{player.tools.crowbar={pro:true};feed('단단한 크로우바 구매');}});
      it.push({label:'전동 드릴',desc:'불법 · 절대 안 망가짐 · 지금 '+toolTxt('drill'),price:3000,crime:true,dis:TD&&TD.pro?'이미 가지고 있다':null,act:()=>{player.tools.drill={pro:true};feed('전동 드릴 구매');}});
      it.push({label:'차량 배선 따개 (10회)',desc:'불법 · 잠긴 주차 차량을 3초 만에 시동 · 보유 '+player.kits.car+'회',price:300,crime:true,act:()=>{player.kits.car+=10;feed('차량 배선 따개 +10회');}});
      it.push({label:'군용 차량 배선 따개 (1회)',desc:'불법 · 군용 트럭 · 장갑차 · 헬기 · 경비정을 5초 만에 시동 · 보유 '+player.kits.mil+'개',price:1500,crime:true,act:()=>{player.kits.mil++;feed('군용 차량 배선 따개 +1');}});
      it.push({label:'대화 끝내기',desc:'"경찰 앞에서 꺼내 들면 끝장이야. 알지?"',act:()=>{menu.talk=false;}});
    }
  } else if(t==='conv'){
    it.push(foodItem('삼각김밥',15,25,10));
    it.push(foodItem('컵라면',20,40,0));
    it.push({label:'에너지 드링크',desc:'90초 동안 이동 속도 +20% · 허기 +5',price:35,act:()=>{player.buffs.speed=90;eat(5,0);}});
    it.push({label:'아이스 아메리카노',desc:'90초 동안 재장전 35% 빠르게',price:25,act:()=>{player.buffs.reload=90;}});
    it.push({label:'진통제',desc:'90초 동안 받는 피해 25% 감소',price:60,act:()=>{player.buffs.armor=90;}});
    it.push(robItem(loc,'계산대 털기','총을 겨누고 4초 버티기 · 수배 ★1',4,[300,900]));
  } else if(t==='diner'){
    it.push(foodItem('떡볶이',25,35,0));
    it.push(foodItem('김치찌개',40,60,15));
    it.push(foodItem('불고기 정식',70,100,30));
    it.push(robItem(loc,'계산대 털기','총을 겨누고 5초 버티기 · 수배 ★1',5,[400,1200]));
  } else if(t==='bank'){
    const B=player.bank,dep=a=>{const v=Math.min(a,player.money);player.money-=v;player.bank+=v;feed('예금 +$'+v.toLocaleString()+' · 잔액 $'+player.bank.toLocaleString());};
    const wd=a=>{const v=Math.min(a,player.bank);player.bank-=v;player.money+=v;feed('출금 $'+v.toLocaleString()+' · 잔액 $'+player.bank.toLocaleString());};
    it.push({label:'현금 전부 예금',desc:'잔액 $'+B.toLocaleString()+' · 매일 자정 이자 1% (하루 최대 $2,000)',dis:player.money>0?null:'가진 현금이 없다',act:()=>dep(player.money)});
    it.push({label:'$500 예금',desc:'현금 → 통장',dis:player.money>0?null:'가진 현금이 없다',act:()=>dep(500)});
    it.push({label:'전부 출금',desc:'통장 → 현금',dis:B>0?null:'잔액이 없다',act:()=>wd(B)});
    it.push({label:'$500 출금',desc:'통장 → 현금',dis:B>0?null:'잔액이 없다',act:()=>wd(500)});
    it.push(robItem(loc,'금고 털기','창구 앞에서 8초 버티기 · 경비원이 반격 · 수배 ★2 · $5,000–12,000',8,[5000,12000]));
  } else if(t==='hospital'){
    const price=Math.min(200,player.money);
    it.push({label:'치료 받기',desc:price<200?'체력 100 회복 · 가진 돈만 받아요':'체력 100 회복',price,dis:player.health>=100?'다친 곳이 없다':null,act:()=>{player.health=100;feed('치료 완료');}});
  } else if(t==='police'){
    const fine=250*wanted.stars,sent=sentenceFor(wanted.stars),no=wanted.stars?null:'수배 중이 아니다';
    it.push({label:'자수 · 보석금 내고 풀려나기',desc:'★당 $250 · 수배 즉시 해제',price:wanted.stars?fine:null,dis:no,close:true,act:()=>{setStars(0);toast('보석금 납부 · 수배 해제');feed('보석금 −$'+fine);}});
    it.push({label:'자수 · 감옥 가기',desc:'돈은 그대로 · 형기 '+sent+'초 · 감방 환풍구로 탈옥 가능',crime:true,dis:no,close:true,act:()=>goJail(sent,loc)});
  } else if(t==='hotel'){
    const price=HOTEL_PRICE(loc),booked=player.hotel&&player.hotel.loc===loc;
    it.push({label:'객실 예약 · 1박',desc:booked?'엘리베이터를 타고 객실로':'오른쪽 엘리베이터로 객실 이동 · 침대에서 자면 아침 7시 · 노트북으로 웹 서핑'+(player.hotel?' · 다른 호텔 예약은 취소됨':''),price:booked?null:price,dis:booked?'이미 예약했다':null,
      act:()=>{player.hotel={loc,slept:false};toast('예약 완료 · 오른쪽 엘리베이터로 객실에 올라가세요');feed(loc.title+' 1박 −$'+price);}});
    it.push({label:'라운지 안내',desc:'왼쪽 라운지에서 식사할 수 있어요',act:()=>toast('라운지는 로비 왼쪽입니다 · 주황 원에서 E')});
    if(booked)it.push({label:'체크아웃',desc:'객실 키 반납 · 환불은 안 돼요',close:true,act:()=>{player.hotel=null;toast('체크아웃 완료');}});
  } else if(t==='lounge'){
    const L=loc.hotel,k=L.look==='city'?1.6:L.look==='army'?1.2:1;
    it.push(foodItem('아메리칸 조식',Math.round(30*k),45,10));
    it.push(foodItem('클럽 샌드위치',Math.round(25*k),35,0));
    it.push(foodItem(L.look==='army'?'부대찌개 정식':'안심 스테이크',Math.round(70*k),90,30));
    it.push({label:'하우스 와인',desc:'60초 동안 받는 피해 25% 감소',price:Math.round(40*k),act:()=>{player.buffs.armor=Math.max(player.buffs.armor,60);}});
  } else if(t==='web'){
    it.push({label:'하버 뉴스',desc:'오늘의 헤드라인',act:()=>toast(wanted.stars>0?'[속보] 경찰, 수배자 추적 중 · 수배 ★'+wanted.stars:pick(NEWS))});
    it.push({label:'날씨 · 교통',desc:'시각 · 신호등 · 페리',act:()=>{const h=Math.floor(tod);toast('현재 '+h+'시 · 신호등 '+(sigOn?'운영 중':'꺼짐 (23–06시)')+' · 페리 하버↔공항 상시 운항');}});
    it.push({label:'온라인 복권 1장',desc:'8% 확률로 $120',price:10,act:()=>{if(RNG()<.08){player.money+=120;toast('당첨! +$120');}else toast('꽝 · 다음 기회에');}});
    it.push({label:'광물 시세',desc:Object.keys(ORES).map(k=>ORES[k][0]+' $'+ORES[k][1]).join(' · '),act:()=>toast('광산 갱도 안쪽 광부가 광물을 사들여요')});
    it.push({label:'부동산 매물',desc:'공인중개사 사무소 오픈 예정',act:()=>toast('매물 준비 중 · 공인중개사 사무소가 곧 문을 엽니다')});
    it.push({label:'항공권 검색',desc:'네온 아일랜드 → 본토 편도',act:()=>toast('NI-001 본토행 편도 $100,000 · 국제공항 발권 카운터')});
    it.push({label:'로그아웃',desc:'',close:true,act:()=>{}});
  } else if(t==='terminal'){
    it.push({label:'본토행 편도 항공권 · NI-001',desc:'이 섬을 떠난다 · 엔딩',price:TICKET_PRICE,dis:wanted.stars>0?'수배 중에는 출국 심사를 통과할 수 없다':null,close:true,act:()=>{feed('항공권 구매 −$'+TICKET_PRICE.toLocaleString());startEnding();}});
    it.push({label:'공항 안내',desc:'공항버스 · 페리 · 다리로 오갈 수 있어요',act:()=>toast('공항버스는 버스 차고지에서, 페리는 하버 부두에서 출발합니다')});
  } else if(t==='mine'){
    it.push({label:'곡괭이 구매',desc:'광맥을 캘 수 있다 · 내구도 '+PICK_DUR+'회',price:PICK_PRICE,dis:player.pickaxe?'이미 있다 · 내구도 '+player.pickaxe.dur+'/'+PICK_DUR:null,act:()=>{player.pickaxe={dur:PICK_DUR};toast('곡괭이 구매 · 갱도 벽의 광맥(노란 원)에서 E');}});
    for(const k in ORES){const n=player.ores[k];it.push({label:ORES[k][0]+' 팔기',desc:'개당 $'+ORES[k][1]+' · 보유 '+n+'개',gain:n*ORES[k][1],dis:n?null:'가진 게 없다',act:()=>{const g=n*ORES[k][1];player.money+=g;player.ores[k]=0;feed(ORES[k][0]+' '+n+'개 판매 +$'+g);}});}
  } else if(t==='marina'){
    for(const M of BOAT_MODELS)it.push({label:M.name+' 구매',desc:M.desc,price:M.price,close:true,act:()=>buyBoat(M)});
  } else if(t==='garage'){
    const c=player.car;
    if(c){
      const val=carValue(c),hp=Math.round(c.health/c.maxHealth*100),cost=repairCost(c);
      const what=c.price?'산 차 · 구입가의 절반':c.type==='civ'?'훔친 차':'훔친 관용차 · 비싸게 팔림';
      it.push({label:'이 차 팔기',desc:what+' · 상태 '+hp+'%',gain:val,dis:wanted.stars>0&&c.stolen?'수배 중에는 훔친 차를 받지 않아요':null,close:true,act:()=>sellCar(c,val)});
      it.push({label:'수리하기',desc:'내구도 '+hp+'% → 100%',price:cost||null,dis:cost?null:'고칠 곳이 없다',act:()=>{c.health=c.maxHealth;feed('수리 완료');}});
    }
    for(const M of CAR_MODELS)it.push({label:M.name+' 구매',desc:M.desc,price:M.price,close:true,act:()=>buyCar(loc,M)});
  }
  return it;
}
function eat(hg,hp){player.hunger=Math.min(100,player.hunger+hg);if(hp)player.health=Math.min(100,player.health+hp);player.hungerWarn=0;}
function foodItem(label,price,hg,hp){
  return {label,desc:'허기 +'+hg+(hp?' · 체력 +'+hp:''),price,dis:player.hunger>=99?'배가 부르다':null,act:()=>{eat(hg,hp);feed(label+' 먹음');}};
}
function itemBlock(it){if(it.dis)return it.dis;if(it.price!=null&&player.money<it.price)return '돈이 부족하다';return null;}
function openMenu(loc){
  job=null;menu={loc,items:[],talk:false};renderMenu();$('menu').hidden=false;
  try{document.exitPointerLock&&document.exitPointerLock();}catch(e){}
  input.keys={};input.fireHeld=false;input.punch=false;
}
function closeMenu(){if(!menu)return;menu=null;$('menu').hidden=true;canvas.focus();}
function renderMenu(){
  const T=menu.loc.T;menu.items=menuItems(menu.loc);
  $('menuTitle').textContent=menu.loc.title||T.title;$('menuSub').textContent=menu.talk?'카운터 밑 · 불법 품목':(menu.loc.sub||T.sub);$('menuCash').textContent='보유 현금 $'+player.money.toLocaleString();
  const list=$('menuList');list.innerHTML='';
  menu.items.forEach((it,i)=>{
    const b=document.createElement('button');b.type='button';b.className='mitem'+(it.crime?' crime':'');
    const why=itemBlock(it);b.disabled=!!why;
    const k=document.createElement('kbd');k.textContent=i+1;
    const nm=document.createElement('span');nm.className='mname';nm.textContent=it.label;
    const sm=document.createElement('small');sm.textContent=why||it.desc;nm.appendChild(sm);
    const pr=document.createElement('span');pr.className='mprice';pr.textContent=it.price!=null?'$'+it.price.toLocaleString():it.gain!=null?'+$'+it.gain.toLocaleString():'';
    b.append(k,nm,pr);b.addEventListener('click',()=>choose(i));list.appendChild(b);
  });
}
function choose(i){
  const it=menu&&menu.items[i];if(!it||itemBlock(it))return;
  if(it.price)player.money-=it.price;
  it.act();
  if(it.close)closeMenu();else if(menu)renderMenu();
}
function startRob(loc,dur,range){
  robbing={loc,t:0,dur,range};
  setStars(Math.max(wanted.stars,loc.type==='bank'?2:1));
  crime(0,player.pos,{bank:'은행 강도',conv:'편의점 강도',diner:'식당 강도'}[loc.type]);
  for(const p of peds){if(p.room===loc&&p.kind==='civ'&&!p.weapon&&!p.out&&p.state!=='down'){p.state='cower';p.fleeT=dur+8;}}
  toast((loc.type==='bank'?'금고':'계산대')+' 털이 시작 · '+dur+'초 버텨라');
}
function updateRobbery(dt){
  if(!robbing)return;
  const L=robbing.loc;
  if(player.inside!==L||d2(player.pos,L.room.counter)>3.5){robbing=null;L.robCD=20;toast('강도 실패 · 카운터를 벗어났다');return;}
  robbing.t+=dt;wanted.unseen=0;
  if(robbing.t>=robbing.dur){
    const loot=randi(robbing.range[0]/10,robbing.range[1]/10)*10;player.money+=loot;
    L.robCD=L.type==='bank'?120:90;
    if(L.type==='bank')crime(8,player.pos,'은행 털이 성공');
    toast('$'+loot.toLocaleString()+' 강탈!');feed('+ $'+loot.toLocaleString());robbing=null;
  }
}

// ---------- player ----------
function playerUpdate(dt){
  for(const k in player.buffs)if(player.buffs[k]>0)player.buffs[k]=Math.max(0,player.buffs[k]-dt);
  player.hunger=Math.max(0,player.hunger-dt*HUNGER_RATE);
  if(player.hunger<25&&player.hungerWarn<1){player.hungerWarn=1;toast('배가 고프다 · 식당이나 편의점으로');}
  if(player.hunger<10&&player.hungerWarn<2){player.hungerWarn=2;toast('굶어 쓰러지기 직전이다');}
  if(player.swim)player.hunger=Math.max(0,player.hunger-dt*HUNGER_RATE*.6); // swimming is hungry work
  if(player.hunger<=0){if(GOD)player.hunger=1;else{die('굶주림으로 쓰러졌습니다.');return;}}
  updateRobbery(dt);
  updateJail(dt);
  updateSurrender(dt);
  if(player.ride&&input.v){view=view==='third'?'first':'third';input.v=false;}
  if(player.ride&&player.ride.bus)busRide(dt);
  if(player.ride){input.punch=false;input.f=false;input.e=false;input.g=false;player.moving=false;return;}
  updateJob(dt);
  player.punchT-=dt;player.punchAnim=Math.max(0,player.punchAnim-dt);player.hitCD-=dt;player.fireT-=dt;
  if(player.reloadT>0){player.reloadT-=dt;if(player.reloadT<=0){const A=curAmmo();if(A){A.mags--;A.mag=WEAPONS[player.weapon].mag;}}}
  if(menu||transFn){input.punch=false;input.f=false;input.e=false;input.g=false;player.moving=false;return;}
  const k=input.keys;
  const mx=clamp(((k.KeyD||k.ArrowRight)?1:0)-((k.KeyA||k.ArrowLeft)?1:0)+input.joy.x,-1,1);
  const my=clamp(((k.KeyW||k.ArrowUp)?1:0)-((k.KeyS||k.ArrowDown)?1:0)-input.joy.y,-1,1);
  const space=k.Space||input.jumpHeld;
  if(input.v){view=view==='third'?'first':'third';input.v=false;}
  const zone=currentZone();
  if(input.f){input.f=false;
    if(player.car)exitCar(false);
    else{const c=player.inside?null:nearestCar(2.6),nb=!c&&!player.inside?nearNavyBoat():null;
      if(c){if(c.milLock)milUnlock(c.milLock,()=>{if(!c.dead&&!player.car)enterCar(c);});else if(isLocked(c))hotwire(c);else enterCar(c);}
      else if(nb){milUnlock('boat',()=>{if(!player.car)stealNavyBoat(nb);});}
      else if(zone)interact(zone);else{const m=nearestMark();if(m)pickpocket(m);}}
  }
  if(input.e){input.e=false;if(zone)interact(zone);}
  if(input.g){input.g=false;const m=nearestMark();if(m)pickpocket(m);}
  if(input.h){input.h=false;if(player.surrender)cancelSurrender('항복 취소');else trySurrender();}
  if(input.q){cycleWeapon(input.q);input.q=0;}
  if(input.c){input.c=false;if(!player.car)player.crouch=!player.crouch;}
  if(input.sel){switchWeapon(input.sel);input.sel=null;}
  if(input.reload){input.reload=false;startReload();}
  const A=curAmmo();
  if(A&&A.mag===0&&A.mags>0&&player.reloadT<=0&&player.fireT<=0)startReload();
  if(player.car){
    if(player.car.type==='fire'&&(input.fireHeld||input.punch))sprayCannon(player.car,dt);
    else if(GUN_VEH[player.car.type]&&(input.fireHeld||input.punch))vehicleGun(player.car,dt);
    input.punch=false;player.moving=false;
    driveCar(player.car,burnFuel(player.car,dt,my),mx,space,dt);
    return;
  }
  if(player.surrender){
    if(Math.abs(mx)+Math.abs(my)>.3||input.punch||space){input.punch=false;cancelSurrender('움직여서 항복이 취소됐다');}
    else{input.punch=false;player.moving=false;return;}
  }
  const fx=Math.sin(camYaw),fz=Math.cos(camYaw),rx=-fz,rz=fx;
  let vx=fx*my+rx*mx,vz=fz*my+rz*mx;const l=Math.hypot(vx,vz);
  player.moving=l>.1;
  const sprint=k.ShiftLeft||k.ShiftRight||(l>.95&&coarse);
  if(l>0){vx/=Math.max(1,l);vz/=Math.max(1,l);}
  const swim=player.swim=inSea(player.pos)&&player.pos.y<QUAY.y-.6;
  if(swim){player.crouch=false;input.punch=false;}
  const spd=swim?(sprint?3.8:2.5):(player.crouch?2.3:sprint?8.5:4.8)*(player.buffs.speed>0?1.2:1);
  player.pos.x+=vx*spd*dt;player.pos.z+=vz*spd*dt;
  if(l>.05){if(view==='third'&&player.weapon==='fist')player.yaw+=angDiff(player.yaw,Math.atan2(vx,vz))*Math.min(1,dt*14);player.phase+=dt*spd*2.4*Math.min(1,l);}
  if(view==='first'||player.weapon!=='fist')player.yaw=camYaw;
  if(space&&player.crouch)player.crouch=false;
  else if(space&&player.grounded&&player.vy<=0&&!swim){player.vy=6.6;player.grounded=false;}
  player.vy-=20*dt;player.pos.y+=player.vy*dt;
  collideCircle(player.pos,.4,false,true);
  { // stand on the ground (or the mountainside, a deck, or tread water); stick to it walking downhill
    const inWater=inSea(player.pos);
    const fl=inWater?SWIM_Y:floorH(player.pos.x,player.pos.z);
    if(inWater&&player.pos.y>SWIM_Y+.3&&player.pos.y+player.vy*dt<=SWIM_Y+.3){for(let k=0;k<8;k++)puff(new V3(player.pos.x,WATER_Y+.1,player.pos.z),0xe6f2ff,rand(.3,.6),new V3(rand(-2,2),rand(2,4),rand(-2,2)),.6);}
    if(inWater&&l>.1){player.splashT=(player.splashT||0)-dt;if(player.splashT<=0){player.splashT=.35;puff(new V3(player.pos.x,WATER_Y+.05,player.pos.z),0xe6f2ff,rand(.25,.4),new V3(rand(-.6,.6),.8,rand(-.6,.6)),.7);}}
    if(player.pos.y<=fl||(player.grounded&&player.vy<=0&&player.pos.y-fl<.7&&!inWater)){player.pos.y=fl;player.vy=0;player.grounded=true;}
    else player.grounded=false;
  }
  if(!player.inside)for(const c of cars){
    if(c.dead||Math.abs(c.pos.y-player.pos.y)>2.2)continue;const f=fwdOf(c),r={x:-f.z,z:f.x};const dx=player.pos.x-c.pos.x,dz=player.pos.z-c.pos.z;
    const lz=dx*f.x+dz*f.z,lx=dx*r.x+dz*r.z,hw=c.w/2+.4,hl=c.half+.4;
    if(Math.abs(lx)<hw&&Math.abs(lz)<hl){
      if(Math.abs(c.speed)>6&&player.hitCD<=0&&c.ai!=='player'){
        player.hitCD=.8;damagePlayer(Math.abs(c.speed)*1.3,'차에 치였습니다.');shake=Math.max(shake,.5);
        player.pos.x+=f.x*Math.sign(c.speed)*2.5;player.pos.z+=f.z*Math.sign(c.speed)*2.5;
      }
      const px=hw-Math.abs(lx),pz=hl-Math.abs(lz);
      if(px<pz){const s=Math.sign(lx)||1;player.pos.x+=r.x*px*s;player.pos.z+=r.z*px*s;}
      else{const s=Math.sign(lz)||1;player.pos.x+=f.x*pz*s;player.pos.z+=f.z*pz*s;}
    }
  }
  const W=WEAPONS[player.weapon];
  if(player.swim){input.punch=false;}
  else if(input.punch){input.punch=false;if(player.weapon==='fist')punch();else fire();}
  else if(W.auto&&input.fireHeld)fire();
}

// ---------- collisions between cars & with peds ----------
function carCollisions(){
  const list=cars.filter(c=>!c.dead&&c.ai!=='towed'&&!(c.type==='pheli'&&c.pos.y>heliFloor(c.pos.x,c.pos.z)+1));
  for(let i=0;i<list.length;i++)for(let j=i+1;j<list.length;j++){
    const a=list[i],b=list[j];
    if((a.ai==='traffic'||a.ai==='patrol')&&(b.ai==='traffic'||b.ai==='patrol'))continue;
    if((a.lotMove&&(b.ai==='parked'||b.lotMove))||(b.lotMove&&a.ai==='parked'))continue;
    if(Math.abs(a.pos.x-b.pos.x)>7||Math.abs(a.pos.z-b.pos.z)>7)continue;
    const fa=fwdOf(a),fb=fwdOf(b),oa=a.half-a.rad,ob=b.half-b.rad;
    let hit=false,nx=0,nz=0;
    for(const sa of [1,-1])for(const sb of [1,-1]){
      const ax=a.pos.x+fa.x*oa*sa,az=a.pos.z+fa.z*oa*sa,bx_=b.pos.x+fb.x*ob*sb,bz=b.pos.z+fb.z*ob*sb;
      const dx=ax-bx_,dz=az-bz,d=Math.hypot(dx,dz),m=a.rad+b.rad;
      if(d<m&&d>1e-4){const pen=(m-d)/2;a.pos.x+=dx/d*pen;a.pos.z+=dz/d*pen;b.pos.x-=dx/d*pen;b.pos.z-=dz/d*pen;hit=true;nx=dx/d;nz=dz/d;}
    }
    if(!hit)continue;
    const vax=fa.x*a.speed,vaz=fa.z*a.speed,vbx=fb.x*b.speed,vbz=fb.z*b.speed;
    const impact=-((vax-vbx)*nx+(vaz-vbz)*nz);
    if(impact>2){
      const sa=a.speed,sb=b.speed;
      a.speed=sa*.5+(vbx*fa.x+vbz*fa.z)*.35;b.speed=sb*.5+(vax*fb.x+vaz*fb.z)*.35;
      for(const c of [a,b])if(c.ai==='traffic'){c.ai='parked';c.crashed=true;}
      if(impact>7){const dmg=(impact-6)*2;a.health-=dmg*(b.type==='army'?1.6:1);b.health-=dmg*(a.type==='army'?1.6:1);
        if(a===player.car||b===player.car){shake=Math.max(shake,impact/26);const o=a===player.car?b:a;
          if(o.type==='civ'&&impact>9)crashCivil(o);
          if(o.type!=='civ'&&o.ai==='chase'){player.health-=impact*.15;hurtFlash();}
        }
        const at=new V3((a.pos.x+b.pos.x)/2,1,(a.pos.z+b.pos.z)/2);
        for(let k=0;k<4;k++)puff(at,0xffd080,.15,new V3(rand(-4,4),rand(1,4),rand(-4,4)),.25,true);
      }
    }
  }
  for(const c of list){
    if(Math.abs(c.speed)<3.5||c.ai==='wreck')continue;
    const f=fwdOf(c),r={x:-f.z,z:f.x};
    for(const p of peds){
      if(p.state==='fly'||p.state==='down'||p.dead||p.room)continue;
      const dx=p.pos.x-c.pos.x,dz=p.pos.z-c.pos.z;if(Math.abs(dx)>5||Math.abs(dz)>5)continue;
      const lz=dx*f.x+dz*f.z,lx=dx*r.x+dz*r.z;
      if(Math.abs(lx)<c.w/2+.35&&Math.abs(lz)<c.half+.35){
        const s=c.speed,byP=c===player.car;
        p.hp-=Math.abs(s)*4.5;if(p.hp<=0)p.out=true;
        if(byP&&!p.crim){const C=CRIME[p.kind];crime(C.base*(p.out?2.5:1),p.pos,C.car);if(!p.out)p.provokeOnUp=true;}
        knock(p,f.x*s*.6+r.x*Math.sign(lx||1)*2,3+Math.abs(s)*.18,f.z*s*.6+r.z*Math.sign(lx||1)*2);
        c.speed*=.9;
      }
    }
  }
}

// ---------- heli ----------
function heliUpdate(dt){
  if(!heli)return;
  const tp=playerPos();heli.lifeT+=dt;
  if(wanted.stars<5&&heli.state!=='leave'){heli.state='leave';heli.lifeT=0;}
  let target;
  if(heli.state==='leave'){target=new V3(heli.pos.x+(heli.pos.x-tp.x),70,heli.pos.z+(heli.pos.z-tp.z));if(heli.lifeT>9){scene.remove(heli.g);scene.remove(heli.cone);heli=null;return;}}
  else{heli.t+=dt*.35;target=new V3(tp.x+Math.cos(heli.t)*24,(tp.y||0)+26,tp.z+Math.sin(heli.t)*24);}
  const dv=target.clone().sub(heli.pos),dl=dv.length();if(dl>.01)heli.pos.addScaledVector(dv,Math.min(1,dt*1.2));
  heli.g.position.copy(heli.pos);heli.rotor.rotation.y+=dt*28;
  heli.g.rotation.y=Math.atan2(tp.x-heli.pos.x,tp.z-heli.pos.z);heli.g.rotation.x=.12;
  const aim=new V3(tp.x,tp.y||0,tp.z),dir=heli.pos.clone().sub(aim),len=dir.length();
  heli.cone.visible=heli.state!=='leave';
  heli.cone.position.copy(heli.pos);heli.cone.quaternion.setFromUnitVectors(Y,dir.normalize());heli.cone.scale.set(1,len,1);
  if(heli.state==='hunt'&&!dead&&!player.inside&&!player.surrender){
    heli.fireT-=dt;
    if(heli.fireT<=0){
      if(heli.burst<=0)heli.burst=10;
      heli.fireT=.11;heli.burst--;if(heli.burst===0)heli.fireT=1.8;
      const hit=RNG()<.25*(player.car&&Math.abs(player.car.speed)>14?.5:1),spr=hit?.4:3;
      const from=heli.pos.clone();from.y-=1.2;
      tracer(from,new V3(tp.x+rand(-spr,spr),1,tp.z+rand(-spr,spr)),0xffe9a8);
      if(hit)damagePlayer(2.5,'공격 헬기의 사격에 쓰러졌습니다.');
    }
  }
}

// ---------- spawn manager ----------
let spawnT=0,seenT=0;
const TRAFFIC=18;
function manage(dt){
  spawnT-=dt;if(spawnT>0)return;spawnT=.8;
  const s=wanted.stars,wantP=[0,1,2,2,1,1][s],wantS=[0,0,0,1,1,1][s],wantA=[0,0,0,0,2,2][s];
  let nP=0,nS=0,nA=0,nT=0;const parkedCiv=[];
  for(const c of cars){if(c.dead)continue;
    if(c.ai==='chase'){if(c.type==='police')nP++;else if(c.type==='swat')nS++;else nA++;}
    if(c.ai==='traffic'&&!c.keep)nT++;
    if(c.ai==='parked'&&c.type==='civ'&&c!==player.car&&!c.owned&&!c.fleet&&!c.lotCar)parkedCiv.push(c);}
  if(nP<wantP)spawnUnit('police');else if(nS<wantS)spawnUnit('swat');else if(nA<wantA)spawnUnit('army');
  if(s>=5&&!heli&&heliCD<=0)heli=makeHeli();
  if(nT<TRAFFIC){const sp=spawnRoadPos(80,170);if(sp)makeTraffic(sp);}
  // shift traffic through the estate gates: workers driving in, deliveries heading out
  if(nT<TRAFFIC+4&&RNG()<.3){const tp=playerPos();
    for(const sx of [-1,1]){const gx=sx*R[N];if(Math.hypot(tp.x-gx,tp.z-IND_FZ)>260)continue;
      const inb=RNG()<.5,dz=inb?1:-1,z=IND_FZ+(inb?-1:1)*rand(70,120),li=sx<0?0:N,x=R[li]-LANE*dz;
      if(Math.hypot(tp.x-x,tp.z-z)<70||!freeAt(x,z,8)||!segAt(false,li,z))continue;
      let ni;if(dz>0){ni=0;while(R[ni]<=z)ni++;}else{ni=NZ;while(R[ni]>=z)ni--;}
      makeTraffic({x,z,dx:0,dz,li,ni});break;}}
  const tp=playerPos();
  // the world is big: keep trash, parked cars, traffic and pedestrians around the player and recycle the far ones
  for(let i=pickups.length-1;i>=0;i--)if(litter(pickups[i].kind)&&d2(pickups[i].pos,tp)>300)removePickup(i);
  if(pickups.filter(p=>p.kind==='trash').length<TRASH_N)spawnTrash(40);
  if(pickups.filter(p=>p.kind==='scrap').length<SCRAP_N)spawnTrash(40,'scrap');
  for(const c of cars){if(c===player.car)continue;const d=d2(c.pos,tp);
    if(c.ai==='wreck'&&d>110&&!(c.tow&&!c.tow.dead))c.dead=true;
    if(c.ai==='traffic'&&d>320&&!c.keep)c.dead=true;
    if(c.ai==='parked'&&c.type!=='civ'&&!c.fixed&&!c.owned&&d>120)c.dead=true;}
  if(parkedCiv.length>16){parkedCiv.sort((a,b)=>d2(b.pos,tp)-d2(a.pos,tp));if(d2(parkedCiv[0].pos,tp)>100)parkedCiv[0].dead=true;}
  else if(parkedCiv.filter(c=>d2(c.pos,tp)<200).length<12)makeParked(70,170);
  // crowds: more walkers, packed into the blocks around the player
  const civ=peds.filter(p=>p.kind==='civ'&&!p.dead&&!p.room&&!p.role);
  for(const p of civ)if((p.state==='walk'||p.state==='flee')&&d2(p.pos,tp)>175)p.dead=true;
  if(civ.length<CIV_TARGET)for(let k=0;k<3;k++)spawnCivWalker(45);
  // patrols: squad cars cruising each patrol zone, officers walking its sidewalks while you are there
  const act=actualPos(),[pbi,pbj]=blockOf(tp.x,tp.z);
  for(const Z of PATROL_ZONES){
    const zc=cars.filter(c=>c.ai==='patrol'&&!c.dead&&c.zone===Z);
    if(zc.length<Z.cars)spawnPatrolCar(Z);
    const foot=peds.filter(p=>p.kind==='cop'&&p.state==='patrol'&&!p.dead&&p.zone===Z);
    for(const p of foot)if(d2(p.pos,tp)>240)p.dead=true;
    if(pbi>=Z.i0&&pbi<Z.i1&&pbj>=Z.j0&&pbj<Z.j1&&foot.length<Z.foot)spawnPatrolCop(Z);
  }
  for(const c of cars)if(c.ai==='patrol'&&!c.dead&&wanted.stars>0&&!player.inside&&d2(c.pos,act)<70&&hasLOS(c.pos,act)){c.ai='chase';feed('순찰차가 당신을 발견했다');}
  justiceScan();
  refillSlots(false);
  // accidents: mark blocked road segments, send tow trucks for wrecks and crashed cars
  BLOCKED.clear();
  const busyTow=c=>!c.dead&&!c.city&&(c.ai==='towRun'||c.ai==='towHook'||c.ai==='towBack');
  let tows=cars.filter(c=>busyTow(c)&&!c.road).length,roads=cars.filter(c=>busyTow(c)&&c.road).length;
  for(const c of cars){
    if(c.dead||c.owned||c===player.car)continue;
    const acc=c.ai==='wreck'||(c.crashed&&c.ai==='parked');if(!acc){c.accT=0;continue;}
    const k=segKeyAt(c.pos);if(k)BLOCKED.add(k);
    c.accT=(c.accT||0)+.8;
    if(!c.accRep&&d2(c.pos,tp)<350){
      const off=officialOf(c.pos,60);
      if(off){c.accRep=true;if(d2(c.pos,tp)<150)feed(offName(off)+'이 사고 차량을 신고했다');}
      else if(!c.accW&&witnessOf(c.pos,40)){c.accW=true;if(RNG()<.6){c.accRep=true;if(d2(c.pos,tp)<150)feed('시민이 사고 차량을 신고했다');}}
      else if(!c.accF&&c.accT>40){c.accF=true;if(RNG()<.3)c.accRep=true;}
    }
    if(!c.accRep||c.accT<6||(c.tow&&!c.tow.dead)||d2(c.pos,tp)>=350)continue;
    if(tows<2){if(dispatchTow(c))tows++;}
    else if(roads<2&&c.accT>14){if(dispatchTow(c,false,true))roads++;} // garages swamped: city road maintenance helps out
  }
  // fire brigade
  let trucks=cars.filter(c=>!c.dead&&(c.ai==='fireRun'||c.ai==='fireWait')).length;
  for(const f of fires){if(trucks>=3)break;if(f.dead||f.truck&&!f.truck.dead&&f.truck.ai!=='player'&&f.truck.ai!=='leave'||!f.reported||emCalls.some(e=>e.o===f))continue;if(dispatchTruck(f))trucks++;}
  // base sentries come back once you are well away
  for(const G of GUARD_SLOTS){
    if(G.p&&!G.p.dead)continue;
    if(Math.hypot(G.x-tp.x,G.z-tp.z)<130)continue;
    G.p=makePed(G.kind||'soldier',G.x,G.z,{role:'gate',weapon:G.weapon||'rifle',yaw:G.yaw,state:'idle',hpMul:1.2,look:G.look});G.p.lifeT=0;
  }
}
const CIV_TARGET=72;
// north-west (old downtown) and the west harbour each have their own patrols; bounds are intersection indices
const PATROL_ZONES=[
  {id:'nw',i0:0,i1:6,j0:0,j1:6,cars:3,foot:5},
  {id:'harbor',i0:0,i1:6,j0:6,j1:12,cars:2,foot:4}
];
function spawnPatrolCar(Z){
  const tp=actualPos();
  for(let tries=0;tries<30;tries++){
    const horiz=RNG()<.5,s=RNG()<.5?1:-1,li=horiz?randi(Z.j0,Z.j1):randi(Z.i0,Z.i1);
    const t=horiz?rand(R[Z.i0]+10,R[Z.i1]-10):rand(R[Z.j0]+10,R[Z.j1]-10),near=Math.round((t-R[0])/CELL);if(Math.abs(t-R[near])<11||!segAt(horiz,li,t))continue;
    const dx=horiz?s:0,dz=horiz?0:s,x=horiz?t:R[li]-LANE*dz,z=horiz?R[li]+LANE*dx:t;
    if(Math.hypot(x-tp.x,z-tp.z)<60||cars.some(c=>!c.dead&&Math.hypot(c.pos.x-x,c.pos.z-z)<8))continue;
    let ni;if(s>0){ni=0;while(R[ni]<=t)ni++;}else{ni=R.length-1;while(R[ni]>=t)ni--;}
    const c=makeCar('police',x,z,Math.atan2(dx,dz),'patrol');
    c.dx=dx;c.dz=dz;c.li=li;c.ni=ni;c.zone=Z;c.speed=6;c.crew=2;chooseTurn(c);
    return c;
  }
}
function spawnPatrolCop(Z){
  const ij=nearBlock(b=>WALKABLE.has(b.kind),2);if(!ij||ij[0]<Z.i0||ij[0]>=Z.i1||ij[1]<Z.j0||ij[1]>=Z.j1)return;
  const tp=playerPos(),cs=cornersOf(ij[0],ij[1]),k=randi(0,3),dir=RNG()<.5?1:-1,a=cs[k],b=cs[(k+dir+4)%4],t=RNG();
  const x=a[0]+(b[0]-a[0])*t,z=a[1]+(b[1]-a[1])*t;if(Math.hypot(x-tp.x,z-tp.z)<40)return;
  const p=makePed('cop',x,z,{weapon:RNG()<.25?'shotgun':'pistol'});
  p.corners=cs;p.ci=(k+dir+4)%4;p.dirc=dir;p.state='patrol';p.lifeT=0;p.zone=Z;
}
let baseIn=false,afbWarn=false,afbT=0;
function updateSeen(dt){
  seenT-=dt;if(seenT<=0){seenT=.25;
    const ps=playerSpace(),act=actualPos();let seen=false;
    // walking or driving into the walled base is a crime on its own
    const ib=!player.inside&&inBase(act);
    if(ib&&!baseIn&&started&&!dead){
      if(player.pass&&wanted.stars===0&&!player.car)toast('위조 출입증으로 정문 통과');
      else{if(wanted.stars<2)setStars(2);crime(0,act,'군사 기지 무단 침입');toast('군사 기지 무단 침입 · 수배 ★2');}}
    baseIn=ib;
    // the air force base island and its waters are off-limits
    const nearAfb=!player.inside&&inAfbZone(act,130);
    if(nearAfb&&started&&!dead){
      if(!afbWarn){afbWarn=true;toast('공군 기지 경계 수역 · 민간인 출입금지');}
      afbT+=.25;const onIt=inRect(act,AFB);
      if((onIt||afbT>10)&&wanted.stars<3){setStars(3);crime(0,act,onIt?'공군 기지 침입':'공군 기지 접근');toast('공군 기지 침입 · 수배 ★3');}
    } else {afbWarn=false;afbT=0;}
    // black-market weapons in hand in view of the police
    if(wanted.stars===0&&!ps&&!player.car&&!dead&&WEAPONS[player.weapon].illegal){
      let spot=false;
      for(const p of peds){if(p.kind!=='cop'||p.dead||p.out||p.room||p.state==='down'||p.state==='fly')continue;if(d2(p.pos,act)<32&&hasLOS(p.pos,act)){spot=true;break;}}
      if(!spot)for(const c of cars)if(!c.dead&&(c.ai==='patrol'||c.ai==='chase'||(c.type==='police'&&c.fixed))&&d2(c.pos,act)<38&&hasLOS(c.pos,act)){spot=true;break;}
      if(spot){crime(4,act,'불법 무기 소지');toast(WEAPONS[player.weapon].name+'을(를) 경찰이 봤다!');}
    }
    for(const p of peds){if(p.kind!=='civ'&&p.state==='chase'&&!p.dead&&!p.out&&(p.room||null)===ps&&d2(p.pos,act)<45&&hasLOS(p.pos,act)){seen=true;break;}}
    if(!seen&&!ps)for(const c of cars){if(c.ai==='chase'&&!c.dead&&d2(c.pos,act)<55&&hasLOS(c.pos,act)){seen=true;break;}}
    if(!seen&&!ps&&heli&&heli.state==='hunt'&&d2(heli.pos,act)<70)seen=true;
    wanted.seen=seen;
  }
  if(wanted.stars>0){
    if(wanted.seen)wanted.unseen=0;else wanted.unseen+=dt;
    if(wanted.unseen>LOSE_TIME){wanted.unseen=0;setStars(wanted.stars-1);}
  } else if(player.health<100&&!dead&&player.hunger>15) player.health=Math.min(100,player.health+4*dt);
}

// ---------- camera ----------
const camTmp=new V3();
function camClip(pivot,desired){
  let tb=1;forColliders(pivot.x-.3,pivot.z-.3,desired.x+.3,desired.z+.3,c=>{if(c.tree)return;if(c.h<Math.min(pivot.y,desired.y))return;const t=segEntry(pivot.x,pivot.z,desired.x,desired.z,c,.3);if(t!==null&&t>0&&t<tb)tb=t;});
  if(tb<1){const b=desired.clone();desired.lerpVectors(pivot,b,Math.max(.08,tb-.06));}
}
function settle(dt,k){if(camSnap){camera.position.copy(camTmp);camSnap=false;}else camera.position.lerp(camTmp,1-Math.exp(-k*dt));}
let attract=0;
function updateCamera(dt){
  lastLookT+=dt;
  if(!started){attract+=dt*.06;const c=playerPos();camera.position.set(c.x+Math.cos(attract)*70,42,c.z+Math.sin(attract)*70);camera.lookAt(c.x,4,c.z);return;}
  let sx=0,sy=0;if(shake>0){sx=rand(-1,1)*shake*.4;sy=rand(-1,1)*shake*.4;shake=Math.max(0,shake-dt*2.2);}
  const fp=view==='first',RC=player.car||(player.ride&&player.ride.bus)||null;
  if(RC){
    const c=RC,big=c.type==='bus'||c.type==='army'||c.type==='swat'||c.type==='fire'||c.type==='apc'||c.type==='pheli'||c.type==='navyboat';
    if(lastLookT>1.2&&Math.abs(c.speed)>3)carYawOff+=angDiff(carYawOff,0)*Math.min(1,dt*2.2);
    const yaw=c.heading+carYawOff,pitch=fp?camPitch+.1:Math.min(camPitch,.25);
    const f=new V3(Math.sin(yaw)*Math.cos(pitch),Math.sin(pitch),Math.cos(yaw)*Math.cos(pitch));
    if(fp){
      const cf=fwdOf(c),l={x:cf.z,z:-cf.x};
      const big2=big||c.type==='fire';
      if(c.type==='pheli'||isBoat(c)||c.type==='apc'){const S={pheli:[.45,1.9,1.8],apc:[.5,2.3,1.2],navyboat:[.6,2.4,-.6],mboat:[.4,1.25,-.2]}[c.type];
        const seat=new V3(c.pos.x+l.x*S[0]+cf.x*S[2],c.pos.y+S[1],c.pos.z+l.z*S[0]+cf.z*S[2]);
        camera.position.copy(seat);camSnap=false;camera.lookAt(seat.x+f.x+sx*.02,seat.y+f.y+sy*.02,seat.z+f.z);return;}
      const seat=new V3(c.pos.x+l.x*(big2?.5:.42)+cf.x*(c.type==='fire'?2.9:big?1.7:-.15),c.pos.y+(c.type==='army'||c.type==='fire'?2.45:big?2:1.32),c.pos.z+l.z*(big2?.5:.42)+cf.z*(c.type==='fire'?2.9:big?1.7:-.15));
      camera.position.copy(seat);camSnap=false;camera.lookAt(seat.x+f.x+sx*.02,seat.y+f.y+sy*.02,seat.z+f.z);
    } else {
      const pivot=new V3(c.pos.x,c.pos.y+(big?3:2),c.pos.z),dist=c.type==='pheli'?15:c.type==='navyboat'?14:big?12:9;
      camTmp.set(pivot.x-f.x*dist,pivot.y-f.y*dist+1.4,pivot.z-f.z*dist);camClip(pivot,camTmp);
      settle(dt,14);camera.position.y=Math.max(terrainH(camera.position.x,camera.position.z)+.6,camera.position.y);
      camera.lookAt(pivot.x+f.x*4+sx,pivot.y+f.y*4+sy,pivot.z+f.z*4);
    }
  } else {
    const f=new V3(Math.sin(camYaw)*Math.cos(camPitch),Math.sin(camPitch),Math.cos(camYaw)*Math.cos(camPitch));
    const r={x:-Math.cos(camYaw),z:Math.sin(camYaw)};
    if(fp){
      const eye=new V3(player.pos.x+Math.sin(camYaw)*.15,player.pos.y+(player.crouch?1.05:1.62),player.pos.z+Math.cos(camYaw)*.15);
      camera.position.copy(eye);camSnap=false;camera.lookAt(eye.x+f.x,eye.y+f.y,eye.z+f.z);
    } else {
      const inside=player.inside,dist=inside?3.1:4.8;
      const pivot=new V3(player.pos.x+r.x*.55,player.pos.y+(player.crouch?1.08:1.65),player.pos.z+r.z*.55);
      camTmp.set(pivot.x-f.x*dist,pivot.y-f.y*dist+.3,pivot.z-f.z*dist);camClip(pivot,camTmp);
      if(inside){const rm=inside.room;camTmp.x=clamp(camTmp.x,rm.x0+.3,rm.x1-.3);camTmp.z=clamp(camTmp.z,rm.z0+.3,rm.z1-.3);camTmp.y=Math.min(camTmp.y,rm.h-.35);}
      settle(dt,22);camera.position.y=Math.max(terrainH(camera.position.x,camera.position.z)+.4,camera.position.y);
      if(inside)camera.position.y=Math.min(camera.position.y,inside.room.h-.3);
      camera.lookAt(pivot.x+f.x*10+sx,pivot.y+f.y*10+sy,pivot.z+f.z*10);
    }
  }
}

// ---------- sync meshes ----------
let clock=0;
function syncMeshes(dt){
  const pb=player.body,armed=player.weapon!=='fist';
  pb.g.visible=!player.car&&!(player.ride&&player.ride.bus)&&view!=='first';
  player.shadow.visible=!player.car&&!(player.ride&&player.ride.bus);
  {const gy=groundY(player.pos.x,player.pos.z);player.shadow.position.set(player.pos.x,gy,player.pos.z);
  const s=.95*Math.max(.55,1-Math.max(0,player.pos.y-gy)*.25);player.shadow.scale.set(s,1,s);}
  pb.g.position.copy(player.pos);pb.g.rotation.set(0,player.yaw,0);
  animPerson(pb,player.phase,player.moving?(player.crouch?.35:.8):0);
  if(player.surrender&&!player.car){pb.armL.rotation.x=pb.armR.rotation.x=-2.95;pb.armL.rotation.z=-.2;}
  if(player.crouch){pb.g.position.y-=.42;pb.legL.rotation.x-=1.25;pb.legR.rotation.x-=1.25;}
  if(player.swim){const st=clock*(player.moving?5:2.2);pb.armL.rotation.x=-2.2+Math.sin(st)*1.1;pb.armR.rotation.x=-2.2-Math.sin(st)*1.1;pb.armL.rotation.z=-.5;pb.legL.rotation.x=Math.sin(st*1.4)*.5;pb.legR.rotation.x=-Math.sin(st*1.4)*.5;}
  if(player.punchAnim>0)pb.armR.rotation.x=-1.65*Math.sin(player.punchAnim/.25*Math.PI);
  for(const k in pGuns)pGuns[k].visible=player.weapon===k;
  if(armed){const aim=-Math.PI/2-camPitch;pb.armR.rotation.x=aim+recoil*.35;pb.armL.rotation.x=aim+.15;pb.armL.rotation.z=-.45;}
  if(player.reloadT>0&&armed){pb.armR.rotation.x=-.9;pb.armL.rotation.x=-.9;}
  const vmOn=started&&view==='first'&&!player.car&&armed;
  for(const k in vmG)vmG[k].visible=vmOn&&player.weapon===k;
  vm.position.set(.24,-.22+(player.reloadT>0?-.12:0),-.5+recoil*.07);vm.rotation.x=recoil*.3+(player.reloadT>0?-.5:0);
  for(const r of rings){r.material.opacity=.55+.35*Math.sin(clock*4);r.scale.setScalar((r.userData.base||1)*(1+.06*Math.sin(clock*4)));}
  for(const p of peds){
    const b=p.body;b.g.position.copy(p.pos);
    p.shadow.position.set(p.pos.x,groundY(p.pos.x,p.pos.z),p.pos.z);
    if(p.state==='down'){p.shadow.scale.set(1.1,1,1.9);p.shadow.rotation.y=p.yaw;}else{p.shadow.scale.set(.95,1,.95);}
    const showGun=p.weapon&&!p.dropped&&(p.kind!=='civ'||p.state==='fight'||p.state==='brawl');
    if(p.gm)p.gm.visible=!!showGun;
    if(p.state==='fly'){b.g.rotation.y=p.yaw;b.g.rotation.x+=p.spin*dt;}
    else if(p.state==='down'){b.g.rotation.set(-Math.PI/2,p.yaw,0);b.g.position.y=p.pos.y+.17;animPerson(b,0,0);b.armL.rotation.x=-.3;b.armR.rotation.x=.4;}
    else{
      b.g.rotation.set(p.stunT>0?-.3:0,p.yaw,0);
      animPerson(b,p.phase,p.animAmp||0);
      if(p.state==='chase'||p.state==='fight'||p.state==='arrest'||p.state==='brawl'){
        if(showGun){if(!(p.animAmp>0)){b.armR.rotation.x=-1.5;b.armL.rotation.x=-1.3;}else b.armR.rotation.x=-1.2;}
        else{b.armL.rotation.x=-1.0;b.armR.rotation.x=p.punchAnim>0?-1.7:-.9;}
      } else if(p.state==='cower'){b.armL.rotation.x=b.armR.rotation.x=-2.9;}
      else if(p.state==='cuffed'||p.state==='escorted'){b.armL.rotation.x=b.armR.rotation.x=.55;b.armL.rotation.z=.25;b.armR.rotation.z=-.25;}
      else if(p.kneel){b.g.position.y-=.45;b.legL.rotation.x=-1.3;b.legR.rotation.x=.2;b.armL.rotation.x=b.armR.rotation.x=-1.1;}
      else if(p.carrying||p.prying){b.armL.rotation.x=b.armR.rotation.x=-1.2;}
      else if(p.spray){b.armL.rotation.x=-1.35;b.armR.rotation.x=-1.25;b.armL.rotation.z=-.3;}
    }
  }
  const flash=Math.floor(clock*6)%2===0;
  for(const c of cars){
    if(c.ai==='traffic'||c.ai==='patrol')c.vis+=angDiff(c.vis,c.heading)*Math.min(1,dt*9);else c.vis=c.heading;
    // cars sit on the mountainside: height from the terrain, pitch and roll from its slope
    if(c.type==='pheli'||isBoat(c))syncAirSea(c,dt);else{
    const ty=floorH(c.pos.x,c.pos.z);c.pos.y=ty;
    if(ty>0||c.tilted){const f=fwdOf(c),hl=c.half*.8,hw=c.w/2;
      const hf=terrainH(c.pos.x+f.x*hl,c.pos.z+f.z*hl),hb=terrainH(c.pos.x-f.x*hl,c.pos.z-f.z*hl),hL=terrainH(c.pos.x+f.z*hw,c.pos.z-f.x*hw),hR=terrainH(c.pos.x-f.z*hw,c.pos.z+f.x*hw);
      c.pos.y=Math.max(ty,(hf+hb)/2);c.mesh.rotation.x=-Math.atan2(hf-hb,hl*2);c.mesh.rotation.z=Math.atan2(hL-hR,hw*2);c.tilted=ty>0;}
    {const cy=c.pos.y===0&&onMainXZ(c.pos.x,c.pos.z,553)?Math.max(0,groundY(c.pos.x,c.pos.z)-.025):0;c.cy=(c.cy||0)+(cy-(c.cy||0))*Math.min(1,dt*12);}
    c.mesh.position.set(c.pos.x,c.pos.y+c.cy,c.pos.z);c.mesh.rotation.y=c.vis;}
    if(c.ai==='towed'){c.mesh.position.y+=.5;c.mesh.rotation.x=-.13;c.tilted=true;}
    c.shadow.position.set(c.pos.x,groundY(c.pos.x,c.pos.z),c.pos.z);c.shadow.rotation.y=c.vis;
    const lit=c.ai==='bus'||/^taxi/.test(c.ai)||c.ai==='depOut'||c.ai==='freight'||c.ai==='lotIn'||c.ai==='lotOut'||c.ai==='rejoin'||c.ai==='respond'||c.ai==='respondWait'||c.ai==='ambRun'||c.ai==='ambWait'||c.ai==='traffic'||c.ai==='patrol'||c.ai==='chase'||c.ai==='leave'||c.ai==='fireRun'||c.ai==='fireWait'||c.ai==='towRun'||c.ai==='towHook'||c.ai==='towBack'||c===player.car;
    if(c.glowOn!==lit){c.glowOn=lit;for(const s of c.glows)s.visible=lit;}
    if(c.lights){
      if(c.type==='amb'){const on=c.ai==='ambRun'||c.ai==='ambWait';c.lights[0].color.setHex(on&&flash?0xff2a3a:0x550010);c.lights[1].color.setHex(on&&!flash?0xffffff:0x333338);}
      else if(c.type==='tow'){const on=c.ai==='towRun'||c.ai==='towHook'||c.ai==='towBack';c.lights[0].color.setHex(on&&flash?0xffa020:0x553300);c.lights[1].color.setHex(on&&!flash?0xffa020:0x553300);}
      else if(c.type==='fire'){const on=c.ai==='fireRun'||c.ai==='fireWait'||c===player.car;c.lights[0].color.setHex(on&&flash?0xff2a3a:0x550010);c.lights[1].color.setHex(on&&!flash?0xffffff:0x333338);}
      else{const on=c.ai==='chase'||c.ai==='respond'||c.ai==='respondWait'||(c.ai==='parked'&&wanted.stars>0)||(c===player.car&&wanted.stars>0);
      c.lights[0].color.setHex(on&&flash?0xff2a3a:0x550010);c.lights[1].color.setHex(on&&!flash?0x2a6bff:0x001055);}}
  }
}

// ---------- map icons: one vector glyph per kind of place ----------
const hex=c=>'#'+c.toString(16).padStart(6,'0');
const ICON_PATH={
  bank(g){g.beginPath();g.moveTo(-6.4,-2.6);g.lineTo(0,-6.6);g.lineTo(6.4,-2.6);g.closePath();g.fill();g.fillRect(-6.4,4.6,12.8,1.9);for(const x of [-5,-1,3])g.fillRect(x,-1.6,2,5.8);},
  gun(g){g.fillRect(-6.4,-4.2,12.4,3.4);g.beginPath();g.moveTo(-5.6,-1.2);g.lineTo(-1.6,-1.2);g.lineTo(-2.6,5.8);g.lineTo(-6.4,5.8);g.closePath();g.fill();g.lineWidth=1.4;g.beginPath();g.arc(.4,-.8,2,0,Math.PI);g.stroke();},
  hospital(g){g.fillRect(-1.9,-6.4,3.8,12.8);g.fillRect(-6.4,-1.9,12.8,3.8);},
  conv(g){g.fillRect(-5.2,-1.8,10.4,8.2);g.lineWidth=1.6;g.beginPath();g.arc(0,-1.8,3,Math.PI,0);g.stroke();},
  diner(g){g.fillRect(-4.6,-1.2,1.7,7.6);for(const x of [-6,-4.4,-2.8])g.fillRect(x,-6.4,1,5.4);g.fillRect(-6,-1.8,4.2,1.5);
    g.beginPath();g.moveTo(2.4,-6.4);g.quadraticCurveTo(6.2,-3,4.6,.6);g.lineTo(4.6,6.4);g.lineTo(2.4,6.4);g.closePath();g.fill();},
  police(g,c){g.beginPath();g.moveTo(0,-6.8);g.lineTo(5.8,-4.6);g.lineTo(5.2,1);g.quadraticCurveTo(4,5.2,0,7);g.quadraticCurveTo(-4,5.2,-5.2,1);g.lineTo(-5.8,-4.6);g.closePath();g.fill();
    g.fillStyle=c;g.beginPath();for(let k=0;k<10;k++){const r=k%2?1.3:3,a=-Math.PI/2+k*Math.PI/5;g.lineTo(Math.cos(a)*r,Math.sin(a)*r+.2);}g.closePath();g.fill();},
  garage(g,c){g.rotate(-Math.PI/4);g.fillRect(-1.4,-1.6,2.8,8.4);g.beginPath();g.arc(0,-3.4,3.4,0,Math.PI*2);g.fill();g.fillStyle=c;g.fillRect(-1.2,-7.4,2.4,4);},
  cityoffice(g,c){ICON_PATH.cityhall(g,c);},
  gang(g,c){g.beginPath();g.arc(0,-1.6,5.4,0,Math.PI*2);g.fill();g.fillRect(-3.4,1.6,6.8,4.8);g.fillStyle=c;g.beginPath();g.arc(-2.1,-1.8,1.5,0,Math.PI*2);g.arc(2.1,-1.8,1.5,0,Math.PI*2);g.fill();g.fillRect(-2.4,3,1.1,2.4);g.fillRect(-.55,3,1.1,2.4);g.fillRect(1.3,3,1.1,2.4);},
  cityhall(g){g.beginPath();g.arc(0,-1.4,3.8,Math.PI,0);g.fill();g.fillRect(-6.4,-1.2,12.8,1.5);for(const x of [-5.4,-2.4,.6,3.6])g.fillRect(x,.7,1.8,4.3);g.fillRect(-6.8,5,13.6,1.6);g.fillRect(-.3,-7.6,.6,2.6);},
  fire(g,c){g.beginPath();g.moveTo(0,-7);g.bezierCurveTo(4.8,-2.4,6.4,1.6,4,5);g.quadraticCurveTo(0,7.8,-4,5);g.bezierCurveTo(-6.4,1.6,-4.4,-1.6,-2.2,-3.2);g.quadraticCurveTo(-1.6,-.4,.2,.6);g.quadraticCurveTo(.6,-3.6,0,-7);g.fill();
    g.fillStyle=c;g.beginPath();g.moveTo(0,.4);g.quadraticCurveTo(2.6,2.4,1.6,4.6);g.quadraticCurveTo(0,5.8,-1.6,4.6);g.quadraticCurveTo(-2.4,2.6,0,.4);g.fill();},
  airport(g){g.rotate(-Math.PI/4);g.fillRect(-1.1,-6.8,2.2,13.4);g.beginPath();g.moveTo(-6.8,1);g.lineTo(0,-2.4);g.lineTo(6.8,1);g.lineTo(6.8,2.6);g.lineTo(0,.4);g.lineTo(-6.8,2.6);g.closePath();g.fill();g.beginPath();g.moveTo(-3,6.6);g.lineTo(0,4.6);g.lineTo(3,6.6);g.lineTo(3,7.4);g.lineTo(-3,7.4);g.closePath();g.fill();},
  afb(g){g.beginPath();g.moveTo(0,-7);g.lineTo(1.6,-1.6);g.lineTo(7,2.4);g.lineTo(7,4);g.lineTo(1.4,2.2);g.lineTo(1,5);g.lineTo(3,6.6);g.lineTo(3,7.4);g.lineTo(-3,7.4);g.lineTo(-3,6.6);g.lineTo(-1,5);g.lineTo(-1.4,2.2);g.lineTo(-7,4);g.lineTo(-7,2.4);g.lineTo(-1.6,-1.6);g.closePath();g.fill();},
  ferry(g){g.beginPath();g.moveTo(-7,1);g.lineTo(7,1);g.lineTo(5,5.6);g.lineTo(-5,5.6);g.closePath();g.fill();g.fillRect(-4.6,-2.6,9.2,3);g.fillRect(-2.4,-5.6,4.8,2.6);g.fillRect(1,-7.2,1.6,2);},
  marina(g){g.beginPath();g.moveTo(-6.6,0);g.lineTo(6.6,0);g.lineTo(4.4,4);g.lineTo(-4.6,4);g.closePath();g.fill();g.fillRect(-.6,-6.8,1.2,6.8);g.beginPath();g.moveTo(.8,-6.4);g.lineTo(5.6,-1.2);g.lineTo(.8,-1.2);g.closePath();g.fill();g.fillRect(-6.8,5.4,13.6,1.2);},
  mine(g){g.rotate(Math.PI/4);g.fillRect(-.95,-4.6,1.9,11.6);g.lineWidth=2.3;g.beginPath();g.arc(0,2.6,7.2,-Math.PI*.8,-Math.PI*.2);g.stroke();},
  junk(g,c){for(let k=0;k<8;k++){g.save();g.rotate(k*Math.PI/4);g.fillRect(-1.3,-6.8,2.6,3);g.restore();}g.beginPath();g.arc(0,0,4.6,0,Math.PI*2);g.fill();g.fillStyle=c;g.beginPath();g.arc(0,0,1.9,0,Math.PI*2);g.fill();},
  hotel(g,c){g.fillRect(-6.6,-4.6,1.8,11);g.fillRect(-6.6,2,13.2,1.8);g.fillRect(4.8,-.4,1.8,6.4);g.fillRect(-2.6,-2.2,9.2,4.2);g.beginPath();g.arc(-2.6,-1.6,2.1,0,Math.PI*2);g.fill();},
  logistics(g,c){g.fillRect(-6,-4.6,8.4,7);g.fillRect(2.4,-1.6,3.8,4);g.fillRect(-5,2.4,2.6,2.6);g.fillRect(2.6,2.4,2.6,2.6);g.fillStyle=c;g.fillRect(-4.6,-3.2,5.6,1.2);},
  taxidepot(g,c){g.fillRect(-6.4,-1.2,12.8,4.6);g.fillRect(-4,-4.6,8,3.6);g.fillRect(-1.8,-6.8,3.6,1.8);g.fillRect(-5.2,3,2.6,2.6);g.fillRect(2.6,3,2.6,2.6);g.fillStyle=c;g.fillRect(-3.2,-3.9,2.6,2.4);g.fillRect(.6,-3.9,2.6,2.4);},
  busdepot(g,c){g.fillRect(-5.4,-6.4,10.8,11);g.fillRect(-4.4,4.2,2.2,2.4);g.fillRect(2.2,4.2,2.2,2.4);g.fillStyle=c;g.fillRect(-4.2,-4.4,8.4,4.4);g.fillRect(-4,1.6,1.8,1.4);g.fillRect(2.2,1.6,1.8,1.4);},
  realty(g,c){g.beginPath();g.moveTo(-6.6,-.4);g.lineTo(0,-6.6);g.lineTo(6.6,-.4);g.closePath();g.fill();g.fillRect(-4.8,-.6,9.6,7.2);g.fillStyle=c;g.fillRect(-1.4,2.2,2.8,4.4);},
  gas(g,c){g.fillRect(-5.6,-6.6,8,13.2);g.fillRect(3.2,-4,1.6,8);g.fillRect(3.2,-4.6,3.2,1.6);g.fillStyle=c;g.fillRect(-4,-4.8,4.8,3.6);},
  parking(g,c){g.fillRect(-6,-6.6,12,13.2);g.fillStyle=c;g.font='bold 11px sans-serif';g.textAlign='center';g.textBaseline='middle';g.fillText('P',.2,.8);},
  airsec(g,c){ICON_PATH.police(g,c);},
  terminal(g){g.rotate(-Math.PI/4);g.fillRect(-1.1,-6.8,2.2,13.4);g.beginPath();g.moveTo(-6.8,1);g.lineTo(0,-2.4);g.lineTo(6.8,1);g.lineTo(6.8,2.6);g.lineTo(0,.4);g.lineTo(-6.8,2.6);g.closePath();g.fill();},
  car(g){g.fillRect(-6,-.6,12,4);g.beginPath();g.moveTo(-3.6,-.6);g.lineTo(-2.2,-4);g.lineTo(2.6,-4);g.lineTo(4,-.6);g.closePath();g.fill();},
  nav(g){g.beginPath();g.arc(0,-1.6,3.6,0,Math.PI*2);g.fill();g.beginPath();g.moveTo(-3,0);g.lineTo(0,6.6);g.lineTo(3,0);g.closePath();g.fill();}
};
const ICON_COLOR=t=>t==='car'?'#37e6ff':t==='nav'?NAV_COL:hex(LOC_TYPES[t].color);
function drawIcon(g,type,x,y,r,ring){
  const col=ICON_COLOR(type);
  g.save();g.translate(x,y);
  g.beginPath();g.arc(0,0,r,0,Math.PI*2);g.fillStyle=col;g.fill();
  g.lineWidth=Math.max(1,r*.17);g.strokeStyle=ring||'#0b0d1c';g.stroke();
  const k=r/10;g.scale(k,k);g.fillStyle='#0b0d1c';g.strokeStyle='#0b0d1c';g.lineCap='round';g.lineJoin='round';
  (ICON_PATH[type]||(()=>{}))(g,col);
  g.restore();
}
// mountain and walled base drawn as single shapes over the street grid
function drawLand(g){
  g.fillStyle='#3e4a32';for(const r of MT_RECTS)g.fillRect(r[0],r[2],r[1]-r[0],r[3]-r[2]);
  g.fillStyle='#55603f';g.beginPath();g.ellipse(-5,-10,70,62,0,0,Math.PI*2);g.fill();
  g.fillStyle='#6d7356';g.beginPath();g.ellipse(0,-10,34,30,0,0,Math.PI*2);g.fill();
  g.fillStyle='#dfe4ea';g.beginPath();g.ellipse(0,-10,12,10,0,0,Math.PI*2);g.fill();
  g.fillStyle='#3b4130';g.fillRect(BASE.x0,BASE.z0,EDGE-BASE.x0,BASE.z1-BASE.z0);
  g.strokeStyle='#c8c08a';g.lineWidth=2.2;g.setLineDash([5,3]);g.strokeRect(BASE.x0,BASE.z0,BASE.x1-BASE.x0,BASE.z1-BASE.z0);g.setLineDash([]);
}

function drawDocks(g){g.fillStyle='#8a8a90';for(const D of DECKS)g.fillRect(D.x0,D.z0,D.x1-D.x0,D.z1-D.z0);}
function drawIslands(g){
  for(const I of ISLANDS){g.fillStyle='#b8a878';g.fillRect(I.x0-2,I.z0-2,I.x1-I.x0+4,I.z1-I.z0+4);g.fillStyle=I===AFB?'#4a5236':'#3f5a34';g.fillRect(I.x0+4,I.z0+4,I.x1-I.x0-8,I.z1-I.z0-8);}
  g.fillStyle='#2c2d33';g.fillRect(-1305,-545,50,370);g.fillRect(995,-205,390,50);g.fillRect(-1046,-368,86,16);
  g.fillStyle='#d8dde6';g.fillRect(-1112,-445,64,170);
  g.fillStyle='#6a6a70';g.fillRect(BRIDGE.x0,BRIDGE.z0,BRIDGE.x1-BRIDGE.x0,BRIDGE.z1-BRIDGE.z0);
  g.strokeStyle='#ff5a5a';g.lineWidth=3;g.setLineDash([8,6]);g.strokeRect(AFB.x0-130,AFB.z0-130,AFB.x1-AFB.x0+260,AFB.z1-AFB.z0+260);g.setLineDash([]);
  g.strokeStyle='rgba(127,243,255,.6)';g.lineWidth=2;g.setLineDash([5,5]);g.beginPath();g.moveTo(FERRY.A.x,FERRY.A.z);g.lineTo(FERRY.B.x,FERRY.B.z);g.stroke();g.setLineDash([]);
  if(FERRY.pos){g.fillStyle='#ffffff';g.beginPath();g.arc(FERRY.pos.x,FERRY.pos.z,6,0,Math.PI*2);g.fill();}
}
const blinkB=()=>Math.floor(clock*4)%2===0;
// ---------- minimap ----------
const mm=$('minimap'),mctx=mm.getContext('2d');
function sizeMinimap(){const dpr=Math.min(2,window.devicePixelRatio||1),w=mm.clientWidth||168;mm.width=w*dpr;mm.height=w*dpr;}
sizeMinimap();addEventListener('resize',sizeMinimap);
const MINI={zoom:1,ox:0,oz:0};
function drawMinimap(){
  const S=mm.width,pp=playerPos(),tp={x:pp.x+MINI.ox,z:pp.z+MINI.oz},span=170/MINI.zoom,sc=S/span,cull=span*.85;
  mctx.setTransform(1,0,0,1,0,0);mctx.fillStyle='#1c2f52';mctx.fillRect(0,0,S,S);
  mctx.save();mctx.translate(S/2,S/2);mctx.scale(sc,sc);mctx.translate(-tp.x,-tp.z);
  mctx.fillStyle='#4a4c5e';mctx.fillRect(-EDGE,-EDGE,EDGE*2,EDGE+EDGE_S);
  for(const b of blocks){if(b.closed||Math.abs(b.bx0-tp.x)>cull||Math.abs(b.bz0-tp.z)>cull)continue;mctx.fillStyle=b.park?'#2f5a3c':KIND_MAP[b.kind];mctx.fillRect(b.bx0,b.bz0,b.bx1-b.bx0,b.bz1-b.bz0);}
  drawLand(mctx);drawDocks(mctx);drawIslands(mctx);
  if(Math.abs(IND_FZ-tp.z)<cull){mctx.strokeStyle='#ffd27a';mctx.lineWidth=1.6;mctx.setLineDash([4,3]);mctx.beginPath();mctx.moveTo(-IND_FX,IND_FZ);mctx.lineTo(IND_FX,IND_FZ);mctx.stroke();mctx.setLineDash([]);}
  for(const b of boats){if(!b||b.dead)continue;mctx.save();mctx.translate(b.pos.x,b.pos.z);mctx.rotate(-b.heading);mctx.fillStyle=b.state==='hunt'?(blinkB()?'#ff3b4e':'#3f8cff'):'#b8c8d8';mctx.fillRect(-2,-6,4,12);mctx.restore();}
  if(nav&&nav.pts){mctx.strokeStyle=NAV_COL;mctx.lineWidth=S*.045/sc;mctx.lineJoin=mctx.lineCap='round';mctx.beginPath();nav.pts.forEach((p,i)=>i?mctx.lineTo(p.x,p.z):mctx.moveTo(p.x,p.z));mctx.stroke();}
  for(const f of fires){mctx.fillStyle='#ff7a2a';mctx.beginPath();mctx.arc(f.pos.x,f.pos.z,f.r+1.5,0,Math.PI*2);mctx.fill();}
  const blink=Math.floor(clock*4)%2===0;
  for(const c of cars){if(c.dead||c===player.car)continue;
    if(c.jobTruck&&DJOB.on){mctx.fillStyle='#ff8a3d';mctx.strokeStyle='#0b0d1c';mctx.lineWidth=1.4;mctx.fillRect(c.pos.x-3.6,c.pos.z-3.6,7.2,7.2);mctx.strokeRect(c.pos.x-3.6,c.pos.z-3.6,7.2,7.2);continue;}
    if(c.isTaxi&&(c===taxiLive()||c.jobTaxi&&TJOB.on)){mctx.fillStyle='#f4c430';mctx.strokeStyle='#0b0d1c';mctx.lineWidth=1.4;mctx.fillRect(c.pos.x-3.6,c.pos.z-3.6,7.2,7.2);mctx.strokeRect(c.pos.x-3.6,c.pos.z-3.6,7.2,7.2);continue;}
    if(c.owned&&c.ai!=='wreck'){mctx.fillStyle='#37e6ff';mctx.strokeStyle='#0b0d1c';mctx.lineWidth=1.4;mctx.fillRect(c.pos.x-3.4,c.pos.z-3.4,6.8,6.8);mctx.strokeRect(c.pos.x-3.4,c.pos.z-3.4,6.8,6.8);continue;}
    let col=null;if(c.ai==='patrol')col='#6fa8ff';else if((c.type==='police'||c.type==='swat')&&c.ai!=='leave'&&!c.fixed)col=blink?'#ff3b4e':'#3f8cff';else if(c.type==='army')col='#9bbf5a';else if(c.type==='fire'&&!c.fixed)col='#ff5a3d';else if(c.type==='tow'&&c.ai!=='parked')col='#ffa020';else if(c.type==='amb'&&c.ai!=='parked')col=blink?'#ffffff':'#ff3b4e';else if(c.ai==='respond'||c.ai==='respondWait')col='#6fa8ff';
    if(col){mctx.fillStyle=col;mctx.beginPath();mctx.arc(c.pos.x,c.pos.z,3.6,0,Math.PI*2);mctx.fill();}}
  for(const p of peds){if(p.crim&&!p.dead&&!p.out&&!p.room){mctx.fillStyle='#ff3b4e';mctx.beginPath();mctx.moveTo(p.pos.x,p.pos.z-3.2);mctx.lineTo(p.pos.x+3.2,p.pos.z);mctx.lineTo(p.pos.x,p.pos.z+3.2);mctx.lineTo(p.pos.x-3.2,p.pos.z);mctx.closePath();mctx.fill();}}
  for(const p of peds){if(p.dead||p.out||p.room||p.kind==='civ'||p.state==='leave'||(p.role==='gate'&&p.state==='idle'))continue;mctx.fillStyle=p.kind==='cop'?'#ff8a96':p.kind==='swat'?'#b8c6ff':'#c8e08a';mctx.fillRect(p.pos.x-1.6,p.pos.z-1.6,3.2,3.2);}
  for(const S of BUS_STOPS){if(S.depot||Math.abs(S.sh.x-tp.x)>cull*1.6||Math.abs(S.sh.z-tp.z)>cull*1.6)continue;mctx.fillStyle=S.kind==='air'?'#3f8cff':S.kind==='mix'?'#5fe8e0':'#3ad07a';mctx.fillRect(S.sh.x-2.6,S.sh.z-2.6,5.2,5.2);}
  if(heli){mctx.strokeStyle='#ffe9a8';mctx.lineWidth=2;mctx.beginPath();mctx.arc(heli.pos.x,heli.pos.z,6,0,Math.PI*2);mctx.stroke();}
  MP.drawMini(mctx,sc);
  mctx.restore();
  // place icons: everything in view; off-screen only the nearest of each kind, pinned to the edge
  const ir=S/14,lim=S/2-ir-2,near={};
  for(const L of LOCS){const d=d2(L.door,tp);if(!near[L.type]||d<near[L.type].d)near[L.type]={L,d};}
  const list=[];
  for(const L of LOCS){
    let x=(L.door.x-tp.x)*sc,y=(L.door.z-tp.z)*sc;const m=Math.max(Math.abs(x),Math.abs(y));
    if(m>lim){if(near[L.type].L!==L)continue;x=x/m*lim;y=y/m*lim;list.push([L.type,x,y,1]);}else list.push([L.type,x,y,0]);
  }
  list.sort((a,b)=>b[3]-a[3]);
  for(const [t,x,y,edge] of list){mctx.globalAlpha=edge?.82:1;drawIcon(mctx,t,S/2+x,S/2+y,edge?ir*.82:ir);}
  mctx.globalAlpha=1;
  if(nav){
    let x=(nav.x-tp.x)*sc,y=(nav.z-tp.z)*sc;const m=Math.max(Math.abs(x),Math.abs(y));if(m>lim){x=x/m*lim;y=y/m*lim;}
    drawIcon(mctx,'nav',S/2+x,S/2+y,ir*1.05,'#ffffff');
  }
  const a=player.car?player.car.heading:(view==='first'||player.weapon!=='fist'?camYaw:player.yaw);
  {const px=clamp((pp.x-tp.x)*sc,-S/2+6,S/2-6),pz=clamp((pp.z-tp.z)*sc,-S/2+6,S/2-6);mctx.save();mctx.translate(S/2+px,S/2+pz);}mctx.rotate(-a);const u=S/22;
  mctx.fillStyle='#ffb53d';mctx.strokeStyle='#1a1205';mctx.lineWidth=S/120;
  mctx.beginPath();mctx.moveTo(0,u);mctx.lineTo(u*.7,-u*.7);mctx.lineTo(0,-u*.3);mctx.lineTo(-u*.7,-u*.7);mctx.closePath();mctx.fill();mctx.stroke();mctx.restore();
  // north marker
  mctx.textAlign='center';mctx.textBaseline='middle';mctx.font="700 "+Math.round(S*.075)+"px 'JetBrains Mono',monospace";
  mctx.lineWidth=S/60;mctx.strokeStyle='#0b0d1c';mctx.strokeText('N',S/2,S*.06);mctx.fillStyle='#f4efe4';mctx.fillText('N',S/2,S*.06);
  if(player.inside){
    mctx.fillStyle='rgba(11,13,28,.78)';mctx.fillRect(0,S-S*.17,S,S*.17);
    mctx.fillStyle='#f4efe4';mctx.font="700 "+Math.round(S*.085)+"px 'Noto Sans KR',sans-serif";mctx.fillText(player.inside.name+' 실내',S/2,S-S*.085);
  }
}

// ---------- navigation (GPS) ----------
let nav=null,navT=0,mapOpen=false,bigView=null,bigHover=null;
const BIG={zoom:1,cx:0,cz:0},BIG_MAXZ=16,ISLE_H=(EDGE+EDGE_S)/2+6,ISLE_CZ=LAND_S/2;
const NAV_COL='#d35bff';
const beacon=new THREE.Mesh(new THREE.CylinderGeometry(1.3,1.3,70,16,1,true),new THREE.MeshBasicMaterial({color:0xd35bff,transparent:true,opacity:.3,blending:THREE.AdditiveBlending,depthWrite:false,side:THREE.DoubleSide,fog:false}));
beacon.visible=false;scene.add(beacon);
// shortest route along existing roads: start → best nearby intersection → … → intersection nearest the goal → goal
function navRoute(a,b){
  const A=onAirSide(a),B=onAirSide(b);
  if(A&&B)return [{x:a.x,z:a.z},{x:b.x,z:b.z}];
  if(B)return navRouteMain(a,{x:R[0],z:R[3]}).concat([{x:BRIDGE.x0,z:R[3]},{x:b.x,z:b.z}]);
  if(A)return [{x:a.x,z:a.z},{x:BRIDGE.x0,z:R[3]}].concat(navRouteMain({x:R[0],z:R[3]},b));
  return navRouteMain(a,b);
}
function navRouteMain(a,b){
  const gn=nearNode(b),pts=[{x:a.x,z:a.z}];
  if(!gn||Math.hypot(a.x-b.x,a.z-b.z)<25){pts.push({x:b.x,z:b.z});return pts;}
  const f=nodeField(gn[0],gn[1]);
  let id=-1,bc=1e9;
  for(const [i,j] of roadCands(a)){const k=i*NS+j;if(f[k]<0)continue;const c=Math.hypot(a.x-R[i],a.z-R[j])+f[k]*CELL;if(c<bc){bc=c;id=k;}}
  for(let guard=0;id>=0&&guard<80;guard++){
    const i=(id/NS)|0,j=id%NS;pts.push({x:R[i],z:R[j]});if(f[id]===0)break;const d=f[id]-1;
    id=segH(i,j)&&f[id+NS]===d?id+NS:segH(i-1,j)&&f[id-NS]===d?id-NS:segV(i,j)&&f[id+1]===d?id+1:segV(i,j-1)&&f[id-1]===d?id-1:-1;
  }
  pts.push({x:b.x,z:b.z});
  return pts;
}
function setWaypoint(x,z,label){
  nav={x:clamp(x,-1640,1640),z:clamp(z,-1640,1640),label};nav.pts=navRoute(playerPos(),nav);navT=0;
  beacon.position.set(nav.x,terrainH(nav.x,nav.z)+35,nav.z);beacon.visible=true;toast('목적지 설정 · '+label);
}
function clearNav(){nav=null;beacon.visible=false;}
function updateNav(dt){
  if(!nav)return;
  navT-=dt;if(navT<=0){navT=.5;nav.pts=navRoute(playerPos(),nav);}
  beacon.material.opacity=.22+.1*Math.sin(clock*3);
  if(d2(playerPos(),nav)<8){toast('목적지에 도착했다 · '+nav.label);clearNav();}
}
function nearestLoc(type){const tp=playerPos();let best=null,bd=1e9;for(const L of LOCS)if(L.type===type){const d=d2(L.door,tp);if(d<bd){bd=d;best=L;}}return best?{L:best,d:bd}:null;}
const DEST_TYPES=['bank','gun','hospital','conv','diner','police','garage','fire','junk','marina','ferry','airport','busdepot','taxidepot','logistics','hotel','parking','gas','realty','mine','cityhall','cityoffice','gang'];
function iconCanvas(type){const c=document.createElement('canvas');c.width=c.height=48;drawIcon(c.getContext('2d'),type,24,24,21);return c;}
function renderDestList(){
  const box=$('destList');box.innerHTML='';
  const add=(type,name,dist,fn)=>{
    const b=document.createElement('button');b.type='button';b.className='dest';
    const n=document.createElement('span');n.textContent=name;
    const s=document.createElement('small');s.textContent=dist;
    b.append(iconCanvas(type),n,s);b.addEventListener('click',fn);box.appendChild(b);
  };
  for(const t of DEST_TYPES){
    const r=nearestLoc(t);if(!r)continue;const T=LOC_TYPES[t],many=LOCS.filter(l=>l.type===t).length>1;
    add(t,T.name+(many?' · 가까운 곳':''),Math.round(r.d)+'m',()=>{setWaypoint(r.L.door.x,r.L.door.z,r.L.title&&r.L.type!=='junk'?r.L.title:T.name);closeMap();});
  }
  const tp=playerPos();let car=null,cd=1e9;
  for(const c of cars){if(!c.owned||c.dead||c.ai==='wreck'||c===player.car)continue;const d=d2(c.pos,tp);if(d<cd){cd=d;car=c;}}
  if(car)add('car','내 차 · 가까운 차',Math.round(cd)+'m',()=>{setWaypoint(car.pos.x,car.pos.z,'내 차');closeMap();});
}
const bm=$('bigmapCanvas'),bctx=bm.getContext('2d');
function drawBig(){
  const dpr=Math.min(2,window.devicePixelRatio||1),css=bm.clientWidth||600;
  const want=Math.max(200,Math.round(css*dpr));if(bm.width!==want)bm.width=bm.height=want;
  const H0=1450,S=bm.width,pad=S*.04;BIG.zoom=clamp(BIG.zoom,1,BIG_MAXZ);{const zb=$('mapZoom');if(zb)zb.textContent=BIG.zoom<1450/ISLE_H*.97?'본섬 보기':'전체 보기';}const HV=H0/BIG.zoom;
  BIG.cx=clamp(BIG.cx,-H0+HV,H0-HV);BIG.cz=clamp(BIG.cz,-H0+HV,H0-HV);
  const sc=(S-pad*2)/(HV*2),cx=BIG.cx,cz=BIG.cz;bigView={pad,sc,S,H:HV,cx,cz,H0};
  const X=x=>pad+(x-cx+HV)*sc,Y=z=>pad+(z-cz+HV)*sc;
  {const zl=$('bmZoomLbl');if(zl)zl.textContent='×'+(BIG.zoom*ISLE_H/1450).toFixed(1);}
  bctx.setTransform(1,0,0,1,0,0);bctx.fillStyle='#1c2f52';bctx.fillRect(0,0,S,S);
  bctx.fillStyle='#4a4c5e';bctx.fillRect(X(-EDGE),Y(-EDGE),EDGE*2*sc,(EDGE+EDGE_S)*sc);
  for(const b of blocks){if(b.closed)continue;bctx.fillStyle=b.park?'#2f5a3c':KIND_MAP[b.kind];bctx.fillRect(X(b.bx0),Y(b.bz0),(b.bx1-b.bx0)*sc,(b.bz1-b.bz0)*sc);}
  bctx.save();bctx.translate(X(0),Y(0));bctx.scale(sc,sc);drawLand(bctx);drawDocks(bctx);drawIslands(bctx);bctx.restore();
  {bctx.font="700 "+Math.round(S*.022)+"px 'Noto Sans KR',sans-serif";bctx.textAlign='center';
    for(const [t,x,z] of [['국제공항',-1150,-140],['등대섬',-1155,500],['공군 기지 · 출입금지',1175,140],['바위섬',1130,600],['네온 하버',0,-600]]){bctx.lineWidth=S*.006;bctx.strokeStyle='rgba(11,13,28,.9)';bctx.strokeText(t,X(x),Y(z));bctx.fillStyle='#f4efe4';bctx.fillText(t,X(x),Y(z));}}
  bctx.textAlign='center';bctx.textBaseline='middle';bctx.font="700 "+Math.round(S*.024)+"px 'Noto Sans KR',sans-serif";
  for(let rj=0;rj<3;rj++)for(let ri=0;ri<3;ri++){
    const reg=REGION[rj][ri];
    const x=X(R[ri*6+3]),y=Y(R[rj*6+3])+(reg==='mountain'?S*.06:reg==='base'?-S*.07:0);
    bctx.lineWidth=S*.008;bctx.strokeStyle='rgba(11,13,28,.85)';bctx.strokeText(REGION_NAME[reg],x,y);bctx.fillStyle='rgba(244,239,228,.82)';bctx.fillText(REGION_NAME[reg],x,y);
  }
  {const x=X(0),y=Y(R[IND_J+1]+30);bctx.strokeText(REGION_NAME.industry,x,y);bctx.fillStyle='rgba(244,239,228,.82)';bctx.fillText(REGION_NAME.industry,x,y);
    bctx.strokeStyle='rgba(255,210,122,.75)';bctx.lineWidth=S*.003;bctx.setLineDash([S*.006,S*.004]);bctx.beginPath();bctx.moveTo(X(-IND_FX),Y(IND_FZ));bctx.lineTo(X(IND_FX),Y(IND_FZ));bctx.stroke();bctx.setLineDash([]);bctx.strokeStyle='rgba(11,13,28,.85)';bctx.lineWidth=S*.008;}
  {const x=X((BASE.x0+EDGE)/2),y=Y((BASE.z0+BASE.z1)/2);bctx.strokeText('군사 기지',x,y);bctx.fillStyle='#e8c547';bctx.fillText('군사 기지',x,y);}
  if(nav&&nav.pts){bctx.strokeStyle=NAV_COL;bctx.lineWidth=S*.009;bctx.lineJoin=bctx.lineCap='round';bctx.beginPath();nav.pts.forEach((p,i)=>i?bctx.lineTo(X(p.x),Y(p.z)):bctx.moveTo(X(p.x),Y(p.z)));bctx.stroke();}
  for(const f of fires){bctx.fillStyle='#ff7a2a';bctx.beginPath();bctx.arc(X(f.pos.x),Y(f.pos.z),S*.008,0,Math.PI*2);bctx.fill();}
  for(const c of cars){if(!c.owned||c.dead||c.ai==='wreck'||c===player.car)continue;bctx.fillStyle='#37e6ff';bctx.strokeStyle='#0b0d1c';bctx.lineWidth=S*.003;const r=S*.009;bctx.fillRect(X(c.pos.x)-r,Y(c.pos.z)-r,r*2,r*2);bctx.strokeRect(X(c.pos.x)-r,Y(c.pos.z)-r,r*2,r*2);}
  {const t=taxiLive();if(t){const r=S*.011;bctx.fillStyle='#f4c430';bctx.strokeStyle='#0b0d1c';bctx.lineWidth=S*.003;bctx.fillRect(X(t.pos.x)-r,Y(t.pos.z)-r,r*2,r*2);bctx.strokeRect(X(t.pos.x)-r,Y(t.pos.z)-r,r*2,r*2);}}
  bctx.strokeStyle='#0b0d1c';bctx.lineWidth=S*.002;for(const B of BUS_STOPS){if(B.depot)continue;bctx.fillStyle=B.kind==='air'?'#3f8cff':B.kind==='mix'?'#5fe8e0':'#3ad07a';const r=S*.005;bctx.fillRect(X(B.sh.x)-r,Y(B.sh.z)-r,r*2,r*2);bctx.strokeRect(X(B.sh.x)-r,Y(B.sh.z)-r,r*2,r*2);}
  const ir=S*.019;
  for(const L of LOCS)drawIcon(bctx,L.type,X(L.door.x),Y(L.door.z),L===bigHover?ir*1.3:ir,L===bigHover?'#ffffff':null);
  if(nav){drawIcon(bctx,'nav',X(nav.x),Y(nav.z),ir*1.15,'#ffffff');}
  const tp=playerPos(),a=player.car?player.car.heading:camYaw,u=S*.022;
  bctx.save();bctx.translate(X(tp.x),Y(tp.z));bctx.rotate(-a);bctx.fillStyle='#ffb53d';bctx.strokeStyle='#1a1205';bctx.lineWidth=S*.004;
  bctx.beginPath();bctx.moveTo(0,u);bctx.lineTo(u*.7,-u*.7);bctx.lineTo(0,-u*.3);bctx.lineTo(-u*.7,-u*.7);bctx.closePath();bctx.fill();bctx.stroke();bctx.restore();
  if(bigHover){ // name tag for the hovered place
    const L=bigHover,label=(L.title&&L.type!=='junk'&&L.type!=='mine'?L.title:L.name)+' · '+Math.round(d2(L.door,tp))+'m';
    bctx.font="700 "+Math.round(S*.026)+"px 'Noto Sans KR',sans-serif";const w=bctx.measureText(label).width+S*.03,h=S*.045;
    let x=X(L.door.x),y=Y(L.door.z)-ir*2.6;x=clamp(x,w/2+4,S-w/2-4);if(y<h)y=Y(L.door.z)+ir*2.6;
    bctx.fillStyle='rgba(11,13,28,.92)';bctx.fillRect(x-w/2,y-h/2,w,h);bctx.strokeStyle=hex(L.T.color);bctx.lineWidth=S*.003;bctx.strokeRect(x-w/2,y-h/2,w,h);
    bctx.fillStyle='#f4efe4';bctx.fillText(label,x,y);
  }
}
function bigPoint(e){const r=bm.getBoundingClientRect();return {px:(e.clientX-r.left)/r.width*bigView.S,py:(e.clientY-r.top)/r.height*bigView.S};}
function locAtPx(px,py){let best=null,bd=bigView.S*.03;for(const L of LOCS){const x=bigView.pad+(L.door.x-bigView.cx+bigView.H)*bigView.sc,y=bigView.pad+(L.door.z-bigView.cz+bigView.H)*bigView.sc,d=Math.hypot(x-px,y-py);if(d<bd){bd=d;best=L;}}return best;}
bm.addEventListener('mousemove',e=>{if(!bigView||bigPtrs.size)return;const {px,py}=bigPoint(e),L=locAtPx(px,py);if(L!==bigHover){bigHover=L;drawBig();}bm.style.cursor=L?'pointer':'crosshair';});
bm.addEventListener('mouseleave',()=>{if(bigHover){bigHover=null;drawBig();}});
bm.addEventListener('click',e=>{
  if(!bigView)return;if(bigMoved){bigMoved=false;return;}const {px,py}=bigPoint(e);
  const L=locAtPx(px,py);
  if(L){setWaypoint(L.door.x,L.door.z,L.title&&L.type!=='junk'?L.title:L.name);drawBig();return;}
  const x=bigToWorld(px,'x'),z=bigToWorld(py,'z');
  if(Math.abs(x)>bigView.H0||Math.abs(z)>bigView.H0)return;
  if(nav&&Math.hypot(nav.x-x,nav.z-z)<10)clearNav();else setWaypoint(x,z,'지도에 찍은 곳');
  drawBig();
});
let bigWorld=false;
// big map zoom & pan: wheel / +− buttons / pinch to zoom, drag to move
const bigToWorld=(p,ax)=>(p-bigView.pad)/bigView.sc-bigView.H+(ax==='x'?bigView.cx:bigView.cz);
function bigZoomAt(f,px,py){
  if(!bigView){BIG.zoom=clamp(BIG.zoom*f,1,BIG_MAXZ);return;}
  if(px==null){px=py=bigView.S/2;}
  const wx=bigToWorld(px,'x'),wz=bigToWorld(py,'z');
  BIG.zoom=clamp(BIG.zoom*f,1,BIG_MAXZ);const HV=bigView.H0/BIG.zoom,sc=(bigView.S-bigView.pad*2)/(HV*2);
  BIG.cx=wx-((px-bigView.pad)/sc-HV);BIG.cz=wz-((py-bigView.pad)/sc-HV);drawBig();
}
const bigPtrs=new Map();let bigMoved=false,bigPinch=0;
bm.addEventListener('wheel',e=>{e.preventDefault();if(!bigView)return;const {px,py}=bigPoint(e);bigZoomAt(e.deltaY<0?1.25:.8,px,py);},{passive:false});
bm.addEventListener('pointerdown',e=>{bigPtrs.set(e.pointerId,{x:e.clientX,y:e.clientY});if(bigPtrs.size===1)bigMoved=false;
  if(bigPtrs.size===2){const [a,b]=[...bigPtrs.values()];bigPinch=Math.hypot(a.x-b.x,a.y-b.y);bigMoved=true;}
  try{bm.setPointerCapture(e.pointerId);}catch(_){}});
bm.addEventListener('pointermove',e=>{
  const pr=bigPtrs.get(e.pointerId);if(!pr||!bigView)return;
  const r=bm.getBoundingClientRect(),k=bigView.S/r.width;
  if(bigPtrs.size>=2){pr.x=e.clientX;pr.y=e.clientY;const [a,b]=[...bigPtrs.values()],d=Math.hypot(a.x-b.x,a.y-b.y);
    if(bigPinch>0&&d>0){bigZoomAt(d/bigPinch,((a.x+b.x)/2-r.left)*k,((a.y+b.y)/2-r.top)*k);}bigPinch=d;return;}
  const dx=e.clientX-pr.x,dy=e.clientY-pr.y;if(!bigMoved&&Math.hypot(dx,dy)<5)return;
  bigMoved=true;pr.x=e.clientX;pr.y=e.clientY;BIG.cx-=dx*k/bigView.sc;BIG.cz-=dy*k/bigView.sc;bm.style.cursor='grabbing';
  if(bigHover)bigHover=null;drawBig();});
const bigUp=e=>{bigPtrs.delete(e.pointerId);if(bigPtrs.size<2)bigPinch=0;if(!bigPtrs.size)bm.style.cursor='crosshair';};
bm.addEventListener('pointerup',bigUp);bm.addEventListener('pointercancel',bigUp);
$('bmIn').addEventListener('click',()=>bigZoomAt(1.5));
$('bmOut').addEventListener('click',()=>bigZoomAt(1/1.5));
$('bmMe').addEventListener('click',()=>{const tp=playerPos();if(BIG.zoom<2.5)BIG.zoom=2.5;BIG.cx=tp.x;BIG.cz=tp.z;bigHover=null;drawBig();});
$('bmAll').addEventListener('click',()=>{BIG.zoom=1;bigWorld=true;BIG.cx=BIG.cz=0;bigHover=null;drawBig();});
function openMap(){
  if(!started||dead||mapOpen)return;
  {const tp=playerPos();bigWorld=Math.abs(tp.x)>600||Math.abs(tp.z)>600;BIG.zoom=bigWorld?1:1450/ISLE_H;BIG.cx=0;BIG.cz=bigWorld?0:ISLE_CZ;}
  if(menu)closeMenu();
  mapOpen=true;paused=true;input.keys={};input.fireHeld=false;input.punch=false;input.joy.x=input.joy.y=0;
  $('bigmap').hidden=false;
  try{if(document.pointerLockElement)document.exitPointerLock();}catch(e){}
  renderDestList();drawBig();
}
function closeMap(){if(!mapOpen)return;mapOpen=false;paused=false;$('bigmap').hidden=true;canvas.focus();if(!coarse)tryLock(true);}
// minimap: wheel to zoom, drag to pan, +/−/◎ buttons; a plain click still opens the big map
let miniDrag=null,miniMoved=false;
const miniZoom=f=>{MINI.zoom=clamp(MINI.zoom*f,.35,4);};
mm.addEventListener('wheel',e=>{e.preventDefault();e.stopPropagation();miniZoom(e.deltaY<0?1.25:.8);},{passive:false});
mm.addEventListener('pointerdown',e=>{miniDrag={x:e.clientX,y:e.clientY};miniMoved=false;try{mm.setPointerCapture(e.pointerId);}catch(_){}});
mm.addEventListener('pointermove',e=>{if(!miniDrag)return;const dx=e.clientX-miniDrag.x,dy=e.clientY-miniDrag.y;if(!miniMoved&&Math.hypot(dx,dy)<4)return;miniMoved=true;
  const k=(170/MINI.zoom)/mm.clientWidth;MINI.ox-=dx*k;MINI.oz-=dy*k;miniDrag={x:e.clientX,y:e.clientY};});
mm.addEventListener('pointerup',()=>{miniDrag=null;});mm.addEventListener('pointercancel',()=>{miniDrag=null;});
mm.addEventListener('dblclick',e=>{e.stopPropagation();MINI.ox=MINI.oz=0;});
$('mmIn').addEventListener('click',e=>{e.stopPropagation();miniZoom(1.4);});
$('mmOut').addEventListener('click',e=>{e.stopPropagation();miniZoom(1/1.4);});
$('mmHome').addEventListener('click',e=>{e.stopPropagation();MINI.ox=MINI.oz=0;MINI.zoom=1;});
$('mapWrap').addEventListener('click',e=>{if(miniMoved){miniMoved=false;return;}if(!paused&&(!e||e.target===mm||e.target===$('mapWrap')))openMap();});
const hudOpen=fn=>e=>{e&&e.stopPropagation&&e.stopPropagation();if(paused&&started&&!dead&&!menu&&!mapOpen&&!craftOpen&&!endingOpen)setPaused(false);fn();};
$('kMap')?.addEventListener('click',e=>{e.stopPropagation();if(!paused)openMap();});
$('kPhone')?.addEventListener('click',hudOpen(()=>openPhone()));
$('kSurr')?.addEventListener('click',e=>{e.stopPropagation();input.h=true;});
$('phoneDock').addEventListener('click',hudOpen(()=>openPhone()));
$('mapClose').addEventListener('click',closeMap);
$('mapZoom').addEventListener('click',()=>{bigWorld=BIG.zoom>1450/ISLE_H*.97;BIG.zoom=bigWorld?1:1450/ISLE_H;BIG.cx=0;BIG.cz=bigWorld?0:ISLE_CZ;bigHover=null;drawBig();});
$('navClear').addEventListener('click',()=>{clearNav();drawBig();});
addEventListener('resize',()=>{if(mapOpen)drawBig();});

// ---------- HUD ----------
let hudT=0;
const BUFF_NAMES={speed:'에너지',reload:'커피',armor:'진통제'};
const COUNTER_LABEL=t=>LOC_TYPES[t].counter;
function updateHUD(dt){
  if(toastT>0){toastT-=dt;if(toastT<=0)$('toast').style.opacity=0;}
  $('vignette').style.opacity=flashT>0?Math.min(1,flashT*3):(player.health<30?.35:0);flashT=Math.max(0,flashT-dt);
  if(hitT>0){hitT-=dt;$('hitmark').hidden=false;$('hitmark').className='hud'+(hitKill?' kill':'');}else $('hitmark').hidden=true;
  $('pauseBtn').hidden=!(started&&!dead);
  hudT-=dt;if(hudT>0)return;hudT=.08;
  const hiding=wanted.stars>0&&!wanted.seen&&wanted.unseen>1.5;
  starEls.forEach((s,i)=>s.classList.toggle('on',i<wanted.stars));
  $('stars').classList.toggle('blink',hiding);
  const th=$('threat');
  const labels=['평온','경찰 추적','경찰 추적','특수부대 출동','군대 투입','헬기 추적'];
  th.textContent=player.jailed?'수감 중 · 출소까지 '+Math.ceil(player.jailT)+'초':hiding?'시야 밖 · '+Math.max(1,Math.ceil(LOSE_TIME-wanted.unseen))+'초 뒤 별 감소':labels[wanted.stars];
  th.className=wanted.stars>=4?'army':(wanted.stars>0?'police':'');
  $('money').textContent='$'+player.money.toLocaleString();
  {const h=Math.floor(tod),m=Math.floor((tod-h)*60);$('clock').textContent=String(h).padStart(2,'0')+':'+String(m).padStart(2,'0');
   $('clockPh').textContent=tod<5?'밤':tod<7?'새벽':tod<11?'아침':tod<17?'낮':tod<19.5?'저녁':'밤';}
  const nt=$('navTag');
  if(nav&&started){nt.hidden=false;nt.textContent=nav.label+' · '+Math.round(d2(playerPos(),nav))+'m';}else nt.hidden=true;
  $('healthFill').style.width=player.health+'%';
  $('healthFill').style.background=player.health<30?'var(--siren-r)':'var(--health)';
  $('mapWrap').classList.toggle('alert',wanted.stars>0);
  {const h=Math.floor(tod),m=Math.floor((tod%1)*60);$('pdTime').textContent=String(h).padStart(2,'0')+':'+String(m).padStart(2,'0');$('phoneDock').hidden=!started||!!player.inside||dead;}
  $('hungerFill').style.width=player.hunger+'%';$('hungerWrap').classList.toggle('low',player.hunger<25);
  let bh='';for(const k in player.buffs)if(player.buffs[k]>0)bh+='<span class="buff">'+BUFF_NAMES[k]+'<b>'+Math.ceil(player.buffs[k])+'s</b></span>';
  if(player.trash>0)bh+='<span class="buff">쓰레기<b>'+player.trash+'/'+TRASH_MAX+'</b></span>';
  {const kk=player.keys;if(kk.mil)bh+='<span class="buff">군용 차량 키<b>'+kk.mil+'</b></span>';if(kk.heli)bh+='<span class="buff">헬기 코드<b>'+kk.heli+'</b></span>';if(kk.boat)bh+='<span class="buff">경비정 키<b>'+kk.boat+'</b></span>';}
  if(player.surrender)bh+='<span class="buff">항복 중<b>움직이면 취소</b></span>';
  if(GOD)bh+='<span class="buff">무적 테스트<b>ON</b></span>';
  if(player.swim)bh+='<span class="buff">수영 중<b>무기 못 씀</b></span>';
  if(player.crouch&&!player.car)bh+='<span class="buff">'+(coverNow()?'엄폐 중<b>피해 대폭 감소</b>':'웅크림<b>피해 감소</b>')+'</span>';
  $('buffs').innerHTML=bh;
  const inCar=!!player.car,armed=player.weapon!=='fist',W=WEAPONS[player.weapon],A=curAmmo();
  $('speed').hidden=!inCar;$('carHpWrap').hidden=!inCar;$('weapon').hidden=inCar;
  if(inCar){$('speedNum').textContent=Math.round(Math.abs(player.car.speed)*3.6);$('carHpFill').style.width=clamp(player.car.health/player.car.maxHealth*100,0,100)+'%';}
  {const fu=inCar&&hasFuel(player.car);$('fuelWrap').hidden=!fu;if(fu){const v=player.car.fuel==null?100:player.car.fuel;$('fuelFill').style.width=clamp(v,0,100)+'%';$('fuelFill').className=v<15?'low':'';$('fuelTxt').textContent=Math.round(v)+'%';}}
  $('wname').textContent=W.name;
  $('ammo').innerHTML=armed?A.mag+'<small>/ '+W.magName+' '+A.mags+'</small>':'—';
  $('reloadTag').hidden=!(armed&&player.reloadT>0);
  [...$('wslots').children].forEach((s,i)=>{const k=ORDER[i];s.className=(player.owned[k]?'own':'')+(player.weapon===k?' cur':'');});
  $('viewTag').textContent=(player.inside?player.inside.name+' 안 · ':'')+(view==='first'?'1인칭':'3인칭')+' · V 전환';
  const ch=$('crosshair');ch.hidden=!(started&&!inCar&&!menu&&(view==='first'||armed));ch.className='hud'+(armed?' gun':'')+(player.weapon==='shotgun'?' wide':'');
  if(coarse){$('bPunch').textContent=inCar&&player.car.type==='fire'?'물대포':armed?(W.proj?'던지기':'사격'):'펀치';$('bEnter').textContent=inCar?'내리기':(currentZone()||(!nearestCar(2.6)&&nearestMark()))?'이용':'탑승';}
  let pr='';
  if(started&&!dead&&!menu){
    const ek=coarse?'':'<kbd>E</kbd>';
    if(player.ride&&player.ride.taxi){const c=player.ride.bus;pr='택시 탑승 중 · 요금 $'+taxiFare(c)+' · '+(c.stopReq?'세우는 중':nav&&taxiArea(nav)?nav.label+'까지 '+Math.round(d2(c.pos,nav))+'m':(nav?'섬 밖은 못 가요 · ':'')+'<kbd>M</kbd> 지도에서 목적지 찍기')+' · '+(coarse?'이용 버튼':'<kbd>E</kbd>')+' 내리기';}
    else if(player.ride&&player.ride.bus){const c=player.ride.bus,S=c.route&&c.route.stops[c.si];pr=(c.route.air?'공항버스':'버스 '+c.route.id+'번')+' 탑승 중 · '+(c.dwell>0||c.dwelling?(S?S.name+' 정류장 · ':'')+(coarse?'이용 버튼':'<kbd>E</kbd>')+' 내리기':'다음 정류장 '+(S?S.name:''));}
    else if(player.ride)pr='페리 탑승 중 · '+(player.ride.side==='A'?'국제공항':'하버')+'까지 약 '+Math.ceil(ferryWait(player.ride.side==='A'?'B':'A'))+'초';
    else if(robbing)pr=(robbing.loc.type==='bank'?'금고':'계산대')+' 터는 중 '+Math.floor(robbing.t/robbing.dur*100)+'% · 카운터를 벗어나지 마세요<span class="bar"><i style="width:'+Math.floor(robbing.t/robbing.dur*100)+'%"></i></span>';
    else if(escaping)pr='환풍구 뜯는 중 '+Math.floor(escaping.t/escaping.dur*100)+'% · 환풍구 앞을 벗어나지 마세요<span class="bar"><i style="width:'+Math.floor(escaping.t/escaping.dur*100)+'%"></i></span>';
    else if(job)pr=job.label+' '+Math.floor(job.t/job.dur*100)+'% · 자리를 벗어나지 마세요<span class="bar"><i style="width:'+Math.floor(job.t/job.dur*100)+'%"></i></span>';
    else if(inCar&&player.car.type==='pheli')pr='고도 '+Math.max(0,Math.round(player.car.pos.y-heliFloor(player.car.pos.x,player.car.pos.z)))+'m · '+(coarse?'점프 상승 · 웅크리기 하강':'<kbd>Space</kbd>상승 <kbd>Shift</kbd>하강 · <kbd>클릭</kbd>기관포')+' · <kbd>F</kbd>착륙 후 내리기';
    else if(inCar&&DJOB.on&&player.car===DJOB.car){const O=DJOB.order,c=player.car;pr='배송 근무 · '+(DJOB.stage==='deliver'&&O?O.dest.name+(O.dest.estate?' (공단)':'')+'까지 '+Math.round(d2(c.pos,O.dest))+'m · 수당 $'+O.pay+(O.unload>0?' · 하역 중 '+Math.ceil(4-O.unload)+'초':O.t<=O.limit?' · 보너스까지 '+Math.ceil(O.limit-O.t)+'초':''):'물류센터로 돌아가 짐 싣기 · '+Math.round(d2(c.pos,LOGI.load))+'m'+(DJOB.t>0?' · 싣는 중':''))+' · 오늘 $'+DJOB.earned+' · <kbd>F</kbd>내리기';}
    else if(inCar&&TJOB.on&&player.car===TJOB.car){const F=TJOB.fare,c=player.car;pr='택시 근무 중 · '+(!F?'콜 기다리는 중…':F.stage==='pickup'?'손님에게 가기 '+Math.round(d2(c.pos,F.p.pos))+'m · 옆에 서면 탑승':F.name+'까지 '+Math.round(d2(c.pos,F.dest))+'m · 요금 $'+F.pay+(F.t<=F.limit?' · 팁까지 '+Math.ceil(F.limit-F.t)+'초':''))+' · 오늘 $'+TJOB.earned+' · <kbd>F</kbd>내리기';}
    else if(inCar&&GUN_VEH[player.car.type])pr=(coarse?'사격 버튼 ':'<kbd>클릭</kbd>')+'기관포 · <kbd>F</kbd>내리기';
    else if(inCar&&isBoat(player.car))pr='<kbd>F</kbd>내리기 · 부두 가까이에서 내리면 부두로, 아니면 바다로';
    else if(inCar&&currentZone()&&currentZone().kind==='gas'){const c=player.car,n=Math.ceil(100-c.fuel);pr=ek+'주유하기 · 1%당 $'+GAS_PRICE+' · 연료 '+Math.round(c.fuel)+'% · 가득 $'+Math.max(0,n)+' · <kbd>F</kbd>내리기';}
    else if(inCar)pr=currentZone()?ek+'카센터 이용 · '+(coarse?'':'<kbd>F</kbd>')+'내리기':player.car.type==='fire'?(coarse?'':'<kbd>클릭</kbd>')+'물대포 · <kbd>F</kbd>내리기':'<kbd>F</kbd>내리기';
    else{
      const c=player.inside?null:nearestCar(2.6);
      const nb=!c?nearNavyBoat():null;
      const VN={army:'군용 트럭',apc:'장갑차',pheli:'군용 헬기'};
      const zb=player.inside?null:currentZone();
      if(zb&&zb.kind==='logiDesk')pr=ek+(DJOB.on?'배송 근무 끝내기 · '+DJOB.drops+'건 · 번 돈 $'+DJOB.earned:'배송 기사로 취업하기 · 화물차로 공단과 시내에 짐 배달')+' · 네온 익스프레스';
      else if(zb&&zb.kind==='taxiDesk')pr=ek+(TJOB.on?'택시 근무 끝내기 · 손님 '+TJOB.trips+'명 · 번 돈 $'+TJOB.earned:'택시 기사로 취업하기 · 영업소 택시로 손님을 태워 돈 벌기')+' · '+zb.D.name;
      else if(zb&&zb.kind==='taxi')pr='택시 타기'+(coarse?'':' <kbd>E</kbd>')+' · 기본 $'+TAXI_BASE+' + 100m당 $'+Math.round(TAXI_PER_M*100)+(nav?' · '+nav.label+'(으)로':' · 탄 뒤 M 지도에서 목적지 찍기');
      else if(zb&&zb.kind==='bus'){const b=zb.bus,n=b.route.stops[(b.si+1)%b.route.stops.length];pr='버스 탑승(이용료 $'+BUS_FARE+')'+(coarse?'':' <kbd>E</kbd>')+' · '+(b.route.air?'공항버스':b.route.id+'번')+' · 다음 '+(n?n.name:'');}
      else if(c&&c.milLock)pr='<kbd>F</kbd>'+VN[c.type]+' 훔치기 · '+((player.keys[c.milLock]||0)>0?LOCK_INFO[c.milLock][0]+' 있음 (★4 경보)':player.kits.mil>0?'군용 배선 따개로 5초 (남은 '+player.kits.mil+'개 · ★4 경보)':'군용 차량 배선 따개 필요 · 총포상 암시장');
      else if(c&&isLocked(c))pr=player.kits.car>0?'<kbd>F</kbd>잠긴 차 · 배선 따개로 3초 (남은 '+player.kits.car+'회)':'잠긴 차 · 차량 배선 따개 필요 (총포상 주인과 대화)';
      else if(nb)pr='<kbd>F</kbd>해군 경비정 훔치기 · '+((player.keys.boat||0)>0?'경비정 키 있음 (★4 경보)':player.kits.mil>0?'군용 배선 따개로 5초 (★4 경보)':'군용 차량 배선 따개 필요 · 총포상 암시장');
      else if(c&&c.impound&&c.mine)pr='<kbd>F</kbd>보관료 $20 내고 내 차 찾기';
      else if(c&&c.type==='mboat')pr='<kbd>F</kbd>'+(c.owned?'내 보트 타기':'보트 훔치기 (경범죄)');
      else if(c)pr=c.hasDriver?'<kbd>F</kbd>'+(c.type==='civ'?'운전자 끌어내고 차 뺏기':'관용차 빼앗기'):'<kbd>F</kbd>'+(c.type==='civ'?'차에 타기':'관용차 훔치기');
      else{const z=currentZone();
        if(z&&z.kind==='door')pr=z.loc.room?ek+(z.loc.type==='hotel'||z.loc.type==='terminal'?z.loc.title:z.loc.name)+' 들어가기':(z.loc.title||z.loc.name)+' · 아직 문을 열지 않았다';
        else if(z&&z.kind==='exit')pr=ek+'밖으로 나가기';
        else if(z&&z.kind==='counter')pr=ek+COUNTER_LABEL(z.loc.type);
        else if(z&&z.kind==='bin')pr=ek+'쓰레기 버리기 · '+player.trash+'개';
        else if(z&&z.kind==='bus'){const c=z.bus,n=c.route.stops[(c.si+1)%c.route.stops.length];pr='버스 탑승(이용료 $'+BUS_FARE+')'+(coarse?'':' <kbd>E</kbd>')+' · '+(c.route.air?'공항버스':c.route.id+'번')+' · 다음 '+(n?n.name:'');}
        else if(z&&z.kind==='binSearch')pr=z.bin.cd>0?'쓰레기통 · 방금 뒤졌다 ('+Math.ceil(z.bin.cd)+'초)':ek+'쓰레기통 뒤지기 · 2초 · 폐품';
        else if(z&&z.kind==='spot')pr=ek+(typeof z.spot.label==='function'?z.spot.label():z.spot.label);
        else if(z&&z.kind==='garage')pr=ek+'카센터 · 새 차 구매 (차를 몰고 오면 팔기 · 수리)';
        else if(z&&z.kind==='vent')pr=ek+'환풍구 뜯기 · 탈옥 (8초)';
        else if(z&&z.kind==='term'){const T=z.term,miss=T.need.filter(k=>!player.tools[k]);pr=T.cd>0?T.name+' · 비어 있음 ('+Math.ceil(T.cd)+'초)':miss.length?T.name+' · '+miss.map(k=>TOOL_NAME[k]).join('+')+' 필요 (I 제작)':ek+T.name+' 열기 · '+T.dur+'초 · '+T.give+' · 군인 눈에 띄면 ★3';}
        else if(z&&z.kind==='shop')pr=ek+z.loc.T.counter;
        else if(z&&z.kind==='ferry')pr=ferryDocked(z.side)?ek+'페리 타기 · $'+FERRY_FARE+' · '+(z.side==='A'?'국제공항':'하버')+'행 · '+Math.ceil(FERRY_DOCK-FERRY.t)+'초 뒤 출항':'페리 운항 중 · 약 '+Math.ceil(ferryWait(z.side))+'초 뒤 도착';
        else if(z&&z.kind==='heap')pr=z.heap.cd>0?'고물 더미 · 다시 뒤지려면 '+Math.ceil(z.heap.cd)+'초':ek+'고물 뒤지기 · 3초 · 제작 재료';
        else if(z&&z.kind==='mail')pr=z.poi.cd>0?'우체통 · 비어 있음 ('+Math.ceil(z.poi.cd)+'초)':player.tools.crowbar?ek+'우체통 따기 · 2.5초 · 10% 확률로 수배':'우체통 · 크로우바가 있으면 딸 수 있다 (I 제작)';
        else if(z&&z.kind==='atm')pr=z.poi.cd>0?'ATM · 현금 없음 ('+Math.ceil(z.poi.cd)+'초)':player.tools.crowbar&&player.tools.drill?ek+'ATM 뚫기 · 6초 · 45% 확률로 수배':'ATM · 크로우바와 드릴이 있으면 뚫을 수 있다 (I 제작)';
        else if(player.jailed)pr='형기 '+Math.ceil(player.jailT)+'초 남음 · 감방 안쪽 환풍구로 탈옥할 수 있다';
        else if(nearestMark())pr=(coarse?'이용 버튼 · ':'<kbd>G</kbd>')+'소매치기 · 반은 들킨다';}
    }
  }
  const pe=$('prompt');if(pr){pe.innerHTML=pr;pe.hidden=false;}else pe.hidden=true;
}

// ---------- init world population ----------
for(const s of stationSpots){const c=makeCar('police',s.x,s.z,s.h,'parked');c.fixed=true;}
for(const s of fireSpots){const c=makeCar('fire',s.x,s.z,s.h,'parked');c.fixed=true;}
refillSlots(true);
for(let i=0;i<TRAFFIC;i++){const sp=spawnRoadPos(15,400);if(sp)makeTraffic(sp);}
for(let i=0;i<11;i++)makeParked();
makeCar('civ',OLD_C-3.5,OLD_C-13,0,'parked');
{const tp=playerPos();let b=null,bd=1e9;for(const c of cars)if(c.ai==='parked'&&c.type==='civ'){const d=d2(c.pos,tp);if(d<bd){bd=d;b=c;}}if(b)b.locked=false;} // the nearest car at the start is always open
for(let i=0;i<CIV_TARGET;i++)spawnCivWalker();
for(const L of LOCS)if(L.type==='hospital'&&L.pad)spawnMedHeli(L);
for(const R_ of BUS_ROUTES)for(let k=0;k<R_.n;k++){const S=R_.stops[Math.floor(k*R_.stops.length/R_.n+(R_.air?1:0))%R_.stops.length];if(S)makeBus(R_,S,true);}
for(const Z of PATROL_ZONES)for(let i=0;i<Z.cars;i++)spawnPatrolCar(Z);
for(let i=0;i<PATROL_ZONES[0].foot;i++)spawnPatrolCop(PATROL_ZONES[0]);
for(let i=0;i<TRASH_N;i++)spawnTrash(6);
for(let i=0;i<SCRAP_N;i++)spawnTrash(6,'scrap');

// ---------- day & night: 24 game hours in 12 real minutes ----------
let tod=18,dayT=0;const DAY_RATE=1/30;{const w=NET.worldTod(DAY_RATE);if(w!==null)tod=w;} // online: the room's shared clock
const PAL={
  night:{fog:0x1a1830,near:60,far:250,hs:0x6a74b0,hg:0x1e1828,hi:.55,sc:0x8fa4d8,si:.3,win:1,house:.85,lamp:1,stars:.9,water:0x141f3a,bloom:.5},
  dusk:{fog:0x4b3358,near:70,far:290,hs:0x9ea4dc,hg:0x3a2a35,hi:.85,sc:0xffb27a,si:.6,win:.95,house:.8,lamp:.85,stars:.6,water:0x1c2f52,bloom:.45},
  day:{fog:0xa9c4dc,near:90,far:360,hs:0xe6eeff,hg:0x6a5a48,hi:1.05,sc:0xfff3e0,si:.95,win:.12,house:.08,lamp:0,stars:0,water:0x2f6a9a,bloom:.2}
};
const _c1=new THREE.Color(),_c2=new THREE.Color(),_c3=new THREE.Color();
function mixHex(a,b,c,wD,wK,out){_c1.setHex(a);_c2.setHex(b);_c3.setHex(c);_c1.lerp(_c2,wD).lerp(_c3,wK);return (out||new THREE.Color()).copy(_c1);}
const mixN=(a,b,c,wD,wK)=>(a+(b-a)*wD)*(1-wK)+c*wK;
function applyDaylight(){
  const ang=(tod-6)/24*Math.PI*2,e=Math.sin(ang);
  const wD=smooth(-.1,.32,e),wK=Math.exp(-Math.pow(e/.17,2))*.85,N_=PAL.night,D=PAL.day,K=PAL.dusk;
  const mix=k=>mixN(N_[k],D[k],K[k],wD,wK);
  mixHex(N_.fog,D.fog,K.fog,wD,wK,scene.fog.color);scene.fog.near=mix('near');scene.fog.far=mix('far');
  mixHex(N_.hs,D.hs,K.hs,wD,wK,hemi.color);mixHex(N_.hg,D.hg,K.hg,wD,wK,hemi.groundColor);hemi.intensity=mix('hi');
  mixHex(N_.sc,D.sc,K.sc,wD,wK,sun.color);sun.intensity=mix('si');
  const win=mix('win');for(const k in SMC)SMC[k].emissiveIntensity=win;HOUSE.emissiveIntensity=mix('house');
  const lamp=mix('lamp');haloMat.opacity=.75*lamp;lampPoolMat.opacity=.22*lamp;lampHeadMat.color.setHex(lamp>.3?0xffd08a:0x9a9488);
  SKY.starMat.opacity=mix('stars');
  mixHex(N_.water,D.water,K.water,wD,wK,water.material.color);
  if(bloom)bloom.strength=mix('bloom');
  // sky gradient
  const cols=SKY.cols,ts=SKY.ts;
  for(let i=0;i<ts.length;i++){const t=ts[i];let s=SKY_T.length-2;for(let k=0;k<SKY_T.length-1;k++)if(t<=SKY_T[k+1]){s=k;break;}
    const u=clamp((t-SKY_T[s])/(SKY_T[s+1]-SKY_T[s]),0,1);
    const a=mixHex(SKY_PAL.night[s],SKY_PAL.day[s],SKY_PAL.dusk[s],wD,wK,_skyA),b=mixHex(SKY_PAL.night[s+1],SKY_PAL.day[s+1],SKY_PAL.dusk[s+1],wD,wK,_skyB);
    a.lerp(b,u);cols[i*3]=a.r;cols[i*3+1]=a.g;cols[i*3+2]=a.b;}
  if(SKY.g.attributes.color)SKY.g.attributes.color.needsUpdate=true;
  // sun rises in the east (+x) and sets over the harbour in the west; the moon is opposite
  const sd=new V3(Math.cos(ang),Math.sin(ang),-.35).normalize();
  SKY.sun.position.set(sd.x*300,sd.y*300,sd.z*300);SKY.sun.visible=sd.y>-.08;
  SKY.moon.position.set(-sd.x*300,-sd.y*300+40,-sd.z*300);SKY.moon.visible=-sd.y>-.12;
  SKY.sunDir=sd.y>0?sd:new V3(-sd.x,-sd.y,-sd.z);
}
const _skyA=new THREE.Color(),_skyB=new THREE.Color();
applyDaylight();

// ---------- bloom: soft glow on neon, windows and lamps (desktop only) ----------
(function(){
  if(coarse||!THREE.EffectComposer||!THREE.RenderPass||!THREE.UnrealBloomPass)return;
  try{
    const w=container.clientWidth||innerWidth,h=container.clientHeight||innerHeight,pr=renderer.getPixelRatio();
    let rt;
    if(THREE.WebGLMultisampleRenderTarget&&renderer.capabilities.isWebGL2){rt=new THREE.WebGLMultisampleRenderTarget(w*pr,h*pr,{format:THREE.RGBAFormat});rt.samples=4;}
    composer=new THREE.EffectComposer(renderer,rt);
    composer.setPixelRatio(pr);composer.setSize(w,h);
    composer.addPass(new THREE.RenderPass(scene,camera));
    bloom=new THREE.UnrealBloomPass(new THREE.Vector2(w,h),.45,.4,.86);
    composer.addPass(bloom);
  }catch(e){composer=null;}
})();
function draw(dt){
  if(composer){try{composer.render(dt);return;}catch(e){composer=null;}}
  renderer.render(scene,camera);
}

// ---------- online multiplayer: other players in the same room ----------
// Every client simulates its own NPCs, traffic and police; what is shared is the city itself
// (same seed), the world clock, players (position · pose · vehicle · weapon · health · wanted level),
// gunshots, thrown/launched projectiles, PvP hits and deaths.
const MP=(function(){
  const remotes=new Map();
  const tmp=new V3();
  let lastHit=null,sendT=0,lastKey='',lastSentAt=0,stateT=0;
  const hexInt=h=>{const n=parseInt(String(h||'').replace('#',''),16);return Number.isFinite(n)?n:0xffffff;};
  const shade=(c,k)=>{const r=(c>>16)&255,g=(c>>8)&255,b=c&255;return (Math.round(r*k)<<16)|(Math.round(g*k)<<8)|Math.round(b*k);};
  const v3=a=>new V3(a[0],a[1],a[2]);

  // name tag above a player's head (always readable, drawn over the city)
  function drawTag(R){
    const c=R.tagC,g=c.getContext('2d'),W=c.width,H=c.height;
    g.clearRect(0,0,W,H);
    g.font="700 34px 'Noto Sans KR',system-ui,sans-serif";
    const tw=Math.min(W-40,g.measureText(R.name).width),bw=tw+44,x0=(W-bw)/2;
    g.fillStyle='rgba(11,13,30,.82)';g.fillRect(x0,8,bw,H-16);
    g.fillStyle=R.color;g.fillRect(x0,8,8,H-16);
    g.strokeStyle='rgba(255,190,90,.35)';g.lineWidth=2;g.strokeRect(x0+1,9,bw-2,H-18);
    g.fillStyle='#f4efe4';g.textAlign='center';g.textBaseline='middle';
    g.fillText(R.name,W/2+4,H/2+1,W-48);
    R.tagT.needsUpdate=true;
  }
  function create(p){
    if(!p||remotes.has(p.id)||(NET.me&&p.id===NET.me.id))return remotes.get(p&&p.id);
    const col=hexInt(p.color);
    const body=makePerson({skin:pick(skins),shirt:col,pants:0x22263a,hair:pick(hairs),vest:shade(col,.55)});
    const guns={};for(const k of ['pistol','shotgun','rifle','molotov','rpg']){guns[k]=gunMesh(k);guns[k].visible=false;body.armR.add(guns[k]);}
    const tagC=document.createElement('canvas');tagC.width=320;tagC.height=72;
    const tagT=new THREE.CanvasTexture(tagC);tagT.minFilter=THREE.LinearFilter;
    const tag=new THREE.Sprite(new THREE.SpriteMaterial({map:tagT,depthTest:false,depthWrite:false,transparent:true,fog:false}));
    tag.renderOrder=999;scene.add(tag);
    const R={id:p.id,name:p.name,color:p.color,body,guns,shadow:blob(.95,.95),tag,tagC,tagT,
      pos:new V3(),tgt:new V3(),yaw:0,tYaw:0,pitch:0,phase:0,st:null,has:false,seenAt:0,
      car:null,carKey:'',carS:null,cPos:new V3(),cTgt:new V3(),cRot:new V3(),cRotT:new V3()};
    body.g.visible=false;R.shadow.visible=false;tag.visible=false;
    drawTag(R);remotes.set(p.id,R);
    return R;
  }
  function dropCar(R){if(R.car){scene.remove(R.car.g);R.car=null;}R.carKey='';R.carS=null;}
  function remove(id){
    const R=remotes.get(id);if(!R)return;
    scene.remove(R.body.g);scene.remove(R.shadow);scene.remove(R.tag);
    R.tagT.dispose();R.tag.material.dispose();dropCar(R);remotes.delete(id);
  }
  function apply(R,s){
    R.st=s;R.tgt.set(s.p[0],s.p[1],s.p[2]);R.tYaw=s.y;R.pitch=s.pi;
    if(!R.has){R.pos.copy(R.tgt);R.yaw=s.y;R.has=true;}
    if(s.c){
      const key=s.c.k+'|'+(s.c.m||'')+'|'+s.c.col;
      if(key!==R.carKey){
        dropCar(R);
        try{
          const t=s.c.k;R.car=makeCarMesh(t,s.c.col,s.c.m||undefined);R.car.g.rotation.order='YXZ';
          R.carS=(t==='civ'&&MODEL_STATS[s.c.m])||(t==='mboat'&&s.c.m==='speed'&&CAR_STATS.mspeed)||CAR_STATS[t]||CAR_STATS.civ;
          R.cPos.set(s.c.p[0],s.c.p[1],s.c.p[2]);R.cRot.set(s.c.r[0],s.c.r[1],s.c.r[2]);
        }catch(e){R.car=null;}
        R.carKey=key;
      }
      R.cTgt.set(s.c.p[0],s.c.p[1],s.c.p[2]);R.cRotT.set(s.c.r[0],s.c.r[1],s.c.r[2]);
    } else if(R.carKey)dropCar(R);
    R.seenAt=performance.now();
  }
  const live=R=>R.has&&!(R.st.f&4)&&!(R.st.f&512)&&performance.now()-R.seenAt<15000;

  // ----- per frame -----
  function update(dt){
    const k=1-Math.exp(-dt*12),now=performance.now();
    for(const R of remotes.values()){
      if(!R.has)continue;
      const s=R.st,stale=now-R.seenAt>15000,inCar=!!s.c,down=!!(s.f&4);
      const px=R.pos.x,pz=R.pos.z;
      if(R.pos.distanceToSquared(R.tgt)>900)R.pos.copy(R.tgt);else R.pos.lerp(R.tgt,k);
      R.yaw+=angDiff(R.yaw,R.tYaw)*k;
      const spd=Math.hypot(R.pos.x-px,R.pos.z-pz)/Math.max(dt,1e-3);
      const far=R.pos.distanceToSquared(camera.position)>480*480;
      const b=R.body;
      b.g.visible=!stale&&!inCar&&!far&&!(s.f&512);
      R.shadow.visible=b.g.visible&&!down;
      if(b.g.visible){
        b.g.position.copy(R.pos);b.g.rotation.set(0,R.yaw,0);
        const moving=(s.f&1)||spd>.6;
        if(moving)R.phase+=dt*(s.f&128?11:7.5);
        animPerson(b,R.phase,moving?(s.f&2?.35:.8):0);
        const armed=s.w!=='fist';
        for(const g in R.guns)R.guns[g].visible=!down&&s.w===g;
        if(armed&&!down){const aim=-Math.PI/2-R.pitch;b.armR.rotation.x=aim;b.armL.rotation.x=aim+.15;b.armL.rotation.z=-.45;}
        if((s.f&32)&&armed){b.armR.rotation.x=-.9;b.armL.rotation.x=-.9;}
        if(s.f&16){b.armL.rotation.x=b.armR.rotation.x=-2.95;b.armL.rotation.z=-.2;}
        if(s.f&8){const st=clock*(moving?5:2.2);b.armL.rotation.x=-2.2+Math.sin(st)*1.1;b.armR.rotation.x=-2.2-Math.sin(st)*1.1;b.armL.rotation.z=-.5;}
        if(s.f&2){b.g.position.y-=.42;b.legL.rotation.x-=1.25;b.legR.rotation.x-=1.25;}
        if(down){b.g.rotation.set(-Math.PI/2,R.yaw,0);b.g.position.y=R.pos.y+.17;animPerson(b,0,0);}
        R.shadow.position.set(R.pos.x,groundY(R.pos.x,R.pos.z),R.pos.z);
      }
      if(R.car){
        if(R.cPos.distanceToSquared(R.cTgt)>900)R.cPos.copy(R.cTgt);else R.cPos.lerp(R.cTgt,k);
        R.cRot.x+=(R.cRotT.x-R.cRot.x)*k;R.cRot.z+=(R.cRotT.z-R.cRot.z)*k;R.cRot.y+=angDiff(R.cRot.y,R.cRotT.y)*k;
        R.car.g.position.copy(R.cPos);R.car.g.rotation.set(R.cRot.x,R.cRot.y,R.cRot.z);
        R.car.g.visible=!stale&&!far;
      }
      // name tag
      const at=inCar&&R.car?R.cPos:R.pos,h=inCar&&R.carS?R.carS.top+1.1:down?.9:(s.f&2)?1.95:2.45;
      R.tag.position.set(at.x,at.y+h,at.z);
      const dc=camera.position.distanceTo(R.tag.position);
      R.tag.visible=!stale&&dc<170&&!(s.f&512&&!inCar);
      const sc=Math.max(1,dc/20);R.tag.scale.set(2.2*sc,.5*sc,1);
      R.tag.material.opacity=down?.55:1;
    }
    sendState(dt);
  }

  // ----- my state → server (10 Hz while things change, 1 Hz heartbeat when idle) -----
  const r2=v=>Math.round(v*100)/100;
  function sendState(dt){
    sendT-=dt;if(sendT>0||NET.offline||!NET.connected)return;sendT=.1;
    const P=player,c=P.car,ride=P.ride&&P.ride.bus;
    const f=(P.moving?1:0)|(P.crouch?2:0)|(dead?4:0)|(P.swim?8:0)|(P.surrender?16:0)|(P.reloadT>0?32:0)|(P.inside?64:0)|
      ((input.keys.ShiftLeft||input.keys.ShiftRight)&&P.moving?128:0)|(!started?512:0)|(ride?512:0);
    const m={t:'s',p:[r2(P.pos.x),r2(P.pos.y),r2(P.pos.z)],y:r2(P.yaw),pi:r2(camPitch),w:P.weapon,h:Math.max(0,Math.round(P.health)),f,ws:wanted.stars,c:0};
    if(c&&c.mesh){const g=c.mesh;m.c={k:c.isTaxi?'taxi':c.type,m:c.model||null,col:(c.color|0)>>>0&0xffffff,p:[r2(g.position.x),r2(g.position.y),r2(g.position.z)],r:[r2(g.rotation.x),r2(g.rotation.y),r2(g.rotation.z)]};}
    const key=JSON.stringify(m),now=performance.now();
    if(key===lastKey&&now-lastSentAt<1000)return;
    if(NET.send(m)){lastKey=key;lastSentAt=now;}
    stateT-=.1;if(stateT<=0){stateT=1;NET.updateMe(m);}
  }

  // ----- bullets hitting other players (called from castShot) -----
  function rayHit(o,dir,best){
    if(!NET.pvp())return null;
    let hit=null;const hh=dir.x*dir.x+dir.z*dir.z;
    for(const R of remotes.values()){
      if(!live(R))continue;
      if(R.st.c&&R.car&&R.carS){
        const S=R.carS,hd=R.cRot.y,f={x:Math.sin(hd),z:Math.cos(hd)},r={x:-f.z,z:f.x},rx=o.x-R.cPos.x,rz=o.z-R.cPos.z;
        const lo={x:rx*r.x+rz*r.z,y:o.y-R.cPos.y,z:rx*f.x+rz*f.z},ld={x:dir.x*r.x+dir.z*r.z,y:dir.y,z:dir.x*f.x+dir.z*f.z};
        const t=rayBox(lo,ld,-S.w/2,0,-S.half,S.w/2,S.top,S.half);
        if(t!==null&&t<best){best=t;hit={t,R};}
        continue;
      }
      if(hh<1e-6)continue;
      const p=R.pos,t=((p.x-o.x)*dir.x+(p.z-o.z)*dir.z)/hh;if(t<0||t>best)continue;
      const qx=o.x+dir.x*t-p.x,qz=o.z+dir.z*t-p.z,y=o.y+dir.y*t,top=(R.st.f&2)?1.5:1.95;
      if(qx*qx+qz*qz<.22&&y>p.y&&y<p.y+top){best=t;hit={t,R};}
    }
    return hit;
  }
  function hit(R,dmg,w){if(NET.send({t:'hit',to:R.id,dmg:Math.round(dmg),w}))hitMarker(false);}
  function punchAt(f){
    if(!NET.pvp()||player.car)return;
    for(const R of remotes.values()){
      if(!live(R)||R.st.c)continue;
      const dx=R.pos.x-player.pos.x,dz=R.pos.z-player.pos.z,d=Math.hypot(dx,dz);
      if(d<2.1&&Math.abs(R.pos.y-player.pos.y)<1.6&&(dx*f.x+dz*f.z)>d*.35)hit(R,20,'fist');
    }
  }
  // projectiles: touching a remote player sets them off
  function projTouch(np,owner){
    for(const R of remotes.values()){
      if(!live(R)||R.id===owner)continue;
      if(R.st.c&&R.car&&R.carS){const S=R.carS,hd=R.cRot.y,f={x:Math.sin(hd),z:Math.cos(hd)},dx=np.x-R.cPos.x,dz=np.z-R.cPos.z;
        if(Math.abs(dx*f.x+dz*f.z)<S.half&&Math.abs(-dx*f.z+dz*f.x)<S.w/2&&np.y<R.cPos.y+S.top)return true;continue;}
      if(Math.abs(R.pos.x-np.x)<.55&&Math.abs(R.pos.z-np.z)<.55&&np.y>R.pos.y&&np.y<R.pos.y+1.9)return true;
    }
    return false;
  }
  function touchesMe(np){
    if(dead||player.inside)return false;
    if(player.car){const c=player.car,f=fwdOf(c),dx=np.x-c.pos.x,dz=np.z-c.pos.z;return Math.abs(dx*f.x+dz*f.z)<c.half&&Math.abs(-dx*f.z+dz*f.x)<c.w/2&&np.y<c.pos.y+c.top;}
    const p=player.pos;return Math.abs(p.x-np.x)<.55&&Math.abs(p.z-np.z)<.55&&np.y>p.y&&np.y<p.y+1.9;
  }

  // ----- my actions → others -----
  const rv=v=>[r2(v.x),r2(v.y),r2(v.z)];
  function shot(w,muzzle,ends){if(!NET.offline)NET.send({t:'shot',w,m:rv(muzzle),e:ends.map(rv)});}
  function proj(kind,start,vel){if(!NET.offline)NET.send({t:'proj',k:kind,p:rv(start),v:rv(vel)});}
  function died(){
    if(NET.offline)return;
    const by=lastHit&&performance.now()-lastHit.t<12000?lastHit.id:null;
    NET.send({t:'died',by});lastHit=null;
  }
  function noteHit(id){lastHit={id,t:performance.now()};}

  // ----- others' actions → my world -----
  function remoteShot(m){
    const R=remotes.get(m.id),mz=v3(m.m);
    if(mz.distanceToSquared(camera.position)>260*260)return;
    for(const e of m.e){const end=v3(e);tracer(mz,end,0xfff0c0);puff(end,0xffc070,.1,new V3(0,1,0),.14,true);}
    puff(mz,0xffd27a,m.w==='shotgun'?.22:.14,new V3(),.06,true);
    if(R)R.pitch=R.pitch; // pose already follows the state stream
    scare(mz,30); // townsfolk near the shooter scatter in my world too
  }
  function remoteProj(m){
    if(!m.p||!m.v)return;
    const kind=m.k,start=v3(m.p),vel=v3(m.v),g=new THREE.Group();g.position.copy(start);
    if(kind==='molotov'){const b=mesh(bottleMeshG,mat(0x3f8a5a));b.rotation.x=Math.PI/2;g.add(b);const fl=new THREE.Sprite(flameCore);fl.scale.set(.5,.5,1);fl.position.z=.22;g.add(fl);}
    else{const b=mesh(rocketG,mat(0x4a5a2a));b.rotation.x=Math.PI/2;g.add(b);const n=mesh(noseG,mat(0x2a2a26));n.rotation.x=Math.PI/2;n.position.z=.6;g.add(n);const fl=new THREE.Sprite(flameMat);fl.scale.set(.9,.9,1);fl.position.z=-.55;g.add(fl);}
    scene.add(g);
    projs.push({kind,g,pos:start.clone(),vel,t:0,trailT:0,remote:true,owner:m.id});
  }
  function onHit(m){
    if(dead||!NET.pvp())return;
    noteHit(m.from);
    damagePlayer(m.dmg,m.name+'에게 당했습니다.');
  }

  NET.on('s',m=>{let R=remotes.get(m.id);if(!R)R=create(NET.players.get(m.id)||{id:m.id,name:'?',color:'#ffffff'});if(R)apply(R,m);});
  NET.on('join',m=>{create(m.player);feed(m.player.name+' 님 입장');});
  NET.on('leave',m=>{const R=remotes.get(m.id);if(R)feed(R.name+' 님 퇴장');remove(m.id);});
  NET.on('roster',m=>{
    const ids=new Set(m.players.map(p=>p.id));
    for(const id of [...remotes.keys()])if(!ids.has(id))remove(id);
    for(const p of m.players){const R=remotes.get(p.id);if(R&&(R.name!==p.name||R.color!==p.color)){R.name=p.name;R.color=p.color;drawTag(R);}}
  });
  NET.on('welcome',m=>{ // reconnected: rebuild the roster from the server's snapshot
    const ids=new Set(m.players.map(p=>p.id));
    for(const id of [...remotes.keys()])if(!ids.has(id))remove(id);
    for(const p of m.players){const R=create(p);if(R&&p.state)apply(R,p.state);}
    lastKey='';
  });
  NET.on('shot',remoteShot);
  NET.on('proj',remoteProj);
  NET.on('hit',onHit);
  NET.on('kill',m=>{
    if(NET.me&&m.killer===NET.me.id&&m.victim!==NET.me.id){const v=NET.players.get(m.victim);hitMarker(true);toast((v?v.name:'상대')+' 처치!');}
  });
  NET.on('pvp',on=>toast(on?'PvP 켜짐 · 다른 플레이어를 공격할 수 있다':'PvP 꺼짐 · 서로 공격할 수 없다'));
  NET.on('chatline',m=>{const R=remotes.get(m.id);if(R&&R.tag.visible)feed(m.name+': '+m.text);});
  // players already in the room when I joined
  for(const p of NET.players.values()){const R=create(p);if(R&&p.state)apply(R,p.state);}

  // ----- minimap -----
  function drawMini(ctx,sc){
    for(const R of remotes.values()){
      if(!R.has||performance.now()-R.seenAt>15000)continue;
      const at=R.st.c&&R.car?R.cPos:R.pos;if(at.x>ROOM_X)continue;
      ctx.fillStyle=R.color;ctx.strokeStyle='#0b0d1c';ctx.lineWidth=2.2/sc;
      ctx.beginPath();ctx.arc(at.x,at.z,Math.max(3.4,7/sc),0,Math.PI*2);ctx.fill();ctx.stroke();
    }
  }
  return {remotes,update,rayHit,hit,punchAt,projTouch,touchesMe,shot,proj,died,noteHit,drawMini,blastBy:null};
})();
function openChat(){
  input.keys={};input.fireHeld=false;input.punch=false;input.joy.x=input.joy.y=0;
  if(document.pointerLockElement){hudCursor=true;try{document.exitPointerLock();}catch(e){}}
  NET.openChat(()=>{if(started&&!dead&&!paused&&!menu&&!phoneOpen&&!mapOpen&&!craftOpen&&!endingOpen){canvas.focus();if(!coarse)tryLock(true);}});
}

// ---------- loop ----------
let last=performance.now();
function frame(now){
  requestAnimationFrame(frame);
  const dt=Math.min(.05,(now-last)/1000);last=now;
  MP.update(dt);
  if(paused){draw(dt);return;}
  clock+=dt;
  recoil=Math.max(0,recoil-dt*7);heliCD=Math.max(0,heliCD-dt);
  for(const L of LOCS)if(L.robCD>0)L.robCD=Math.max(0,L.robCD-dt);
  updateHospRelease(dt);updateMedHelis(dt);updateGang(dt);updateBuses(dt);updateTaxiDepots(dt);updateTaxiJob(dt);updateFreight(dt);updateCourier(dt);updateNatFire(dt);updateLots(dt);updateCabs(dt);updateParking(dt);updateTraffic(dt);
  if(started)playT+=dt;for(const V of ORE_VEINS)if(V.cd>0)V.cd-=dt;for(const b of bins)if(b.cd>0)b.cd-=dt;
  for(const P of pois)if(P.cd>0)P.cd-=dt;
  for(const h of heaps)if(h.cd>0)h.cd-=dt;
  for(const T of TERMINALS)if(T.cd>0)T.cd-=dt;
  {const t0=tod,w=NET.worldTod(DAY_RATE);tod=w===null?(tod+dt*DAY_RATE)%24:w;if(tod<t0&&t0-tod>12)bankInterest();}dayT-=dt;if(dayT<=0){dayT=.25;applyDaylight();}
  if(transFn){transT-=dt;if(transT<=0){const f=transFn;transFn=null;f();$('fade').style.opacity=0;}}
  if(started&&!dead)playerUpdate(dt);else{input.punch=false;input.f=false;input.e=false;}
  for(const c of cars){
    if(c.dead||c===player.car)continue;
    if(c.rampOut&&c.hasDriver&&c.ai!=='parked'&&c.ai!=='wreck'&&rampOutDrive(c,dt))continue;
    if(c.ai==='traffic'||c.ai==='patrol')trafficUpdate(c,dt);
    else if(c.ai==='rejoin')rejoinDrive(c,dt);
    else if(c.ai==='gangRun'||c.ai==='gangWait'||c.ai==='gangBack')gangVanAI(c,dt);
    else if(c.ai==='medRun'||c.ai==='medWait'||c.ai==='medBack')medHeliAI(c,dt);
    else if(c.ai==='bus')busDrive(c,dt);
    else if(c.ai==='taxiRun'||c.ai==='taxiWait'||c.ai==='taxiRide')taxiDrive(c,dt);
    else if(c.ai==='depOut')depotOutDrive(c,dt);
    else if(c.ai==='freight')freightDrive(c,dt);
    else if(c.ai==='lotIn'||c.ai==='lotOut')lotDrive(c,dt);
    else if(c.ai==='chase')chaseDrive(c,dt);
    else if(c.ai==='leave')leaveDrive(c,dt);
    else if(c.ai==='fireRun'||c.ai==='fireWait')fireDrive(c,dt);
    else if(c.ai==='towRun'||c.ai==='towHook'||c.ai==='towBack')towDrive(c,dt);
    else if(c.ai==='towed'){}
    else if(c.ai==='respond'||c.ai==='respondWait'||c.ai==='ambRun'||c.ai==='ambWait')emergDrive(c,dt);
    else driveCar(c,0,0,true,dt);
  }
  for(const c of cars)if(c.ai==='towed'&&!c.dead)placeTowed(c);
  carCollisions();
  for(const c of cars){
    if(c.dead)continue;
    if(c.ai!=='wreck'&&c.health<=0)explode(c);
    else if(c.ai!=='wreck'&&c.health<c.maxHealth*.3){const fire=c.health<c.maxHealth*.15;c.smokeT-=dt;if(c.smokeT<=0){c.smokeT=fire?.08:.22;const f=fwdOf(c);puff(new V3(c.pos.x+f.x*c.half*.7,1.3,c.pos.z+f.z*c.half*.7),fire?0xff7a2a:0x5a5660,rand(.3,.5),new V3(rand(-.4,.4),rand(1.5,2.5),rand(-.4,.4)),rand(.8,1.3),fire);}}
    else if(c.ai==='wreck'&&c.wreckT>0){c.wreckT-=dt;c.smokeT-=dt;if(c.smokeT<=0){c.smokeT=.25;puff(new V3(c.pos.x,1.4,c.pos.z),0x2e2b33,rand(.6,1),new V3(rand(-.3,.3),rand(1.5,2.6),rand(-.3,.3)),rand(1.6,2.4));}}
  }
  for(const p of peds)if(!p.dead)pedUpdate(p,dt);
  updatePickups(dt);
  updateFires(dt);
  updateProjs(dt);
  updateBoats(dt);
  updateFerry(dt);updatePlanes(dt);
  updateJustice(dt);
  for(const k in phoneCD)if(phoneCD[k]>0)phoneCD[k]=Math.max(0,phoneCD[k]-dt);
  if(phoneOpen){phoneT=(phoneT||0)-dt;if(phoneT<=0){phoneT=.5;renderPhone();}}
  updateNav(dt);
  heliUpdate(dt);
  if(started&&!dead)updateSeen(dt);
  manage(dt);
  for(let i=particles.length-1;i>=0;i--){const q=particles[i];q.life-=dt;if(q.life<=0){scene.remove(q.o);q.o.material.dispose();particles.splice(i,1);continue;}
    q.o.position.addScaledVector(q.vel,dt);const k=1-q.life/q.max;q.o.scale.setScalar(q.size*(1+k*q.grow));q.o.material.opacity=(q.o.material.blending===THREE.AdditiveBlending?.9:.55)*(1-k);}
  for(let i=streaks.length-1;i>=0;i--){const S=streaks[i];S.t+=dt;const k=S.t/S.dur;if(k>=1){scene.remove(S.m);streaks.splice(i,1);continue;}S.m.position.lerpVectors?S.m.position.lerpVectors(S.a,S.b,k):S.m.position.copy(S.b);}
  for(let i=flashes.length-1;i>=0;i--){const Fl=flashes[i];Fl.t-=dt;if(Fl.t<=0){scene.remove(Fl.m);flashes.splice(i,1);}}
  for(let i=tracers.length-1;i>=0;i--){const t=tracers[i];t.t-=dt;if(t.t<=0){scene.remove(t.l);t.l.geometry.dispose();t.l.material.dispose();tracers.splice(i,1);}}
  for(let i=cars.length-1;i>=0;i--)if(cars[i].dead){scene.remove(cars[i].mesh);scene.remove(cars[i].shadow);cars.splice(i,1);}
  for(let i=peds.length-1;i>=0;i--)if(peds[i].dead){scene.remove(peds[i].body.g);scene.remove(peds[i].shadow);peds.splice(i,1);}
  beaconMat.color.setHex(Math.floor(clock*1.25)%2?0x2a0306:0xff2030);
  syncMeshes(dt);
  updateCamera(dt);
  scene.userData.sky.position.copy(camera.position);
  if(SKY.sunDir){const sd=SKY.sunDir;sun.position.set(camera.position.x+sd.x*150,camera.position.y+sd.y*150,camera.position.z+sd.z*150);if(sun.target){sun.target.position.copy(camera.position);sun.target.updateMatrixWorld();}}
  const sg=$('sirenGlow');
  if(wanted.stars>0&&started){const f=Math.floor(clock*3)%2===0;sg.style.opacity=.12;sg.style.background=f?'radial-gradient(ellipse at 0% 0%,rgba(255,59,78,.9),transparent 55%)':'radial-gradient(ellipse at 100% 0%,rgba(63,140,255,.9),transparent 55%)';}else sg.style.opacity=0;
  updateHUD(dt);
  drawMinimap();
  draw(dt);
}
RNG=()=>Math.random(); // world built: normal randomness for the live simulation
requestAnimationFrame(frame);
};
