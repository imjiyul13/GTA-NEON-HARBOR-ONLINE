# 네온 하버 ONLINE (온라인 전용) — 배포 설명서

이 폴더 하나에 **게임 + 멀티플레이 서버**가 모두 들어 있습니다.
Cloudflare Worker 하나로 배포되며, 게임 화면과 서버가 같은 주소를 쓰기 때문에 **주소를 적어 넣을 필요가 없습니다.**
(Durable Objects · SQLite · WebSocket 구성은 그대로, 무료 플랜에서 동작)

> **`wrangler.json` 은 이 묶음에 들어 있지 않고 따로 드린 파일입니다.**
> 압축을 푼 폴더의 **맨 위**(package.json 옆)에 넣어 주세요. 이 파일이 없으면 서버가 실행되지 않고 정적 사이트로만 배포됩니다.

```
neon-harbor/
├─ wrangler.json            ← ★ 따로 받은 파일을 여기에 넣기
├─ package.json
├─ src/index.js             ← 멀티플레이 서버 (Worker + GameRoom Durable Object)
├─ public/                  ← 게임 (index.html · style.css · game.js)
├─ 배포하기(Windows).bat
└─ 배포하기(Mac).command
```

## 방법 1 — 더블클릭 (PC)
1. https://nodejs.org 에서 **LTS** 버전 설치 (한 번만)
2. 따로 받은 `wrangler.json` 을 압축을 푼 폴더 맨 위에 넣은 뒤, **배포하기(Windows).bat** (맥은 **배포하기(Mac).command**) 더블클릭
3. 브라우저가 열리면 Cloudflare 로그인 → **Allow**
4. 창에 나온 `https://neon-harbor.<내이름>.workers.dev` 가 **게임 주소** — 친구에게 보내면 끝

> 맥에서 "확인되지 않은 개발자" 경고가 나오면: 파일을 우클릭 → 열기.
> 처음 배포라면 workers.dev 서브도메인 이름을 정하라고 물어볼 수 있습니다.

## 방법 2 — GitHub (설치 없이)
1. GitHub 에서 새 저장소 → **uploading an existing file** → 압축을 푼 폴더 **안의 내용 전체**와 따로 받은 `wrangler.json` 을 한꺼번에 끌어다 놓기 → Commit
   (`wrangler.json`, `package.json`, `src`, `public` 이 저장소 맨 위에 보여야 합니다)
2. Cloudflare 대시보드 → **Workers & Pages** → **Create** → **Import a repository** → 그 저장소 선택 → **Deploy**
3. 배포가 끝나면 나오는 `https://neon-harbor.<내이름>.workers.dev` 가 게임 주소

## 온라인 전용
방을 만들거나 방 코드로 들어가야만 게임이 시작됩니다(오프라인 혼자 하기 없음). 서버에 연결되지 않으면 로비에 이유가 표시됩니다.

## 확인
- 게임 주소를 열면 로비(닉네임 · 방 만들기 · 방 코드 참가)가 나옵니다.
- `게임주소/api/health` 를 열면 `{"ok":true,...}` 가 나오면 서버도 정상입니다.

## 수정 후 다시 배포
파일을 고친 뒤 방법 1 은 bat/command 파일을 다시 실행, 방법 2 는 GitHub 에 다시 올리면 자동 배포됩니다.
