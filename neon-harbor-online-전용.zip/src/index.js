/**
 * GRAND THEFT ACHOO: GTA 네온 하버 — 온라인 멀티플레이 서버
 *
 * Cloudflare Worker + Durable Object (SQLite 백엔드, WebSocket Hibernation API)
 *
 *  ┌──────────────┐  HTTPS / WSS   ┌──────────────────────┐
 *  │ Cloudflare   │ ─────────────► │ Worker (이 파일)       │
 *  │ Pages (게임)  │                │  POST /api/rooms      │──► GameRoom DO (방 코드 = 이름)
 *  └──────────────┘                │  GET  /api/rooms/:code│        · SQLite: meta, chat
 *                                  │  GET  /ws/:code (WS)  │        · WebSocket 브로드캐스트
 *                                  └──────────────────────┘
 *
 * 방 하나 = Durable Object 인스턴스 하나. 방 코드(예: K7Q2MZ)를 idFromName()에 넣어
 * 항상 같은 인스턴스로 연결된다. 방마다 세션·채팅·점수가 완전히 독립적이다.
 */
import { DurableObject } from "cloudflare:workers";

// ---------------------------------------------------------------- 상수
const CODE_ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"; // 헷갈리는 0/O, 1/I 제외
const CODE_LEN = 6;
const CODE_RE = /^[A-HJ-NP-Z2-9]{6}$/;
const PLAYER_COLORS = ["#37e6ff", "#ff5ab4", "#ffd23d", "#7cff6b", "#b48cff", "#ff8a3d", "#5aa8ff", "#ff4d5e"];
const WEAPONS = new Set(["fist", "pistol", "shotgun", "rifle", "molotov", "rpg"]);
const PROJ_KINDS = new Set(["molotov", "rpg"]);
const MAX_MSG_BYTES = 8 * 1024;
const CHAT_MAX_LEN = 200;
const CHAT_HISTORY = 40;        // 새로 들어온 사람에게 보여 줄 최근 채팅 수
const CHAT_KEEP = 200;          // SQLite에 보관하는 채팅 수
const EMPTY_ROOM_TTL_MS = 15 * 60 * 1000; // 아무도 없는 방은 15분 뒤 삭제
const START_TOD = 18;           // 방이 처음 만들어질 때의 게임 시각(저녁 6시)

// ---------------------------------------------------------------- 유틸
const json = (data, status = 200, headers = {}) =>
  new Response(JSON.stringify(data), { status, headers: { "content-type": "application/json; charset=utf-8", ...headers } });

function randomCode() {
  const buf = new Uint8Array(CODE_LEN);
  crypto.getRandomValues(buf);
  let s = "";
  for (const b of buf) s += CODE_ALPHABET[b % CODE_ALPHABET.length];
  return s;
}

function randomId(len = 10) {
  const buf = new Uint8Array(len);
  crypto.getRandomValues(buf);
  return Array.from(buf, (b) => (b % 36).toString(36)).join("");
}

const num = (v, lim = 20000) => {
  const n = Number(v);
  if (!Number.isFinite(n)) return 0;
  return Math.max(-lim, Math.min(lim, Math.round(n * 100) / 100));
};
const vec3 = (a, lim) => (Array.isArray(a) && a.length >= 3 ? [num(a[0], lim), num(a[1], lim), num(a[2], lim)] : null);
const int = (v, lo, hi) => Math.max(lo, Math.min(hi, Math.round(Number(v) || 0)));

/** 닉네임 정리: 제어문자·꺾쇠 제거, 공백 정리, 최대 16자 */
function cleanName(raw) {
  let s = String(raw ?? "")
    .replace(/[\u0000-\u001f\u007f<>]/g, "")
    .replace(/\s+/g, " ")
    .trim();
  s = Array.from(s).slice(0, 16).join("");
  return s;
}

function cleanChat(raw) {
  let s = String(raw ?? "").replace(/[\u0000-\u0008\u000b-\u001f\u007f]/g, "").replace(/\s+/g, " ").trim();
  return Array.from(s).slice(0, CHAT_MAX_LEN).join("");
}

function allowedOrigin(request, env) {
  const list = String(env.ALLOWED_ORIGINS || "*").split(",").map((s) => s.trim()).filter(Boolean);
  const origin = request.headers.get("Origin");
  if (list.includes("*")) return origin || "*";
  if (!origin) return null; // 브라우저가 아닌 요청은 허용 목록이 있을 때 거절
  if (list.includes(origin)) return origin;
  // 와일드카드 서브도메인: https://*.my-game.pages.dev (Pages 미리보기 배포 대응)
  for (const pat of list) {
    if (!pat.includes("*.")) continue;
    const [scheme, host] = pat.split("://");
    const suffix = host.replace(/^\*\./, ".");
    try {
      const u = new URL(origin);
      if (u.protocol === scheme + ":" && u.hostname.endsWith(suffix)) return origin;
    } catch {}
  }
  return null;
}

function corsHeaders(origin) {
  return {
    "Access-Control-Allow-Origin": origin || "*",
    "Access-Control-Allow-Methods": "GET,POST,OPTIONS",
    "Access-Control-Allow-Headers": "content-type",
    "Access-Control-Max-Age": "86400",
    Vary: "Origin",
  };
}

const roomStub = (env, code) => env.ROOMS.get(env.ROOMS.idFromName(code));

// ---------------------------------------------------------------- Worker 진입점
export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    const origin = allowedOrigin(request, env);
    const cors = corsHeaders(origin);

    if (request.method === "OPTIONS") return new Response(null, { status: 204, headers: cors });
    if (origin === null) return json({ error: "ORIGIN_NOT_ALLOWED" }, 403);

    // 상태 확인
    if (url.pathname === "/" || url.pathname === "/api/health") {
      return json({ ok: true, service: "neon-harbor-mp", time: Date.now() }, 200, cors);
    }

    // 방 만들기
    if (url.pathname === "/api/rooms" && request.method === "POST") {
      let body = {};
      try { body = await request.json(); } catch {}
      const max = int(body.maxPlayers ?? env.MAX_PLAYERS ?? 8, 2, int(env.MAX_PLAYERS ?? 8, 2, 16));
      const pvp = body.pvp !== false;
      for (let attempt = 0; attempt < 8; attempt++) {
        const code = randomCode();
        const res = await roomStub(env, code).init({ code, pvp, max });
        if (res.ok) return json({ code, pvp, max }, 201, cors);
      }
      return json({ error: "ROOM_CODE_EXHAUSTED" }, 503, cors);
    }

    // 방 정보 (참가 전 확인용)
    let m = url.pathname.match(/^\/api\/rooms\/([A-Za-z0-9]{6})$/);
    if (m && request.method === "GET") {
      const code = m[1].toUpperCase();
      if (!CODE_RE.test(code)) return json({ exists: false }, 404, cors);
      const info = await roomStub(env, code).info();
      return json(info, info.exists ? 200 : 404, cors);
    }

    // WebSocket 연결 → 방 Durable Object로 그대로 넘긴다
    m = url.pathname.match(/^\/ws\/([A-Za-z0-9]{6})$/);
    if (m) {
      if (request.headers.get("Upgrade")?.toLowerCase() !== "websocket") {
        return json({ error: "EXPECTED_WEBSOCKET" }, 426, cors);
      }
      const code = m[1].toUpperCase();
      return roomStub(env, code).fetch(request);
    }

    return json({ error: "NOT_FOUND" }, 404, cors);
  },
};

// ---------------------------------------------------------------- 방 Durable Object
/**
 * 한 방의 게임 세션.
 *  - SQLite(meta, chat 테이블)에 방 설정·시드·월드 시계·채팅 기록을 영구 보관
 *  - 플레이어 정보(이름·색·점수)는 WebSocket attachment에 넣어 hibernation에서도 유지
 *  - 위치 같은 고빈도 상태는 메모리(Map)에만 두고 그대로 중계
 */
export class GameRoom extends DurableObject {
  constructor(ctx, env) {
    super(ctx, env);
    this.env = env;
    this.sql = ctx.storage.sql;
    this.states = new Map(); // pid → 마지막 위치 상태 (메모리 전용)
    this.rate = new Map();   // pid → 속도 제한 버킷
    this.meta = null;
    ctx.blockConcurrencyWhile(async () => {
      this.ensureSchema();
      this.meta = this.loadMeta();
    });
    // 클라이언트의 "ping" 문자열에는 Durable Object를 깨우지 않고 "pong"으로 자동 응답 (요금 절약)
    ctx.setWebSocketAutoResponse(new WebSocketRequestResponsePair("ping", "pong"));
  }

  // ---------- SQLite ----------
  ensureSchema() {
    this.sql.exec(`CREATE TABLE IF NOT EXISTS meta (k TEXT PRIMARY KEY, v TEXT NOT NULL)`);
    this.sql.exec(`CREATE TABLE IF NOT EXISTS chat (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      ts INTEGER NOT NULL,
      pid TEXT,
      name TEXT,
      color TEXT,
      text TEXT NOT NULL,
      sys INTEGER NOT NULL DEFAULT 0
    )`);
  }

  loadMeta() {
    const rows = this.sql.exec(`SELECT k, v FROM meta`).toArray();
    if (!rows.length) return null;
    const m = {};
    for (const r of rows) m[r.k] = JSON.parse(r.v);
    return m.code ? m : null;
  }

  saveMeta(patch) {
    for (const [k, v] of Object.entries(patch)) {
      this.sql.exec(`INSERT INTO meta (k, v) VALUES (?, ?) ON CONFLICT(k) DO UPDATE SET v = excluded.v`, k, JSON.stringify(v));
    }
    this.meta = { ...(this.meta || {}), ...patch };
  }

  addChat({ pid = null, name = null, color = null, text, sys = 0 }) {
    const ts = Date.now();
    this.sql.exec(`INSERT INTO chat (ts, pid, name, color, text, sys) VALUES (?, ?, ?, ?, ?, ?)`, ts, pid, name, color, text, sys);
    this.sql.exec(`DELETE FROM chat WHERE id <= (SELECT MAX(id) FROM chat) - ?`, CHAT_KEEP);
    return { t: "chat", id: pid, name, color, text, sys: !!sys, ts };
  }

  recentChat() {
    return this.sql
      .exec(`SELECT ts, pid, name, color, text, sys FROM chat ORDER BY id DESC LIMIT ?`, CHAT_HISTORY)
      .toArray()
      .reverse()
      .map((r) => ({ t: "chat", id: r.pid, name: r.name, color: r.color, text: r.text, sys: !!r.sys, ts: r.ts }));
  }

  // ---------- RPC (Worker에서 호출) ----------
  async init({ code, pvp, max }) {
    this.ensureSchema();
    if (this.meta) return { ok: false, reason: "EXISTS" };
    const seed = (crypto.getRandomValues(new Uint32Array(1))[0] >>> 0) || 1;
    this.saveMeta({ code, pvp: !!pvp, max, seed, tod0: START_TOD, t0: Date.now(), created: Date.now() });
    this.addChat({ text: `방 ${code}이(가) 만들어졌습니다. PvP ${pvp ? "켜짐" : "꺼짐"} · 최대 ${max}명`, sys: 1 });
    await this.ctx.storage.setAlarm(Date.now() + EMPTY_ROOM_TTL_MS); // 아무도 안 들어오면 정리
    return { ok: true };
  }

  async info() {
    if (!this.meta) return { exists: false };
    return { exists: true, code: this.meta.code, players: this.roster().length, max: this.meta.max, pvp: this.meta.pvp };
  }

  // ---------- 접속자 ----------
  sockets() {
    return this.ctx.getWebSockets().filter((ws) => {
      const a = ws.deserializeAttachment();
      return a && !a.replaced && !a.left && ws.readyState === 1;
    });
  }

  roster(except) {
    const list = [];
    for (const ws of this.sockets()) {
      if (ws === except) continue;
      list.push(ws.deserializeAttachment());
    }
    list.sort((a, b) => a.joinedAt - b.joinedAt);
    return list;
  }

  hostId(except) {
    const r = this.roster(except);
    return r.length ? r[0].pid : null;
  }

  publicPlayer(a, host) {
    return { id: a.pid, name: a.name, color: a.color, kills: a.kills, deaths: a.deaths, host: a.pid === host, joinedAt: a.joinedAt };
  }

  broadcast(msg, except) {
    const data = typeof msg === "string" ? msg : JSON.stringify(msg);
    for (const ws of this.sockets()) {
      if (ws === except) continue;
      try { ws.send(data); } catch {}
    }
  }

  sendRoster(except) {
    const host = this.hostId(except);
    this.broadcast({ t: "roster", host, pvp: this.meta.pvp, max: this.meta.max, players: this.roster(except).map((a) => this.publicPlayer(a, host)) }, except);
  }

  findSocket(pid) {
    return this.sockets().find((ws) => ws.deserializeAttachment().pid === pid) || null;
  }

  // ---------- WebSocket 연결 ----------
  async fetch(request) {
    const url = new URL(request.url);
    const pair = new WebSocketPair();
    const [client, server] = Object.values(pair);

    const reject = (code, reason, error) => {
      server.accept();
      server.send(JSON.stringify({ t: "error", code: error, message: reason }));
      server.close(code, reason);
      return new Response(null, { status: 101, webSocket: client });
    };

    if (!this.meta) return reject(4004, "room not found", "NO_ROOM");

    let pid = String(url.searchParams.get("pid") || "").replace(/[^a-z0-9]/gi, "").slice(0, 24);
    if (pid.length < 6) pid = randomId();

    // 같은 pid가 다시 접속하면(새로고침·재연결) 예전 소켓을 정리하고 점수를 이어받는다
    let carried = null;
    for (const ws of this.ctx.getWebSockets()) {
      const a = ws.deserializeAttachment();
      if (a && a.pid === pid && !a.replaced) {
        carried = a;
        ws.serializeAttachment({ ...a, replaced: true });
        try { ws.close(4001, "replaced by new connection"); } catch {}
      }
    }

    const current = this.roster();
    if (!carried && current.length >= this.meta.max) return reject(4003, "room is full", "ROOM_FULL");

    // 닉네임: 비었으면 기본값, 겹치면 #2, #3…
    let base = cleanName(url.searchParams.get("name")) || `플레이어${current.length + 1}`;
    let name = base;
    const taken = new Set(current.map((a) => a.name));
    for (let i = 2; taken.has(name); i++) name = `${Array.from(base).slice(0, 13).join("")}#${i}`;

    const usedColors = new Set(current.map((a) => a.color));
    const color = carried?.color || PLAYER_COLORS.find((c) => !usedColors.has(c)) || PLAYER_COLORS[current.length % PLAYER_COLORS.length];

    const att = {
      pid,
      name,
      color,
      kills: carried?.kills || 0,
      deaths: carried?.deaths || 0,
      joinedAt: carried?.joinedAt || Date.now(),
    };

    // Hibernation API: Durable Object가 잠들어도 연결은 유지된다
    this.ctx.acceptWebSocket(server, [pid]);
    server.serializeAttachment(att);
    await this.ctx.storage.deleteAlarm();

    const host = this.hostId();
    const players = this.roster().map((a) => ({ ...this.publicPlayer(a, host), state: this.states.get(a.pid) || null }));
    server.send(JSON.stringify({
      t: "welcome",
      you: { id: pid, name, color },
      room: { code: this.meta.code, seed: this.meta.seed, pvp: this.meta.pvp, max: this.meta.max, tod0: this.meta.tod0, t0: this.meta.t0, host },
      now: Date.now(),
      players,
      chat: this.recentChat(),
    }));

    if (!carried) {
      this.broadcast({ t: "join", player: this.publicPlayer(att, host) }, server);
      this.broadcast(this.addChat({ text: `${name} 님이 도시에 들어왔습니다.`, sys: 1 }));
    }
    this.sendRoster();

    return new Response(null, { status: 101, webSocket: client });
  }

  // ---------- 속도 제한 (토큰 버킷) ----------
  allow(pid, kind, perSec, burst) {
    const now = Date.now();
    let r = this.rate.get(pid);
    if (!r) this.rate.set(pid, (r = {}));
    let b = r[kind];
    if (!b) b = r[kind] = { tokens: burst, at: now };
    b.tokens = Math.min(burst, b.tokens + ((now - b.at) / 1000) * perSec);
    b.at = now;
    if (b.tokens < 1) return false;
    b.tokens -= 1;
    return true;
  }

  // ---------- 메시지 처리 ----------
  async webSocketMessage(ws, raw) {
    if (typeof raw !== "string" || raw.length > MAX_MSG_BYTES) return;
    let msg;
    try { msg = JSON.parse(raw); } catch { return; }
    if (!msg || typeof msg !== "object") return;
    const me = ws.deserializeAttachment();
    if (!me || me.replaced || !this.meta) return;
    const pid = me.pid;

    switch (msg.t) {
      // 위치·자세·차량 상태 (초당 최대 ~15회)
      case "s": {
        if (!this.allow(pid, "s", 15, 20)) return;
        const st = { t: "s", id: pid, p: vec3(msg.p) || [0, 0, 0], y: num(msg.y, 100), pi: num(msg.pi, 10),
          w: WEAPONS.has(msg.w) ? msg.w : "fist", h: int(msg.h, 0, 100), f: int(msg.f, 0, 1023), ws: int(msg.ws, 0, 5), c: 0 };
        if (msg.c && typeof msg.c === "object") {
          st.c = {
            k: String(msg.c.k || "civ").replace(/[^a-z]/g, "").slice(0, 12),
            m: msg.c.m ? String(msg.c.m).replace(/[^a-z]/g, "").slice(0, 12) : null,
            col: int(msg.c.col, 0, 0xffffff),
            p: vec3(msg.c.p) || st.p,
            r: vec3(msg.c.r, 100) || [0, 0, 0],
          };
        }
        this.states.set(pid, st);
        this.broadcast(st, ws);
        return;
      }

      // 총 쏘기 (다른 화면에 총알 궤적·총구 화염 표시)
      case "shot": {
        if (!this.allow(pid, "fx", 20, 30)) return;
        const e = Array.isArray(msg.e) ? msg.e.slice(0, 8).map((v) => vec3(v)).filter(Boolean) : [];
        this.broadcast({ t: "shot", id: pid, w: WEAPONS.has(msg.w) ? msg.w : "pistol", m: vec3(msg.m) || [0, 0, 0], e }, ws);
        return;
      }

      // 화염병·RPG 발사체
      case "proj": {
        if (!this.allow(pid, "fx", 20, 30)) return;
        if (!PROJ_KINDS.has(msg.k)) return;
        this.broadcast({ t: "proj", id: pid, k: msg.k, p: vec3(msg.p), v: vec3(msg.v, 200) }, ws);
        return;
      }

      // 다른 플레이어를 맞힘 → 맞은 사람에게만 전달 (PvP가 켜진 방만)
      case "hit": {
        if (!this.meta.pvp) return;
        if (!this.allow(pid, "hit", 25, 40)) return;
        const to = String(msg.to || "");
        if (to === pid) return;
        const target = this.findSocket(to);
        if (!target) return;
        try { target.send(JSON.stringify({ t: "hit", from: pid, name: me.name, dmg: int(msg.dmg, 0, 300), w: WEAPONS.has(msg.w) ? msg.w : "pistol" })); } catch {}
        return;
      }

      // 내가 쓰러짐 → 점수 기록 + 처치 알림
      case "died": {
        if (!this.allow(pid, "died", 0.5, 2)) return;
        me.deaths++;
        ws.serializeAttachment(me);
        let killer = null;
        if (msg.by && msg.by !== pid) {
          const kws = this.findSocket(String(msg.by));
          if (kws) {
            killer = kws.deserializeAttachment();
            killer.kills++;
            kws.serializeAttachment(killer);
          }
        }
        const text = killer ? `${killer.name} ▸ ${me.name} 처치` : `${me.name} 님이 쓰러졌습니다.`;
        this.broadcast({ t: "kill", killer: killer?.pid || null, victim: pid });
        this.broadcast(this.addChat({ text, sys: 1 }));
        this.sendRoster();
        return;
      }

      // 채팅
      case "chat": {
        const text = cleanChat(msg.text);
        if (!text) return;
        if (!this.allow(pid, "chat", 1, 5)) {
          try { ws.send(JSON.stringify({ t: "notice", text: "채팅을 너무 빨리 보내고 있어요. 잠시 후 다시 보내 주세요." })); } catch {}
          return;
        }
        if (text.startsWith("/")) return this.command(ws, me, text);
        this.broadcast(this.addChat({ pid, name: me.name, color: me.color, text }));
        return;
      }
    }
  }

  // ---------- 채팅 명령어 ----------
  command(ws, me, text) {
    const [cmd, ...rest] = text.slice(1).split(" ");
    const arg = rest.join(" ").trim();
    const notice = (t) => { try { ws.send(JSON.stringify({ t: "notice", text: t })); } catch {} };
    const isHost = this.hostId() === me.pid;

    switch (cmd.toLowerCase()) {
      case "help":
      case "도움말":
        return notice("명령어: /pvp on|off (방장) · /nick 새닉네임 · /who · /help");
      case "who":
        return notice("접속자: " + this.roster().map((a) => a.name).join(", "));
      case "pvp": {
        if (!isHost) return notice("PvP 설정은 방장만 바꿀 수 있어요.");
        const on = arg === "on" || arg === "켜기";
        const off = arg === "off" || arg === "끄기";
        if (!on && !off) return notice(`지금 PvP는 ${this.meta.pvp ? "켜짐" : "꺼짐"} 상태예요. /pvp on 또는 /pvp off`);
        this.saveMeta({ pvp: on });
        this.broadcast(this.addChat({ text: `방장이 PvP를 ${on ? "켰습니다" : "껐습니다"}.`, sys: 1 }));
        this.sendRoster();
        return;
      }
      case "nick":
      case "닉네임": {
        const name = cleanName(arg);
        if (!name) return notice("사용법: /nick 새닉네임 (최대 16자)");
        if (this.roster().some((a) => a.name === name && a.pid !== me.pid)) return notice("이미 쓰고 있는 닉네임이에요.");
        const old = me.name;
        me.name = name;
        ws.serializeAttachment(me);
        try { ws.send(JSON.stringify({ t: "renamed", name })); } catch {}
        this.broadcast(this.addChat({ text: `${old} 님이 닉네임을 ${name}(으)로 바꿨습니다.`, sys: 1 }));
        this.sendRoster();
        return;
      }
      default:
        return notice(`알 수 없는 명령어: /${cmd} · /help 로 목록 보기`);
    }
  }

  // ---------- 연결 종료 ----------
  async webSocketClose(ws, code, reason) {
    await this.handleLeave(ws);
    try { ws.close(code === 1005 || code === 1006 ? 1000 : code, "bye"); } catch {}
  }

  async webSocketError(ws) {
    await this.handleLeave(ws);
  }

  async handleLeave(ws) {
    const a = ws.deserializeAttachment();
    if (!a || a.replaced || a.left) return;
    ws.serializeAttachment({ ...a, left: true });
    this.states.delete(a.pid);
    this.rate.delete(a.pid);
    if (!this.meta) return;
    this.broadcast({ t: "leave", id: a.pid }, ws);
    this.broadcast(this.addChat({ text: `${a.name} 님이 나갔습니다.`, sys: 1 }), ws);
    this.sendRoster(ws);
    if (this.roster(ws).length === 0) await this.ctx.storage.setAlarm(Date.now() + EMPTY_ROOM_TTL_MS);
  }

  // ---------- 빈 방 정리 ----------
  async alarm() {
    if (this.sockets().length > 0) return;
    await this.ctx.storage.deleteAll(); // SQLite 테이블까지 모두 삭제 → 방 코드 재사용 가능
    this.meta = null;
    this.states.clear();
  }
}
