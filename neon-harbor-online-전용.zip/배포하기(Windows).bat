@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo [네온 하버] Cloudflare 배포를 시작합니다.
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js 가 설치되어 있지 않습니다. 열리는 페이지에서 LTS 버전을 설치한 뒤 이 파일을 다시 실행하세요.
  start https://nodejs.org
  pause
  exit /b
)
if not exist wrangler.json (
  echo wrangler.json 파일이 없습니다. 따로 받은 wrangler.json 을 이 폴더에 넣고 다시 실행하세요.
  pause
  exit /b
)
call npm install
echo 브라우저가 열리면 Cloudflare 에 로그인하고 [Allow] 를 누르세요.
call npx wrangler login
call npx wrangler deploy
echo.
echo 위에 나온 https://neon-harbor.....workers.dev 주소가 게임 주소입니다.
pause
