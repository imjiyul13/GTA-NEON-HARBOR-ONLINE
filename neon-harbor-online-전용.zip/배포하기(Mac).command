#!/bin/bash
cd "$(dirname "$0")"
echo "[네온 하버] Cloudflare 배포를 시작합니다."
if ! command -v node >/dev/null 2>&1; then
  echo "Node.js 가 설치되어 있지 않습니다. 열리는 페이지에서 LTS 버전을 설치한 뒤 다시 실행하세요."
  open https://nodejs.org; read -p "Enter 를 누르면 닫힙니다"; exit 1
fi
if [ ! -f wrangler.json ]; then echo "wrangler.json 파일이 없습니다. 따로 받은 wrangler.json 을 이 폴더에 넣고 다시 실행하세요."; read -p "Enter"; exit 1; fi
npm install
echo "브라우저가 열리면 Cloudflare 에 로그인하고 [Allow] 를 누르세요."
npx wrangler login
npx wrangler deploy
echo; echo "위에 나온 https://neon-harbor.....workers.dev 주소가 게임 주소입니다."
read -p "Enter 를 누르면 닫힙니다"
